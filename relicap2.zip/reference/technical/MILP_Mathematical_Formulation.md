# RAO MILP Formulation: Mathematical Reference

**Purpose of this document:** the complete mathematical formulation of the MILP
solved by this pipeline — sets, parameters, decision variables, constraints, and
objective function. Self-contained and descriptive of structure only: this
document does not describe how any parameter's value is computed upstream (that
lives in the data-ingestion and sensitivity-computation reference material), nor
does it describe the iterative solution procedure the pipeline wraps around this
model (the linearisation loop, the completeness loop; see
`AC_Verification_Loop_Technical_Reference.md`). This document is a
snapshot of one MILP instance's mathematical structure. Sections 1–6 describe the
first solve (operating point = original network). **Section 7 gives the cumulative
form the same model takes in every later solve of the iterative loop.**

**Scope:** covers everything the model can contain based on R0–R3 of the release
plan — N-0 preventive PST and RD remedial actions, N-X security constraints,
curative PST and RD remedial actions, and scanned-element handling at both N-0
and N-X. Multi-timestamp generalisation (R4) and generator physics (R5) are out
of scope for this document; every quantity below is implicitly for a single,
fixed timestamp. HVDC, countertrade, and system constraints (R6) are out of
scope; R3.7's own system-constraint extension is deferred pending R6 and is not
part of the model this document describes.

**Composability:** every variable and constraint family below is conditionally
present. A workflow with PST disabled contains none of the PST-indexed
variables or constraints; a workflow with RD disabled contains none of the
RD-indexed ones. N-X, curative, and scanned-element components are each
present only if their respective inputs are provided. The model is never
"all of the below at once" except in the maximal case where every RA type and
every feature is active simultaneously.

---

## 1. Sets and Indices

| Symbol | Description |
|---|---|
| $\tau \in T$ | Available preventive PSTs |
| $\tau \in T^{cur}$ | PSTs with at least one curative-eligible (PST, contingency) pairing. Built from the PSTs' *curative* RAs only; $T$ and $T^{cur}$ are separate sets and a transformer with both a preventive and a curative RA appears in both, with separate variables and separate penalty values. A curative-only PST is in $T^{cur}$ but not in $T$. |
| $g \in G$ | Generating units reachable through at least one RD bid's GLSK participation |
| $d \in D$ | Power bids (redispatch), each one-directional (upward or downward) |
| $d \in D^{cur}$ | Curative power bids, $D^{cur}$ disjoint from $D$ (preventive) |
| $r \in R$ | Redispatch remedial actions (RAs); each RA links to one or more bids $d \in D$ |
| $k \in K$ | TSOs |
| $b \in B^{sec}$ | Secured branches (XNEs) |
| $b \in B^{scan}$ | Scanned branches (SNEs), $B^{scan}$ disjoint from $B^{sec}$ |
| $c \in C$ | Contingencies with `mustStudy = True` at the current timestamp |
| $(b,c) \in P^{sec}_{PATL}$ | Candidate (secured branch, contingency) pairs surviving N-X Filter 1/2 for PATL |
| $(b,c) \in P^{sec}_{TATL} \subseteq P^{sec}_{PATL}$ | Candidate pairs where $b$ additionally has a defined TATL |
| $(b,c) \in P^{scan}$ | Candidate (scanned branch, contingency) pairs surviving N-X Filter 1/2 |
| $(\tau,b,c) \in L^{cra}_{PST}$ | (PST, XNE, contingency) triples where curative PST availability is confirmed (`pst_cra_availability`) |
| $(d,c) \in L^{cra}_{RD}$ | (curative bid, contingency) pairs where the linked generating unit is in operation |
| $\pi \in \Pi$ | Preventive PST group-equality pairs, $\pi = (\tau_1, \tau_2)$, built from $T$ only |
| $\pi \in \Pi^{cur}_c$ | Curative PST group-equality pairs for contingency $c$, built from $T^{cur}$ only (all unique pairs of each group's members that are available in $c$) |
| $\gamma \in \Gamma$ | Restrictive RA groups (volume-limited bid sets) |

---

## 2. Parameters

### PST

| Symbol | Description |
|---|---|
| $r^0_\tau$ | Current tap position of PST $\tau$ |
| $r^{min}_\tau, r^{max}_\tau$ | Effective preventive tap bounds (online > offline > IGM priority, relative-limit narrowed) |
| $r^{cur,min}_\tau, r^{cur,max}_\tau$ | Effective curative tap bounds |
| $M^{cur}_{\tau,b}$ | Maximum curative tap movement for PST $\tau$ relative to XNE $b$'s TATL duration |
| $S^{PST}_{b,\tau}$ | N-0 sensitivity of branch $b$'s current to PST $\tau$'s tap (A/tap, post degrees-per-tap conversion) |
| $S^{PST,c}_{b,\tau}$ | N-X sensitivity of branch $b$'s current under contingency $c$ to PST $\tau$'s tap |
| $\phi_\tau$ | PST penalty factor |
| $\rho^{PST}$ | Penalty reference cost, PST preventive (EUR/tap), optionally TSO-specific |

### RD

| Symbol | Description |
|---|---|
| $p^0_g$ | Current active power output of generating unit $g$ (`target_p`) |
| $p^{min}_g, p^{max}_g$ | Active power bounds of generating unit $g$ |
| $\alpha_{g,d}$ | GLSK participation factor of unit $g$ in bid $d$'s remedial action |
| $v^{max}_d$ | Maximum available volume of bid $d$ (MW) |
| $v^{max,cur}_d$ | Maximum available curative volume of bid $d \in D^{cur}$ |
| $S^{RD}_{b,g}$ | N-0 sensitivity of branch $b$'s current to unit $g$'s injection (A/MW) |
| $S^{RD,c}_{b,g}$ | N-X sensitivity of branch $b$'s current under contingency $c$ to unit $g$'s injection |
| $\phi_d$ | Bid penalty factor |
| $\pi^{price+}_d, \pi^{price-}_d$ | Upward/downward price of bid $d$ (EUR/MW) |
| $\rho^{RD}$ | Penalty reference cost, RD preventive (EUR/MW), optionally TSO-specific |
| $M$ | Big-M constant for RA activation linking |
| $N^{ts}_k, N^{tf}_k$ | Maximum activated RA count for TSO $k$, per-timestamp and per-timeframe |
| $\rho^{cnt}$ | RA-count-limit penalty (EUR per RA over the limit, when soft) |
| $V^{up}_\gamma, V^{down}_\gamma$ | Maximum regulating-up/-down volume for RA group $\gamma$ |
| $t^{lead}_d$ | Lead time of bid $d$ (hours from RA Deciding Point) |

### Branch limits and sensitivities (N-0 and N-X, both AE types)

| Symbol | Description |
|---|---|
| $I^0_b$ | Initial (pre-RA) current of branch $b$, N-0 |
| $I^{0,c}_b$ | Initial (pre-RA) current of branch $b$ under contingency $c$, N-X |
| $PATL_b$ | Permanently Admissible Transmission Loading of secured branch $b \in B^{sec}$ |
| $TATL_b$ | Temporarily Admissible Transmission Loading of secured branch $b$, where defined |
| $L^{eff}_b$ | Effective limit of scanned branch $b \in B^{scan}$ ($\max(PATL_b \cdot (1+m_b/100),\ I^0_b)$, supplied as a parameter to this model) |

### Cost / penalty references

| Symbol | Description |
|---|---|
| $c^{ovl}_{N0,sec}$ | Overload penalty cost, N-0, secured branches (EUR/A) |
| $c^{ovl}_{N0,scan}$ | Overload penalty cost, N-0, scanned branches (EUR/A), used only if the N-0 scanned constraint is configured soft |
| $c^{ovl}_{NX,PATL}$ | Overload penalty cost, N-X, secured PATL (EUR/A) |
| $c^{ovl}_{NX,TATL}$ | Overload penalty cost, N-X, secured TATL (EUR/A), typically $> c^{ovl}_{NX,PATL}$ |
| $c^{ovl}_{NX,scan}$ | Overload penalty cost, N-X, scanned branches (EUR/A) |

### Curative-specific

| Symbol | Description |
|---|---|
| $\rho^{PST,cur}$ | Penalty reference for curative PST. **No separate parameter:** equals $\rho^{PST}$ (`penalty_reference_pst_pra`, optional per-TSO override). The curative PST penalty value per tap is $\phi^{cur}_\tau \cdot \rho^{PST}$, where $\phi^{cur}_\tau$ is the penalty factor of the PST's *curative* RA. |
| $\rho^{RD,cur}$ | Penalty reference for curative RD. **No separate parameter:** equals $\rho^{RD}$ (`penalty_reference_rd_pra`, optional per-TSO override). |
| $\pi^{price}_d$ | Energy price of bid $d$ (EUR/MW); used in the curative RD term (deviation from spec, see §4) |
| $\kappa_k \in \{\text{reduced},\text{blocked}\}$ | PST group kind per TSO $k$ (`curative_ra.pst_group_kind_default`, default blocked; optional per-TSO map) |
| $\ell_{\tau,b} \in \{0,1\}$ | CRA–XNE linkage indicator (only meaningful when `activate_cra_xne_linkage` is enabled) |

---

## 3. Decision Variables

### PST — preventive

| Symbol | Domain | Description |
|---|---|---|
| $\Delta r^+_\tau,\ \Delta r^-_\tau$ | $\mathbb{Z}_{\geq 0}$ or $\mathbb{R}_{\geq 0}$ | Upward / downward preventive tap change, PST $\tau$. Integer when `pst_taping_discrete = True` (default), continuous otherwise. |

### PST — curative

| Symbol | Domain | Description |
|---|---|---|
| $\Delta r^{cur+}_{\tau,c},\ \Delta r^{cur-}_{\tau,c}$ | $\mathbb{R}_{\geq 0}$ (continuous, not integer) | Upward / downward curative tap change, PST $\tau$, contingency $c$. Defined only for $(\tau,\cdot,c)$ with at least one linked $(τ,b,c) \in L^{cra}_{PST}$. One pair per (PST, contingency); the TATL duration enters through the cap $M^{cur}_{\tau,b}$, not through a variable index. |

### RD — preventive

| Symbol | Domain | Description |
|---|---|---|
| $v^+_d,\ v^-_d$ | $\mathbb{R}_{\geq 0}$ | Upward / downward preventive volume of bid $d$. Only one of the pair is unbounded above (the bid's own direction); the other is fixed at 0. |
| $y_r$ | $\{0,1\}$ | RA $r$ activation indicator |

### RD — curative

| Symbol | Domain | Description |
|---|---|---|
| $v^{cur+}_{d,c},\ v^{cur-}_{d,c}$ | $\mathbb{R}_{\geq 0}$ | Upward / downward curative volume of bid $d \in D^{cur}$, contingency $c$. Defined only for $(d,c) \in L^{cra}_{RD}$. |
| $\bar v^{cur+}_d,\ \bar v^{cur-}_d$ | $\mathbb{R}_{\geq 0}$ | Auxiliary maxima over contingencies of the curative volumes of bid $d$, up and down separately (spec eq. 3.42–3.43) |

### Slack (all continuous, $\geq 0$)

| Symbol | Description |
|---|---|
| $s^{N0}_{sec,b}$ | N-0 overload slack, secured branch $b$ |
| $s^{N0}_{scan,b}$ | N-0 overload slack, scanned branch $b$ (present only when the N-0 scanned constraint is configured soft) |
| $s^{NX}_{PATL,b,c}$ | N-X overload slack, secured branch $b$, contingency $c$, PATL |
| $s^{NX}_{TATL,b,c}$ | N-X overload slack, secured branch $b$, contingency $c$, TATL — defined only for $(b,c) \in P^{sec}_{TATL}$ |
| $s^{NX}_{scan,b,c}$ | N-X overload slack, scanned branch $b$, contingency $c$ |
| $s^{cnt,ts}_k,\ s^{cnt,tf}_k$ | RA-count-limit slack, TSO $k$, per-timestamp / per-timeframe (present only when the corresponding limit is configured soft) |

### Derived quantities (Expressions, not independent decision variables)

$$
\Delta p_g \;=\; \sum_{d \in D} \alpha_{g,d} \cdot (v^+_d - v^-_d)
\qquad \forall g \in G
$$

$$
\Delta p^{cur}_{g,c} \;=\; \sum_{d \in D^{cur}} \alpha_{g,d} \cdot (v^{cur+}_{d,c} - v^{cur-}_{d,c})
\qquad \forall g \in G,\ c \in C
$$

---

## 4. Objective Function

Minimise the sum of every applicable term below. A term is included only if
the corresponding variable family exists on the model (composability — see
§1); an excluded term is treated as identically zero, not omitted from the
sum's meaning.

$$
\min\ Z \;=\;
\underbrace{\sum_{\tau \in T} \phi_\tau \cdot \rho^{PST} \cdot (\Delta r^+_\tau + \Delta r^-_\tau)}_{\text{PST preventive penalty}}
\;+\;
\underbrace{\sum_{d \in D} \Big[(\phi_d \rho^{RD} + \pi^{price+}_d)\, v^+_d + (\phi_d \rho^{RD} + \pi^{price-}_d)\, v^-_d\Big]}_{\text{RD preventive penalty + price}}
$$

$$
+\ \underbrace{\sum_{(\tau,c)} \phi^{cur}_\tau \cdot \rho^{PST} \cdot \big(\Delta r^{cur+}_{\tau,c} + \Delta r^{cur-}_{\tau,c}\big)}_{\text{PST curative penalty (sum over contingencies, spec eq. 3.47)}}
$$

$$
+\ \underbrace{\sum_{d \in D^{cur}_{up}} (\phi_d \rho^{RD} + \pi^{price}_d)\,\bar v^{cur+}_d
\;+\; \sum_{d \in D^{cur}_{down}} (\phi_d \rho^{RD} + \pi^{price}_d)\,\bar v^{cur-}_d}_{\text{RD curative (max over contingencies, up and down bids separate)}}
$$

$$
+\ \underbrace{c^{ovl}_{N0,sec} \sum_{b \in B^{sec}} s^{N0}_{sec,b}}_{\text{N-0 PATL slack}}
\;+\;
\underbrace{c^{ovl}_{N0,scan} \sum_{b \in B^{scan}} s^{N0}_{scan,b}}_{\text{N-0 scanned slack (if soft)}}
$$

$$
+\ \underbrace{c^{ovl}_{NX,PATL} \sum_{(b,c) \in P^{sec}_{PATL}} s^{NX}_{PATL,b,c}}_{\text{N-X PATL slack}}
\;+\;
\underbrace{c^{ovl}_{NX,TATL} \sum_{(b,c) \in P^{sec}_{TATL}} s^{NX}_{TATL,b,c}}_{\text{N-X TATL slack}}
\;+\;
\underbrace{c^{ovl}_{NX,scan} \sum_{(b,c) \in P^{scan}} s^{NX}_{scan,b,c}}_{\text{N-X scanned slack}}
$$

$$
+\ \underbrace{\rho^{cnt} \sum_{k \in K} \big(s^{cnt,ts}_k + s^{cnt,tf}_k\big)}_{\text{RA-count-limit slack (if soft)}}
$$

**Curative PST** is priced per tap, summed over every (PST, contingency) pair
(spec SF3077 eq. 3.47–3.48, CORNET-1982). There is **no max construction** for PST:
the max is only an "Outlook" item for a future release in the spec. The penalty
value uses the penalty factor of the PST's own curative RA times the existing
$\rho^{PST}$; no separate curative reference exists. (Before the correction
described in R3's implementation notes, curative taps carried no cost at all.)

**Curative RD** uses a maximum-over-contingencies construction per bid, with
upward and downward handled separately: $\bar v^{cur+}_d \geq v^{cur+}_{d,c}$ and
$\bar v^{cur-}_d \geq v^{cur-}_{d,c}$ for every $c$ (spec SF3077 eq. 3.42–3.43).
Each bid is one-directional, so an up bid contributes only through $\bar v^{cur+}$
and a down bid only through $\bar v^{cur-}$, each with its own price.

**Documented deviation from the spec (curative RD):** the spec's curative term
(eq. 3.40, BUC 14#43) uses the *reservation cost* (`reservePriceCRA`) and states
that the bid's energy price is not considered. This model keeps the bid energy
price $\pi^{price}_d$ instead, by project decision. No reservation cost is parsed
and none exists in the datasets.

---

## 5. Constraints

Organised by remedial-action (RA) type. Under each RA type: first the **N-0 constraints**, then the **N-X constraints**. The branch **flow constraints** (which combine all RA types in one inequality) come last, in §5.5, N-0 first and then N-X. Each RA section states which term it contributes to the flow constraints.

| Section | Content |
|---|---|
| 5.1 | PST preventive — N-0, then N-X |
| 5.2 | PST curative — N-0, then N-X |
| 5.3 | RD preventive — N-0, then N-X |
| 5.4 | RD curative — N-0, then N-X |
| 5.5 | Flow constraints — N-0 (secured, scanned), then N-X (PATL, TATL, scanned) |

---

### 5.1 PST preventive

*(Over preventive PSTs $T$ only: a PST that has only a curative RA gets no preventive variables.)*

#### 5.1.1 N-0 constraints

**Tap bounds**

$$
r^{min}_\tau \;\leq\; r^0_\tau + \Delta r^+_\tau - \Delta r^-_\tau \;\leq\; r^{max}_\tau
\qquad \forall \tau \in T
$$

**Group equality**

$$
r^0_{\tau_1} + \Delta r^+_{\tau_1} - \Delta r^-_{\tau_1}
\;=\;
r^0_{\tau_2} + \Delta r^+_{\tau_2} - \Delta r^-_{\tau_2}
\qquad \forall (\tau_1,\tau_2) \in \Pi
$$

*(On the confirmed real dataset, $\Pi = \emptyset$ — no NCP-declared PST groups exist; this family is structurally present but currently vacuous.)*

**Tap-change limit per TSO** (CORNET-3653 / 3654, collapsed to one constraint at a single timestamp; hard, no slack; $L_k$ = `max_taps_per_tso`, default 6, optional per-TSO override)

$$
\sum_{\tau \in T_k} \left(\Delta r^+_\tau + \Delta r^-_\tau\right) \;\leq\; L_k
\qquad \forall k \in K
$$

*(In later solves of the loop this limit applies to the cumulative movement; see §7.3.)*

**Contribution to the flow constraints:** the term $\sum_\tau S^{PST}_{b,\tau}(\Delta r^+_\tau - \Delta r^-_\tau)$ in §5.5.1.

#### 5.1.2 N-X constraints

No PST-preventive constraint exists that is specific to a contingency: the preventive tap is one decision for all contingencies. Its effect under contingency $c$ enters only through the term $\sum_\tau S^{PST,c}_{b,\tau}(\Delta r^+_\tau - \Delta r^-_\tau)$ in §5.5.2 (PATL, TATL and scanned).

---

### 5.2 PST curative

#### 5.2.1 N-0 constraints

None. A curative PST action exists only conditional on a contingency.

#### 5.2.2 N-X constraints

**Curative tap bounds (combined with the preventive tap) and movement cap**

$$
r^{cur,min}_\tau
\;\leq\;
r^0_\tau + \Delta r^+_\tau - \Delta r^-_\tau + \Delta r^{cur+}_{\tau,c} - \Delta r^{cur-}_{\tau,c}
\;\leq\;
r^{cur,max}_\tau
\qquad \forall (\tau,\cdot,c) \text{ with at least one } (\tau,b,c) \in L^{cra}_{PST}
$$

$$
\Delta r^{cur+}_{\tau,c} + \Delta r^{cur-}_{\tau,c} \;\leq\; M^{cur}_{\tau,b}
\qquad \forall (\tau,b,c) \in L^{cra}_{PST}
$$

*(Curative tap bounds $r^{cur,min}_\tau, r^{cur,max}_\tau$: an explicit curative range from the data when present, otherwise the PST's own operating tap range. The fallback is built from the curative PSTs only, so a preventive RA on the same transformer with a different range cannot override it. No dataset currently carries an explicit curative PST range. Curative PST has no lead-time rule; its limit is the TATL-based cap $M^{cur}_{\tau,b}$ and the reaction time, CORNET-1985 / CORNET-1978.)*

**Curative PST group equality (spec SF3074)**

$$
\big(\Delta r^{cur+}_{\tau_1,c} - \Delta r^{cur-}_{\tau_1,c}\big)
\;=\;
\big(\Delta r^{cur+}_{\tau_2,c} - \Delta r^{cur-}_{\tau_2,c}\big)
\qquad \forall c \in C,\ \forall (\tau_1,\tau_2) \in \Pi^{cur}_c
$$

All unique pairs of each group (not a chain). Availability rules, applied before the constraint is built:

- **Outage element:** a PST that is itself an outage element of contingency $c$ has no curative entries for $c$.
- **Group kind** $\kappa_k$ when a member is unavailable in $c$: *reduced* — the remaining members stay a group and keep equal delta tap; *blocked* — the whole group is unavailable in $c$. Default blocked; per-TSO override allowed. A group spanning several TSOs uses the default (with a warning).
- **No common delta:** if the members have no common feasible rectified delta tap (from the up/down headroom at the initial tap, ignoring preventive movement), the whole group is excluded for $c$.

*(No dataset currently contains a curative PST group. This family is verified on synthetic data only; real runs write a header-only `results_curative_pst_groups.csv`.)*

**Contribution to the flow constraints:** the term $\ell_{\tau,b}(\Delta r^{cur+}_{\tau,c} - \Delta r^{cur-}_{\tau,c})$ in §5.5.2 PATL, and the same term (without $\ell$) in the N-X scanned constraint. The TATL constraint has no curative term. The linkage indicator $\ell_{\tau,b}$ defaults to 1 for every $\tau$ when `activate_cra_xne_linkage = False`; when the flag is enabled, $\ell_{\tau,b} = 1$ only for pairs explicitly present in the NCP's linked-elements data.

---

### 5.3 RD preventive

#### 5.3.1 N-0 constraints

**Active power bounds (unit without curative pairing)**

$$
p^{min}_g \;\leq\; p^0_g + \Delta p_g \;\leq\; p^{max}_g
\qquad \forall g \in G,\ \text{if } g \text{ has no curative pairing under any } c
$$

*(For a unit with a curative pairing the bound is the combined form in §5.4.2, which subsumes this one.)*

**Volume bounds (direction-restricted)**

$$
0 \;\leq\; v^+_d \;\leq\; v^{max}_d \cdot \mathbb{1}[d \text{ is an upward bid}]
$$

$$
0 \;\leq\; v^-_d \;\leq\; v^{max}_d \cdot \mathbb{1}[d \text{ is a downward bid}]
\qquad \forall d \in D
$$

**Balancing (hard, no relaxation)**

$$
\sum_{g \in G} \Delta p_g \;=\; 0
$$

**Activation linking (big-M)**

$$
v^+_d + v^-_d \;\leq\; M \cdot y_r
\qquad \forall d \in D,\ r \in R \text{ such that } d \text{ belongs to } r
$$

**RA count limits, per TSO**

$$
\sum_{r \in R_k} y_r \;-\; s^{cnt,ts}_k \;\leq\; N^{ts}_k
\qquad \forall k \in K
$$

$$
\sum_{r \in R_k} y_r \;-\; s^{cnt,tf}_k \;\leq\; N^{tf}_k
\qquad \forall k \in K
$$

*($R_k$ denotes the subset of $R$ belonging to TSO $k$. Both constraints are hard [$s \equiv 0$, not present on the model] or soft depending on `ra_limit_constraint_hard`; in the current single-timestamp scope the per-timestamp and per-timeframe forms are structurally identical.)*

**RA group volume limits**

$$
\sum_{d \in \gamma} v^+_d \;\leq\; V^{up}_\gamma,
\qquad
\sum_{d \in \gamma} v^-_d \;\leq\; V^{down}_\gamma
\qquad \forall \gamma \in \Gamma
$$

**Lead time enforcement (preventive)**

$$
v^+_d = 0,\ v^-_d = 0
\qquad \forall d \in D \text{ such that } t^{lead}_d \text{ has not yet elapsed at the current timestamp}
$$

*(Implemented as variable upper-bound tightening — `setub(0.0)` — not as a separate inequality. Variables and Pmax/Pmin rows stay in the model for blocked bids. A bid is usable only if lead time + RA deciding point $\leq$ timestamp.)*

**Contribution to the flow constraints:** the term $\sum_g S^{RD}_{b,g}\,\Delta p_g$ in §5.5.1.

#### 5.3.2 N-X constraints

No RD-preventive constraint is specific to a contingency: the preventive dispatch is one decision for all contingencies. Its effect under contingency $c$ enters through the term $\sum_g S^{RD,c}_{b,g}\,\Delta p_g$ in §5.5.2 (PATL, TATL and scanned). The unit bounds under a contingency with a curative pairing are in §5.4.2.

---

### 5.4 RD curative

#### 5.4.1 N-0 constraints

None. A curative RD action exists only conditional on a contingency.

#### 5.4.2 N-X constraints

**Active power bounds combined with the curative dispatch**

$$
p^{min}_g \;\leq\; p^0_g + \Delta p_g + \Delta p^{cur}_{g,c} \;\leq\; p^{max}_g
\qquad \forall g \in G,\ \forall c \in C \text{ where } g \text{ has a curative pairing}
$$

*(A unit with no active curative pairing under a given $c$ has $\Delta p^{cur}_{g,c} = 0$ by construction, since no curative bid variables exist for it under that $c$.)*

**Maximum-over-contingencies linking (cost construction, spec eq. 3.42–3.43)**

$$
\bar v^{cur+}_d \;\geq\; v^{cur+}_{d,c},
\qquad
\bar v^{cur-}_d \;\geq\; v^{cur-}_{d,c}
\qquad \forall (d,c) \in L^{cra}_{RD}
$$

**Lead time enforcement (curative, spec CORNET-576)**

$$
v^{cur+}_{d,c} = 0,\ v^{cur-}_{d,c} = 0
\qquad \forall d \in D^{cur},\ \forall c \text{ such that } t^{lead}_d \text{ has not yet elapsed}
$$

*(Same implementation and rule as the preventive lead time, applied to curative bids.)*

**Contribution to the flow constraints:** the term $\sum_g S^{RD,c}_{b,g}\,\Delta p^{cur}_{g,c}$ in §5.5.2 PATL and scanned. The TATL constraint has no curative term.

---

### 5.5 Flow (branch loading) constraints

Each inequality sums the contributions of all RA types that exist in the model (§5.1–5.4); a term of an RA type that is absent is zero.

#### 5.5.1 N-0 flow constraints

**Secured branches (XNE, PATL)**

$$
I^0_b \;+\; \sum_{\tau \in T} S^{PST}_{b,\tau} \cdot (\Delta r^+_\tau - \Delta r^-_\tau)
\;+\; \sum_{g \in G} S^{RD}_{b,g} \cdot \Delta p_g
\;\leq\; PATL_b + s^{N0}_{sec,b}
\qquad \forall b \in B^{sec}
$$

**Scanned branches**

$$
I^0_b \;+\; \sum_{\tau \in T} S^{PST}_{b,\tau} \cdot (\Delta r^+_\tau - \Delta r^-_\tau)
\;+\; \sum_{g \in G} S^{RD}_{b,g} \cdot \Delta p_g
\;\leq\; L^{eff}_b + s^{N0}_{scan,b}
\qquad \forall b \in B^{scan}
$$

*($s^{N0}_{scan,b} \equiv 0$ when the constraint is configured hard — the slack variable does not exist on the model at all in that case, not merely fixed to zero.)*

#### 5.5.2 N-X flow constraints

**Secured branches, PATL (preventive + curative)**

$$
I^{0,c}_b
\;+\; \sum_{\tau} S^{PST,c}_{b,\tau} \Big[(\Delta r^+_\tau - \Delta r^-_\tau) + \ell_{\tau,b}\big(\Delta r^{cur+}_{\tau,c} - \Delta r^{cur-}_{\tau,c}\big)\Big]
\;+\; \sum_{g} S^{RD,c}_{b,g} \Big[\Delta p_g + \Delta p^{cur}_{g,c}\Big]
\;\leq\; PATL_b + s^{NX}_{PATL,b,c}
$$
$$
\forall (b,c) \in P^{sec}_{PATL}
$$

**Secured branches, TATL (preventive only)**

$$
I^{0,c}_b
\;+\; \sum_{\tau} S^{PST,c}_{b,\tau} \cdot (\Delta r^+_\tau - \Delta r^-_\tau)
\;+\; \sum_{g} S^{RD,c}_{b,g} \cdot \Delta p_g
\;\leq\; TATL_b + s^{NX}_{TATL,b,c}
\qquad \forall (b,c) \in P^{sec}_{TATL}
$$

**Scanned branches (preventive + curative, no TATL equivalent)**

$$
I^{0,c}_b
\;+\; \sum_{\tau} S^{PST,c}_{b,\tau} \Big[(\Delta r^+_\tau - \Delta r^-_\tau) + \big(\Delta r^{cur+}_{\tau,c} - \Delta r^{cur-}_{\tau,c}\big)\Big]
\;+\; \sum_{g} S^{RD,c}_{b,g} \Big[\Delta p_g + \Delta p^{cur}_{g,c}\Big]
\;\leq\; L^{eff}_b + s^{NX}_{scan,b,c}
\qquad \forall (b,c) \in P^{scan}
$$

---

### Mapping from the earlier numbering

Other documents may still cite the earlier section numbers.

| Earlier | Now |
|---|---|
| 5.1 PST tap bounds | 5.1.1 |
| 5.2 PST group equality | 5.1.1 |
| 5.3 RD active power bounds | 5.3.1 (no curative pairing) and 5.4.2 (with curative pairing) |
| 5.4 RD volume bounds | 5.3.1 |
| 5.5 RD balancing | 5.3.1 |
| 5.6 N-0 secured loading | 5.5.1 |
| 5.7 N-0 scanned loading | 5.5.1 |
| 5.8 RA activation linking | 5.3.1 |
| 5.9 RA count limits | 5.3.1 |
| 5.10 RA group volume limits | 5.3.1 |
| 5.11 Lead time | 5.3.1 (preventive) and 5.4.2 (curative) |
| 5.12 PST curative tap bounds | 5.2.2 |
| 5.13 N-X PATL | 5.5.2 |
| 5.14 N-X TATL | 5.5.2 |
| 5.15 N-X scanned | 5.5.2 |
| 5.16 Curative PST group equality | 5.2.2 |
| (new) PST tap-change limit per TSO | 5.1.1 |
| (new) Curative max-linking | 5.4.2 |

---

## 6. Constraint and Variable Presence Summary (Composability Reference)

| Family | Present when |
|---|---|
| §5.1 (PST preventive: tap bounds, group equality, tap limit per TSO) | `enable_pst_remedial_actions = True` |
| §5.2 (PST curative: tap bounds, movement cap) | `nx_inputs` provided *and* $L^{cra}_{PST}$ non-empty |
| §5.2.2 curative PST group equality | At least one curative PST group (members sharing one GSARA) is eligible in some contingency |
| §5.3 (RD preventive) | `enable_rd_remedial_actions = True` |
| §5.4 (RD curative) | `nx_inputs` provided *and* $L^{cra}_{RD}$ non-empty |
| §5.5.1 (N-0 secured; PST term / RD term) | PST term present iff PST enabled; RD term present iff RD enabled; either alone still yields a valid, smaller sum |
| §5.5.1 (N-0 scanned) and §5.5.2 (N-X scanned) | At least one branch classified `AEType.SCANNED` exists in the candidate set |
| §5.5.2 (N-X PATL, scanned) | `nx_inputs` provided (N-X analysis enabled) |
| §5.5.2 (N-X TATL) | A TATL is defined for branch $b$ *and* N-X analysis is enabled |

A model instance with both `enable_pst_remedial_actions = False` and
`enable_rd_remedial_actions = False` is invalid and rejected before
construction begins — there would be nothing for the objective to act on.

---

## 7. Cumulative (state-based) form in later solves of the iterative loop

The loop (linearisation iterations inside completeness iterations) re-builds this
model at each solve around the **current operating point** $k$ (the grid after the
remedial actions applied so far), while the **original** operating point (before
any remedial action) stays frozen. Everything in §1–§6 holds unchanged; the items
below say which quantities are read from which state. At the first solve the
current state equals the original state and the cumulative variables equal the
$\Delta$ variables, so §7 reduces to §1–§6.

### 7.1 Notation

| Symbol | Description |
|---|---|
| $r^{orig}_\tau,\ p^{orig}_g$ | Original (frozen) tap / `target_p` |
| $r^{k}_\tau,\ p^{k}_g$ | Current-state tap / `target_p` (after the previous iteration's applied result) |
| $R^{up}_\tau,\ R^{down}_\tau \in \mathbb{R}_{\geq 0}$ | Cumulative upward / downward tap movement of PST $\tau$ relative to the **original** tap |
| $u_d$ | Net cumulative volume of bid $d$ already applied to the network, relative to the original (signed, MW) |
| $\bar v_d$ | Original availability of bid $d$ (as in §2, $v^{max}_d$) |
| $L_k$ | Maximum total tap movement for TSO $k$ (the per-TSO PST tap-change limit) |

$\Delta r^\pm_\tau$ and $v^\pm_d$ remain the changes of this solve, relative to the **current** state.

### 7.2 Where each baseline comes from

| Quantity | Read from |
|---|---|
| $I^0_b$, $I^{0,c}_b$ (N-0 / N-X currents) | AC load flows of the current state, re-run every iteration |
| $S^{PST}_{b,\tau}$, $S^{RD}_{b,g}$, $S^{PST,c}_{b,\tau}$, $S^{RD,c}_{b,g}$ | Sensitivity analyses at the current state, re-run every iteration with the pipeline load-flow parameters |
| $r^0_\tau,\ p^0_g$ in §5.1.1, §5.3.1, §5.4.2 | $r^{k}_\tau,\ p^{k}_g$ |
| $L^{eff}_b$ (scanned limit) | $\max(PATL_b\cdot(1+m_b/100),\ I^{orig}_b)$ — **anchored on the original N-0 load flow**, not on the current state |
| Curative "unit in operation" flag | Original `target_p` (`original_target_p_mw`, `milp_builder.py:1389`) |

### 7.3 Cumulative PST movement

$$
R^{up}_\tau - R^{down}_\tau \;=\; (r^{k}_\tau - r^{orig}_\tau) + \Delta r^+_\tau - \Delta r^-_\tau
\qquad \forall \tau \in T
$$

Tap bounds (§5.1.1) apply to $r^{k}_\tau + \Delta r^+_\tau - \Delta r^-_\tau$ (`milp_builder.py`, tap bounds on `pst.r0`). The cumulative variables $R^{up}, R^{down}$ exist only for a PST whose current tap differs from the original (`cum_tap_balance`, lines 790–835); for any other PST they are the $\Delta r^\pm$ variables themselves. The per-TSO tap limit applies to the cumulative movement:

$$
\sum_{\tau \in T_k} \left(R^{up}_\tau + R^{down}_\tau\right) \;\leq\; L_k
\qquad \forall k \in K \text{ with a defined limit}
$$

$L_k$ is the per-TSO override if one is set, else the default (`max_taps_per_tso_constraint`, `milp_builder.py:885–920`); the constraint is hard (no slack).

(At the first solve $R^{up}-R^{down} = \Delta r^+ - \Delta r^-$, so this is the same limit as in a single-shot model.)

### 7.4 Cumulative RD volume and bid headroom

(`milp_builder.py:1036–1082`: the upper bounds are set per bid from `cumulative_signed_volume_mw`.) With $u_d$ the net volume already applied for bid $d$, the bounds of §5.3.1 become headroom bounds on this solve's change, so that the net cumulative volume never exceeds the bid's availability:

- same direction as the volume already used: $0 \le v_d \le \bar v_d - |u_d|$,
- opposite direction (retracting): $0 \le v_d \le |u_d|$.

Balancing (§5.3.1) concerns the change of this solve and is unchanged.

### 7.5 RA activation and count limit

The activation binary $y_r$ is linked to the **cumulative net volume of each bid in the bid's own direction** (a non-negative quantity), not fixed to 1 and not linked to this solve's change only. The constraint is **one-sided** (`ra_activation_big_m`, `milp_builder.py:1951–1962`):

$$
w_d \;\leq\; M_d\, y_r,
\qquad w_d = u_d + v^{dir}_d - v^{opp}_d \;(\text{or } v^{up}_d + v^{down}_d \text{ when } u_d = 0),
\qquad M_d = \bar v_d
$$

where $u_d \ge 0$ is the volume already applied in the bid's own direction and $M_d = \bar v_d$ is **that bid's own** original availability (`bid.available_mw[timestamp]`), not one shared constant. There is no lower link because $w_d \ge 0$ by the headroom bounds of §7.4. An RA fully retracted to its original value therefore no longer counts. The count limits of §5.3.1 are unchanged. There is no penalty on $y_r$ itself; the exported "activated" flag is derived from $|u_d + v^+_d - v^-_d| > 10^{-6}$ MW (`RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW`, `n0_results_export.py:708`).

### 7.6 Pricing against the original network

The objective terms for preventive PST and RD (§4) are priced on the **cumulative** movements $R^{up}_\tau + R^{down}_\tau$ and on the cumulative bid volumes, i.e. against the original network. An iteration that adds to earlier movement pays for the total; retraction reduces the cost. (PST cost: cumulative terms `cum_tap_up_term` / `cum_tap_down_term`, `milp_builder.py` ~2358; RD cost: `rd_cumulative_volume_term`, ~2443.)

### 7.7 Curative actions

Curative variables (§3) are **re-optimised at every solve and never applied to the network**; each solve prices its own curative actions. Their effect enters the N-X flow constraints (§5.5.2) only through the linearised terms. The post-curative loading seen in the AC verification is therefore the AC N-X current plus the linearised curative effect, not a load flow with curative actions applied.

### 7.8 Applied taps

Taps applied to the network between solves are rounded to integers, unconditionally (`ac_convergence_loop.py:130–132`); the next solve starts from the rounded state.

### 7.9 Not in the objective (open)

Bid activation cost (spec eq. 3.38) and generating-unit start-up cost (BUC14#102/#103, eq. 3.39) are not part of the objective. Eq. 3.35 (sum of RA change in MW including the approximated PST flow shift) is not built as such: taps and MW are compared against the same threshold in the convergence check. See `R3_NX_CRA.md`, section "Loop redesign and consistency pass".
