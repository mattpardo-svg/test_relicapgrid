# Data validation reference

What the pipeline checks on its inputs and intermediate data, where, and what it does when a check fails.

Paths are relative to `src/rao/`; tests are in `tests/`.

**Action**: halt = the run stops (exception, or the loop ends with a stop status); exclude = the element is not optimised; skip = the pair or item is left out; default = a value is substituted; warn = only a log line.
**Logged as**: log level and the start of the message; "exception" = only the raised error text; "none" = nothing is logged.

## 1. Config

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Config file present | `run_pipeline.py:145-152` | `rao_config.yaml` or `load_flow_config.yaml` missing | halt (at import) | exception "Required config file not found" | none |
| Key present | `run_pipeline.py:180-188` | a key read by the code is missing | halt (`ConfigKeyError`) | exception "Missing config key" | `test_a_missing_key_names_the_key_and_the_file` |
| Thresholds | `run_pipeline.py:219-225` | one of 9 threshold keys not a number or < 0 (bool rejected) | halt (at import) | exception "Invalid config value" | `test_an_out_of_range_config_value_raises_a_clear_error_naming_key_value_and_file` |
| Iteration caps, thread count | `run_pipeline.py:226-232` | not an integer or < 1 | halt (at import) | exception "Invalid config value" | `test_a_bad_config_value_stops_the_import_of_the_pipeline` |
| Solver time limit / MIP gap | `run_pipeline.py:233-244` | not null and not > 0 (limit) / not ≥ 0 (gap) | halt (at import) | exception "Invalid config value" | `test_an_out_of_range_config_value_raises_a_clear_error_naming_key_value_and_file` |
| `write_nx_sensitivity_csvs` | `run_pipeline.py:245-251` | not a boolean | halt (at import) | exception "must be true or false" | `test_an_out_of_range_config_value_raises_a_clear_error_naming_key_value_and_file` |
| Tap limits | `run_pipeline.py:303-308`, `milp/milp_builder.py:289-293` | `max_taps_per_tso` or an override not a non-negative integer | halt (at import) | exception "must be a non-negative integer" | `test_invalid_tap_limit_values_are_rejected` |
| Tap-limit override TSO names | `run_pipeline.py:254-262`, `:433` | TSO name not a TSO of the run | warn (entry unused) | WARNING "Config ... names TSO ..., which is not a TSO of this run" | `test_unknown_tso_names_in_the_tap_limit_overrides_are_warned_about_one_by_one` |
| PST group kind | `run_pipeline.py:311-317`, `pre_milp/cra_preprocessing.py:150-155` | default or per-TSO value not `blockedGroup`/`reducedGroup` | halt (at import) | exception "pst_group_kind_default must be one of" | `test_group_kind_value_is_validated`, `test_invalid_per_tso_kind_is_rejected` |
| Load-flow enum names | `run_pipeline.py:164-166` | `voltage_init_mode`, `balance_type` or `component_mode` not a pypowsybl enum name | halt (at import, AttributeError) | exception | none |
| `use_reactive_limits` key | `run_pipeline.py:339` | missing from `load_flow_config.yaml` | halt (KeyError) | exception | none |
| At least one RA type | `run_pipeline.py:580-585` | `enable_pst_remedial_actions` and `enable_rd_remedial_actions` both false | halt (after parsing and the first CSVs) | exception "At least one of ENABLE_PST_REMEDIAL_ACTIONS" | none |

## 2. Data loading (CGM, NCP zip, timestamps)

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Input folder | `run_pipeline.py:105-110` | `input/` missing | halt | exception "Required input folder not found" | `test_missing_folder_raises_file_not_found` |
| One zip per prefix | `run_pipeline.py:111-125` | no `cgm*`/`ncp*` zip, or more than one | halt | exception "No file starting with" / "Expected exactly one" | `test_zero_matches_raises_file_not_found`, `test_multiple_matches_raises_value_error` |
| CGM load | `pre_milp/cgmes_loader.py:40-41`, `:53-54` | zip missing, or load returns nothing | halt | exception "CGM zip not found" | none |
| Initial load flow | `pre_milp/cgmes_loader.py:74-83` | status of component 0 not CONVERGED | halt | CRITICAL "Initial AC load flow did not converge" | `test_a_non_converged_initial_load_flow_halts_with_runtime_error_and_a_fatal_log` |
| NCP zip present | `pre_milp/ncp_loader.py:74-75` | zip missing | halt | exception "NCP zip not found" | `test_missing_zip_raises` |
| Duplicate base names | `pre_milp/ncp_loader.py:80-96` | two entries extract to the same file name | halt | exception "multiple entries that would extract to the same filename" | `test_same_basename_different_path_raises_before_extraction` |
| Organisation profile | `pre_milp/ncp_loader.py:101-107` | `Org-NineRealms_CD.xml` missing | halt | exception "no file named exactly" | `test_missing_organisation_file_raises` |
| TSO without name | `pre_milp/tso_name_resolver.py:55-57` | TransmissionSystemOperator has no name | skip | WARNING "has no IdentifiedObject.name" | none |
| ControlArea without operator | `pre_milp/tso_name_resolver.py:64-66` | no SystemOperator reference | skip | WARNING "has no SystemOperator reference" | none |
| Operator not in profile | `pre_milp/tso_name_resolver.py:68-74` | operator mRID unknown | default (name "") | WARNING "TSO name set to empty string" | none |
| Unrecognised NCP file | `pre_milp/ncp_loader.py:138-139`, `:151-157` | name not `{TSO}_{PROFILE}.xml` of a known TSO | skip | WARNING "did not match the expected" | `test_unrecognized_file_does_not_block_valid_tsos` |
| Known irrelevant NCP file | `pre_milp/ncp_loader.py:136-137` | SSI, CD_OR, unparsed profile, cross-TSO export | skip | none | `test_ssi_suffix_is_known_irrelevant` |
| Duplicate (TSO, profile) | `pre_milp/ncp_loader.py:143-164` | two files parse as the same profile | halt | exception "duplicate (TSO, profile)" | none |
| Required profiles | `pre_milp/ncp_loader.py:166-184` | AE, CO or RA missing for a TSO | halt | exception "missing required NCP profile(s)" | `test_missing_required_profile_raises` |
| Optional profiles | `pre_milp/ncp_loader.py:174-178` | SHS or SIS missing | warn | WARNING "optional profile ... not found" | `test_missing_optional_profile_is_not_an_error` |
| EQ file per TSO | `run_pipeline.py:469-478` | no `_{country}_EQ` file | default (empty tap-changer and side maps) | WARNING "no EQ file found" | none |
| Timestamp list | `pre_milp/ncp_loader.py:269-280` | count outside 1-24, not HHMMZ, hour > 23 or minute > 59 | halt | exception | `test_invalid_format_raises`, `test_invalid_hour_raises` |
| SHS time point | `pre_milp/ncp_parser.py:147-156` | schedule, atTime or value missing; atTime not a run timestamp; no limit link | skip | none | none |
| SHS value | `pre_milp/ncp_parser.py:158` | value not a number | halt (ValueError) | exception | none |
| Bid time point | `pre_milp/ncp_parser.py:1085-1090` | schedule, atTime or p missing; atTime not a run timestamp | skip | none | none |
| Bid p / price | `pre_milp/ncp_parser.py:1093-1094` | not a number | halt (ValueError) | exception | none |
| ISO duration | `pre_milp/ncp_parser.py:79-84` | not an ISO 8601 duration | default 0.0 h | none | `test_invalid_returns_zero` |
| CGM accessors | `pre_milp/cgmes_loader.py:410-411`, `:428-429`, `:465-466`, `:494-495` | lines, tap changers or generators unreadable | default (that table empty) | ERROR "extract_equipment_dicts: failed to read" | `test_a_failing_accessor_in_extract_equipment_dicts_is_logged` |
| Equipment-type accessors | `pre_milp/cgmes_loader.py:380-385` | accessor raises | default (type missing, equipment later dropped) | ERROR "Failed to build equipment-type mapping" | none |

## 3. CGM-derived inputs (initial currents, static limits, degrees per tap)

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Branch current present | `pre_milp/cgmes_loader.py:105-128` | i1 or i2 missing | default NaN (branch excluded at build) | WARNING "without an i1/i2 current - set to NaN" | `test_a_missing_current_column_is_nan_not_zero_with_a_warning` |
| Current table readable | `pre_milp/cgmes_loader.py:142-143`, `:157-158` | line or transformer results unreadable | default (branches absent, excluded at build) | ERROR "Failed to extract line/transformer currents" | none |
| Static PATL table | `pre_milp/cgmes_loader.py:170-177` | limits unreadable or empty | default {} | ERROR (unreadable) / none (empty) | `test_empty_operational_limits_returns_empty_dict` |
| Static PATL rows | `pre_milp/cgmes_loader.py:183-192` | not CURRENT, not permanent, duration unreadable, not line or 2W transformer | skip | none | `test_excludes_tatl_entries` |
| Static PATL side | `pre_milp/cgmes_loader.py:194-200` | side not ONE/TWO | skip | WARNING "unrecognized side" | none |
| Tap-step table | `pre_milp/cgmes_loader.py:215-223` | table unreadable or no `alpha` column | default {} (no PST has a conversion) | ERROR / WARNING "no 'alpha' column" | `test_no_alpha_column_returns_empty` |
| PST in tap-step table | `pre_milp/cgmes_loader.py:227-233` | PST missing | exclude (no tap effect, see area 7) | WARNING "not found in phase tap changer steps table — omitted" | `test_missing_pst_omitted_not_defaulted` |
| Number of tap steps | `pre_milp/cgmes_loader.py:239-244` | fewer than 2 | exclude (no tap effect) | WARNING "fewer than 2 tap steps — omitted" | `test_single_step_pst_omitted` |
| Uniform tap steps | `pre_milp/cgmes_loader.py:248-256` | step deviates > 1e-6 deg from the average | warn (average used) | WARNING "not uniformly spaced" | none |
| Generator Pmax/Pmin | `pre_milp/cgmes_loader.py:476-488` | missing or NaN | default 0.0 (unit fixed) | WARNING "has no max_p / min_p in the CGM - defaulted to 0.0" | `test_a_generator_without_pmax_and_pmin_gets_zero_limits_with_one_warning_through_the_pipeline_path` |
| Generator target_p | `pre_milp/cgmes_loader.py:474` | missing | default 0.0 | none | none |
| Tap-changer positions | `pre_milp/cgmes_loader.py:420-422` | low_tap, high_tap or tap missing | default 0 | none | none |
| CurrentLimit side chain | `pre_milp/ncp_parser.py:517-528` | no limit set, terminal or sequenceNumber | skip (AE side then 1) | none | none |
| CurrentLimit sequenceNumber | `pre_milp/ncp_parser.py:530-546` | not an integer or not 1/2 | skip | WARNING "non-integer sequenceNumber" / "outside {1,2}" | none |
| TapChanger → transformer | `pre_milp/ncp_parser.py:578-607` | no TransformerEnd, no PowerTransformer, or two transformers | skip (first transformer kept) | WARNING "cannot resolve parent transformer" / "resolves to multiple" | none |
| Initial tap in hardware range | `pre_milp/ncp_parser.py:747` | CGM tap outside low/high step | default (clamped) | none | none |
| Initial tap in effective bounds | `pre_milp/pst_bounds.py:40-44` | current tap outside effective bounds | warn | WARNING "current tap ... outside effective bounds" | `test_warning_when_current_outside_effective_bounds` |

## 4. Assessed elements

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Branch reference | `pre_milp/ncp_parser.py:187-198` | no ConductingEquipment/Line, but DCTieCorridor, corridor or OperationalLimit | exclude | INFO "a different assessment kind ... skipped" | none |
| Any reference | `pre_milp/ncp_parser.py:199-208` | none of the five associations | exclude | WARNING "has none of ConductingEquipment, Line" | none |
| Branch in CGM | `pre_milp/ncp_parser.py:210-219` | not a line or 2W transformer of the CGM | exclude | INFO "not a Line or 2W-Transformer in the CGM" | none |
| Limit side | `pre_milp/ncp_parser.py:227-237` | OperationalLimit not in the side map | default side 1 | DEBUG "defaulting to side 1" | none |
| BaseCaseCurrentLimit value | `pre_milp/ncp_parser.py:244-252` | normalValue not a number | default (next PATL source) | WARNING "is not a valid float — ignored" | none |
| Exclusion reason | `pre_milp/ncp_parser.py:263-271` | not one of the three SecuredExclusionReasonKind values | halt | CRITICAL "invalid exclusionReason ... cancelling the AE parse" | `test_ae_with_invalid_exclusion_reason_cancels_the_parse` |
| Region codes | `pre_milp/ncp_parser.py:279-286` | no secured, no scanned code, no reason | exclude | INFO "excluded - no secured or scanned region code" | `test_ae_with_neither_region_code_nor_exclusion_is_excluded_and_logged` |
| Reason without scanned code | `pre_milp/ncp_parser.py:277-278` | exclusion reason, no scanned code | exclude | none (count in INFO summary) | none |
| Scanned code only | `pre_milp/ncp_parser.py:287-295` | scanned code, no secured code, no reason | default secured | DEBUG "defaulting to SECURED" | `test_ae_with_both_region_codes_and_no_exclusion_stays_secured` |
| SHS against CGM PATL | `pre_milp/ncp_parser.py:306-312` | SHS PATL differs > 10 % from CGM static | warn | WARNING "differs >10% from CGM static" | none |
| PATL from NCP | `pre_milp/ncp_parser.py:316-325` | no SHS value, no BaseCaseCurrentLimit | default CGM static PATL | WARNING "no PATL in NCP ... using CGM static PATL" | `test_falls_through_to_cgm_static_with_warning` |
| Any PATL | `pre_milp/ncp_parser.py:326-332` | no source at all | default 0.0 (branch excluded at build) | WARNING "defaulting to 0" | none |
| One AE per branch | `run_pipeline.py:527`, `milp/milp_builder.py:239-240` | several AEs on one branch | default (last AE wins: limit, type, side) | none | none |
| Scanned list branch | `pre_milp/scanned_elements.py:50-52` | scanned AE without branch | skip | WARNING "has no branch_mrid — skipped" | `test_skips_ae_without_branch_mrid` |

## 5. Contingencies

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Equipment link | `pre_milp/ncp_parser.py:379-380` | ContingencyEquipment without contingency or equipment | skip | none | none |
| Must-study flag | `pre_milp/ncp_parser.py:398-399` | `normalMustStudy` missing | default false (not studied) | none | none |
| Equipment in CGM | `pre_milp/ncp_parser.py:406-415` | mRID not in the 8 mapped equipment types | skip (equipment) | WARNING "equipment ... not found in CGM — skipped" | `test_empty_with_no_cgm_equipment` |
| Equipment left | `pre_milp/ncp_parser.py:417-422` | listed equipment but none valid | exclude | WARNING "has no valid equipment after CGM check — excluded" | `test_empty_with_no_cgm_equipment` |
| Any must-study contingency | `pre_milp/nx_security_analysis.py:109-110` | none at the run timestamp | halt | exception "No must-study contingencies" | `test_raises_when_no_must_study_contingencies` |
| Any monitored branch | `pre_milp/nx_security_analysis.py:113-114` | none | halt | exception "No monitored branch IDs" | `test_raises_when_no_monitored_branches` |
| Post-contingency result | `pre_milp/nx_security_analysis.py:137-140` | no result returned | exclude | WARNING "must-study contingency(ies) skipped" (`run_pipeline.py:787-791`) | none |
| Contingency status | `pre_milp/nx_security_analysis.py:57-58`, `:149-155` | not CONVERGED or NO_IMPACT | exclude | WARNING "skipped — non-convergent" | `test_skips_non_convergent_contingency` |
| Network split | `pre_milp/nx_security_analysis.py:60-66` | a monitored branch (not own equipment) missing from results | exclude | WARNING "likely network split" | `test_missing_branch_is_treated_as_likely_network_split` |
| Pair current | `pre_milp/nx_security_analysis.py:165-185` | current missing or NaN | skip (pair) | WARNING "without a usable current ... left out of lf_nx" | `test_a_nan_current_in_the_security_analysis_is_left_out_of_lf_nx_with_a_warning` |
| Own tripped branch | `pre_milp/nx_security_analysis.py:168`, `:175-179` | branch is the contingency's own equipment | skip (pair) | DEBUG | `test_the_contingencys_own_tripped_branch_gets_no_zero_entry` |
| Refresh skips | `run_pipeline.py:994-999` | contingency skipped at an N-X refresh | exclude (next build) | WARNING "N-X load flow at the applied state: ... skipped" | `test_refresh_skips_are_merged_into_the_contingency_status_reasons` |
| Contingencies lost at refresh | `milp/ac_convergence_loop.py:766-770` | refresh has fewer contingencies | exclude (next build) | column `nx_contingencies_lost_at_refresh` | `test_the_iteration_history_counts_the_contingencies_lost_at_each_nx_refresh` |
| Empty refresh | `milp/ac_convergence_loop.py:762-776` | refresh returns nothing | default (last N-X baseline kept) | WARNING "keeping the previous N-X baseline" | `test_an_empty_nx_refresh_never_counts_as_criterion_4` |

## 6. PATL/TATL and effective limit

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| N-0 current present | `milp/milp_builder.py:265-267` | no current on the branch side | exclude | WARNING "missing initial current ... excluding from MILP" | none |
| N-0 current finite | `milp/milp_builder.py:268-270` | NaN | exclude | WARNING "has a NaN initial current" | `test_an_n0_branch_with_a_nan_initial_current_is_excluded_with_a_warning` |
| N-0 PATL | `milp/milp_builder.py:272-275` | limit missing or ≤ 0 | exclude | WARNING "missing or invalid PATL; excluding from MILP" | `test_a_branch_with_patl_zero_has_no_n0_constraint` |
| N-0 loading threshold | `milp/milp_builder.py:277-278` | loading < `min_loading_threshold_pct` | exclude | none | none |
| PATL at timestamp | `milp/milp_builder.py:227-229` | AE has no PATL at the timestamp | exclude | none | none |
| Scanned effective limit | `milp/milp_builder.py:231-235` | scanned branch | default max(PATL, original N-0 current); PATL when no current | none | `test_scanned_branch_gets_constraint_against_effective_limit` |
| Virtual margin | `pre_milp/scanned_elements.py:55` | always | default 0 % | none | `test_patl_scanned_equals_patl_cgm_when_margin_zero` |
| N-X limit | `milp/milp_builder.py:1010-1016` | limit ≤ 0 | exclude (from N-X) | WARNING "has a limit of ... (<= 0) - excluded" | `test_a_branch_with_patl_zero_has_no_nx_pair_and_one_warning_per_branch` |
| N-X loading threshold | `milp/milp_builder.py:1069-1071` | loading < `min_loading_threshold_pct_nx` | skip (pair) | none | `test_min_loading_threshold_pct_nx_excludes_lightly_loaded_pairs` |
| Secured branch for TATL | `pre_milp/nx_security_analysis.py:267-268` | no secured branch | halt | exception "No monitored SECURED branch IDs" | `test_raises_when_no_secured_branches_in_ae_flat_list` |
| Limit table for TATL | `pre_milp/nx_security_analysis.py:277-280` | unreadable | halt | exception "Failed to fetch operational limits" | none |
| Limit table content | `pre_milp/nx_security_analysis.py:283-290` | None / empty | default (TATL = PATL for all) | WARNING (None) / INFO (empty) | `test_empty_operational_limits_falls_back_to_patl_for_every_branch` |
| TATL row | `pre_milp/nx_security_analysis.py:311-335` | no TATL on the branch side | default TATL = PATL, 600 s | INFO "falling back to its own PATL" | `test_no_tatl_row_falls_back_to_patl_with_600s_duration` |
| TATL and PATL | `pre_milp/nx_security_analysis.py:313-321` | no TATL and no PATL | skip (no TATL constraint) | WARNING "no TATL constraint possible" | `test_branch_with_no_tatl_and_no_patl_is_absent_and_warns` |
| Number of TATLs | `pre_milp/nx_security_analysis.py:337-343` | more than one on the side | skip (no TATL constraint) | WARNING "(exactly one expected) — skipped" | `test_several_tatls_on_one_side_give_no_entry_and_no_patl_fallback` |
| TATL below PATL | `pre_milp/nx_security_analysis.py:351-356`, `:369-376` | TATL < PATL | default raised to PATL | WARNING (one summary line) | `test_tatl_lower_than_patl_is_corrected_to_patl` |
| TATL for scanned | `milp/milp_builder.py:1241-1242` | branch not secured | skip | none | `test_scanned_branch_has_no_tatl_equivalent` |
| Side value present | `data_model.py:259-265` | requested side missing | default other side | WARNING "missing side ... data, using side" | `test_falls_back_to_other_side_when_missing` |

## 7. PST preprocessing

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| TapPositionAction links | `pre_milp/ncp_parser.py:647-648` | no GSARA or TapChanger | skip | none | none |
| Availability | `pre_milp/ncp_parser.py:688-689` | `normalAvailable` missing | default not available | none | none |
| Kind | `pre_milp/ncp_parser.py:691-693` | kind missing or not curative | default preventive | none | none |
| Penalty factor | `pre_milp/ncp_parser.py:695-703` | `penaltyFactor` missing | default 1.0 | WARNING "has no RemedialAction.penaltyFactor - defaulted to 1.0" | `test_a_pst_remedial_action_without_penalty_factor_gets_one_with_a_warning` |
| TapChanger resolved | `pre_milp/ncp_parser.py:719-728` | no phase-shifting transformer found | exclude | INFO "likely a RatioTapChanger ... skipped" | none |
| Transformer in CGM | `pre_milp/ncp_parser.py:730-736` | no CGM tap-changer data | exclude | WARNING "not found in CGM — skipped" | `test_empty_with_no_cgm_tapchangers` |
| Curative timing | `pre_milp/ncp_parser.py:760-771` | curative PST without reaction time or time per stage | warn (excluded later, area 9) | WARNING "missing reaction_time_minutes and/or time_per_stage_minutes" | `test_real_curative_pst_has_no_reaction_time_or_time_per_stage` |
| Any available PST | `run_pipeline.py:602-611` | no available preventive or curative PST | exclude (no PST block) | WARNING "No available preventive or curative PSTs" | none |
| Tap range | `pre_milp/pst_bounds.py:32-38` | effective min > max | exclude | WARNING "effective tap bounds empty ... excluded from MILP" | `test_a_pst_with_an_empty_tap_range_builds_and_solves_without_that_pst` |
| Group availability | `pre_milp/pst_groups.py:28-35` | a member unavailable | skip (group pairs) | WARNING "excluded because unavailable PSTs present" | `test_excludes_group_when_unavailable` |
| Group bounds | `pre_milp/pst_groups.py:37-46` | a member without bounds | skip (group pairs) | WARNING "have no valid tap bounds" | `test_excludes_group_when_member_missing_from_pst_tap_bounds` |
| Group range | `pre_milp/pst_groups.py:52-59` | common range empty | skip (group pairs) | WARNING "effective group range ... is empty" | `test_excludes_group_when_bounds_empty` |
| Group size | `pre_milp/pst_groups.py:25-26` | one member only | skip | none | none |
| Group pair members modelled | `milp/milp_builder.py:359-367` | a pair names a PST without variables | skip (pair) | WARNING "PST group pair ... dropped" | `test_a_group_pair_naming_the_dropped_pst_is_dropped_with_a_warning` |
| 3-winding PST | `pre_milp/n0_sensitivity.py:102-110`, `pre_milp/nx_sensitivity.py:55-63` | PST not a 2W transformer | exclude (no sensitivity) | WARNING "Excluding ... backed by a 3-winding transformer" | `test_excludes_three_winding_transformer_pst_when_network_provided` |
| Degrees per tap | `milp/milp_builder.py:346-352` | no conversion factor | exclude (no tap effect) | WARNING "missing degrees-per-tap conversion factor" | `test_missing_pst_degrees_per_tap_excludes_pst_from_tap_effect` |
| One transformer, two RAs | `milp/milp_builder.py:339-344` | two available preventive RAs share an mRID | default (modelled once) | WARNING "share an mRID" | `test_two_preventive_ras_on_one_transformer_count_once_in_the_tso_tap_limit` |
| Penalty of shared transformer | `milp/milp_builder.py:308-314` | different penalties for one kind | default the larger | WARNING "using the larger" | none |
| Curative range direction | `pre_milp/ncp_parser.py:848-856` | direction neither up nor down | skip (that range) | WARNING "unrecognized/ambiguous direction" | none |
| Curative range value | `pre_milp/ncp_parser.py:820-827` | no link or not a number | skip | none | none |
| Curative range complete | `pre_milp/ncp_parser.py:858-867`, `pre_milp/pst_bounds.py:51-73` | upper or lower missing | default (own operating range) | WARNING + INFO fallback count | `test_fallback_count_is_logged_once` |
| Curative bounds at build | `milp/milp_builder.py:726-733` | curative PST without bounds entry | skip (bound constraint) | WARNING "constraint skipped" | `test_missing_curative_bounds_entry_skips_constraint_not_crash` |

## 8. RD, GLSK, bids

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| RotatingMachineAction links | `pre_milp/ncp_parser.py:964-965` | no GSARA or machine | skip | none | none |
| Ramp rate | `pre_milp/ncp_parser.py:973-980` | not a number | default None | none | none |
| Availability / kind | `pre_milp/ncp_parser.py:999-1004` | missing | default not available / preventive | none | none |
| RA penalty factor | `pre_milp/ncp_parser.py:1008-1016` | missing | default 1.0 | WARNING "has no RemedialAction.penaltyFactor - defaulted to 1.0" | `test_rd_unit_penalty_factor_defaults_to_one_when_absent` |
| Unit in CGM | `pre_milp/ncp_parser.py:1019-1025` | generating unit not in CGM | exclude | WARNING "not found in CGM — skipped" | `test_empty_with_no_cgm_generating_units` |
| Unit limits | `pre_milp/ncp_parser.py:1031-1038` | max_p/min_p key missing | default 0.0 | WARNING "defaulted to 0.0" | `test_a_unit_without_pmax_and_pmin_gets_zero_and_one_warning_naming_it` |
| Initial production | `pre_milp/ncp_parser.py:1028` | target_p missing | default 0.0 | none | none |
| Unsupported power RAs | `pre_milp/ncp_parser.py:880-918` | Redispatch or Countertrade RA | exclude (with bids) | WARNING "is not supported and is IGNORED" | `test_each_ignored_ra_is_listed_with_its_bid_count` |
| SIS file | `pre_milp/ncp_parser.py:1069-1072` | missing | default (no bids) | INFO "no SIS file — no power bids" | `test_no_sis_file_still_warns_with_zero_bids` |
| Bid schedule RA | `pre_milp/ncp_parser.py:1101-1107` | no RA, or RA not an RD RA | skip | none / DEBUG | none |
| Bid direction | `pre_milp/ncp_parser.py:1109-1111` | missing or not "down" | default UP | none | none |
| Bid lead time | `pre_milp/ncp_parser.py:1113-1114` | missing | default 0 h | none | none |
| Bid penalty factor | `pre_milp/ncp_parser.py:1119-1120` | missing | default 0.0 (not used) | none | none |
| Bid volume sign | `pre_milp/ncp_parser.py:1094` | negative p | default absolute value | none | none |
| Bid volume at timestamp | `pre_milp/ncp_parser.py:1127-1129` | no time point | default 0 MW | none | none |
| Bid price | `pre_milp/ncp_parser.py:1131-1143` | missing or negative at the run timestamp | default 0 | WARNING "has no price" / "has a negative price" | `test_a_negative_or_missing_price_of_the_run_timestamp_is_zero_with_a_warning` |
| RD workflow gate | `run_pipeline.py:686-694`, `pre_milp/workflow_gates.py:6-12` | no available preventive unit (and no curative unit with N-X) | exclude (no RD block) | WARNING "No available preventive RD units" | `test_gate_stays_closed_without_available_rd` |
| GLSK SIS file | `pre_milp/glsk_resolver.py:65-70` | missing | default empty GLSK | INFO "GLSK cannot be resolved" | `test_resolve_glsk_no_sis_file_yields_empty_for_all_ras` |
| GLSK bid schedule link | `pre_milp/glsk_resolver.py:81-82` | schedule without RA | skip | none | none |
| Schedule with several units | `pre_milp/glsk_resolver.py:130-137` | more than one unit | warn (factor applied to each) | WARNING "has ... GeneratingUnits" | none |
| Factor time point | `pre_milp/glsk_resolver.py:147-152` | field missing or other timestamp | skip | none | `test_resolve_glsk_wrong_timestamp_yields_empty` |
| Factor value | `pre_milp/glsk_resolver.py:155-162` | not a number | skip | WARNING "non-numeric participationFactor" | none |
| Factors resolved | `pre_milp/glsk_resolver.py:179-190` | none for the RA | default empty GLSK | WARNING "GLSK is empty for this RA" | `test_resolve_glsk_ra_with_no_linkage_at_all_yields_empty` |
| Unit in network | `pre_milp/glsk_resolver.py:197-203` | unit not a network generator | exclude (unit), rest rescaled | WARNING "removed and redistributed" | `test_resolve_glsk_removes_invalid_unit_and_redistributes` |
| Factor total | `pre_milp/glsk_resolver.py:205-215` | total ≤ 0 | default empty GLSK | WARNING "zero total participation factor" | none |
| Normalisation | `pre_milp/glsk_resolver.py:217-220` | always | default rescaled to sum 1 | none | `test_resolve_glsk_normalises_across_two_units` |
| RD block inputs | `milp/milp_builder.py:533-543` | no preventive bid or no GLSK unit | exclude (no RD block) | WARNING "RD block skipped" | `test_rd_block_empty_glsk_guard_adds_nothing` |
| Unit data at build | `milp/milp_builder.py:545-556` | GLSK unit without generator data | exclude (unit) | WARNING "missing from generator_data" | none |
| Unavailable RD RA | `milp/milp_builder.py:514-519` | `available` false | exclude (bids) | none | `test_unavailable_preventive_rd_gets_no_bid_variables_and_no_cost` |
| Lead time | `milp/milp_builder.py:613-627` | timestamp not strictly after radp + lead time | default bounds 0 | INFO "lead_time_h ... not satisfied" | `test_bid_with_unmet_lead_time_gets_zero_upper_bounds` |
| Bid RA in RD list | `milp/milp_builder.py:1690-1698` | bid's RA unknown | default penalty 0 (price kept) | WARNING "penalty component ... defaults to 0.0" | none |
| Group dependency kind | `pre_milp/ncp_parser.py:1190-1191` | not restrictive | skip | none | `test_parse_ra_groups_skips_non_restrictive_dependency` |
| Group dependency links | `pre_milp/ncp_parser.py:1195-1201` | restrictive without group or RA | skip | WARNING "missing RemedialActionGroup or RemedialAction link" | none |
| Group limit value | `pre_milp/ncp_parser.py:1225-1240` | field missing, other timestamp, not a number | skip / default None | none | none |
| Group limit resolved | `pre_milp/ncp_parser.py:1248-1256`, `milp/milp_builder.py:1423-1429` | no limit in either direction | skip (no group constraint) | WARNING "has no resolved maxRegulatingUp/maxRegulatingDown" | `test_group_with_unresolved_limit_adds_no_constraint` |
| Group member bids | `milp/milp_builder.py:1430-1436` | limit but no member bid in the model | skip | WARNING "no member RA has a bid in the model" | `test_group_with_no_member_bid_in_model_adds_no_constraint` |

## 9. Curative RAs

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Any curative PST | `pre_milp/cra_preprocessing.py:37-44` | no available curative PST | default empty availability | WARNING "no available curative PSTs" | `test_no_curative_psts_at_all_returns_empty` |
| Linked contingency | `pre_milp/cra_preprocessing.py:53-60` | curative PST without linked contingency | exclude | INFO "contributes no CRA availability" | `test_pst_with_no_linked_contingency_contributes_nothing` |
| Timing data | `pre_milp/cra_preprocessing.py:62-70` | reaction time or time per stage missing | exclude | WARNING "skipped entirely" | `test_missing_timing_data_skips_pst_entirely` |
| Taps within TATL | `pre_milp/cra_preprocessing.py:73-77` | max curative taps ≤ 0 | exclude (entry unavailable) | none (count in INFO) | `test_max_curative_taps_zero_or_negative_is_not_available` |
| PST is outage element | `pre_milp/cra_preprocessing.py:79-81`, `:87-98` | PST tripped by the contingency | skip (that contingency) | INFO "is itself an outage element" | `test_pst_that_is_an_outage_element_is_not_a_curative_ra_in_that_contingency` |
| Group TSO | `pre_milp/cra_preprocessing.py:191-194` | members of several TSOs | default group kind | WARNING "has members of several TSOs" | none |
| Blocked group | `pre_milp/cra_preprocessing.py:204-213` | member tripped, kind blockedGroup | exclude (group for that contingency) | WARNING "the whole group is unavailable" | `test_outage_member_blocked_group_makes_all_three_unavailable` |
| Reduced group | `pre_milp/cra_preprocessing.py:214-219` | member tripped, kind reducedGroup | skip (tripped member) | INFO "the remaining available members still operate" | `test_outage_member_reduced_group_keeps_remaining_psts_as_a_group` |
| Common delta | `pre_milp/cra_preprocessing.py:232-249` | no common delta tap | exclude (group for that contingency) | WARNING "no common rectified delta tap" | `test_no_common_delta_excludes_the_whole_group_and_logs` |
| Group members left | `pre_milp/cra_preprocessing.py:228-230` | fewer than two considered | skip (no group constraint) | none | none |
| Available entries | `milp/milp_builder.py:699-711` | no available entry | default (no curative PST variables) | INFO "none with available=True" | `test_only_available_entries_get_curative_variables` |
| Group triple variables | `milp/milp_builder.py:775-779` | a member has no variable pair in the contingency | skip | none | none |
| Curative RD contingency | `milp/milp_builder.py:839-855` | RA not linked to a contingency in the N-X LF | skip | INFO (only when no pair at all) | none |
| Unit in operation | `milp/milp_builder.py:868-887` | no GLSK unit with original target_p > 0 | default volumes fixed 0 | INFO "not in operation" | `test_generator_not_in_operation_fixes_curative_volume_to_zero` |
| Curative lead time | `milp/milp_builder.py:896-914` | lead time not met | default bounds 0 | INFO "not satisfied" | `test_blocked_timestamp_forces_curative_volumes_to_zero` |
| Unavailable curative RD | `milp/milp_builder.py:831-836` | `available` false | exclude | none | `test_unavailable_curative_rd_gets_no_variables_and_no_cost` |
| Curative RD without N-X | `pre_milp/workflow_gates.py:10-12` | only curative units, N-X off | exclude | WARNING "No available preventive RD units" | `test_gate_curative_only_rd_opens_only_with_nx` |

## 10. Sensitivities

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| N-0 monitored branches | `pre_milp/n0_sensitivity.py:167-168`, `:277-278` | none | halt | exception "No monitored branch IDs" | `test_compute_sensitivity_pst_n0_raises_on_no_branches` |
| N-0 variables | `pre_milp/n0_sensitivity.py:169-170`, `:279-280` | no available preventive PST (for example all 3W) or unit | halt | exception "No available preventive" | `test_compute_sensitivity_pst_n0_raises_on_no_psts` |
| N-0 loading pre-filter | `pre_milp/n0_sensitivity.py:71-79` | loading < `sensitivity_threshold_pct_*` | exclude (branch not requested) | DEBUG | `test_threshold_filtering_uses_correct_side` |
| 2W transformer list | `pre_milp/n0_sensitivity.py:96-100`, `pre_milp/nx_sensitivity.py:49-53` | unreadable | default (no 3W filter) | ERROR "skipping 3W-transformer PST filter" | none |
| Matrix returned | `pre_milp/n0_sensitivity.py:226-228`, `:335-337` | no matrix for a side | skip (that side) | WARNING "returned no matrix" | none |
| Matrix entry | `pre_milp/n0_sensitivity.py:17-37` | entry unreadable | default NaN (branch excluded at build) | WARNING "sensitivity ... unreadable ... NaN" | `test_an_unreadable_matrix_entry_is_nan_not_zero` |
| Matrix coverage | `pre_milp/n0_sensitivity.py:240-245`, `:349-354` | branch or variable missing | warn | WARNING "Sensitivity matrix missing" | none |
| NaN N-0 sensitivity | `milp/milp_builder.py:1528-1540` | NaN for a branch | exclude (branch) | WARNING "has a NaN N-0 sensitivity" | `test_an_n0_branch_with_a_nan_sensitivity_is_excluded_with_a_warning` |
| Pruning evaluable | `pre_milp/n0_sensitivity.py:432-465` | no PATL or current | default kept | WARNING "could not be evaluated ... conservatively kept" | `test_branch_with_no_patl_is_conservatively_kept` |
| N-0 pruning | `pre_milp/n0_sensitivity.py:432-451` | loading < `min_loading_threshold_pct` or max sensitivity < threshold × limit | exclude (branch from that matrix) | INFO count | `test_branch_below_sensitivity_threshold_is_dropped` |
| N-X inputs | `pre_milp/nx_sensitivity.py:485-496` | no contingency, branch, PST or unit | halt | exception | `test_raises_on_no_available_psts` |
| N-X matrix returned | `pre_milp/nx_sensitivity.py:297-302`, `:408-413` | none for a contingency side | skip | WARNING "no matrix for contingency" | none |
| Duplicate matrix label | `pre_milp/nx_sensitivity.py:162-171` | row or column label twice | default first value | WARNING "returned ... value(s) instead of one" | `test_numpy_read_back_equals_the_per_cell_loc_read` |
| N-X loading filter | `pre_milp/nx_sensitivity.py:214-225` | no limit, no current, or loading < `min_loading_threshold_pct_nx` | skip (entries) | none | `test_branch_below_threshold_dropped_from_sensitivity_dict` |
| N-X magnitude pruning | `pre_milp/nx_sensitivity.py:543-547`, `:563-567` | no limit, or below threshold × limit | skip (entries; pair keeps slack-only constraint) | none | `test_weak_sensitivity_pruned_but_branch_retained` |
| NaN N-X sensitivity | `milp/milp_builder.py:1026-1044` | NaN for the branch under the contingency | skip (pair) | WARNING "pair(s) skipped - NaN sensitivity" | `test_a_pair_with_a_nan_sensitivity_is_skipped_with_a_warning` |
| Entry missing at build | `milp/milp_builder.py:441`, `:642`, `:1130`, `:1159` | no (branch, RA) entry | default 0.0 | none | `test_branch_with_all_sensitivity_pruned_still_gets_slack_only_constraint` |

## 11. Sensitivity guard and reuse

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Reference present | `pre_milp/sensitivity_checks.py:42-44` | no reference current while \|LF current\| > 1 A | invalid set (see actions below) | WARNING "SENSITIVITY GUARD (...)" | `test_a_missing_reference_is_invalid` |
| Reference non-zero | `pre_milp/sensitivity_checks.py:45-46` | reference 0 while \|LF current\| > 1 A | invalid set | WARNING "SENSITIVITY GUARD (...)" | `test_a_zero_reference_with_a_non_zero_load_flow_is_invalid` |
| Reference matches LF | `pre_milp/sensitivity_checks.py:47-49` | relative deviation > 1e-2 (N-X) / 1e-3 (N-0), floor 1 A | invalid set | WARNING "SENSITIVITY GUARD (...)" | `test_a_deviation_beyond_the_tolerance_is_invalid_and_one_within_it_is_not` |
| All-zero N-X set | `pre_milp/sensitivity_checks.py:67-74` | every sensitivity of a contingency 0 while a current > 1 A | invalid set | WARNING "SENSITIVITY GUARD (...)" | `test_all_zero_sensitivities_with_a_non_zero_load_flow_current_are_invalid_even_if_the_reference_matches` |
| Invalid at the first computation | `run_pipeline.py:936-967` | any invalid branch or contingency | halt (`SensitivityGuardError`, summary and status files written) | ERROR "SENSITIVITY GUARD: stopping the run" | `test_invalid_sensitivities_at_the_initial_computation_stop_the_run_with_a_clear_error` |
| N-X reuse | `pre_milp/sensitivity_checks.py:141-167` | invalid contingency with a usable last valid set | default last valid set | WARNING (guard line) + column `stale_reused_sensitivity_contingencies` | `test_an_invalid_set_never_reaches_the_builder_the_stale_one_does` |
| N-X last valid set exists | `pre_milp/sensitivity_checks.py:147-151` | none stored | halt (loop ends `SENSITIVITY_INVALID`) | ERROR "SENSITIVITY GUARD: stopping the loop" | `test_no_earlier_valid_set_ends_the_loop_with_sensitivity_invalid_before_any_build` |
| N-X stored set has an LF | `pre_milp/sensitivity_checks.py:152-156` | contingency has no load flow at the current state | halt (loop) | ERROR "SENSITIVITY GUARD: stopping the loop" | `test_a_stored_set_of_a_contingency_without_a_load_flow_also_stops` |
| Stored set keys | `pre_milp/sensitivity_checks.py:124-130`, `:157-165`, `:189-197` | branch no longer monitored or element no longer available | halt (loop) | ERROR "SENSITIVITY GUARD: stopping the loop" | `test_a_stored_set_whose_keys_no_longer_match_the_model_also_stops` |
| N-0 reuse | `pre_milp/sensitivity_checks.py:182-202` | invalid branch with stored set / without | default last valid set / halt (loop) | WARNING / ERROR | `test_an_invalid_branch_gets_the_last_valid_pst_and_rd_sensitivities_and_the_others_stay_fresh`, `test_no_earlier_valid_set_for_the_branch_stops_the_loop` |
| Reference matrix readable | `pre_milp/n0_sensitivity.py:129-135`, `pre_milp/nx_sensitivity.py:185-190` | reference unreadable | default no reference (then flagged by the first rule) | none | none |

## 12. MILP input, solve, load flow, loops and export

| Check | Where (file:line) | Condition | Action | Logged as | Test |
|---|---|---|---|---|---|
| Something to optimise | `run_pipeline.py:907-919` | PST, RD and N-X inputs all absent | halt (clean exit, preprocessing outputs only) | WARNING "Neither PST, RD, nor N-X has anything to optimise" | none |
| Builder inputs | `milp/milp_builder.py:1500-1506` | PST, RD and N-X inputs all None | halt | exception "nothing to optimise" | `test_both_inputs_none_raises_before_model_creation` |
| PST list | `milp/milp_builder.py:322-323` | PST inputs with an empty list | halt | exception "PST list is empty" | `test_build_n0_milp_model_requires_pst_list` |
| Monitored branches in the loop | `milp/ac_convergence_loop.py:420-422` | no secured branch with PATL | halt | exception "No monitored branches found" | none |
| Solve optimal | `milp/milp_solver.py:91-93`, `milp/ac_convergence_loop.py:570-580` | termination not optimal (incl. time limit) | halt (loop ends `SOLVER_NON_OPTIMAL`, last applied state reported) | ERROR "MILP solve did not terminate optimally" | `test_infeasible_at_iteration_one_stops_with_the_original_network` |
| PST rows | `milp/milp_solver.py:112-118` | model PST not in the PST list | skip | WARNING "not found in PSTList — skipped" | none |
| Generator read-back | `milp/ac_convergence_loop.py:659-668` | empty target_p read-back with an RD solution | halt (loop, before apply) | ERROR "read-back of the network is empty" | `test_an_empty_target_p_read_back_stops_before_anything_is_applied` |
| Apply PST/unit | `milp/post_ra_congestion_check.py:56-62`, `:70-76` | PST or unit not in the network | skip | WARNING "not found in ... — skipped" | `test_unknown_pst_mrid_skipped_not_crash` |
| Post-RA load flow | `milp/ac_convergence_loop.py:676-685` | component 0 not CONVERGED | default (incremental fallback) | WARNING "did not converge ... attempting the incremental fallback" | `test_incremental_fallback_resolves_real_non_convergent_scenario` |
| Fallback has changes | `milp/post_ra_congestion_check.py:192-200` | no tap or MW change to ramp | halt (loop, network reverted) | WARNING "no nonzero PST tap or RD target_p change" | none |
| Fallback steps | `milp/post_ra_congestion_check.py:222-229`, `milp/ac_convergence_loop.py:709-733` | a step does not converge | halt (loop, reverted: `REVERTED_NON_CONVERGENT` / `REVERTED_TO_LAST_CONVERGED_STATE`) | WARNING "Incremental fallback ALSO did not converge" | `test_failure_at_iteration_two_reverts_to_the_last_converged_state` |
| Read-back of taps and target_p | `milp/ac_convergence_loop.py:739-747` | value missing after the load flow | default solved tap / last target_p | none | none |
| Criterion 4 inputs | `milp/ac_convergence_loop.py:811-816` | N-X refresh failed | warn (criterion 4 does not hold) | WARNING "Criterion 4 not evaluated" | `test_is_not_evaluable_when_the_n_x_refresh_failed` |
| Element data for criterion 4 | `milp/ac_convergence_loop.py:310-323` | element without AC current | skip | none | `test_an_element_without_ac_data_is_left_out` |
| Iteration cap | `milp/ac_convergence_loop.py:867-868` | `max_linearisation_iterations` reached | halt (loop, `MAX_ITERATIONS_REACHED`, last solution applied) | INFO "terminated after" | `test_max_iterations_ending_applies_and_load_flows_the_last_solution` |
| Cyclic repetition | `milp/ac_convergence_loop.py:844-864` | cumulative solution within `max_change_ra` of an earlier one | halt (loop, `CYCLIC_REPETITION`, best member kept) | INFO "Cyclic repetition" | `test_an_oscillating_solution_stops_the_loop_with_the_cyclic_status` |
| Cycle re-application | `milp/ac_convergence_loop.py:1037-1053` | selected member does not converge / newest neither | default newest member / halt (`REVERTED_TO_LAST_CONVERGED_STATE`) | WARNING / ERROR "did not converge either" | `test_a_non_converging_re_application_reverts_to_the_newest_member_and_says_so` |
| Completeness cap | `milp/ac_convergence_loop.py:1125-1130` | `max_completeness_iterations` reached | halt (outer loop, flag in summary) | WARNING "max_completeness_iterations=... reached" | `test_stops_at_max_completeness_iterations_without_full_convergence` |
| New congested pair current | `milp/post_ra_congestion_check.py:285-286` | no current on the side | skip | none | none |
| Nothing applied | `milp/ac_convergence_loop.py:886-898` | stop before any applied solution | default (files describe the original network) | WARNING "no solution was applied in this run" | `test_files_describe_the_original_network_not_the_rejected_solution` |
| Final model | `run_pipeline.py:1112-1122` | no model at all | halt (summary with status only) | ERROR "No model describes the network" | none |
| Termination reason | `data_model.py:67-74` | unknown reason string | halt | exception "Unrecognized AC verification termination_reason" | `test_an_unknown_reason_is_still_rejected` |
| Export bid rows | `post_milp/n0_results_export.py:395-397`, `:549-554` | model bid not in the bid list | skip | WARNING "not found in PowerBidList — skipped" | none |
| Export bid RA | `post_milp/n0_results_export.py:556-563` | bid's RA not in the RD list | default penalty 0 | WARNING "penalty_cost_eur defaults to 0.0" | none |
| Export N-X rows | `post_milp/nx_results_export.py:127-129`, `:317-324` | no initial N-X current for the pair | skip | none | `test_pair_without_an_initial_n_x_current_is_skipped` |
| Contingency status reason | `post_milp/nx_results_export.py:253-254` | not converged and no reason recorded | default "no load flow result (reason not recorded)" | none | `test_a_contingency_without_load_flow_and_without_a_recorded_reason_is_not_left_blank` |
| `lf_post_n0.csv` currents | `post_milp/n0_results_export.py:1207-1208` | current missing | default 0.0 | none | none |
| Stale result files | `output_file_registry.py:57-74`, `run_pipeline.py:370-377` | registered file of an earlier run present | skip (file deleted) | INFO "Removed ... stale output file(s)" | `test_pipeline_removes_stale_files_of_an_earlier_run_and_keeps_unrelated_files` |

## 13. Silent drops and defaults

Everything below is dropped or defaulted with no WARNING (at most INFO or DEBUG).

| # | Where (file:line) | What is dropped or defaulted |
|---|---|---|
| 1 | `pre_milp/ncp_loader.py:136-137` | NCP files of unparsed profiles (SSI, CD_OR, ER, PS, RAS, FAP, cross-TSO exports) |
| 2 | `pre_milp/ncp_parser.py:79-84` | Unparsable ISO duration → 0.0 h |
| 3 | `pre_milp/ncp_parser.py:147-156` | SHS time points with a missing field, another timestamp, or no limit link |
| 4 | `pre_milp/ncp_parser.py:187-198` | AE via DCTieCorridor, corridor or OperationalLimit only (INFO) |
| 5 | `pre_milp/ncp_parser.py:210-219` | AE on equipment that is not a CGM line or 2W transformer (INFO) |
| 6 | `pre_milp/ncp_parser.py:227-237` | AE limit side unresolved → side 1 (DEBUG) |
| 7 | `pre_milp/ncp_parser.py:277-278` | AE with exclusion reason and no scanned code → excluded (count only) |
| 8 | `pre_milp/ncp_parser.py:287-295` | Scanned-only AE → secured (DEBUG) |
| 9 | `pre_milp/ncp_parser.py:379-380` | ContingencyEquipment without contingency or equipment link |
| 10 | `pre_milp/ncp_parser.py:398-399` | Missing `normalMustStudy` → not studied |
| 11 | `pre_milp/ncp_parser.py:417` | Contingency with no equipment at all is kept with an empty list |
| 12 | `pre_milp/ncp_parser.py:429` | Must-study flag copied to every timestamp |
| 13 | `pre_milp/ncp_parser.py:517-528` | CurrentLimit without limit set, terminal or sequenceNumber (side map entry missing) |
| 14 | `pre_milp/ncp_parser.py:647-648` | TapPositionAction without GSARA or TapChanger |
| 15 | `pre_milp/ncp_parser.py:688-689` | PST `normalAvailable` missing → not available |
| 16 | `pre_milp/ncp_parser.py:691-693` | PST kind missing or unknown → preventive |
| 17 | `pre_milp/ncp_parser.py:719-728` | TapChanger without a phase-shifting transformer (INFO) |
| 18 | `pre_milp/ncp_parser.py:738-740` | PST low/high step or tap missing → 0 |
| 19 | `pre_milp/ncp_parser.py:742-744` | PST operating range = hardware range (no operating limits read) |
| 20 | `pre_milp/ncp_parser.py:747` | Initial tap outside hardware range → clamped |
| 21 | `pre_milp/ncp_parser.py:820-827` | StaticPropertyRange without link or numeric value |
| 22 | `pre_milp/ncp_parser.py:964-965` | RotatingMachineAction without GSARA or machine |
| 23 | `pre_milp/ncp_parser.py:973-980` | Unparsable ramp rate → None |
| 24 | `pre_milp/ncp_parser.py:999-1000` | RD `normalAvailable` missing → not available |
| 25 | `pre_milp/ncp_parser.py:1002-1004` | RD kind missing or unknown → preventive |
| 26 | `pre_milp/ncp_parser.py:1028` | RD initial production missing → 0.0 MW |
| 27 | `pre_milp/ncp_parser.py:1085-1090` | Bid time points with a missing field or another timestamp |
| 28 | `pre_milp/ncp_parser.py:1094` | Bid volume → absolute value; a repeated time point overwrites the first |
| 29 | `pre_milp/ncp_parser.py:1101-1107` | Bid schedule without RA, or of a non-RD RA (DEBUG) |
| 30 | `pre_milp/ncp_parser.py:1109-1111` | Bid direction missing or not "down" → UP |
| 31 | `pre_milp/ncp_parser.py:1113-1114` | Bid lead time missing → 0 h |
| 32 | `pre_milp/ncp_parser.py:1119-1120` | Bid `penaltyFactor` missing → 0.0 |
| 33 | `pre_milp/ncp_parser.py:1127-1129` | Bid without a time point at a timestamp → 0 MW |
| 34 | `pre_milp/ncp_parser.py:1190-1191` | Non-restrictive RA group dependency |
| 35 | `pre_milp/ncp_parser.py:1225-1240` | RA group time point with a missing field or another timestamp; non-numeric limit → None |
| 36 | `pre_milp/cgmes_loader.py:33-34` | Several EQ files match a TSO → first one used |
| 37 | `pre_milp/cgmes_loader.py:183-192` | Static limit rows that are not permanent CURRENT limits of lines or 2W transformers, or with an unreadable duration |
| 38 | `pre_milp/cgmes_loader.py:420-422` | Tap-changer low/high/tap missing → 0 |
| 39 | `pre_milp/cgmes_loader.py:474` | Generator target_p missing → 0.0 MW |
| 40 | `pre_milp/cgmes_loader.py:311` | `lf_basecase.csv` current = max(i1, i2), a missing side as 0 |
| 41 | `run_pipeline.py:527`, `milp/milp_builder.py:239-240` | Several AEs on one branch → the last one sets limit, type and side |
| 42 | `run_pipeline.py:566-568` | Scanned-list initial loading = max(i1, i2), a missing side as 0 |
| 43 | `pre_milp/scanned_elements.py:55` | Virtual load margin → 0 % |
| 44 | `pre_milp/scanned_elements.py:62` | Scanned PATL missing at a timestamp → 0.0 |
| 45 | `run_pipeline.py:254-262`, `:433` | Unknown TSO names in `pst_group_kind_per_tso` and `max_ra_count_per_*_tso` are not checked (entry unused) |
| 46 | `run_pipeline.py:276-334` | Workflow toggles, RA-count limits, `ra_limit_penalty`, penalty costs and `debug_log_mode` have no type or range check |
| 47 | `run_pipeline.py:352-354` | CRA–XNE linkage fixed off; `linked_xne_mrids` always empty |
| 48 | `pre_milp/glsk_resolver.py:81-82` | Bid schedule without RA in the GLSK chain |
| 49 | `pre_milp/glsk_resolver.py:147-152` | Participation factor time point with a missing field or another timestamp |
| 50 | `pre_milp/glsk_resolver.py:217-220` | Factors rescaled to sum 1; negative factors not checked |
| 51 | `pre_milp/pst_groups.py:25-26` | Preventive PST group with one member |
| 52 | `pre_milp/n0_sensitivity.py:71-79` | N-0 branch with loading below `sensitivity_threshold_pct_*` not requested (DEBUG) |
| 53 | `pre_milp/n0_sensitivity.py:129-135` | Unreadable N-0 reference matrix → no reference |
| 54 | `pre_milp/nx_sensitivity.py:214-225` | N-X entries without limit or current, or below the loading threshold |
| 55 | `pre_milp/nx_sensitivity.py:543-547`, `:563-567` | N-X entries without limit or below the magnitude threshold |
| 56 | `pre_milp/sensitivity_checks.py:40-41` | Missing or NaN load-flow current → the guard treats the branch as valid |
| 57 | `pre_milp/sensitivity_checks.py:77-78` | N-X guard ignores branches that are not monitored |
| 58 | `pre_milp/nx_security_analysis.py:299` | TATL side other than 1/2 → side ONE |
| 59 | `pre_milp/nx_security_analysis.py:311-335` | TATL = PATL with 600 s (INFO per branch) |
| 60 | `pre_milp/cra_preprocessing.py:73-77` | Curative entries with max curative taps ≤ 0 (count only) |
| 61 | `pre_milp/cra_preprocessing.py:228-230` | Curative group with fewer than two considered members |
| 62 | `milp/milp_builder.py:227-229` | AE without PATL at the timestamp left out of the limits |
| 63 | `milp/milp_builder.py:277-278` | N-0 branch below `min_loading_threshold_pct` |
| 64 | `milp/milp_builder.py:441`, `:642`, `:1130`, `:1159`, `:1167` | Missing sensitivity entry → 0.0 |
| 65 | `milp/milp_builder.py:578`, `:866` | Bid volume missing at the timestamp → 0 MW |
| 66 | `milp/milp_builder.py:650-654`, `:941-944` | Generator max_p, min_p or target_p missing at build → 0.0 |
| 67 | `milp/milp_builder.py:775-779` | Curative group triple whose member has no variable pair |
| 68 | `milp/milp_builder.py:843-845` | Curative bid whose RA has no linked contingency in the N-X LF |
| 69 | `milp/milp_builder.py:878-887` | Curative bid fixed to 0 when no GLSK unit is in operation (INFO) |
| 70 | `milp/milp_builder.py:1069-1071` | N-X pair below `min_loading_threshold_pct_nx` |
| 71 | `milp/milp_builder.py:1241-1242` | TATL entry of a non-secured branch |
| 72 | `milp/milp_builder.py:1729` | Curative RD penalty of an RA not in the RD list → 0 |
| 73 | `milp/ac_convergence_loop.py:739-747` | Missing tap or target_p read-back → solved tap / last target_p |
| 74 | `milp/ac_convergence_loop.py:310-323` | Element without AC current left out of criterion 4 |
| 75 | `milp/post_ra_congestion_check.py:139-140` | NaN bus voltages skipped when a voltage snapshot is restored |
| 76 | `milp/post_ra_congestion_check.py:285-286` | Pair without a side current not checked for new congestion |
| 77 | `post_milp/n0_results_export.py:1207-1208` | `lf_post_n0.csv` missing current → 0.0 |
| 78 | `post_milp/nx_results_export.py:127-129`, `:317-324` | Result rows without an initial N-X current |
