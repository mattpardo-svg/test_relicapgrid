# Scalability report

Read-only analysis of the RAO prototype for larger networks, more contingencies and remedial actions, and many runs. No source or test file was changed. Every number is labelled **measured** (on this machine, 16 logical CPUs, Windows, Python 3.12.9, pypowsybl 1.15.0, Pyomo appsi + HiGHS) or **estimated** (extrapolated from the measured unit costs named next to it).

Measurement sources:
- **Fixture run**: `run_pipeline.main()` on `tests/fixtures/CGM_package.zip` + `NCP_pst_fallback_scenario.zip`, N-X on (the mock case of the test suite), wall time per phase with wrappers, plus one cProfile run. A second fixture run on `NCP_generic.zip` (the ReliCapGrid NCP set) is used where noted.
- **MILP benchmark**: `build_n0_milp_model` + appsi HiGHS on synthetic inputs of growing size (B secured branches each with a TATL, C contingencies, P PSTs, G generating units with one UP and one DOWN bid, sensitivity density d).
- **pypowsybl benchmark**: `pp.network.create_ieee300()` (300 buses, 411 branches), the repo's `compute_lf_nx` and `compute_sensitivity_rd_nx` against the raw pypowsybl calls, C = 10 to 400 single-line contingencies, 50 generators.

## 1. Summary

Biggest bottlenecks, ranked by impact at scale:
1. **N-X sensitivities (P1)**: computed for every (contingency × monitored branch × variable), twice per refresh (PST and RD runs), one factor matrix per contingency, read back cell by cell in Python. At 150 contingencies × 411 branches × 50 units: 118 s per call, of which 86 s is the Python read-back (measured). Cubic in size; not feasible for L.
2. **MILP build + Pyomo translation (P2)**: every N-X row loops over all PSTs and units; the whole model is rebuilt and re-translated every iteration. 45k pairs (10% density): build 65 s + translation 303 s + 9.2 GB peak, while HiGHS needed 15 s (measured).
3. **Model size (P4)**: with all thresholds 0 every (branch, contingency) pair gets a PATL and a TATL row; curative magnitude rows grow with PSTs × branches × contingencies. 66% of the fixture's N-X rows can never bind (measured).
4. **`compute_lf_nx` post-processing (P3)**: 53.7 s for 150 contingencies where pypowsybl needed 0.29 s (measured); repeated after every applied iteration.
5. **EQ parsing with rdflib (P5)**: each EQ file is parsed twice; 8.5 s of the 16.2 s fixture run (52%, measured).

Top 5 changes (all without changing results):
- Q3 + Q4, sensitivities: one `ALL`-context factor matrix (5.4× faster, identical values) and a vectorised read-back (86 s → 0.3 s, measured). Together, the N-X sensitivity call at C = 150 drops from about 118 s to about 4 s (estimated).
- Q2, `compute_lf_nx`: vectorised read-back; the call drops to near the raw 0.3–0.6 s (estimated from the measured raw time).
- Q1, EQ parsing: parse each EQ file once, about −4.2 s (−26%) on the fixture (measured half of 8.5 s).
- B1, MILP: build rows only from non-zero coefficients and skip rows that can never bind; build cost becomes linear in non-zeros and fixture rows drop by about 66% (estimated from measurements).
- Q5, threads: OpenLoadFlow `threadCount` for the sensitivity analysis: 1.8× at 8 threads with identical results (measured).

## 2. Size model and scenarios

Size drivers: N buses; L branches; B_s secured and B_n scanned branches (B = B_s + B_n monitored), B_t secured branches with a TATL; C must-study contingencies; P PSTs (preventive and curative); G RD generating units, bids ≈ 2G; P_c curative PSTs and C_l the contingencies linked to them; T TSOs; one timestamp (multi-timestamp is out of scope; it would multiply everything by the number of timestamps); I inner (linearisation) iterations, K outer (completeness) iterations.

| Driver | S (fixture, measured) | M (~10×, estimated) | L (~100×, estimated) |
|---|---:|---:|---:|
| Buses N | 275 | 3,000 | 30,000 |
| Branches L | 397 | 4,000 | 40,000 |
| Secured B_s (all with TATL, B_t) | 29 | 300 | 3,000 |
| Scanned B_n | 0 | 300 | 3,000 |
| Contingencies C | 16 (22 in the generic fixture) | 200 | 2,000 |
| Generators | 113 | 1,100 | 11,000 |
| PSTs P | 12 | 50 | 200 |
| RD units G (bids ≈ 2G) | 32 | 300 | 3,000 |
| TSOs (with NCP data) | 7 (4) | 15 | 40 |
| Timestamps | 1 | 1 | 1 |
| Inner I / outer K iterations (cap 10 / 5) | 3 / 1 | 5–10 / 1–3 | 10 / 3–5 |
| **N-X rows ≈ (2·B_s + B_n)·C** (quadratic) | 924 | 180,000 | 18,000,000 |
| **N-X sensitivity entries C·B·(P+G)** (cubic) | ~20,000 | 42,000,000 | 3.8·10¹⁰ |
| **N-X non-zeros, dense ≈ rows·(2P + 2·bids)** (cubic) | 49,875 (all rows) | ~1.3·10⁸ | ~10¹¹ |
| **Curative magnitude rows P_c·B_t·C_l** (cubic) | 406 | ~10⁶ | ~10⁸ |
| **`compute_lf_nx` read-back C·B** (+C²·B mask, quadratic) | 464 | 120,000 | 12,000,000 |
| Solves per run (≤ I·(K+1), worst case 60) | 3 | 10–30 | 30–60 |

The fixture model has 1,193 variables (16 binary, 28 integer), 1,568 rows and 49,875 non-zeros. `nx_patl_loading` and `nx_tatl_loading` hold 924 rows and 47,240 non-zeros, which is 95% (measured).

## 3. Time and memory per phase

S is measured on the fixture run (16.2 s wall in total). M and L are estimated from the unit costs in the last column. "Per run" multiplies by the number of calls.

| Phase | Calls per run (S) | S measured | Share of S | M estimated | L estimated | Basis |
|---|---|---:|---:|---:|---:|---|
| CGM load (`load_cgm`) | 1 | 1.74 s | 11% | ~15 s | ~150 s | linear in network size |
| NCP RDF parsing (AE, CO, RA, SHS, SIS) | 29 parses | 0.44 s | 3% | ~5 s | ~50 s | rdflib ≈ 0.5 s/MB (measured) |
| EQ RDF parsing (two maps per TSO) | 8 parses (4 files ×2) | 8.46 s | 52% | ~170 s | ~1,700 s, multi-GB per file | 0.5 s/MB × 2 parses |
| Initial AC load flow | 1 | 0.016 s | 0% | ~0.2 s | ~3 s | |
| N-0 sensitivities (PST + RD) | 6 analyses | 0.13 s | 1% | ~5 s per run | ~1 min per run | B·(P+G) factors |
| N-X security analysis + `compute_lf_nx` | 4 | 0.91 s | 6% | ~100 s per call | ~10⁴ s per call | Python read-back 0.8 ms per (contingency, branch) (measured, IEEE 300) |
| N-X sensitivities (PST + RD runs) | 3 refreshes (6 analyses) | 1.21 s | 7% | ~1,900 s per refresh, ~8 GB of dicts | not feasible (10¹⁰ entries) | ~41–46 µs per entry (measured, IEEE 300) |
| TATL data, CRA availability | 1 | 0.04 s | 0% | <1 s | ~10 s | |
| MILP build (Pyomo) | 3 | 0.53 s | 3% | ~460 s per build | not feasible | 7.3 µs per (row × RA) (measured) |
| Pyomo → HiGHS translation (appsi) | 3 | 0.97 s | 6% | ~600 s at 10% density, ~18 GB | not feasible | 25–47 µs and ~1.4 KB per non-zero (measured) |
| HiGHS run | 3 | 0.13 s | 1% | unbounded (no limit) | unbounded | data dependent: 0.04 s (fixture) to 543 s (synthetic 1k rows, dense) |
| AC load flow after apply | 3 | 0.03 s | 0% | ~1 s per run | ~10–50 s per run | fallback ×5 steps when needed |
| Post-RA check, convergence, exports | — | ~1.6 s (rest) | 10% | minutes | hours (sensitivity CSVs) | sensitivity_*_nx.csv ≈ 70 B per row |
| **Total wall** | | **16.2 s** | | **hours per run** | **not feasible as built** | |
| **Peak memory (process working set)** | | **384 MB** | | **> 30 GB** | **not feasible** | 9.2 GB measured at 6.4 M non-zeros |

The generic fixture (`NCP_generic.zip`, 22 contingencies, model with slacks only) took 12.4 s, of which EQ parsing was 8.4 s (68%, measured).

## 4. Bottlenecks

| ID | Location | What scales badly | Evidence | Impact M / L |
|---|---|---|---|---|
| P1 | `pre_milp/nx_sensitivity.py:93-127` (one `add_factor_matrix` per contingency, all monitored branches × all variables), `:244-264` and `:360-379` (per-cell `matrix.loc`), `:158-161` (loading filter applied after the analysis), `run_pipeline.py:972-1000` (separate PST and RD analyses each refresh) | C·B·(P+G), cubic. Twice per refresh. Dict of tuple keys. | Measured, IEEE 300: C = 150 call 118 s, raw pypowsybl 32 s; C = 400 call 265 s, raw 70 s. One ALL matrix 3.2 s vs 16.9 s for per-contingency matrices, identical values. Vectorised read of 150 matrices 0.28 s. | M: ~30 min per refresh, GBs of dicts. L: not feasible (10¹⁰ entries). |
| P2 | `milp/milp_builder.py:438-447`, `:640-645` (N-0 effect over all PSTs and units), `:1117-1173` (N-X effect over all RAs per pair), `:1163-1171` (curative RD term scans all curative (unit, contingency) pairs per row), `milp/ac_convergence_loop.py:537` (full rebuild each iteration), `milp/milp_solver.py:73` (appsi translation each solve) | Build ∝ rows × (P+G) even when sensitivities are zero. Translation ∝ non-zeros, memory ~1.4 KB per non-zero. Curative RD scan ∝ rows × curative pairs (quadratic in C). | Measured: build 0.57 s (480 pairs) → 2.7 s (5k) → 65 s (45k), identical for density 1.0 and 0.1. Translation 0.41 s (88k nnz) → 21.5 s (2.5M) → 303 s (6.4M); peak 145 MB → 825 MB → 9.2 GB. Fixture: translation is 88% of solve time (0.97 of 1.10 s). | M: ~15–20 min per iteration. L: not feasible. |
| P3 | `pre_milp/nx_security_analysis.py:126-163` (per contingency a boolean mask over all result rows, then `.xs` per branch) | C·B lookups plus a C²·B mask, quadratic. Runs once per applied iteration, plus the cycle exit. | Measured, IEEE 300: C = 150: 53.7 s vs raw security analysis 0.29 s; C = 400: 91.7 s vs 0.63 s. | M: ~100 s × (I+1) per run. L: hours per call. |
| P4 | `config/rao_config.yaml:74,85,89` (all thresholds 0.0), `milp_builder.py:1075` (all secured pairs), `:1232-1247` (TATL rows for every pair, no pre-filter), `:753-770` + `pre_milp/cra_preprocessing.py:52-90` (magnitude rows per (PST, branch, contingency)) | Rows ∝ (2·B_s + B_n)·C; curative rows ∝ P_c·B_t·C_l. | Measured, fixture: 303 of 462 PATL and 303 of 462 TATL rows can never bind (current + Σ\|coef\|·max movement ≤ limit, with taps ≤ 6 per TSO and bid availability). Synthetic: curative rows 7k vs 1k without (480 pairs), 131k at 5k pairs. | Most rows and non-zeros of M are rows that cannot bind. |
| P5 | `run_pipeline.py:445` and `:448` → `ncp_parser.py:496` and `:551` → `_load_graph` (`ncp_parser.py:91-93`, rdflib full-graph parse) | Same EQ file parsed twice per TSO; rdflib ≈ 0.5 s/MB and builds every triple in memory. | Measured: 8 EQ parses = 8.46 s of 16.2 s; 208k triples parsed in the run. | M: ~3 min; L: ~30 min and several GB per large file. |
| P6 | `milp/milp_solver.py:63-79` | No time limit, no MIP gap, no thread setting; a hard MIP runs until optimal. A limit today would end the run as `SOLVER_NON_OPTIMAL` (DECISIONS 23). | Measured: synthetic 1,067-row dense instance needed 543 s to optimality; with a 10 s limit it stops at the limit. Fixture 0.04 s per solve. | Unbounded at M/L; integer taps (`milp_builder.py:57`, `:370`) and RA binaries make it harder. |
| P7 | `milp/ac_convergence_loop.py:754-756` (`annotate_latest_member(model=…)`), `operating_point_state.py:167`, `:115-116` (deep copies) | Every applied model of the run is kept for the cycle exit: memory ∝ solves × model size. | Code: one Pyomo model per member record. Model memory ~1.4 KB per non-zero (measured). | M: n × 10+ GB. |
| P8 | `run_pipeline.py:759`, `:773` → `nx_sensitivity.py:293-299` (sensitivity_pst_nx.csv, sensitivity_rd_nx.csv) | One row per (contingency, branch, variable). | Measured: fixture 1.04 MB + 0.44 MB for ~20k entries (~70 B/row). | M: ~3 GB; L: not writable. |
| P9 | `ac_convergence_loop.py:447-490`, `:761-776`, `:1088-1107` | Each inner iteration repeats 4 sensitivity analyses, a full rebuild + translation and a full N-X security analysis; up to I·(K+1) = 60 times. | Measured fixture: 3 iterations, 4 security analyses, 6 N-X and 6 N-0 sensitivity analyses. | Multiplies P1–P3 by 10–60. |
| P10 | `pre_milp/lf_parameters.py:35-38`, `nx_sensitivity.py:124`, `n0_sensitivity.py:204` (no `threadCount`); `run_pipeline.py:98-99`, `:333`, `:339` (fixed `input/`/`output/`, root log handler, deletes registered outputs) | Contingencies are computed single-threaded; two runs in one checkout overwrite each other. | Measured: sensitivity 32.3 s → 27.8 s (4 threads) → 17.6 s (8 threads), identical results. | Parallel runs need separate folders or processes. |

## 5. Optimisation proposals

Ranked by gain / effort / risk. "Risk" means risk to results; every one is meant to keep objective and selected actions identical.

| ID | Change | Expected gain | Effort | Risk | Protecting test | Frozen name / decision |
|---|---|---|---|---|---|---|
| Q3 | N-X sensitivity: one factor matrix per side with `ContingencyContextType.ALL` instead of one per contingency (the code comment at `nx_sensitivity.py:83-86` only rules out several IDs with `SPECIFIC`); read matrices with numpy (`to_numpy`, index lookup) instead of per-cell `.loc`, keeping the duplicate-row rule (first value) and NaN rule | P1: 5.4× on pypowsybl (measured), read-back 86 s → 0.3 s (measured); call ~118 s → ~4 s at C = 150 (estimated) | S | low | New test: values of the vectorised read equal the cell-by-cell read on a small network (IEEE 14) including a duplicate row and a NaN; existing `test_rao_nx_sensitivity.py` | none; DECISIONS 12 guard unchanged (same reference matrices) |
| Q2 | `compute_lf_nx`: build `{contingency: {branch: (i1, i2)}}` in one pass over `branch_results` (groupby or `to_dict`) instead of mask + `.xs` per branch; same NaN/missing rules | P3: 53.7 s → ~0.5 s at C = 150 (estimated from raw 0.29 s) | S | none | `test_rao_nx_security_analysis.py` (usable/skip rules); add a vectorised-vs-old equality test | none |
| Q1 | Parse each EQ file once (one graph for both maps, or a small cache keyed by path in `_load_graph`) | −4.2 s (−26%) on the fixture (half of 8.46 s measured) | S | none | `test_rao_ncp_parser.py`, `test_rao_cgmes_loader.py` | `build_current_limit_side_map` and `build_tap_changer_to_transformer_map` are frozen: keep them, add an optional graph argument |
| Q4 | Builder: pre-index sensitivities as `{(contingency, branch): [(ra, value)]}` and sum only non-zero entries; index curative (unit, contingency) pairs by contingency (`milp_builder.py:1163-1171`) | Build ∝ non-zeros instead of rows × RAs: at 10% density about 10× (estimated from 7.3 µs per row×RA); HiGHS already drops zero coefficients (measured 88,406 vs 10,238 non-zeros) | S–M | none (same coefficients) | Model equality test: same constraint set, same coefficients and objective (compare `generate_standard_repn`) on the fixture model | none |
| Q5 | Set OpenLoadFlow `threadCount` (security and sensitivity provider parameters) from config | Sensitivity 1.8× at 8 threads (measured); security analysis small at S | S | none (bit-identical in the measurement) | `test_rao_lf_parameters.py` (parameters reach every call) | DECISIONS 10 (one parameter set everywhere): extend it, do not split it |
| Q6 | Run PST and RD N-X sensitivities in one analysis (two variable sets, same contingencies) | Halves the post-contingency load flows of each refresh (estimated) | S | low (same parameters; verify equality) | Equality test PST/RD values one-run vs two-run | DECISIONS 12 guard: keep both reference sets |
| B1 | Skip N-X rows that can never bind (current + Σ\|coef\|·max movement ≤ limit, using tap bounds, per-TSO tap cap, bid availability and curative bounds); keep the pair sets for monitoring, exports and `find_new_congested_pairs` (`run_pipeline.py:1002-1010` counts pairs not in the model as new) | Fixture: 606 of 924 N-X rows (66%, measured); translation and build in proportion | M | low (exact: the slack is 0 in such rows) | Fixture: objective, taps and MW identical with and without; convergence and completeness counts identical | Interacts with the completeness loop and `included_in_milp`: needs care, no decision change |
| B2 | Build the model once per completeness iteration and update only changing data (baselines, sensitivities) with mutable Params / appsi persistent updates, or assemble the HiGHS matrix directly (numpy CSR → `highspy.passModel`) and keep Pyomo only for result reading | Build + translation are 88% of solve time at S and >95% at 45k pairs (measured); a CSR build is typically 10–100× faster (estimated) | L | low (verify identical LP) | Model-equality test (LP file or matrix) on fixture and synthetic cases | Exporters and the convergence check read Pyomo components (`model.pst_ids`, `nx_*` sets, `pyo.value`): a direct HiGHS build needs an adapter; `build_n0_milp_model` and the input classes are frozen names |
| B3 | Restrict the N-X sensitivity functions to the branches that can appear in rows (after B1 or with a loading threshold) and variables to RAs relevant for those branches | Reduces C·B·(P+G) by the share of dropped branches (estimated 60%+ on the fixture shape) | M | none if restricted to rows that are built; **needs a decision** if a positive loading threshold is used | Fixture equality test | Thresholds are config (`min_loading_threshold_pct_nx`, `sensitivity_threshold_pct_*_nx`); a non-zero default changes results and needs a decision |
| B4 | Solver limits: HiGHS `time_limit` and `mip_rel_gap` from config, and accept a feasible incumbent at the limit | Caps worst-case solve time (P6) | S | **needs a decision**: today a non-optimal termination stops the run (DECISIONS 23); a gap changes the selected actions | `test_rao_milp_solver.py` (termination handling) | DECISIONS 23 |
| B5 | Keep only results (rows, values) of earlier members instead of whole models for the cycle exit | Memory ∝ one model instead of all (P7) | M | low | `test_rao_ac_convergence_loop.py` cycle-exit tests | DECISIONS 7 behaviour must stay |
| B6 | Make `sensitivity_*_nx.csv` optional or compressed above a size | Avoids GB-scale files (P8) | S | none for results; **needs a decision** (documented output files, User_Guide) | `test_rao_output_file_registry.py` | Output file registry |
| B7 | Many runs: run each in its own process with its own input/output folder (parameterise `INPUT_DIR`/`OUTPUT_DIR` instead of module constants) | Linear speed-up with cores for independent runs, timestamps or regions (estimated) | M | none | Two concurrent fixture runs give the same files as one run | `run_pipeline.py` path is frozen; module constants are used by tests via monkeypatch |

## 6. Quick wins and bigger changes

**Quick wins** (small, safe, no decision needed): Q2 (`compute_lf_nx` read-back), Q3 (ALL-context matrix + vectorised read), Q1 (one EQ parse), Q5 (`threadCount`), Q4 (sum only non-zero sensitivities; index curative pairs by contingency), Q6 (one N-X sensitivity analysis). Together they remove the measured Python overheads of P1, P3 and P5: on the fixture about −5 s of 16 s; at C = 150 on IEEE 300 the N-X calls go from ~170 s to ~5 s per refresh (estimated).

**Bigger changes**: B1 (skip never-binding rows), B2 (build once / direct HiGHS matrix), B3 (restrict N-X sensitivity functions), B5 (do not keep every model), B7 (process-level parallelism). B4 and B6, and B3 with a positive threshold, need a decision.

Without B1–B3 the M scenario stays at hours per run and tens of GB. L needs B1–B3 and a lazy constraint scheme (start from loaded or near-limit pairs and let the completeness loop add the rest), which changes the model at intermediate steps and needs a decision (DECISIONS 2, 3).

## 7. Test and benchmark proposal (not built)

- **Synthetic scenario generator**: take a pypowsybl test network (IEEE 14/118/300) or replicate the fixture CGM, and generate AssessedElements (secured/scanned share), contingencies (single and double branch outages), PSTs (on transformers with a phase tap changer added), RD units with UP/DOWN bids and GLSK, curative PSTs linked to contingencies, and TATLs. Parameters: N, B_s, B_n, C, P, G, P_c, sensitivity density, loading distribution. Write it as CGM/NCP zips so the full pipeline runs, plus a direct-input mode that calls `build_n0_milp_model` (like the benchmark used here).
- **What to measure** per phase (as in section 3): wall time and calls, peak working set, model rows/columns/non-zeros per family, HiGHS time vs translation time, iterations (inner/outer), output file sizes, and result fingerprints (objective, taps, MW per unit, convergence reason) to prove that an optimisation keeps results identical.
- **Scales**: S/M/L as in section 2 with a time budget per scale; run in CI only S, M on demand.
- **Regression guard**: a benchmark test marked slow that fails if the fixture run time or model size grows by more than a set percentage.

## 8. Not analysed / unsure

- No real large CGM/NCP data was available: M and L are extrapolations from unit costs measured on the fixture, synthetic MILPs and IEEE 300. The real sensitivity density at threshold 0 is unknown (it decides non-zeros); 10% was used for the large synthetic cases.
- HiGHS time on realistic large instances is unknown: the synthetic random data is harder than the fixture (543 s vs 0.04 s per solve). HiGHS thread options were not tested.
- The ALL-context sensitivity was measured for `BRANCH_CURRENT_1` with generator variables; PST (`TRANSFORMER_PHASE`) variables and `BRANCH_CURRENT_2` were not tested; the comment at `nx_sensitivity.py:83-86` reports an exception for several IDs with `SPECIFIC` only.
- `threadCount` results were bit-identical for the security analysis and the first 20 sensitivity matrices at 1/4/8 threads; not checked on the fixture network.
- The never-binding count (B1) uses tap movement ≤ 6 (per-TSO cap) and a curative movement bound of 34 taps; a tighter or looser bound changes the share, not the exactness.
- cProfile inflates pure-Python code; shares in section 3 come from the unprofiled wall-time run.
- Not analysed: the GUI (`src/rao_pages/`), multi-timestamp behaviour, pypowsybl CGM import options, disk I/O of the zip extraction, and log volume at debug level (the fixture run log is 28–44 KB).
