# RAO prototype: design overview

Reference document. Not for agents. Written 2026-10-12 from the earlier technical references and the code analysis, then checked against the decisions up to DECISIONS 39 in `docs/`. If this file and the code or `docs/DECISIONS.md` disagree, the code and `docs/` are right.

For the equations see `MILP_Mathematical_Formulation.md`. For spec coverage see `../release_plan/Spec_Coverage.md`. For input checks see `Data_Validation_Reference.md`. For run time and memory see `Scalability_Report.md`.

---

## 1. What it does

Input: one CGM zip (CGMES network) and one NCP zip (per-TSO assessed elements, contingencies, remedial actions, schedules, bids). Output: CSV files in `output/` with the proposed remedial actions and the resulting loadings.

It finds a cheap set of remedial actions (RAs) that removes overloads on secured elements, now (N-0) and after contingencies (N-X), for **one timestamp** (`START_HOUR`). Other timestamps are parsed but not optimised; they only appear in the lead-time report.

RA types:
| Type | Preventive (PRA) | Curative (CRA) |
|---|---|---|
| PST (tap changers) | yes, continuous tap in the MILP, integer when applied | yes, per contingency, continuous |
| RD (redispatch of generating units, with GLSK) | yes, up and down, balanced | yes, per contingency |

Curative actions are optimised in every solve but **never applied** to the network. Only preventive actions are applied.

Not built: generator physics (ramps, min up/down), HVDC, countertrade, multi-timestamp optimisation, topological RAs, SPS. See `../release_plan/Spec_Coverage.md`.

## 2. Pipeline

1. **Load and parse.** CGM into a pypowsybl network; NCP files classified per TSO; TSO names from the Organisation profile.
2. **Classify assessed elements.** Each is exactly one of SECURED, SCANNED, EXCLUDED. No secured or scanned code and no exclusion reason: EXCLUDED and not optimised. Scanned-only without exclusion stays SECURED (real data uses it that way).
3. **Limits.** PATL order: SHS schedule, then BaseCaseCurrentLimit, then CGM static limit, then 0 with a warning. PATL <= 0 is excluded. TATL: if missing, several, or incomplete, TATL = PATL with 600 s.
4. **Initial state.** AC load flow (`lf_initial`, current per side). A missing current becomes NaN and the branch is excluded with a warning.
5. **Sensitivities.** N-0 PST (A/degree) and RD (A/MW), pruned below a threshold. N-X via security analysis (`lf_nx`, contingency propagation off) and N-X sensitivities.
6. **RA preprocessing.** Tap bounds and degrees per tap, PST groups, GLSK, RA groups and limits, bid lead times, curative availability.
7. **Nested loop** (section 3), then **export** (section 5).

All load flows and analyses use one parameter set from `pre_milp/lf_parameters.py` and `config/load_flow_config.yaml` (`MAIN_SYNCHRONOUS` component mode, reactive limits off by default).

## 3. The loops

The MILP uses a linear sensitivity approximation, so its answer must be checked on the real AC network.

**Inner loop (linearisation).** Build the cumulative MILP at the current operating point, solve, apply the preventive result to the network, run an AC load flow, check convergence, rebuild with refreshed baselines and sensitivities.

**Outer loop (completeness).** After the inner loop, look at the N-X load flow at the current state; if new congested (branch, contingency) pairs appear, add them and run the inner loop again, up to the completeness limit.

Key rules:
- **Apply, then check.** A solution counts only after an AC load flow converged on it.
- **State object.** `OperatingPointState` holds the frozen original and the current operating point; every baseline (taps, target P, N-0 and N-X load flows, sensitivities) is refreshed from the current state in each iteration.
- **Cumulative MILP.** Variables are totals against the original network: per-TSO tap limit, RD bid headroom and RA count refer to the original; costs are priced against the original.
- **Convergence criteria (any one is enough).** 1: sum of RA change below threshold. 3: each RA change below threshold. 4: change of AC overloads below threshold. Criteria 2 and 5 are not applicable.
- **Cycle exit.** If a later solution repeats an earlier one, the member with the lowest AC overload is kept and re-applied.
- **Load-flow failure.** First try an incremental fallback (small steps from the last good state). If that fails, revert the network to the last converged state (the original at iteration 1). Result files then describe only what was applied.
- **Sensitivity guard.** Sensitivities are compared with the load flow at the same state. On failure the last valid set is reused; with none, the run ends with `SENSITIVITY_INVALID`.
- **Non-optimal solve.** The run ends cleanly with the last applied state and status `SOLVER_NON_OPTIMAL`; result files are still written.

Termination statuses: `CONVERGED`, `CYCLIC_REPETITION`, `MAX_ITERATIONS_REACHED`, `REVERTED_NON_CONVERGENT`, `REVERTED_TO_LAST_CONVERGED_STATE`, `SENSITIVITY_INVALID`, `SOLVER_NON_OPTIMAL`, `NOT_APPLICABLE`.

## 4. The MILP in one page

- **Variables:** preventive PST taps (up and down parts), preventive RD upward and downward volumes per unit, curative PST and RD per contingency, overload slacks, binary RA-activation variables for the RA count limit.
- **Objective:** RA costs (PST penalty, RD penalty and energy price) plus penalties on overload slacks. Activation and start-up costs are not in the objective.
- **Constraints:** PST group equality; tap and per-TSO limits; Pmax/Pmin and balancing for RD through GLSK; bid lead times; RA count per TSO; RA group volume limits; N-0 loading on secured branches (with slack); N-0 scanned elements (hard by default); N-X PATL and TATL pairs (with curative effect); N-X scanned pairs with limit max(PATL, original N-0 current).
- **Solver:** HiGHS via `appsi_highs`. Optional time limit and relative MIP gap from `performance.*` in `rao_config.yaml` (both off by default).

## 5. Outputs

29 registered files (`output_file_registry.py`). Groups:
- **Preprocessing:** `lf_basecase`, `co_flat_list`, `glsk_resolved`, `pst_cra_availability`, sensitivity files, `lf_nx_initial`.
- **Results:** `results_pst`, `results_preventive_rd`, `results_curative_pst`, `results_curative_rd`, `results_curative_pst_groups`, `results_generating_units`, RA count and RA group files, `results_summary`, `results_iteration_history`, `results_completeness_iterations`, `results_contingency_status`, `results_nx_loadings`, `results_nx_scanned_elements`, `lf_post_n0`.
- `output/` is cleaned at the start of each run. Each result file carries the status of the run so it says whether its solution was applied.

## 6. Why it is built this way

| Choice | Reason |
|---|---|
| Apply then check | The spec's order; a solution that does not converge in AC cannot be trusted. |
| Cumulative MILP with refreshed baselines | An earlier hybrid mixed original and applied baselines and produced inconsistent results. |
| Curative never applied | Curative actions only exist after a contingency; they must not change the base state. |
| One load-flow parameter source | Some analyses ran with pypowsybl defaults and gave zero or 23 % lower sensitivities. |
| Contingency propagation off | With it on, the security analysis tripped extra equipment that the sensitivity analysis did not, so the references disagreed. Not reproduced for the busbar contingency (open). |
| No warm start for the N-X refresh | Measured: no effect on mock data. |
| No silent defaults | Every default or dropped input logs a warning and is listed in `docs/ASSUMPTIONS.md`. |
| Scanned constraint hard by default | The spec treats it as a must-hold; switchable in config. |

## 7. Glossary

| Term | Meaning |
|---|---|
| CGM / CGMES | Common Grid Model, the network (EQ, SSH, SV, TP, boundary) |
| NCP | Network code profiles: per-TSO AE, CO, RA, SHS, SIS, Organisation files |
| AE / XNE | Assessed element (monitored branch) / cross-border network element |
| Secured / scanned / excluded | Hard-limited element / monitored with effective limit max(PATL, initial loading) / ignored |
| PATL / TATL | Permanent / temporary admissible transmission loading (A or kA) |
| N-0 / N-X | Base case / after contingency X |
| PST | Phase-shifting transformer; tap change gives degrees; sensitivity in A/degree |
| RD | Redispatch of generating units; sensitivity in A/MW |
| GLSK | Generation shift key: how an RD bid is spread over generating units |
| PRA / CRA | Preventive / curative remedial action |
| RADP | RA deciding point (time from which lead times count) |
| SHS / SIS | Schedule profiles: time-dependent limits / power bids and RA group limits |
| Slack | Overload the model accepts at a penalty |
| mRID | CIM identifier, the key of every element |
