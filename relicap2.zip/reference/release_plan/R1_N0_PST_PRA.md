> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R1 — N-0 Single-Timestamp MILP: PST PRA Only

**Goal:** First end-to-end solve. One timestamp, N-0 constraints only, PST degrees of freedom
only. Establishes the MILP scaffold, sensitivity call, linearisation loop, and HiGHS integration.
Every subsequent release adds to this scaffold.

**Prerequisite:** R0 complete — `network`, `AEFlatList`, `PSTList`, `TSO_NAME_MAP` available in memory.

**Stack:** pypowsybl 1.15.0 (AC LF + AC sensitivity via `pp.sensitivity.create_ac_analysis()`),
Pyomo (`ConcreteModel`) + HiGHS via `highspy` (persistent solver interface), Python

**MILP solver setup:** Pyomo is the modelling layer; HiGHS is the solver, invoked via `highspy`
(installed with `pip install highspy pyomo`). The solver can be swapped by changing the
`SolverFactory` call without touching the model definition.

**Default tap mode:** `pst_taping_discrete = True` — PST tap change variables are integer by
default (`pyo.NonNegativeIntegers`). Set `pst_taping_discrete = False` for continuous relaxation
(`pyo.NonNegativeReals`).

**Variable naming convention:** All Pyomo variables and parameters use full descriptive names
aligned with the spec. Short abbreviations (e.g. `dr_pos`, `op_max`, `c_tau`) are not used.
Names should be self-explanatory without referring back to the spec.

---

## Deferred items (R1 scope)

| Item | Reason deferred |
|------|----------------|
| CORNET-103 — PST consideration in LF (PV/PQ, ramp control) | pypowsybl handles LF internals; prototype just calls it |
| CORNET-104 — PV/PQ conversion | pypowsybl internal |
| CORNET-105 — Active power control | pypowsybl internal |
| CORNET-111 — Initial LF non-convergence handling | Handled in R1.1; only log and stop, no re-try logic needed |
| CORNET-106 — Non-convergent LF approximated solution | Out of scope for prototype; treat non-convergence as fatal |
| CORNET-107/109 — LF result output per topological node / 3W transformer | Per-node voltage/angle export and 3W transformer winding results deferred; branch results covered in R1.9 |
| Multi-timestamp extension | Added in R2 |

---

## R1.1 — Initial AC load flow convergence check (CORNET-111)

**Spec ref:** CORNET-111 — Initial LF calculation with non-convergence

**What it delivers:**
- Using the `network` object loaded in R0.1, run the initial AC LF via pypowsybl:
  ```python
  import pypowsybl as pp
  lf_result = pp.loadflow.run_ac(network)
  converged = lf_result[0].status.name == 'CONVERGED'
  ```
- If non-convergent: log a fatal error and halt the RAO procedure (no optimisation attempted)
- If convergent: extract branch currents and build the MRID-keyed result dict for use
  in sensitivity computation and MILP construction
- Build the branch name-to-MRID mapping from the pypowsybl network object:
  ```python
  lines_df = network.get_lines()            # index = mRID
  trafos_df = network.get_2_windings_transformers()  # index = mRID
  # branch_mrid_to_name: dict[mrid, name] built from both DataFrames
  ```
- Extract per-branch currents from pypowsybl results:
  ```python
  lines_res   = network.get_lines_results()           # columns: i1, i2 (A)
  trafos_res  = network.get_2_windings_transformers_results()  # columns: i1, i2 (A)
  ```
  Use `max(i1, i2)` per branch as the representative current magnitude in A
- Build `lf_initial: dict[branch_mrid, float]` — current in A keyed by mRID

**Inputs:**
- `network` (pypowsybl `Network` from R0.1)

**Outputs:**
- `lf_initial: dict[branch_mrid, float]` — current magnitude in A keyed by branch mRID,
  populated from `network.get_lines_results()` and
  `network.get_2_windings_transformers_results()` using `max(i1, i2)`
- `branch_mrid_to_name: dict[mrid, name]` — built once from `network.get_lines()` and
  `network.get_2_windings_transformers()` index and `name` column;
  used throughout R1 to label results
- Console log: convergence status, component count, slack bus imbalance MW

**Acceptance criteria:**
- Given the pypowsybl `network` is loaded and `pp.loadflow.run_ac(network)` is called,
- When convergence is checked,
- Then if `converged == False` the process halts with a logged fatal error AND if
  `converged == True` `lf_initial` contains a current value in A keyed by mRID for every
  branch in `AEFlatList` AND `branch_mrid_to_name` covers all lines and 2W transformers
  in the pypowsybl network.

**Implementation note:** pypowsybl `get_lines_results()` and
`get_2_windings_transformers_results()` return currents in A directly (no per-unit
conversion needed). The index of these DataFrames matches the mRID index of
`get_lines()` and `get_2_windings_transformers()` when loaded with
`source-for-iidm-id=mRID`.

---

## R1.2 — N-0 AC sensitivity matrix for PSTs (CORNET-4836 / CORNET-102)

**Spec ref:** CORNET-4836 — Calculation of Sensitivities; CORNET-102 — Sensitivity results

**Implementation note:** pypowsybl AC sensitivity is confirmed working on ReliCapGrid via
`pp.sensitivity.create_ac_analysis()`. The PSDF (Phase Shift Distribution Factor) gives
`dI_b / ds_τ` (branch current sensitivity per PST tap change) and is accessed as follows:
```python
sa = pp.sensitivity.create_ac_analysis()
# Add branch flow factors (current sensitivity) for each monitored branch and PST
sa.add_branch_flow_factor_matrix(
    branches_ids=[...],       # list of branch mRIDs
    variables_ids=[...],      # list of PST mRIDs (phase tap changer IDs)
    matrix_id='psdf_n0'
)
result = sa.run_ac(network)
psdf_matrix = result.get_branch_flows_sensitivity_matrix('psdf_n0')
# psdf_matrix is a DataFrame: rows = branches, columns = PSTs, values = dI/ds (A/tap)
```
Confirmed physically sound: BO-TR2_1 and BO-TR2_2 show exactly opposite-sign
equal-magnitude sensitivities on the same branch (expected for parallel transformers on
shared busbar). AC vs DC sensitivity delta is ~15-20% (physically reasonable).

**What it delivers:**
- Call `pp.sensitivity.create_ac_analysis()` to compute `dI_b / ds_τ` (A per tap step)
  for each PST `τ` in `PSTList` where `available == True` and `kind == 'preventive'`,
  evaluated at the current operating point (post-initial LF in R1.1)
- Compute sensitivity only for branches `b` in `AEFlatList` where
  `loading_pct >= sensitivity_threshold_pct` (parameter default 0.0 for R1; pruning added in R3)
- Store as `sensitivity_pst_n0: dict[(branch_mrid, pst_mrid), float]` — values in A per tap step

**Inputs:**
- `network` (pypowsybl `Network` from R0.1, post-LF state from R1.1)
- `PSTList` (from R0.6)
- `AEFlatList` (from R0.4)
- `sensitivity_threshold_pct: float` (default 0.0)

**Outputs:**
- `sensitivity_pst_n0: dict[(branch_mrid, pst_mrid), float]` (in-memory, values in A/tap)
- `sensitivity_pst_n0.csv`: columns `[branch_mrid, pst_mrid, di_ds_ampere_per_tap, timestamp]`

**Acceptance criteria:**
- Given the initial LF has converged and `PSTList` contains at least one available preventive PST,
- When `sensitivity_pst_n0` is computed,
- Then every `(branch_mrid, pst_mrid)` pair for an available preventive PST has a non-null
  value AND `sensitivity_pst_n0.csv` has at least one non-zero entry AND BO-TR2_1 and BO-TR2_2
  show opposite-sign equal-magnitude values on any branch where both are non-zero.

---

## R1.3 — PST tap bounds and operational limit constraints (CORNET-2895)

**Spec ref:** CORNET-2895 — Limitation of PST in preventive mode

**What it delivers:**
- For each PST in `PSTList`, compute the effective tap bounds to be used in the MILP:
  ```
  operating_tap_max = min(high_tap, high_step_operating_absolute)
  operating_tap_min = max(low_tap, low_step_operating_absolute)
  ```
  applying the online > offline > IGM priority rule (§3.6.4)
- If relative limits are also provided, apply:
  ```
  effective_tap_max = min(operating_tap_max, current_tap + high_step_relative)
  effective_tap_min = max(operating_tap_min, current_tap + low_step_relative)
  ```
- Validate that `effective_tap_min <= current_tap <= effective_tap_max`;
  log a warning if not (do not exclude from MILP)
- Store effective bounds as `pst_tap_bounds: dict[pst_mrid, (effective_tap_min, effective_tap_max)]`

**Inputs:**
- `PSTList` (from R0.6) — contains `low_tap`, `high_tap`, `current_tap`
  (from `network.get_phase_tap_changers()`), `operating_tap_min`, `operating_tap_max`,
  `high_step_relative`, `low_step_relative` per timestamp

**Outputs:**
- `pst_tap_bounds: dict[pst_mrid, (effective_tap_min, effective_tap_max)]` (in-memory)

**Acceptance criteria:**
- Given `PSTList` is populated from pypowsybl `network.get_phase_tap_changers()`,
- When `pst_tap_bounds` is computed,
- Then for every PST `effective_tap_min <= effective_tap_max` AND
  `effective_tap_min >= low_tap` AND `effective_tap_max <= high_tap`.

---

## R1.4 — PST group equality constraint construction (CORNET-21)

**Spec ref:** CORNET-21 — Group constraints for PST

**What it delivers:**
- For each PST group (identified by shared `group_id` in R0.6), check that the overlapping
  tap range `[max(effective_tap_min), min(effective_tap_max)]` across all PSTs in the group
  is non-empty
- If the range is empty: exclude all PSTs in the group from the MILP and log a warning
- If any PST in the group has `available == False`: exclude the whole group and log a warning
- For valid groups: prepare equality constraints for the MILP:
  `current_tap_τ1 + tap_change_τ1 == current_tap_τ2 + tap_change_τ2`
  for all PST pairs in the group (resulting tap positions must be equal;
  delta tap changes may differ if current tap positions differ)
- Store as `pst_group_equality_pairs: list[tuple[pst_mrid, pst_mrid]]`
- Dataset note: no CORNET-21 groups exist in the current ReliCapGrid NCP dataset —
  BO-TR2_1 and BO-TR2_2 are independent RAs. This increment will produce an empty
  `pst_group_equality_pairs` list on this dataset, which is correct.

**Inputs:**
- `PSTList` (from R0.6), `pst_tap_bounds` (from R1.3)

**Outputs:**
- `pst_group_equality_pairs: list[tuple[pst_mrid, pst_mrid]]` (in-memory)
- Console log: valid groups found, excluded groups with reason

**Acceptance criteria:**
- Given two PSTs share a `group_id` and have overlapping tap ranges,
- When group constraints are built,
- Then one equality constraint pair appears in `pst_group_equality_pairs` for that group AND
  a group with non-overlapping tap ranges produces zero constraint pairs and a logged warning
  AND on the current ReliCapGrid dataset `pst_group_equality_pairs` is empty (no NCP groups
  declared).

---

## R1.5 — N-0 MILP construction: PST variables and XNE loading constraints (CORNET-1790)

**Spec ref:** CORNET-1790 — Consideration of XNEs in MILP

**What it delivers:**
- Build a Pyomo `ConcreteModel` for a single timestamp with:
  - **Variables (discrete by default, `pst_taping_discrete = True`):**
    - `tap_change_upward[pst_mrid]` >= 0 — tap increase
      (`domain=pyo.NonNegativeIntegers` when `pst_taping_discrete=True`,
       `domain=pyo.NonNegativeReals` when `False`)
    - `tap_change_downward[pst_mrid]` >= 0 — tap decrease (same domain)
    - `overload_slack_n0[branch_mrid]` >= 0 — overload slack per monitored XNE
      (always continuous: `domain=pyo.NonNegativeReals`)
  - **Constraints (Pyomo `Constraint` objects, named as follows):**
    - `tap_upper_bound[pst_mrid]`:
      `current_tap + tap_change_upward - tap_change_downward <= effective_tap_max`
    - `tap_lower_bound[pst_mrid]`:
      `effective_tap_min <= current_tap + tap_change_upward - tap_change_downward`
    - `pst_group_equality[pst_mrid_1, pst_mrid_2]` (from `pst_group_equality_pairs`):
      `current_tap_1 + tap_change_upward_1 - tap_change_downward_1 ==
       current_tap_2 + tap_change_upward_2 - tap_change_downward_2`
    - `xne_loading_n0[branch_mrid]` (soft, for branches above `min_loading_threshold_pct`):
      `initial_current_ampere[b] + sum_tau(sensitivity_pst_n0[b,tau]
       * (tap_change_upward[tau] - tap_change_downward[tau]))
       <= patl_ampere[b] + overload_slack_n0[b]`
  - **Objective (`pyo.Objective`, sense=minimize):**
    `sum_tau(effective_penalty_cost_per_tap[tau]
     * (tap_change_upward[tau] + tap_change_downward[tau]))
     + penalty_cost_overload_n0 * sum_b(overload_slack_n0[b])`
    where `effective_penalty_cost_per_tap[tau] = pst_penalty_factor[tau] * penalty_reference_pst_pra`

**Inputs:**
- `sensitivity_pst_n0` (from R1.2)
- `pst_tap_bounds` (from R1.3)
- `pst_group_equality_pairs` (from R1.4)
- `AEFlatList` (PATL values via `patl` dict from R0.4), `lf_initial` (initial currents in A from R1.1)
- RAO control parameters: `penalty_reference_pst_pra: float`,
  `penalty_cost_overload_n0: float`, `min_loading_threshold_pct: float` (default 0.0),
  `pst_taping_discrete: bool` (default `True`)

**Outputs:**
- `milp_model` — Pyomo `ConcreteModel` (in-memory)

**Acceptance criteria:**
- Given `sensitivity_pst_n0` and `pst_tap_bounds` are populated and `pst_taping_discrete=True`,
- When the MILP is built,
- Then `tap_change_upward` and `tap_change_downward` are `NonNegativeIntegers` AND the number of
  `xne_loading_n0` constraints equals the number of monitored branches above
  `min_loading_threshold_pct` AND setting `pst_taping_discrete=False` produces
  `NonNegativeReals` variables instead.

---

## R1.6 — Pyomo/HiGHS solve and result extraction (SF3079 PST results)

**Spec ref:** SF3079 — GridStateIntensitySchedule Optimisation results (PST block)

**What it delivers:**
- Solve the Pyomo `ConcreteModel` from R1.5 using HiGHS via the `highspy` persistent
  solver interface:
  ```python
  from pyomo.environ import SolverFactory
  solver = SolverFactory('highs', solver_io='python')
  results = solver.solve(milp_model, tee=False)
  ```
- Check termination condition: `optimal` -> proceed; `infeasible` or other -> log and halt
- Extract per-PST results using `pyo.value()`:
  - `tap_change_result[pst_mrid]` = `pyo.value(tap_change_upward[tau]) - pyo.value(tap_change_downward[tau])`
  - `current_tap_position[pst_mrid]` — from `PSTList`
  - `result_tap_position[pst_mrid]` = `current_tap_position + tap_change_result`
  - `penalty_cost_eur[pst_mrid]` = `effective_penalty_cost_per_tap * |tap_change_result|`
- Extract per-branch overload slack: `overload_slack_n0_result[branch_mrid]` = `pyo.value(overload_slack_n0[b])`
- Log objective function value

**Inputs:**
- `milp_model` (from R1.5)
- `pst_tap_bounds`, `PSTList`, `AEFlatList`

**Outputs:**
- `pst_results: dict[pst_mrid, {tap_change_result, current_tap_position, result_tap_position, penalty_cost_eur}]`
- `overload_slack_n0_result: dict[branch_mrid, float]`
- `results_pst.csv`: columns `[pst_mrid, pst_name, tso, current_tap_position, tap_change_result, result_tap_position, penalty_cost_eur, timestamp]`
- Console log: objective value, number of PSTs activated, number of branches with remaining overload

**Acceptance criteria:**
- Given the MILP is built and feasible,
- When HiGHS solves it via Pyomo,
- Then `result_tap_position` for every PST satisfies
  `effective_tap_min <= result_tap_position <= effective_tap_max` AND for every branch where
  `overload_slack_n0_result == 0` the post-optimisation linearised current
  `initial_current_ampere[b] + sum(sensitivity_pst_n0[b,tau] * tap_change_result[tau]) <= patl_ampere[b]`.

---

## R1.7 — Post-solve LF and linearisation loop (CORNET-12, CORNET-4850)

**Spec ref:** CORNET-12 — RAO Procedure; CORNET-4850 — Accuracy Requirement; CORNET-16 (completeness iterations); CORNET-106 (non-convergent load flow); spec pp. 68–72

> **Current state (after the loop redesign) — read this first.** The text of
> this increment below was written before the redesign and is partly
> historical. What the code does now, in short (full account:
> `AC_Verification_Loop_Technical_Reference.md`; formulation:
> `MILP_Mathematical_Formulation.md` §7; session record: `R3_NX_CRA.md`,
> "Loop redesign and consistency pass"):
>
> - **Spec-conform order:** build MILP at the current operating point → solve → apply the RAs (temporarily) → new load flow → Convergence Check only if the load flow converged. Completeness iterations are the outer loop, linearisation iterations the inner loop.
> - **One state object** (`OperatingPointState`): original frozen, current updated; every baseline (taps, `target_p`, N-0 / N-X load flows, N-0 / N-X sensitivities) is refreshed every iteration; the MILP is cumulative against the original.
> - **Convergence criteria are independent, OR** (spec pp. 69–70): (1) sum of RA change — Σ|tap change| and Σ|ΔMW| below `max_change_ra_sum_threshold`; (3) each RA change below `max_change_ra`; (4) Σ over elements |overload(k) − overload(k−1)| below `max_change_overload`, with overload = max(0, **AC current** − model limit) per element. The earlier model-slack version of criterion 4 (below) is **superseded**: it fired meaninglessly at iteration 2.
> - **Cycle exit:** if none holds and the cumulative solution repeats an earlier one (difference below `max_change_ra`), the cycle member with the lowest total AC overload is re-applied (`CYCLIC_REPETITION`).
> - **Load-flow failure** at iteration k > 1 reverts to the **last converged state**, at k = 1 to the original; this also resolves the earlier open question about the completeness loop running on a reverted state.
> - **Statuses:** `CONVERGED`, `CYCLIC_REPETITION`, `MAX_ITERATIONS_REACHED`, `REVERTED_NON_CONVERGENT`, `REVERTED_TO_LAST_CONVERGED_STATE`, `SENSITIVITY_INVALID`, `NOT_APPLICABLE` (seven members of `AcVerificationStatus`, `data_model.py`).
> - **Load-flow parameters:** all sensitivity analyses now use the pipeline load-flow parameters (a long-standing defect), and the security analysis runs with contingency propagation off.
> - **File names:** `results_rd.csv` is now `results_preventive_rd.csv` (plus `results_curative_rd.csv`).

**⚠ Investigation record — started from a CORNET-3653/3654 question, resolved as
a different, more consequential finding. Kept as its own account rather than
folded silently into the increment text, since the path matters as much as
the destination here.**

**Starting point:** a real single-timestamp test run showed two PSTs each
moving ~20 taps in one solve, with the post-solve AC LF failing to converge.
The initial hypothesis was that CORNET-3653/3654 (per-timestamp and
per-optimisation-timeframe PST tap-change limits) were missing and needed to
be built for the single-timestamp case. **This hypothesis was wrong, and
confirmed wrong by checking, not assumed.** Both PSTs were found pinned
exactly at their hard floor/ceiling — meaning CORNET-2895's operating-range
bounds (R1.3) were already being correctly enforced; the 20-tap movement was
the MILP legitimately using the full available range in one linear solve to
resolve a real 173A overload, with two PSTs of different TSOs being driven in
opposite directions to correct the same congestion. CORNET-3653/3654 limit
tap-change *count/volume* per TSO for equipment-wear reasons — a different
concern from whether a single linear solve should be allowed to jump this far
from the current operating point in one step. Neither CORNET clause is the
right mechanism for this symptom; building either would not have fixed it.

**The spec was checked directly for a linearisation step-size-limiting
mechanism — none exists.** The one "step size" concept found in the spec
(§3.6, LF convergence discussion) is entirely internal to the Newton-Raphson
AC load flow solver's own numerical damping, unrelated to the RAO's tap
decision logic.

**CORNET-106 (Behaviour with non-convergent LF-solutions) — checked directly,
and this is what actually mattered.** The spec's own answer for non-convergent
LF is not "prevent it" but "produce a diagnosable approximated result and
continue" — an anticipated, survivable event with explicit per-node
`MismatchP`/`MismatchQ` diagnostics, not a silent hard stop.

**⚠ Correction — the revert-on-non-convergence behaviour below is confirmed
spec-compliant, not a deviation. An earlier framing during this
investigation implied otherwise and was imprecise; corrected here.** This
increment's own spec text — *"Check convergence; if non-convergent log a
warning and revert to the previous operating point"* — is exactly what the
implementation does. The revert itself was never wrong. **What the spec is
genuinely silent on is what gets exported afterward — and that is where a
real, confirmed bug was found.**

**The confirmed bug: on non-convergence, the network correctly reverts to the
pre-RA baseline, but the exported CSV results did not reflect this at all.**
Traced precisely: `original_tap_positions`/`original_target_p` are captured
once, before the iteration loop starts, and never reassigned — so a
non-convergent revert, including on iteration 1, always reverts the network
all the way back to doing nothing, never to some intermediate corrected
state. That part was correct. But `run_pipeline.py` wrote `results_pst.csv`
(and, confirmed on further investigation, four other result files) from the
MILP's *proposed* solution unconditionally — gated only on `pst_inputs is not
None`, with no check on the loop's actual termination outcome. **The CSV
would report a detailed, specific PST dispatch (the same 20-tap-to-the-limit
values from the original scenario) as if it were the applied outcome, while
the real network state was completely unaltered and still carrying the full
overload.** Confirmed on the real, originating scenario: prior to the fix,
`results_pst.csv` silently implied a corrective action had been taken when
none had.

**This is the same failure category already named twice elsewhere in this
project** — a results artifact that looks complete and passes casual
inspection while not reflecting what actually happened (`results_rd_multits.csv`'s
blank fields, `lf_nx_initial.csv`'s hardcoded placeholders) — but more severe
than either prior instance, since those were *missing* data and this was
*wrong* data presented with full confidence.

**The termination outcome has four distinct states, not two** — confirmed by
tracing every value the loop's `termination_reason` can actually take, not
assumed from the two obvious cases:
1. **`CONVERGED`** — full success, both tap-change and RD MW-change thresholds
   met, applied and AC-validated.
2. **`REVERTED_NON_CONVERGENT`** — the case above. Network reverted to pre-RA
   baseline. Nothing applied.
3. **`MAX_ITERATIONS_REACHED`** — a genuinely different case, confirmed
   separately: every iteration's AC load flow *did* converge (a non-convergent
   solve routes to state 2 instead); the linearisation itself just never
   settled below the change threshold within the iteration budget. **The last
   iteration's dispatch is genuinely applied and AC-validated** — honest, just
   not proven stable. Collapsing this into a boolean with state 2 would have
   misrepresented a legitimate partial success as a failure.
4. **`NOT_APPLICABLE`** — added for a separate code path found during this
   fix: `solve_n0_milp_model`'s own internal CSV-write path never goes through
   this loop at all (confirmed unreachable from `run_pipeline.py` — neither
   real call site into it passes `output_path`; only a direct unit test
   exercises this write). Forcing this path into one of the other three states
   would have been its own small dishonesty; it genuinely doesn't apply.
   **Flagged for revisit if this function ever becomes reachable from the real
   pipeline** — a production CSV silently reporting `NOT_APPLICABLE` would be
   the same category of bug at smaller scale.

**Fix, confirmed complete across the full blast radius, not just the
originally-found file.** `AcVerificationStatus` enum (4 states when written; seven now) added to
the data model. All 5 affected writer functions fixed and tested — `results_pst.csv`,
`results_preventive_rd.csv`, `results_preventive_rd_ra_count.csv`, `results_preventive_rd_ra_groups.csv`,
`results_lead_times.csv` — each gaining an `ac_verification_status` column
carrying the enum value (not the raw internal `termination_reason` string
directly, to avoid every consumer needing to match on exact wording that could
be reworded later; the raw string is preserved alongside it for diagnostic
value). `run_pipeline.py`'s 5 real call sites updated to compute the status
once and thread it through.

**Confirmed on the real, originating non-convergent scenario — the
verification that actually closes this investigation, not just proof the
mechanism works in isolation.** Ran the exact CGM + NCP data that produced the
original 20-tap/non-convergent symptom. `results_pst.csv` now reads
`REVERTED_NON_CONVERGENT` / `load flow non-convergent` on every row — including
the two PSTs at their hard limits — while still preserving the proposed
values for diagnostic value. Confirmed the same honest status across all 5
files on this same run. 473 tests passing, zero regressions, smoke test
manually verified.

**A process near-miss worth recording, distinct from R2.5/R3.8's own
near-miss entries — a different failure shape.** During implementation, a
separate hypothesis (that `run_pipeline.py`'s `lf_nx` variable feeding N-X
export functions was similarly stale) was proposed, shipped, and passed its
own tests and a 447-test suite before being caught and reverted — recorded in
full in R3.8's own entry, not duplicated here, since it belongs to a different
function's investigation. Referenced here only to note that the same session
produced both a confirmed real bug (this one) and a confirmed false lead (that
one), and both were caught by the same discipline: pushing past "the fix's own
test passes" to "does this match the consuming function's actual documented
contract."

**What remains genuinely open, queued but not investigated further:**
- ~~A per-PST maximum tap-change-per-single-solve cap — a legitimate,
  separate engineering mitigation (not a spec requirement; no CORNET clause
  describes this) that would reduce how often the solver reaches for a
  large jump the AC LF then fails to validate.~~ **Resolved — see R1.10.** A
  later investigation found the actual mechanism needed was more specific
  than a generic per-PST cap: CORNET-3653/3654, already spec-defined and
  already partially built for multi-timestamp use (R4.3/R4.4), collapses to
  exactly this kind of per-TSO tap-movement limit at N=1. Built as R1.10
  rather than a bespoke, unlabelled safeguard — confirmed empirically
  sufficient for the originating case (both offending PSTs individually
  exceeded a realistic limit) and operationally realistic (no TSO would
  authorise the scale of movement being capped) in a way a generic
  numerical-stability parameter would not have been.
- ~~**Whether the R3.8 completeness loop and N-X analysis should even run
  against a reverted, non-applied upstream state**~~ **Resolved by the loop
  redesign.** The completeness loop is now the outer loop of one nested
  orchestrator working on one state object; a load-flow failure reverts to the
  last converged state, and the next completeness iteration starts from that
  state.

**What it delivers:**
- Apply the PST tap changes from R1.6 to the pypowsybl network model:
  ```python
  network.update_phase_tap_changers(
      id=pst_mrid,
      tap=result_tap_position
  )
  ```
  for each PST with a non-zero `tap_change_result` — **the kwarg is `tap`, not
  `tap_position`**; an earlier draft of this document had the wrong kwarg name,
  which was itself a confirmed real, silent bug at one point in this project's
  history (wrong kwarg produces no exception, simply does nothing)
- Run a new AC LF via pypowsybl at the updated operating point:
  ```python
  lf_result = pp.loadflow.run_ac(network)
  ```
- Check convergence; if non-convergent log a warning and revert to the previous
  operating point — **confirmed spec-compliant as described above**
- Extract updated branch currents from `network.get_lines_results()` and
  `network.get_2_windings_transformers_results()` — same pattern as R1.1
- Compute the sum of absolute tap changes across all PSTs:
  `total_tap_change_sum = sum(|tap_change_result[tau]|) for all tau`
- Check linearisation termination criterion:
  `total_tap_change_sum < max_change_ra_sum_threshold`
  (RAO control parameter `max_change_ra_sum_threshold`, default 1.0)
- If criterion not met and iteration count < `max_linearisation_iterations`:
  re-run from R1.2 with updated `lf_initial` from this LF
- If criterion met or `max_linearisation_iterations` reached: proceed to output
- Export post-optimisation branch loadings, **including the honest
  `ac_verification_status` column described above** — this is not optional
  metadata, it is what makes every other exported value trustworthy

**Inputs:**
- `pst_results` (from R1.6)
- `network` (pypowsybl `Network` — tap positions updated in place)
- RAO control parameters: `max_change_ra_sum_threshold: float` (default 1.0),
  `max_linearisation_iterations: int` (default 10)

**Outputs:**
- `lf_post: dict[branch_mrid, float]` — updated branch currents in A after RA application
- `lf_post_n0.csv`: columns `[branch_mrid, branch_name, tso, i_ka_before, i_ka_after,
  loading_pct_before, loading_pct_after, patl_ka, timestamp]`
- `results_pst.csv` (and `results_preventive_rd.csv` [formerly `results_rd.csv`],
  `results_preventive_rd_ra_count.csv`, `results_preventive_rd_ra_groups.csv`, `results_lead_times.csv`): each gains
  `ac_verification_status` (enum: `CONVERGED`/`CYCLIC_REPETITION`/
  `MAX_ITERATIONS_REACHED`/`REVERTED_NON_CONVERGENT`/
  `REVERTED_TO_LAST_CONVERGED_STATE`/`SENSITIVITY_INVALID`/`NOT_APPLICABLE`) and the raw termination reason string
- Console log: iteration number, `total_tap_change_sum`, convergence status, termination reason

**Acceptance criteria:**
- Given the MILP produces a non-zero `tap_change_result` for at least one PST,
- When the post-solve LF is run via pypowsybl,
- Then `lf_post_n0.csv` contains one row per monitored branch AND the loop terminates
  within `max_linearisation_iterations` iterations AND the final `total_tap_change_sum`
  is logged with the termination reason.
- Given a scenario where the post-solve AC LF fails to converge,
- When `results_pst.csv` (and the other 4 affected files) are inspected,
- Then `ac_verification_status == REVERTED_NON_CONVERGENT` on every row AND the
  network's real state reflects the pre-RA baseline, not the proposed dispatch
  — confirmed against a real, previously-misreported scenario, not only a
  synthetic test.
- Given a scenario where every iteration's AC LF converges but the
  linearisation doesn't settle within `max_linearisation_iterations`,
- When the results are inspected,
- Then `ac_verification_status == MAX_ITERATIONS_REACHED`, distinct from both
  `CONVERGED` and `REVERTED_NON_CONVERGENT` — the last iteration's dispatch is
  genuinely applied, not discarded.
- Given `solve_n0_milp_model`'s internal write path (confirmed unreachable from
  `run_pipeline.py` today),
- When its own direct unit test runs,
- Then `ac_verification_status == NOT_APPLICABLE`, not a fabricated claim about
  a loop this path never touches.
- Given a converged load flow after an iteration,
- When the element overloads (AC current minus model limit, floored at 0, over
  N-0 secured and scanned branches and N-X PATL/TATL pairs, N-X including the
  linearised curative effect) are compared with the previous iteration's,
- Then criterion 4 holds iff the summed absolute change is below
  `max_change_overload`; any one of criteria 1, 3, 4 holding ends the loop
  with `CONVERGED` (OR). State 0 is the initial AC state; criterion 4 is not
  evaluated if the N-X refresh failed. (Supersedes the earlier model-slack
  acceptance cases.)
- Given no criterion holds and the cumulative solution of iteration k matches
  one of iterations 0…k−2 within `max_change_ra`,
- When the loop evaluates the cycle,
- Then it ends with `CYCLIC_REPETITION`, re-applies the cycle member with the
  lowest total AC overload (ties: lowest cumulative cost; member 0 is not a
  candidate), runs a load flow and records `cycle_selected_iteration`.
- Given a load-flow failure at iteration k > 1,
- When the loop handles it,
- Then the network reverts to the last converged state and the status is
  `REVERTED_TO_LAST_CONVERGED_STATE`; at k = 1 it reverts to the original state
  and the status is `REVERTED_NON_CONVERGENT`.

> **SUPERSEDED (kept as history).** The investigation record below led to a
> model-slack version of criterion 4 and left the OR-versus-AND question open.
> The spec check (pp. 69–70) later confirmed the criteria are independent
> acceptance criteria (OR), and criterion 4 was redefined on AC overloads per
> element (see the box at the top of R1.7). The "still required before this
> increment is closed" list at the end of this record is closed.

**⚠ Investigation record — the loop's stop condition was checking an
incomplete subset of the spec's own termination criteria. Confirmed against
CORNET-4850 directly, not inferred from the existing implementation.**

**Starting symptom:** on a real run, the loop's own internal overload-slack
variables (N-0, N-X PATL, N-X TATL) were confirmed exactly zero across
iterations 1 through 6 — not approximately small, exactly `0.000000` in
every case — while the MILP kept proposing substantial new PST/RD movement
each iteration regardless. The loop only stopped once genuine overload
appeared at iteration 7, then converged normally from there.

**CORNET-4850's own text lists termination criteria checked "after each
iteration," and the current implementation only checks a subset:**
1. Max linearisation iteration count (`MaxCountLinIter`) — implemented, hard cap.
2. Sum of change in redispatch (MW) and approximated PST flow shift
   (`MaxChangeRASum`) — implemented, as `total_tap_change_sum`/`total_rd_mw_change`.
3. **Change in *each* remedial action individually** (`MaxChangeRA`) — **not
   implemented**. Distinct from criterion 2's aggregate sum; the spec defines
   this as a separate, per-RA threshold.
4. **"The change of the element overloads (congestions)"** — **not
   implemented**. Not "is anything currently violated," but whether the
   congestion picture has *stabilised between iterations* — a genuine third
   category, distinct from both the movement-magnitude criteria above and
   from a zero-violation check.
5. CT-adaptation criterion (CORNET-4849) — out of scope, no CT RAs in this
   release's scope.

Also described in the same spec passage, as a further exit condition: *"When
cyclic repetitions of the MILP results occur, there is otherwise also an exit
from the iteration loop by comparing the new result with already determined
solutions in an earlier iteration."*

**Two hypotheses considered for the observed symptom, distinguished
empirically before implementing anything:**
- Cyclic repetition (criterion 6 above) — **ruled out.** Every individual
  PST's tap trajectory across all 10 iterations was traced and confirmed
  monotonic (steadily up, steadily down, or flat) with no oscillation; the
  combined 6-PST state vector never repeated at any two iterations. Not a
  cycle.
- Missing overload-change stabilisation (criterion 4 above) — **confirmed.**
  The per-iteration total overload-slack magnitude was exactly `0.0` for
  every one of the five available consecutive deltas across iterations 1–6,
  before jumping to a real, non-zero value at iteration 7 and shrinking
  smoothly from there (94.67 → 7.20 → 4.63 → 1.74) — itself an independent
  confirmation of genuine convergence at that later stage, not oscillation.
  Under criterion 4 with any reasonable threshold, the loop should have
  exited at iteration 2 — the first point a prior-iteration comparison
  becomes possible — rather than continuing to iteration 10.

**Fix — criterion 4 implemented as an additional, independent stop
condition:**
```
total_overload_change = Σ over all monitored elements (N-0, N-X PATL, N-X TATL)
    of |overload_slack_this_iteration - overload_slack_previous_iteration|

congestion_stabilised = total_overload_change < max_change_overload
```
combined with the existing `pst_converged`/`rd_converged` checks via **OR**,
not AND — the loop terminates once *either* movement has stabilised *or* the
congestion picture has stabilised, whichever comes first.

**⚠ Open interpretation question, not resolved by the spec text, flagged
rather than silently decided:** CORNET-4850 lists its criteria without
stating explicitly how they combine. The OR interpretation above is inferred
from criterion 1 being specifically called out as *"a hard termination
criterion"* — phrasing that implies the others are comparatively soft,
alternative exit conditions, consistent with how iterative optimisation
stopping rules are conventionally structured (several independent sufficient
signals, not all jointly required). This is a reasonable reading, not a
spec-confirmed one. Under AND logic instead, adding criterion 4 would make
the loop strictly *more* conservative (requiring both movement and congestion
to stabilise), which would not have resolved the observed symptom. **OR logic
is the interpretation this fix depends on — flagged the same way the
existing R1.7 damping question and the static-PATL-side convention are
flagged elsewhere in this project's spec record, as an open item for the
spec owner to confirm, not a silently-resolved detail.**

**Criterion 3 (per-RA individual movement threshold) also confirmed
missing and closed alongside criterion 4** — not directly implicated by the
observed symptom, but explicitly spec-required and cheap to add in the same
pass: `max(|tap_change_τ|) < max_change_ra` per PST, `max(|Δp_g|) <
max_change_ra` per generating unit, checked independently of the aggregate
sum criterion 2 already implements.

**Naming note:** `max_change_overload`, `total_overload_change`,
`max_change_ra` (per-RA, distinct from the existing `max_change_ra_sum_threshold`
aggregate) — new RAO control parameters, following the existing naming
convention (`MaxChangeRA` and `MaxChangeRASum` in the spec's own configuration
table map directly to these).

**Confirmed against existing trace data before any code was written, not yet
verified against an actual implementation.** The exact-zero deltas across
iterations 1–6 already establish that criterion 4 under OR logic *would*
terminate the loop at iteration 2, using data already captured from the
original run — this is a confirmed prediction, not yet a confirmed
implementation. **Still required before this increment is closed:** build
the fix, re-run the same scenario against the real code, and confirm the
loop genuinely exits at iteration 2 in practice, not only in the trace-data
prediction.

---

## R1.8 — PST penalty costs in objective function (CORNET-2998)

**Spec ref:** CORNET-2998 — Considered costs for PST in preventive mode

**What it delivers:**
- Verify that the per-PST penalty cost term is correctly wired in the objective:
  ```
  effective_penalty_cost_per_tap[tau] = pst_penalty_factor[tau] * penalty_reference_pst_pra
  ```
  where `pst_penalty_factor[tau]` comes from `RemedialAction.penaltyFactor` in the NCP RA profile
  and `penalty_reference_pst_pra` is a RAO control parameter (EUR/tap)
- Add TSO-specific override (CORNET-4339): if `penalty_reference_pst_pra_per_tso` dict
  contains an entry for the PST's TSO, use it instead of the global `penalty_reference_pst_pra`
- Export penalty cost breakdown to results CSV

**Inputs:**
- `PSTList` (`pst_penalty_factor` per PST, parsed from NCP RA profile in R0.6)
- RAO control parameters: `penalty_reference_pst_pra: float`,
  optional `penalty_reference_pst_pra_per_tso: dict[tso, float]`

**Outputs:**
- `pst_effective_penalty_costs: dict[pst_mrid, float]` — effective penalty cost per tap change (in-memory)
- Extended `results_pst.csv` with columns `pst_penalty_factor`, `penalty_reference_pst_pra`,
  `effective_penalty_cost_per_tap_eur`

**Acceptance criteria:**
- Given two PSTs with different `pst_penalty_factor` values and the same global
  `penalty_reference_pst_pra`,
- When `pst_effective_penalty_costs` is computed,
- Then the PST with the higher `pst_penalty_factor` has a strictly higher
  `effective_penalty_cost_per_tap_eur` AND if `penalty_reference_pst_pra_per_tso` contains
  an entry for a PST's TSO, that value takes precedence over the global parameter.

---

## R1.9 — Full LF result output per branch and per node (CORNET-98, CORNET-3221)

**Spec ref:** CORNET-98 — LF Result output; CORNET-3221 — Results per AC line segment and 2W transformer

**What it delivers:**
- After each AC LF call (initial R1.1 and post-solve R1.7), extract and export the full
  per-branch result set from pypowsybl for all AC line segments and 2W transformers:
  ```python
  lines_res  = network.get_lines_results()
  # columns: p1 (MW), q1 (MVAr), i1 (A), p2 (MW), q2 (MVAr), i2 (A)
  trafos_res = network.get_2_windings_transformers_results()
  # same columns
  ```
  - Active power `P` (MW) at side 1 and side 2
  - Reactive power `Q` (MVAr) at side 1 and side 2
  - Current magnitude `I` (A) at side 1 and side 2
  - Apparent power `S` (MVA) computed as `sqrt(P^2 + Q^2)` at each side
  - Maximum loading as % of PATL (using `max(i1, i2) / patl_ka * 100`)
  - Result type: `BaseCase` or `PostRAO`
  - Element type: `XNE`, `scanned`, or `other` (classified via `AEFlatList`)
- Extract per-bus results from pypowsybl:
  ```python
  buses_res = network.get_buses_results()
  # columns: v_mag (kV), v_angle (degrees)
  ```
- Export both sets to CSV after the initial LF (R1.1) and after the final post-solve LF (R1.7)

**Inputs:**
- `network` (pypowsybl `Network` with completed LF solution)
- `AEFlatList` (from R0.4, for element type classification)
- `patl` dict (from R0.4, for loading % computation)

**Outputs:**
- `lf_results_branches.csv`: columns `[calc_type, branch_mrid, branch_name, tso, element_type,
  p1_mw, q1_mvar, i1_ka, s1_mva, p2_mw, q2_mvar, i2_ka, s2_mva, loading_pct, patl_ka, timestamp]`
- `lf_results_buses.csv`: columns `[calc_type, bus_id, bus_name, tso, v_mag_kv, v_angle_deg, timestamp]`

**Acceptance criteria:**
- Given the AC LF has converged via pypowsybl,
- When branch and bus results are extracted,
- Then every branch in `AEFlatList` appears in `lf_results_branches.csv` with non-null `p1_mw`
  AND every bus in the network appears in `lf_results_buses.csv` with `v_mag_kv > 0`.

---

## R1.10 — PST tap-change limit per TSO, single-timestamp (CORNET-3653, CORNET-3654)

**Spec ref:** CORNET-3653 — Limitation of the PST tap changes per timestamp;
CORNET-3654 — Limitation of the PST tap changes per optimisation timeframe

**Why this increment exists, and why it wasn't built earlier:** confirmed
directly against real data that the MILP can propose combined multi-PST tap
movements (a real observed instance: two PSTs moving 20 and -26 taps in a
single iteration) large enough that the linear sensitivity model used to
build the constraint not only loses precision but **flips sign relative to
the true AC result** on the branch it was meant to protect — a genuine
qualitative breakdown of the linearisation, not ordinary imprecision. Traced
to real sensitivity coefficients (not a stale CSV) and confirmed empirically:
median relative deviation across all 29 monitored branches for this move was
36 A / well under 65% — normal, expected slop — but three branches showed
589–1077% deviation with a clean sign reversal, a distinct cluster separated
from the rest by a wide, structural gap. **This is also not a physically
realistic scenario to begin with** — no TSO would authorise a 20-tap swing on
a single PST within one timestamp in real operation. Rather than build
detection-and-recovery machinery for a move the model should never have been
allowed to propose, this increment prevents the move itself.

**Single-timestamp scope note:** CORNET-3653 (per timestamp) and CORNET-3654
(per optimisation timeframe) are distinct constraints in the spec's own
multi-timestamp formulation, already built for the multi-timestamp case as
R4.3/R4.4, including the confirmed formula correction there — `tap_change_scheduled_τ(t)`
(the schedule's own movement between consecutive timestamps) is the correct
term to sum against the limit, not an absolute tap position, per CORNET-3653's
own definition of "tap change" as a movement magnitude. **In a genuine
single-timestamp context, `tap_change_scheduled_τ(t) = 0` by definition** — a
sequence of one has no consecutive-timestamp delta to speak of — so both
CORNET-3653 and CORNET-3654 collapse to the **identical constraint**, and
only one needs to be built here, not two. This reuses R4.3's already-derived
formula and its degenerate-case reasoning directly rather than re-deriving it.

**A further simplification available specifically at N=1, not present in
R4.3's general multi-timestamp version:** R4.3's general formula requires
auxiliary `abs_tap_change` variables to linearise `|tap_change_scheduled_τ(t)
+ tap_change_τ(t)|`, since both terms can be non-zero and of either sign. Here,
with the scheduled term provably zero, the expression reduces to
`|tap_change_τ|` alone — and since `tap_change_upward_τ` and
`tap_change_downward_τ` are both non-negative and an optimal solution never
benefits from making both simultaneously positive (doing so only adds penalty
cost for no net effect), `tap_change_upward_τ + tap_change_downward_τ`
already equals `|tap_change_τ|` directly, with no separate auxiliary variable
or big-M linearisation required at all.

**What it delivers:**
- For each TSO `k`, add a **hard** constraint (no slack, matching the "a TSO
  will not authorise this" framing — this is a real physical/operational
  limit, not a soft cost tradeoff):
  ```
  Σ_{τ ∈ TSO_k} (tap_change_upward_τ + tap_change_downward_τ) ≤ max_taps_per_tso
  ```
- `max_taps_per_tso` — new control parameter, default `6` (confirmed
  reasonable operational range: 5–7; middle value chosen as the working
  default, freely adjustable)
- If a TSO has zero available preventive PSTs, the constraint is vacuous for
  that TSO (empty sum), not skipped — consistent with how R1.4's PST group
  equality behaves when no groups exist on a given dataset

**Naming note:** Use `max_taps_per_tso` — a single control parameter, not
separate per-timestamp/per-timeframe values, since the two collapse to one
constraint at N=1. When R4's multi-timestamp path is eventually extended to
reuse this increment's logic, `max_taps_per_tso` corresponds to R4.3's
`max_taps_per_timestamp_tso`; R4.4's separate `max_taps_per_timeframe`
parameter remains genuinely distinct once real multi-timestamp variation
exists.

**Inputs:**
- `tap_change_upward_τ`, `tap_change_downward_τ` (from R1.5, already-defined
  Pyomo variables — no new variables introduced by this increment)
- `PSTList` (TSO assignment per PST, from R0.6)
- RAO control parameter: `max_taps_per_tso: int` (default `6`)

**Outputs:**
- Additional hard constraint added to `milp_model`, one per TSO with at least
  one available preventive PST
- Console log: total tap movement per TSO per solve, against the configured limit

**Acceptance criteria:**
- Given a TSO with two available preventive PSTs and `max_taps_per_tso = 6`,
- When the MILP is solved,
- Then the combined tap movement across both PSTs for that TSO does not
  exceed 6, even if a larger movement would otherwise have been the
  unconstrained optimum.
- Given the real dataset scenario that originally surfaced this finding (two
  PSTs proposing a combined 46-tap movement),
- When this constraint is active,
- Then the MILP cannot propose that combined movement, and the resulting
  smaller move keeps the linear sensitivity model's prediction consistent in
  sign with the true AC result on every previously-affected branch — confirmed
  via the same before/after comparison methodology that originally surfaced
  the sign-flip finding, not assumed from the constraint's presence alone.
- Given a TSO with zero available preventive PSTs,
- When the MILP is built,
- Then no error occurs and the (vacuous) constraint for that TSO has no effect.
