> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R5 — Generator Physics: Full RD Optimization

**Goal:** Add the generator technical constraint layer that makes RD realistic for
units with slow ramps, minimum operating windows, start-up requirements, lead times,
discrete step sizes, energy limits, and activation costs. Introduces binary on/off
variables (unit commitment). This release introduces the **Full RD Optimization**
workflow as a superset of the Simple RD Optimization workflow built in R2.

**Prerequisite:** R4 complete — multi-timestamp generalisation working. R5 requires
the time index introduced in R4 for all inter-timestamp constraints (ramps,
min-up/down, energy limits, start-up/shutdown ramp).

**Stack:** pypowsybl 1.15.0 (AC LF + AC sensitivity), Pyomo + HiGHS via `highspy`
(`solver_name="appsi_highs"`, `solver_io=None`), rdflib/ElementTree. Binary variables
already introduced in R2.8 (`ra_activated`); extended here with per-timestamp
commitment variables (`unit_committed`).

**Solver note:** Use `solver_name="appsi_highs"` with `solver_io=None`. Do not use
`solver_io="python"` (raises `NotImplementedError`).

---

## Cross-cutting requirement: Full RD Optimization workflow

**Approved during R5 planning — applies to `milp_builder.py` and `run_pipeline.py`
from R5.1 onwards. This extends the composable RA-type architecture established in
R2 (see R2's "Cross-cutting requirement: composable RA-type workflows" and
"Architecture note: unified branch candidate set" sections) with a third control flag.**

### Motivation

R2 established three workflows based on two independent flags
(`enable_pst_remedial_actions`, `enable_rd_remedial_actions`). R5 adds a third
dimension: whether RD dispatch is also subject to the generator physics layer
(ramps, commitment, start-up/shutdown, lead/lag times, energy limits, step sizes,
activation costs). This produces five selectable workflows in total:

1. **PST Optimization** — `enable_pst_remedial_actions=True`, `enable_rd_remedial_actions=False`
2. **RD Optimization** — `enable_pst_remedial_actions=False`, `enable_rd_remedial_actions=True`,
   `enable_rd_generator_physics=False` (identical to R2's "RD-only" workflow; to be
   renamed "Simple RD Optimization" in a later documentation pass — no functional change)
3. **Full RD Optimization** — `enable_pst_remedial_actions=False`, `enable_rd_remedial_actions=True`,
   `enable_rd_generator_physics=True` (new in R5)
4. **PST+RD Optimization** — both PST and RD enabled, physics disabled (identical to
   R2's "PST+RD" workflow; to be renamed "PST+Simple RD Optimization" later)
5. **PST+Full RD Optimization** — PST enabled, RD enabled, physics enabled (new in R5)

Full RD Optimization is **strictly additive** to RD Optimization — it does not replace
or alter any of R2's Simple RD constraints (GLSK, Pmax/Pmin, balancing, penalty/price
costs, RA count limits, group volume limits, bid lead time enforcement). Enabling
physics adds constraints on top; it never removes or relaxes what R2 already builds.

### Control parameters (extends R2's two-flag pattern)

```python
enable_pst_remedial_actions: bool     # from R1/R2
enable_rd_remedial_actions: bool      # from R2
enable_rd_generator_physics: bool     # new in R5, default False
```

### Preconditions (validated before any model-building begins)

1. **Physics requires RD to be enabled.** If `enable_rd_generator_physics=True` and
   `enable_rd_remedial_actions=False`, raise a clear error and stop computation:
   physics constraints have nothing to attach to without RD dispatch enabled.
   ```
   ValueError: enable_rd_generator_physics=True requires enable_rd_remedial_actions=True.
   Generator physics constraints cannot be built without RD dispatch enabled.
   ```

2. **Physics requires more than one timestamp.** If `enable_rd_generator_physics=True`
   and `N_TIMESTAMPS == 1`, raise a clear error and stop computation — do not run a
   degraded single-timestamp physics pass. Every physics constraint in R5.1–R5.4 is
   an inter-timestamp relationship (a rate of change, a minimum run length, a
   multi-step ramp trajectory); none of these are meaningfully defined at N=1.
   ```
   ValueError: enable_rd_generator_physics=True requires N_TIMESTAMPS > 1.
   Generator physics constraints (gradients, min-up/down, start-up/shutdown ramps)
   are inter-timestamp relationships and are undefined for a single timestamp.
   ```

Both checks run once, early, in `run_pipeline.py`, before any preprocessing or
MILP construction — consistent with R2's "both flags False raises" precondition
pattern.

### Physics scope: preventive dispatch only (CORNET-4614 Outlook)

**Confirmed directly from the functional spec, not inferred.** CORNET-4614
("Consideration of PRAs and CRAs of redispatch RAs for the same Generating Unit")
establishes that Pmin/Pmax constraints apply to the **combined** preventive+curative
production of a unit (`P_prod + ΔP_PRA` for base case, `P_prod + ΔP_PRA + ΔP_CRA`
for each contingency case) — this is what R3.6 already implements. Immediately
after presenting these combined formulas, the spec's own "Outlook" note states:

> "Further technical limits (e.g. restrictions due to max. power gradients) will be
> tackled in a later release."

This means the spec itself scopes power gradients, and by extension the rest of the
generator physics layer (min-up/down, start-up/shutdown, lead/lag times), to the
**preventive** dispatch trajectory only. Concretely:

- All R5.1–R5.4 constraints (gradients, minimum up/down time, start-up ramp,
  shutdown ramp) apply to `rd_net_injection_g[t]` — the preventive RD adjustment per
  generating unit per timestamp (the same `Expression` built in R2.4) — **not** to
  the combined preventive+curative dispatch.
- Curative RD volume (`curative_rd_volume_upward` / `curative_rd_volume_downward`
  from R3.6) remains governed only by the combined Pmin/Pmax envelope already built
  in R3.6. It is not additionally constrained by ramp rate, commitment state,
  start-up, or shutdown logic in R5.
- A generating unit can therefore be ramp-constrained on its preventive trajectory
  while still being available for an unconstrained curative adjustment on top,
  within the combined Pmin/Pmax bounds — this is a deliberate, spec-confirmed scope
  boundary, not an oversight.

### Naming convention (applies throughout R5, correcting earlier drafts of this file)

This release plan file was originally drafted before the pypowsybl migration and the
R2 naming conventions were established. All references below use the corrected,
current naming: `rd_volume_upward` / `rd_volume_downward` (not `dP_pos` / `dP_neg`),
`unit_committed[t,g]` (not `B_on[t,g]`), `network.get_generators()` columns
`target_p` / `max_p` / `min_p` (not CGM EquipmentProfile), `radp` from R2.10
(not "R3.10"), `TIMESTAMP_LIST` (not `r_schedule[t]` as a time index source — use
`rd_schedule[t]` for the pre-RAO production schedule per unit, sourced from
`network.get_generators()` `target_p` per timestamp once R4's multi-timestamp
network state exists).

---

## Deferred items (R5 scope)

| Item | Reason deferred |
|------|----------------|
| End-of-timeframe constraints for min-up/down | Spec marks as TBD outlook; deferred |
| Physics constraints on curative RD dispatch | Spec's own CORNET-4614 Outlook note defers this explicitly; curative RD remains governed by combined Pmin/Pmax from R3.6 only |
| Countertrade, HVDC, system constraints | Out of scope for R5; these remain in R6, untouched by the PST/RD workflow split |

---

## R5.1 — Power gradient constraints (CORNET-45, CORNET-46)

**Spec ref:** CORNET-45 — Consideration of Power Gradient Constraint of Generating Units;
CORNET-46 — Consideration of Power Gradients at the Beginning and End of the
Optimisation Period

**Composability note:** Guarded by the R5 cross-cutting preconditions
(`enable_rd_generator_physics=True` requires `enable_rd_remedial_actions=True` and
`N_TIMESTAMPS > 1`). Constrains `rd_net_injection_g[t]` (preventive only, per the
"Physics scope" note above) — never the combined preventive+curative dispatch.

**What it delivers:**
- For each generating unit `g` with `raise_ramp_rate > 0` or `lower_ramp_rate > 0`
  (from `network.get_generators()` — confirm exact column name against the live
  pypowsybl API; if not exposed there, parse from the NCP RA profile's
  `GeneratingUnit.raiseRampRate` / `lowerRampRate` as a fallback and flag which
  source was used):
  add inter-timestamp ramp constraints (hard, no relaxation) on the preventive
  RD trajectory:
  ```
  rd_net_injection_g[t] − rd_net_injection_g[t-1] ≤ raise_ramp_rate[g] · 1h
  rd_net_injection_g[t-1] − rd_net_injection_g[t] ≤ lower_ramp_rate[g] · 1h
  ```
  where `rd_net_injection_g[t]` is the same Pyomo `Expression` built once in R2.4
  (participation-factor-weighted sum of `rd_volume_upward` / `rd_volume_downward`
  across bids linked to unit `g`)
- If the pre-RAO schedule (`rd_schedule[t]`, i.e. `target_p` per timestamp before
  RAO) already violates the gradient limit between two consecutive timestamps:
  relax the limit to the observed schedule gradient for that timestamp and log a
  WARNING
- Per CORNET-46: no ramp constraint between the first timestamp and the period
  before, and none between the last timestamp and the period after — i.e. no
  constraint references `t-1` for the first timestamp in `TIMESTAMP_LIST`, and none
  references `t+1` for the last

**Inputs:**
- `RDList` (from R0.7), `glsk` (from R2.3) — for `rd_net_injection_g` reconstruction
- `network` (pypowsybl `Network`) — `raise_ramp_rate`, `lower_ramp_rate` per unit
- `rd_schedule[t]` — pre-RAO production schedule per unit per timestamp (from R4.1's
  per-timestamp network state, `target_p` before any RD activation)

**Outputs:**
- Updated `milp_model` with ramp constraints on `rd_net_injection_g[t]`
- `results_ramp_violations.csv`: columns `[gu_mrid, gu_name, timestamp_pair,
  observed_gradient_mw_per_h, limit_used_mw_per_h, relaxed]`

**Acceptance criteria:**
- Given a unit with `raise_ramp_rate = 50 MW/h` and a pre-RAO production of 200 MW,
- When the MILP is solved with `enable_rd_generator_physics=True`,
- Then the preventive RD activation at any timestamp does not increase the unit's
  preventive dispatch by more than 50 MW compared to the previous timestamp (unless
  the schedule already exceeded that rate, in which case the relaxed limit is used
  and logged) AND no gradient constraint exists between the first/last timestamp
  and a timestamp outside `TIMESTAMP_LIST`.
- Given `enable_rd_generator_physics=False`,
- When the MILP is built,
- Then no ramp constraint exists on the model at all.

---

## R5.2 — Minimum up and down times (CORNET-4595)

**Spec ref:** CORNET-4595 — Minimum up and down times of Generating Units;
CORNET-4593 — Limits of minimum up and down times of the Generating Unit

**Composability note:** Same guard as R5.1. `unit_committed[t,g]` tracks the
preventive commitment state only.

**What it delivers:**
- Parse `min_up_time_hours` and `min_down_time_hours` per generating unit from the
  `PowerBidSchedule` in `{TSO}_SIS.xml` (if multiple bids for the same unit define
  different values, use the maximum per the project's existing R0.7 convention)
- Add binary commitment variable `unit_committed[t, gu_mrid] ∈ {0,1}` per unit per
  timestamp (Pyomo `Var(domain=pyo.Binary)`) — linked to `rd_net_injection_g[t] > 0`
  via big-M, not reusing `ra_activated` from R2.8 directly (that variable is
  per-bid-RA, this one is per-generating-unit and per-timestamp)
- Minimum up time constraint: if unit transitions off→on at timestamp `t_start`,
  it must remain on for at least `min_up_time_hours` consecutive timestamps:
  ```
  Σ_{t'=t}^{t+min_up_time_hours-1} unit_committed[t',g]
    ≥ min_up_time_hours · (unit_committed[t,g] − unit_committed[t-1,g])
  ```
  (only enforced for the available remaining timestamps if `t + min_up_time_hours`
  exceeds `N_TIMESTAMPS`)
- Minimum down time constraint: symmetric, using `1 − unit_committed`
- Determine pre-optimisation commitment status from the pre-RAO schedule:
  `unit_committed_initial[g] = 1` if `rd_schedule[first_timestamp][g] > 0` else `0`
- Business rule from CORNET-4593: if the minimum up/down time is violated by the
  pre-RAO schedule itself, adjust the minimum down/up time downward to the actual
  number of consecutive timestamps observed (rounded up to a full timestamp), log a
  WARNING, and apply the adjusted value for the entire optimisation period (the
  minimum is a constant, so the adjustment is global, not per-timestamp)

**Inputs:**
- `PowerBidList` (`min_up_time_hours`, `min_down_time_hours` per bid)
- `RDList`, `glsk` (from R2.3)
- `rd_schedule[t]` (pre-RAO production schedule per unit per timestamp)

**Outputs:**
- Updated `milp_model` with binary commitment variables and min-up/down constraints
- `results_commitment.csv`: columns `[gu_mrid, gu_name, timestamp, committed,
  initial_committed]`

**Acceptance criteria:**
- Given a unit with `min_up_time_hours = 3` that is switched on by the RAO at
  timestamp `t`,
- When the MILP is solved,
- Then `unit_committed[t',g] == 1` for `t' ∈ [t, t+2]` (or the available remaining
  timestamps if `N_TIMESTAMPS < t+3`).
- Given a unit whose pre-RAO schedule already violates its stated
  `min_down_time_hours`,
- When the MILP is built,
- Then the minimum down time is adjusted downward to the observed consecutive-off
  duration, logged as a WARNING, and applied uniformly across the optimisation.

---

## R5.3 — Start-up ramp (CORNET-47, CORNET-49, CORNET-69)

**Spec ref:** CORNET-47 — Definition of start-up; CORNET-49 — Start-up process
without prior start-up; CORNET-69 — Start-up process with prior start-up

**Composability note:** Same guard as R5.1/R5.2. Constrains the preventive
production trajectory only.

**What it delivers:**
- Attempt to read `startup_time_hours` directly from `GeneratingUnit.startupTime`
  in the CGMES 3.0 EquipmentProfile via pypowsybl (confirm exact accessor against
  the live network object — this attribute may not be exposed as a standard
  `network.get_generators()` column; check `network.get_extension()` or equivalent
  before assuming absence):
  - If present and `> 0`: use it directly as `startup_time_hours`
  - If absent or zero: fall back to `startup_time_hours = ceil(pmin[g] / raise_ramp_rate[g])`
  - Log which source was used per unit (`cgmes` or `ramp_derived`)
- Start-up and shutdown are only modelled if `pmin != 0` for the unit (per the
  spec's explicit note: "Startups and shutdowns are only taken into account if
  PMin > 0 MW or PMin < 0 MW")
- During the start-up phase (timestamps from `unit_committed` transitioning 0→1 to
  reaching `pmin`), constrain the preventive production to a linear ramp:
  `rd_net_injection_g[t_start + k] = (k / startup_time_hours) · pmin[g]`
  for `k = 0..startup_time_hours`
- For units already in a start-up phase before the optimisation timeframe begins
  (CORNET-69): set `pmin_effective[g,t] = rd_schedule[t][g]` for timestamps within
  the in-progress ramp, preventing the RAO from forcing a linear ramp retroactively
  onto a start-up that began before `START_HOUR`

**Inputs:**
- `RDList` (`pmin`, `raise_ramp_rate` per unit, from `network.get_generators()` /
  NCP fallback)
- `network` — `GeneratingUnit.startupTime` (CGMES 3.0, optional)
- `rd_schedule[t]` (to detect in-progress start-ups before `START_HOUR`)

**Outputs:**
- Updated `milp_model` with start-up ramp constraints
- `results_startup.csv`: columns `[gu_mrid, gu_name, timestamp, startup_triggered,
  startup_time_hours, startup_time_source, pmin_mw]`

**Acceptance criteria:**
- Given a unit with `pmin = 100 MW` and `raise_ramp_rate = 50 MW/h`, starting from
  zero, with no `startupTime` attribute present,
- When the RAO starts the unit at timestamp `t`,
- Then `rd_net_injection_g[t] = 0`, `rd_net_injection_g[t+1] = 50 MW`,
  `rd_net_injection_g[t+2] = 100 MW` (`startup_time_hours = 2`, ramp-derived) AND
  if a CGMES `startupTime = 3` is present, `startup_time_hours = 3` is used instead
  and `startup_time_source = "cgmes"` is logged.
- Given a unit with `pmin = 0`,
- When start-up modelling is evaluated,
- Then no start-up ramp constraint is built for that unit.

---

## R5.4 — Shutdown ramp (CORNET-48, CORNET-50, CORNET-70)

**Spec ref:** CORNET-48 — Definition of shut-down; CORNET-50 — Shutdown process
without prior shutdown; CORNET-70 — Shutdown process with prior shutdown

**Composability note:** Same guard as R5.1–R5.3. Constrains the preventive
production trajectory only. Symmetric to R5.3.

**What it delivers:**
- Compute `shutdown_time_hours = ceil(pmin[g] / lower_ramp_rate[g])`
- During the shutdown phase (timestamps from last timestamp at `pmin` to zero),
  constrain the preventive production to a linear ramp downward:
  `rd_net_injection_g[t_end - k] = (k / shutdown_time_hours) · pmin[g]`
  for `k = 0..shutdown_time_hours`
- For units already in a shutdown phase before the optimisation timeframe begins
  (CORNET-70): set `pmax_effective[g,t] = rd_schedule[t][g]` for timestamps within
  the in-progress ramp
- Skip shutdown modelling for units with `pmin == 0` (same rule as R5.3)

**Inputs:**
- `RDList` (`pmin`, `lower_ramp_rate` per unit)
- `rd_schedule[t]`

**Outputs:**
- Updated `milp_model` with shutdown ramp constraints
- `results_shutdown.csv`: columns `[gu_mrid, gu_name, timestamp, shutdown_triggered,
  shutdown_time_hours, pmin_mw]`

**Acceptance criteria:**
- Given a unit with `pmin = 100 MW` and `lower_ramp_rate = 50 MW/h` being shut down
  starting at timestamp `t`,
- When the MILP is solved,
- Then `rd_net_injection_g[t] = 100 MW`, `rd_net_injection_g[t+1] = 50 MW`,
  `rd_net_injection_g[t+2] = 0 MW` (`shutdown_time_hours = 2`).

---

## R5.5 — Lead and lag times (CORNET-4596, CORNET-91)

**Spec ref:** CORNET-4596 — Input data on lead and lag times; CORNET-91 —
Consideration of lead times in RAO

**Composability note:** Same guard as R5.1–R5.4. This is distinct from R2.10's bid
lead time (`bid_lead_time_hours`, which constrains when a bid's volume becomes
usable at all) — R5.5's lead/lag times constrain when a unit already in operation
can *change* its output, and when a unit can start up or shut down. Both mechanisms
can apply to the same unit simultaneously; they are not mutually exclusive.

**What it delivers:**
- Parse per-unit lead/lag times: `running_lead_time_hours`, `cold_lead_time_hours`,
  `warm_lead_time_hours`, `lag_time_hours`, `cool_down_time_hours` (source profile
  to be confirmed against live NCP data — likely `{TSO}_SIS.xml` `PowerBidSchedule`
  extension fields; verify exact CIM path before implementation, following the same
  "check against real files before guessing" discipline used throughout R0–R3)
- Determine warm vs. cold status for each unit based on `cool_down_time_hours`
  lookback in `rd_schedule[t]` (how long the unit has been off before `START_HOUR`)
- For running units: fix `rd_net_injection_g[t] = 0` for all timestamps where
  `t ≤ radp + running_lead_time_hours` (using `radp` computed in R2.10 — reuse that
  function, do not recompute)
- For start-ups: fix `unit_committed[t,g] = 0` for timestamps where
  `t < radp + cold_lead_time_hours` (cold) or `t < radp + warm_lead_time_hours` (warm)
- For shutdowns: fix `unit_committed[t,g] = 1` for timestamps where
  `t < radp + lag_time_hours`
- Business rule: if `running_lead_time_hours > cold_lead_time_hours` or
  `> lag_time_hours`, set `running_lead_time_hours = min(cold_lead_time_hours, lag_time_hours)`
  and log a WARNING

**Inputs:**
- NCP source TBD (see note above) — per-unit lead/lag time attributes
- `radp` (from R2.10 — **reuse, do not rebuild**; the coder flagged this exact reuse
  opportunity when closing out R2), `TIMESTAMP_LIST`, `rd_schedule[t]`

**Outputs:**
- Updated variable bounds in `milp_model`
- `results_lead_lag.csv`: columns `[gu_mrid, gu_name, warm_cold_status,
  running_lead_time_hours, cold_lead_time_hours, warm_lead_time_hours,
  lag_time_hours, earliest_runnable_timestamp, earliest_startup_timestamp,
  earliest_shutdown_timestamp]`

**Acceptance criteria:**
- Given a unit with `running_lead_time_hours = 2` and `radp = "2200Z"` and
  `START_HOUR = "0030Z"`,
- When lead time is enforced using the same ceiling-to-next-timestamp rule
  confirmed for R2.10 (see R2.10's corrected acceptance criterion — first usable
  timestamp is the one strictly after `radp + lead_time`, not the one at or before),
- Then `rd_net_injection_g["0030Z", g] = 0`, `rd_net_injection_g["0130Z", g] = 0`,
  and non-zero activation is permitted from the correctly-computed earliest usable
  timestamp onwards.

**Open item:** the exact CIM source path for `running_lead_time_hours` /
`cold_lead_time_hours` / `warm_lead_time_hours` / `lag_time_hours` /
`cool_down_time_hours` must be confirmed against the real `{TSO}_SIS.xml` /
`{TSO}_RA.xml` files before coding — do not guess the property names the way GLSK's
`PowerShiftKeySchedule` naming had to be corrected in R2.3. Check the files first.

---

## R5.6 — Start-up costs (BUC14#103)

**Spec ref:** BUC14#103 — Consideration of generating unit start-up costs

**Composability note:** Same guard as R5.1–R5.5.

**What it delivers:**
- Parse `warm_startup_cost_eur` per generating unit (source profile TBD — confirm
  against live NCP data before implementation; the original draft of this file
  referenced `ErExtensionDocument.GenExtensionErList`, which has not been verified
  against the actual ReliCapGrid dataset and should be checked, not assumed)
- If `warm_startup_cost_eur` is not defined for a unit: the unit cannot be started
  from off by the RAO — fix `unit_committed[t,g] = 0` for all `t` if
  `unit_committed_initial[g] == 0` and no start-up cost is defined
- If defined: add a start-up cost term to the objective:
  `Σ_t warm_startup_cost_eur[g] · unit_startup[t,g]`
  where `unit_startup[t,g]` is an auxiliary binary with
  `unit_startup[t,g] ≥ unit_committed[t,g] − unit_committed[t-1,g]`
- Log a negative `warm_startup_cost_eur` as a fatal error (per spec business rule)

**Inputs:**
- Per-unit `warm_startup_cost_eur` (source TBD — verify against real files)
- `milp_model` (binary `unit_committed` variables from R5.2)

**Outputs:**
- Updated `milp_model` objective with start-up cost terms
- `results_startup_costs.csv`: columns `[gu_mrid, gu_name, timestamp,
  startup_triggered, startup_cost_eur]`

**Acceptance criteria:**
- Given a unit with no `warm_startup_cost_eur` defined that is off before the
  optimisation,
- When the MILP is solved,
- Then the unit remains off in the result AND a unit with
  `warm_startup_cost_eur = 5000` is started only if its start-up cost plus RD cost
  is lower than the congestion penalty avoided.

---

## R5.7 — Energy limits per bid (CORNET-3626, CORNET-3711)

**Spec ref:** CORNET-3626 — Minimum Energy Limit for Power Bids;
CORNET-3711 — Maximum Energy Limit

**Composability note:** Same guard as R5.1–R5.6. Applies to preventive bid volumes
(`rd_volume_upward` / `rd_volume_downward` from R2.4) across all timestamps — this
is inherently a multi-timestamp aggregate, consistent with why Full RD requires
`N_TIMESTAMPS > 1`.

**What it delivers:**
- For each bid with `min_energy_mwh > 0`:
  add a constraint using a binary `bid_active[bid_mrid] ∈ {0,1}` (reuse `ra_activated`
  from R2.8 if the bid's parent RA activation binary already captures this; otherwise
  introduce a bid-level binary):
  `Σ_t (rd_volume_upward[t,b] + rd_volume_downward[t,b]) · 1h ≥ min_energy_mwh[b] · bid_active[b]`
- For each bid with `max_energy_mwh > 0`:
  add a hard constraint (no binary needed):
  `Σ_t (rd_volume_upward[t,b] + rd_volume_downward[t,b]) · 1h ≤ max_energy_mwh[b]`
- `min_energy_mwh` and `max_energy_mwh` from `PowerBidSchedule` in `{TSO}_SIS.xml`
  (confirm exact property names against real files — likely
  `TotalMinimumEnergy` / `TotalMaximumEnergy`, but verify before coding)

**Inputs:**
- `PowerBidList` (`min_energy_mwh`, `max_energy_mwh` per bid), `milp_model`

**Outputs:**
- Updated `milp_model` with energy limit constraints
- `results_energy_limits.csv`: columns `[bid_mrid, ra_mrid, total_activated_mwh,
  min_energy_mwh, max_energy_mwh, constraint_active]`

**Acceptance criteria:**
- Given a bid with `min_energy_mwh = 50` activated across 4 timestamps,
- When the MILP is solved,
- Then `Σ_t (rd_volume_upward[t,b] + rd_volume_downward[t,b]) · 1h ≥ 50` if
  `bid_active == 1` AND the constraint is inactive if the bid is never used.

---

## R5.8 — RD step sizes (CORNET-3632)

**Spec ref:** CORNET-3632 — Consideration of RD step size

**Composability note:** Same guard as R5.1–R5.7. Replaces the continuous
`rd_volume_upward` / `rd_volume_downward` domain from R2.4 with integer-step
variables when active — this is a domain change to R2.4's existing variables, not
new variables; flag explicitly as a modification to committed R2 model structure,
gated entirely behind `enable_rd_generator_physics`.

**What it delivers:**
- When `step_size_active == True` (RAO control parameter, default True):
  replace continuous `rd_volume_upward[t,b]` / `rd_volume_downward[t,b]` with
  integer-step variables:
  `rd_volume_upward[t,b] = step_size_mw[b,t] · steps_upward[t,b]`
  where `steps_upward[t,b]` is a non-negative integer Pyomo `Var`, bounded by
  `floor(max_rd_volume_upward[t,b] / step_size_mw[b,t])`
  symmetric for `rd_volume_downward` / `steps_downward`
- If `step_size_mw` is not defined for a bid: default to `step_size_mw = 1`
- If `step_size_active == False`: keep continuous variables (R2.4 behaviour unchanged)

**Inputs:**
- `PowerBidList` (`step_size_mw` per bid per timestamp — confirm exact CIM property
  against real files, likely `PowerBidScheduleTimePoint.stepincrementP` but verify)
- RAO control parameter: `step_size_active: bool`

**Outputs:**
- Updated `milp_model` with integer step variables (when active)
- `results_step_sizes.csv`: columns `[bid_mrid, timestamp, step_size_mw,
  steps_activated, total_activated_mw]`

**Acceptance criteria:**
- Given a bid with `step_size_mw = 5` and `max_rd_volume_upward = 100` and
  `step_size_active = True`,
- When the MILP is solved,
- Then the activated volume is a multiple of 5 MW and does not exceed 100 MW.
- Given `step_size_active = False`,
- When the MILP is built,
- Then `rd_volume_upward` / `rd_volume_downward` remain continuous, identical to
  R2.4 behaviour.

---

## R5.9 — Bid activation costs (BUC14#102)

**Spec ref:** BUC14#102 — Consideration of Power Bid activation costs

**Composability note:** Same guard as R5.1–R5.8. Activation costs apply to
preventive bids only (per spec assumption, confirmed below) — consistent with the
overall "physics/costs apply to preventive dispatch" scope of R5.

**What it delivers:**
- For each bid with `activation_cost_eur > 0`:
  add an activation cost term to the objective, incurred once per contiguous
  activation sequence across timestamps:
  `Σ_t activation_cost_eur[b] · bid_activation_started[t,b]`
  where `bid_activation_started[t,b] = 1` if bid `b` is first activated at
  timestamp `t` within a contiguous run (`bid_active[t,b] = 1` and
  `bid_active[t-1,b] = 0`), modelled as:
  `bid_activation_started[t,b] ≥ bid_active[t,b] − bid_active[t-1,b]`
- Activation costs apply to preventive bids only, not curative (per spec assumption)
- If `activation_cost_eur` is zero or undefined: no term added

**Inputs:**
- `PowerBidList` (`activation_cost_eur` per bid), `milp_model`

**Outputs:**
- Updated `milp_model` objective with activation cost terms
- Extended `results_preventive_rd.csv` (from R2.7) with `activation_cost_eur` column

**Acceptance criteria:**
- Given a bid activated in timestamps `t` and `t+1` (contiguous) and then again in
  `t+3` (non-contiguous),
- When activation costs are computed,
- Then the activation cost is incurred twice (once for the `t`–`t+1` sequence, once
  for `t+3`), not three times.

---

## R5.10 — Shutdown costs (CORNET-71)

**Spec ref:** CORNET-71 — Consideration of shut-down costs

**Composability note:** Same guard as R5.1–R5.9. Symmetric to R5.6.

**What it delivers:**
- Parse `shutdown_cost_eur` per generating unit (same source document as
  `warm_startup_cost_eur` from R5.6 — confirm against real files, do not assume)
- If `shutdown_cost_eur > 0`: add a shutdown cost term to the objective:
  `Σ_t shutdown_cost_eur[g] · unit_shutdown[t,g]`
  where `unit_shutdown[t,g]` is an auxiliary binary with
  `unit_shutdown[t,g] ≥ unit_committed[t-1,g] − unit_committed[t,g]`
- If `shutdown_cost_eur` is undefined or zero: no term added
- Log a negative `shutdown_cost_eur` as a fatal error (consistent with R5.6's rule)
- Note: shutdown and start-up costs can both apply to the same unit within the same
  optimisation window if it is shut down and restarted — log the combined cost
  contribution per unit for visibility

**Inputs:**
- Per-unit `shutdown_cost_eur` (source TBD, same document as R5.6)
- `milp_model` (binary `unit_committed` variables from R5.2)

**Outputs:**
- Updated `milp_model` objective with shutdown cost terms
- Extended `results_startup_costs.csv` with `shutdown_triggered` and
  `shutdown_cost_eur` columns per unit per timestamp

**Acceptance criteria:**
- Given a unit in operation before the optimisation with `shutdown_cost_eur = 3000`
  that is shut down by the RAO at timestamp `t`,
- When the MILP is solved,
- Then the shutdown cost of 3000 EUR appears in the objective contribution for that
  unit at timestamp `t` AND a unit with no defined `shutdown_cost_eur` is shut down
  without any cost penalty in the objective.
