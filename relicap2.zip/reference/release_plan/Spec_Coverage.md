# Spec coverage

Reference document. Not for agents. Written 2026-10-12 from the code (not from the docs) by reading modules and tests row by row, with DECISIONS up to 39 and ASSUMPTIONS up to 16. Spec: R25_1-ELA-SFS-SYS_14_03_RAO_Calculation-LOT3_09FIN (v14.11.2025). Identifiers are the spec's CORNET / BUC / SF numbers.

The release plan files in this folder (R0-R6) are the original plan. They are partly out of date: where a plan file and this document disagree, this document and the code are right.

**Status words.** Built = in the code and tested. Partly = some of the title is in the code. Deviation = built differently from the spec on purpose (D = DECISIONS number). Not built = in the plan, not in the code.

## 1. Summary

| Release | Content | Built | Partly | Deviation | Not built |
|---|---|---|---|---|---|
| R0 | Data ingestion | 6 | 1 | 2 | 0 |
| R1 | N-0 PST | 7 | 1 | 2 | 0 |
| R2 | N-0 RD | 11 | 1 | 0 | 0 |
| R3 | N-X and curative | 7 | 2 | 2 | 0 |
| R4 | Multi-timestamp | 0 | 1 | 0 | 9 |
| R5 | Generator physics | 0 | 0 | 0 | 10 |
| R6 | HVDC, countertrade, system constraints | 0 | 0 | 0 | 10 |
| Total | 72 rows | 31 | 6 | 6 | 29 |

## 2. What this means

- R0-R3 (single timestamp, N-0 and N-X, preventive and curative PST and RD) are in the code. The gaps inside them are the Partly and Deviation rows below.
- R4-R6 are not built (decision "single timestamp", D1, D20). The only trace is the per-timeframe RA-count limit (R4.7) and parsed-but-unused fields (section 7).
- Open gaps worth a decision: R0.8 SAR cross-check; R1.3 operating and relative PST tap limits never read; R2.8 RA count covers preventive RD only; R3.5 curative taps continuous; R3.7 only Pmax/Pmin per contingency; eq. 3.35 not built (R1.7).

## 3. Increments R0-R6, status per row

| ID | Title | Spec items | Status | Evidence | Note |
|---|---|---|---|---|---|
| R0.1 | CGM load and base-case AC load flow | CORNET-97 | Built | `pre_milp/cgmes_loader.py:37` `load_cgm`, `:58` `run_initial_loadflow`; `test_a_non_converged_initial_load_flow_halts_with_runtime_error_and_a_fatal_log` | `use_reactive_limits` false by default (D32). |
| R0.2 | TSO name resolution via EQ file SubGeographicalRegion | §3.2.1 | Deviation (D35) | `pre_milp/tso_name_resolver.py:41` `_build_from_org_file` (called `run_pipeline.py:431`); `test_returns_four_tsos` | Names come from the Organisation profile; the EQ path `build_substation_mrid_to_tso` (`:85`) exists but the pipeline never calls it and no test covers it. |
| R0.3 | NCP file discovery and TSO inventory | CORNET-85 | Built | `pre_milp/ncp_loader.py:64` `extract_ncp_zip`, `:111` `classify_extracted_ncp_files`; `test_missing_required_profile_raises` | Input is one flat `ncp*.zip`; profiles SSI, ER, PS, RAS, FAP skipped without a warning (D37). |
| R0.4 | Assessed element (XNE) parsing with exclusion logic | CORNET-336, SF927 | Deviation (D15) | `pre_milp/ncp_parser.py:107` `parse_assessed_elements`, classification `:273-295`; `test_ae_with_neither_region_code_nor_exclusion_is_excluded_and_logged` | Scanned code only = secured; scanned only when an exclusion reason and a scanned code are both present. |
| R0.5 | Contingency parsing | CORNET-3693 | Built | `pre_milp/ncp_parser.py:361` `parse_contingencies`; `test_returns_contingencies_with_valid_equipment` | CoMo type "bus" not mapped (D37); contingency type is parsed but never used. |
| R0.6 | PST remedial action parsing | CORNET-338, CORNET-21 | Built | `pre_milp/ncp_parser.py:623` `parse_psts`; `test_returns_pst_with_known_tapchanger` | Operating tap range is the CGM hardware range; no NCP operating limits read (see R1.3). |
| R0.7 | RD remedial action and power bid parsing | CORNET-335 | Built | `pre_milp/ncp_parser.py:921` `parse_rd_units`; `test_the_bid_price_is_the_price_of_the_run_timestamp` | Price of the run timestamp only (D28); Redispatch/Countertrade RAs ignored with a warning (D37). |
| R0.8 | Inventory summary and SAR cross-check |  | Partly | `pre_milp/inventory_summary.py:12` `print_inventory_summary`; test none | Inventory table is logged; no SAR cross-check exists in the code. |
| R0.9 | Scanned element parsing | CORNET-439 | Built | `pre_milp/scanned_elements.py:28` `build_scanned_element_list`; `test_case3_lf_exceeds_patl_effective_equals_lf` | The list only feeds `scanned_element_list.csv`; the MILP recomputes limits in `milp/milp_builder.py:212`. Virtual margin 0 (A11). |
| R1.1 | Initial AC load flow convergence check | CORNET-111 | Built | `pre_milp/cgmes_loader.py:81-83`; `test_a_non_converged_initial_load_flow_halts_with_runtime_error_and_a_fatal_log` | Status read from component 0 only (A10). |
| R1.2 | N-0 AC sensitivity matrix for PSTs | CORNET-4836, CORNET-102 | Built | `pre_milp/n0_sensitivity.py:141` `compute_sensitivity_pst_n0`; `test_compute_sensitivity_pst_n0_mixed_sides_issues_two_calls` | Side-aware, same LF parameters (D10), guarded (D12); 3-winding PSTs left out (D37). |
| R1.3 | PST tap bounds and operational limit constraints | CORNET-2895 | Partly | `pre_milp/pst_bounds.py:10` `build_pst_tap_bounds`, `milp/milp_builder.py:374-396`; `test_hardware_and_operating_limits_applied` | Bounds logic exists, but operating and relative limits are never parsed: operating = hardware (`ncp_parser.py:742-744`), relative limits always None. |
| R1.4 | PST group equality constraint construction | CORNET-21 | Built | `pre_milp/pst_groups.py:12` `build_pst_group_equality_pairs`, `milp/milp_builder.py:386-397`; `test_valid_group_builds_pairs` | Pairs naming a dropped PST are dropped (D18). |
| R1.5 | N-0 MILP construction: PST variables and XNE loading constraints | CORNET-1790 | Built | `milp/milp_builder.py:1480` `build_n0_milp_model`, `:1588-1597` `xne_loading_n0`; `test_pst_only_solves_to_expected_tap_change` | Soft (slack) constraint; cumulative tap variables (D4). |
| R1.6 | Pyomo/HiGHS solve and result extraction | SF3079 | Built | `milp/milp_solver.py:49` `solve_n0_milp_model`; `test_a_real_model_is_solved_and_its_tap_change_extracted` | Non-optimal raises and ends the loop as `SOLVER_NON_OPTIMAL` (D23). |
| R1.7 | Post-solve LF and linearisation loop | CORNET-12, CORNET-4850 | Deviation (D9) | `milp/ac_convergence_loop.py:338` `run_post_rao_ac_verification_loop`; `test_run_post_rao_linearisation_loop_terminates_on_threshold` | Built per D2-D8; the sum-of-RA-change criterion (eq. 3.35) is not built, taps and MW share one threshold. |
| R1.8 | PST penalty costs in objective function | CORNET-2998 | Built | `milp/milp_builder.py:1641-1655`; `test_objective_equals_cost_of_cumulative_changes_after_several_iterations` | Missing `penaltyFactor` = 1.0 with a warning (D27); priced on the cumulative change. |
| R1.9 | Full LF result output per branch and per node | CORNET-98, CORNET-3221 | Deviation (D37) | `pre_milp/cgmes_loader.py:288` `write_lf_basecase_csv`, `post_milp/n0_results_export.py:1237` `write_lf_post_iterations_csv`; `test_lf_post_n0_holds_every_ac_iteration_up_to_the_summary_iteration_count` | `lf_results_branches.csv` / `lf_results_buses.csv` not produced; no per-node output; `lf_post_n0.csv` lists secured branches only. |
| R1.10 | PST tap-change limit per TSO, single-timestamp | CORNET-3653, CORNET-3654 | Built | `milp/milp_builder.py:450-481` `max_taps_per_tso_constraint`; `test_constraint_blocks_a_combined_move_exceeding_the_per_tso_limit` | Hard, cumulative, preventive PSTs only; per-TSO overrides. |
| R2.1 | N-0 AC sensitivity matrix for RD units | CORNET-4836, CORNET-102 | Built | `pre_milp/n0_sensitivity.py:253` `compute_sensitivity_rd_n0`; `test_compute_sensitivity_rd_n0_side_routing_and_shape` | Preventive available units only. |
| R2.2 | Sensitivity threshold pruning | CORNET-3624 | Built | `pre_milp/n0_sensitivity.py:400` `prune_sensitivity_by_threshold`, `pre_milp/nx_sensitivity.py:529`, `:553`; `test_branch_below_sensitivity_threshold_is_dropped` | N-0 drops the branch from that matrix; N-X drops entries, the pair keeps a slack-only constraint. |
| R2.3 | GLSK participation factor mapping | CORNET-4848 | Built | `pre_milp/glsk_resolver.py:43` `resolve_glsk`; `test_resolve_glsk_normalises_across_two_units` | Only the PowerBidSchedule chain; factors renormalised after dropping units not in the network. |
| R2.4 | RD MILP variables and Pmax/Pmin constraints | CORNET-36, CORNET-37 | Built | `milp/milp_builder.py:564-585`, `:649-656` `pmax_pmin_constraint`; `test_rd_only_pmax_pmin_constrains_dispatch` | Missing Pmax/Pmin = 0.0 with a warning (D16). |
| R2.5 | RD N-0 loading constraints extension |  | Built | `milp/milp_builder.py:640-647` `rd_effect_on_branch`, `:1588-1594`; `test_pst_and_rd_together_both_present_and_summed` |  |
| R2.6 | RD balancing constraint | CORNET-73 | Built | `milp/milp_builder.py:1582-1586` `rd_balancing_n0`; `test_rd_only_balancing_constraint_exists_and_holds_when_solved` | Hard, no slack; preventive RD only. |
| R2.7 | RD penalty and price costs in objective | CORNET-4606 | Built | `milp/milp_builder.py:1678-1713`; `test_cheaper_bid_preferred_when_both_resolve_the_same_congestion` | RA-level penalty factor × reference + run-timestamp price (D28). |
| R2.8 | RA count limit per TSO per timestamp | BUC14#119, CORNET-3649 | Partly | `milp/milp_builder.py:1315` `_add_ra_activation_and_count_constraints`; `test_hard_limit_caps_activated_ra_count` | Counts preventive RD RAs only; PST and curative RAs are not counted. Binary linked one-sided (D5). |
| R2.9 | RA group volume limits | CORNET-4838 | Built | `pre_milp/ncp_parser.py:1167` `parse_ra_groups`, `milp/milp_builder.py:1391-1473`; `test_group_upward_limit_caps_combined_dispatch` | Preventive RD bids only; group predicates inferred (A14). |
| R2.10 | RD lead time enforcement | CORNET-3616 | Built | `milp/milp_builder.py:186-198` `_timestamp_is_usable`, `:613-627`, `:896-914`; `test_bid_with_unmet_lead_time_gets_zero_upper_bounds` | radp = one hour before the timestamp (RAART fixed None, D30). |
| R2.11 | Combined PST+RD results output | BUC14#132 | Built | `post_milp/n0_results_export.py:938` `extract_results_summary`, `:512` `extract_rd_results`; `test_summary_identity_and_cumulative_costs` |  |
| R2.12 | Scanned element MILP constraints | CORNET-439 | Built | `milp/milp_builder.py:1599-1616` `scanned_element_n0`; `test_hard_constraint_acceptance_criterion_loading_never_exceeds_limit` | Hard by default (`scanned_element_constraint_hard`); limit anchored to the original LF (D29). |
| R3.1 | Custom N-X sensitivity computation via conventional AC LF |  | Built | `pre_milp/nx_sensitivity.py:459` `compute_sensitivities_nx`, `pre_milp/nx_security_analysis.py:93` `compute_lf_nx`; `test_one_analysis_for_pst_and_rd_equals_two_analyses_on_the_fixture_network` | Done with one AC sensitivity analysis over all contingencies, checked against the security analysis, not a per-contingency LF perturbation. |
| R3.2 | N-X loading constraints in MILP | CORNET-1790, CORNET-16 | Built | `milp/milp_builder.py:979` `_add_nx_block`, `:1216-1229` `nx_patl_loading`; `test_nx_only_overload_resolved_by_pst_tap_change_end_to_end` | Every secured branch under every must-study contingency (AE-contingency links not used). |
| R3.2a | N-X scanned-element loading constraints | CORNET-439 | Built | `milp/milp_builder.py:1280-1310` `nx_scanned_loading`; `test_scanned_branch_gets_constraint_against_effective_limit` | Always soft; limit = max(PATL, original N-0 current) (D29). |
| R3.3 | TATL constraint for N-X | CORNET-1792 | Deviation (D14) | `pre_milp/nx_security_analysis.py:245` `compute_tatl_data`, `milp/milp_builder.py:1231-1278`; `test_no_tatl_row_falls_back_to_patl_with_600s_duration` | No TATL row: TATL = PATL, 600 s. |
| R3.4 | Curative PST RA parsing and reaction time | BUC14#110, CORNET-1978 | Built | `pre_milp/ncp_parser.py:705-771`, `pre_milp/cra_preprocessing.py:22` `compute_pst_cra_availability`; `test_acceptance_criteria_example_from_spec` | PST without timing data is skipped with a warning. |
| R3.5 | Curative PST variables and MILP constraints | CORNET-1985, SF3074 | Partly | `milp/milp_builder.py:685` `_add_curative_pst_block`; `test_acceptance_criteria_curative_pst_linked_to_one_contingency_only` | Curative tap variables are continuous (`NonNegativeReals`, `:714-719`), not integer; group kind from config (D33). |
| R3.6 | Curative RD RA variables and MILP constraints | BUC14#106, CORNET-4614 | Deviation (D31) | `milp/milp_builder.py:815` `_add_curative_rd_block`; `test_curative_only_rd_scenario_solves_uses_bid_and_nx_block_links_it` | Reservation priced at the energy price; cost on the max over contingencies. |
| R3.7 | N-X system constraints per contingency | CORNET-498, CORNET-537 | Partly | `milp/milp_builder.py:938-954` `combined_pmax_pmin_constraint`; `test_combined_pmax_pmin_respects_preventive_plus_curative` | Only per-contingency Pmax/Pmin of units with curative RD; no other system constraint per contingency. |
| R3.8 | Completeness iteration loop | CORNET-16 | Built | `milp/ac_convergence_loop.py:1070` `run_nested_rao_loop`, `milp/post_ra_congestion_check.py:244` `find_new_congested_pairs`; `test_runs_the_linearisation_loop_again_when_new_congestion_is_found_then_stops` | New pairs are counted, then enter through the rebuild at the refreshed N-X LF (D2). |
| R3.9 | N-X results export | BUC14#142, BUC14#141 | Built | `post_milp/nx_results_export.py:66`, `:219`, `:265`; `test_columns_match_spec_exactly` | Corridor results not built (D37). |
| R3.10 | Pipeline integration (`ENABLE_NX_ANALYSIS`) |  | Built | `run_pipeline.py:278`, `:776-900`; `test_real_nx_artifacts_produced_and_non_trivial` | Config key `workflow_toggles.enable_nx_analysis`. |
| R4.1 | Multi-timestamp operating point per timestamp |  | Not built | none | D1. A 4-entry timestamp list is built (`run_pipeline.py:440`) and PATL/bids parsed per timestamp, but only `START_HOUR` is optimised. |
| R4.2 | Multi-timestamp MILP variables and N-0 loading constraints |  | Not built | none | D1; one model per single timestamp. |
| R4.3 | PST tap-change limit per timestamp | CORNET-3653 | Not built | none | D1; only the single-timestamp limit of R1.10. |
| R4.4 | PST tap-change limit per optimisation timeframe | CORNET-3654 | Not built | none | D1; with one timestamp the R1.10 limit stands for both. |
| R4.5 | Multi-timestamp RD operating point per timestamp |  | Not built | none | D1; `available_mw` parsed per timestamp (`ncp_parser.py:1127-1129`), one used. |
| R4.6 | Multi-timestamp RD MILP variables, Pmax/Pmin, and N-0 loading constraint extension |  | Not built | none | D1. |
| R4.7 | Multi-timestamp RD balancing, costs, and RA/group limits |  | Partly | `milp/milp_builder.py:1371-1388` `ra_count_limit_per_timeframe`; test none | Only the per-timeframe RA-count limit exists (soft, acts on the one timestamp); no test sets it. Balancing and costs single-timestamp. |
| R4.8 | Multi-timestamp RD lead time enforcement |  | Not built | none | `results_lead_times.csv` reports the earliest usable timestamp of the 4-entry list (`n0_results_export.py:877`); reporting only. |
| R4.9 | Combined PST+RD multi-timestamp linearisation loop and results output |  | Not built | none | D1. |
| R4.10 | Pipeline integration (`ENABLE_MULTITIMESTAMP`) |  | Not built | none | No such config key or flag. |
| R5.1 | Power gradient constraints | CORNET-45, CORNET-46 | Not built | none | Ramp rates parsed (`ncp_parser.py:971-982`) into `RDUnit`, never used. |
| R5.2 | Minimum up and down times | CORNET-4595 | Not built | none | Nothing in the code. |
| R5.3 | Start-up ramp | CORNET-47, CORNET-49, CORNET-69 | Not built | none | Nothing in the code. |
| R5.4 | Shutdown ramp | CORNET-48, CORNET-50, CORNET-70 | Not built | none | Nothing in the code. |
| R5.5 | Lead and lag times | CORNET-4596, CORNET-91 | Not built | none | Single-timestamp lead time only (R2.10); no lag time. |
| R5.6 | Start-up costs | BUC14#103 | Not built | none | D20. |
| R5.7 | Energy limits per bid | CORNET-3626, CORNET-3711 | Not built | none | `minEnergyBid`/`maxEnergyBid` parsed (`ncp_parser.py:1122-1123`), never used. |
| R5.8 | RD step sizes | CORNET-3632 | Not built | none | `stepSizeCTRD` parsed (`ncp_parser.py:1124`), never used. |
| R5.9 | Bid activation costs | BUC14#102 | Not built | none | D20; `activationCost` parsed (`ncp_parser.py:1116-1117`), never used. |
| R5.10 | Shutdown costs | CORNET-71 | Not built | none | Nothing in the code. |
| R6.1 | HVDC equivalent injection parsing | BUC14#55 | Not built | none | HVDC only as LF parameter `hvdc_ac_emulation` and a count in the network summary; AEs via DCTieCorridor skipped (`ncp_parser.py:187-198`). |
| R6.2 | HVDC sensitivity computation |  | Not built | none | Nothing in the code. |
| R6.3 | HVDC MILP variables and balanced group constraint | BUC14#55, §3.6.11 | Not built | none | Nothing in the code. |
| R6.4 | HVDC curative remedial actions | BUC14#55 | Not built | none | Nothing in the code. |
| R6.5 | Countertrade parsing and GLSK strategies | CORNET-4847, CORNET-4848 | Not built | none | `CountertradeRemedialAction` detected and ignored with a warning (`ncp_parser.py:880-918`, D37); PowerShiftKeyStrategy not read. |
| R6.6 | Countertrade MILP variables and constraints |  | Not built | none | Nothing in the code. |
| R6.7 | CT technical limits for generating units | CORNET-4849 | Not built | none | Nothing in the code. |
| R6.8 | System constraints — active power limits | CORNET-498 | Not built | none | Only per-unit Pmax/Pmin (R2.4, R3.7). |
| R6.9 | System constraints — current limits | CORNET-537 | Not built | none | Only per-branch PATL/TATL constraints (R1.5, R3.2, R3.3). |
| R6.10 | Final consolidated results export |  | Not built | none | Result files exist for the single timestamp only. |


## 4. Deviations kept on purpose

| Topic | Spec | This prototype |
|---|---|---|
| TATL | No TATL means none is considered | TATL = PATL with duration 600 s when missing, several, or incomplete |
| Assessed element classes | - | Exactly one of secured, scanned, excluded; neither code and no exclusion reason: excluded, not optimised. Scanned-only without exclusion stays secured. Invalid exclusionReason cancels the RAO (as in the spec) |
| Pmax/Pmin | - | Missing: default 0.0 and a warning per unit (the unit is then fixed) |
| Curative RD cost | - | Reservation priced at the energy price |
| Reactive limits | - | `use_reactive_limits` defaults to false |
| PST group kind | In data | Not in the data: taken from config (blockedGroup and a per-TSO map) |
| PATL source | - | Order: SHS, BaseCaseCurrentLimit, CGM static limit, 0 with warning |
| TSO names | - | From the Organisation profile, not from the EQ sub-region |
| Missing PST penaltyFactor / RD penaltyFactor | - | Default 1.0 with a warning |
| Bid price | - | Price of the run's timestamp; negative or missing: warning, treated as 0 |
| N-X scanned limit | - | max(PATL, original N-0 current) |
| Missing N-0 current | - | NaN, branch excluded with a warning |
| Applied taps | - | Rounded to integers when applied; continuous inside the MILP |
| Contingency analysis | FOA / FCC | Conventional AC security analysis per contingency |
| Fixed parameters | - | `START_HOUR`, `N_TIMESTAMPS`, `RAART`, per-TSO penalty overrides and the CRA-XNE linkage switch are set in code, not in config |


## 5. Out of scope (decided)

SPS (BUC14#131, 111); topological RAs (BUC14#84, 85, 105, 146); CoMo formats and updates (CORNET-4841/4842/4844/4845/4846, SF2927); HPC manager and runtime estimate (BUC14#130, 83); production export formats (CORNET-3697/4344); RA status from RAC (BUC14#115); load-flow internals (CORNET-103-106); per-node and 3-winding results (CORNET-107/109); RTE-specific TATL (CORNET-2586); multi-terminal HVDC; end-of-timeframe min up/down.


## 6. Behaviour in the code that the plan does not mention

One row each: item, where, what it does, whether DECISIONS/ASSUMPTIONS document it.

| Item | Where | What it does | In DECISIONS / ASSUMPTIONS |
|---|---|---|---|
| Required config files, no fallback | `run_pipeline.py:138-154` | Missing `rao_config.yaml` / `load_flow_config.yaml` stops the import | yes (D19) |
| `ConfigKeyError` | `run_pipeline.py:170-189` | Missing key names the dotted key and the file | yes (D19) |
| Config range checks | `run_pipeline.py:192-251` | 9 thresholds ≥ 0, 4 integer keys ≥ 1, solver limit/gap, CSV switch boolean | yes (D19, D38) |
| Unknown-TSO warning for tap overrides | `run_pipeline.py:254-262`, `:433` | Warns per unknown TSO name in `max_taps_per_tso_overrides` only | no |
| `ra_limits.max_taps_per_tso_overrides` | `run_pipeline.py:305-308`, `milp/milp_builder.py:462-469` | Per-TSO override of the tap limit | no |
| `workflow_toggles.pst_taping_discrete` | `run_pipeline.py:279`, `milp/milp_builder.py:370` | Integer or continuous preventive taps | no |
| `workflow_toggles.ra_limit_constraint_hard`, `ra_limits.ra_limit_penalty` | `milp/milp_builder.py:1358-1369`, `:1740-1751` | Hard or soft per-timestamp RA count; penalty per RA over a limit | no |
| `workflow_toggles.scanned_element_constraint_hard`, `penalty_costs.scanned_element_penalty_eur_per_ka` | `milp/milp_builder.py:1604-1616`, `:1762-1767` | Hard N-0 scanned constraint (can make the solve infeasible) or slack priced in EUR/kA | yes (D23, partly) |
| Separate N-X penalty rates (PATL, TATL, scanned) | `run_pipeline.py:331-333`, `milp/milp_builder.py:1769-1791` | Three slack prices for the N-X constraint kinds | no |
| `logging_options.debug_log_mode` | `run_pipeline.py:381-383`, `milp/milp_builder.py:25-36` | Hides solver trace and repeated INFO lines | no |
| Fixed parameters `START_HOUR`, `N_TIMESTAMPS`, `RAART`, per-TSO penalty overrides, `ACTIVATE_CRA_XNE_LINKAGE` | `run_pipeline.py:129-130`, `:346-354` | Hard-coded run constants | yes (D30) |
| Input discovery `cgm*` / `ncp*` | `run_pipeline.py:102-126` | Exactly one zip per prefix in `input/`, else stop | no |
| NCP zip duplicate-name check | `pre_milp/ncp_loader.py:80-96` | Two entries with one base name stop the run | no |
| Known-irrelevant NCP files | `pre_milp/ncp_loader.py:25-61`, `:136-137` | SSI, CD_OR, other profiles, cross-TSO exports skipped silently | yes (D37) |
| Stale output deletion | `output_file_registry.py:57-74`, `run_pipeline.py:370-377` | Deletes registered result files of an earlier run at start | no |
| `run_log.txt` | `run_pipeline.py:364-366` | Log file, overwritten per run | no |
| One LF parameter set everywhere | `pre_milp/lf_parameters.py:18-30` | Same parameters for LF, security and sensitivity analyses | yes (D10) |
| Contingency propagation off | `pre_milp/lf_parameters.py:33-46` | Security analysis trips only the listed equipment | yes (D11) |
| `component_mode` MAIN_SYNCHRONOUS, `use_reactive_limits` false | `config/load_flow_config.default.yaml:23`, `:75` | LF settings the loop depends on | yes (D32, D36) |
| `performance.lf_thread_count`, solver time limit and MIP gap, `outputs.write_nx_sensitivity_csvs` | `pre_milp/lf_parameters.py:11-15`, `milp/milp_solver.py:17-18`, `:79-87`, `run_pipeline.py:801-802` | Run-time settings | yes (D38) |
| PATL source chain incl. `BaseCaseCurrentLimit` | `pre_milp/ncp_parser.py:297-332` | SHS, then AE normalValue, then CGM static, then 0 | yes (D34) |
| SHS vs CGM PATL difference warning | `pre_milp/ncp_parser.py:306-312` | Warns when SHS PATL differs > 10 % from the CGM static PATL | no |
| CurrentLimit side from EQ `sequenceNumber` | `pre_milp/ncp_parser.py:502-555` | Side 1/2 of each AE limit | yes (A12) |
| One must-study flag for all timestamps | `pre_milp/ncp_parser.py:398-399`, `:429` | `normalMustStudy` copied to every timestamp | no |
| Contingency equipment-type check (8 of 9 types) | `pre_milp/cgmes_loader.py:361-387`, `pre_milp/ncp_parser.py:406-422` | Unknown equipment dropped, empty contingency excluded | yes (D37) |
| Likely network split detection | `pre_milp/nx_security_analysis.py:45-68` | Contingency with a monitored branch missing from results is skipped | no |
| TATL = PATL with 600 s; TATL < PATL raised | `pre_milp/nx_security_analysis.py:239`, `:311-376` | TATL fallbacks | yes (D14) |
| 3-winding PSTs out of sensitivities | `pre_milp/n0_sensitivity.py:86-111`, `pre_milp/nx_sensitivity.py:37-64` | Left out with a warning | yes (D37) |
| N-0 sensitivity loading pre-filter keyed on the sensitivity threshold | `pre_milp/n0_sensitivity.py:40-83`, called `:160-164` | Branches with loading below `sensitivity_threshold_pct_*` are not requested from the analysis | no |
| Degrees per tap averaged | `pre_milp/cgmes_loader.py:210-260` | (alpha_last − alpha_first)/(steps − 1); non-uniform steps warned | no |
| Duplicate matrix label: first value | `pre_milp/nx_sensitivity.py:146-173` | Warns and uses the first row/column | no |
| Sensitivity guard and reuse | `pre_milp/sensitivity_checks.py:29-203` | Reference-current check, last-valid-set reuse, stop | yes (D12) |
| Initial invalid sensitivities stop the run | `run_pipeline.py:936-967` | `SensitivityGuardError`, minimal outputs | yes (D12) |
| Cumulative MILP against the original state | `milp/milp_builder.py:399-436`, `:567-611` | Tap limit, bid headroom, RA count and cost on cumulative change | yes (D4) |
| Applied taps integer-rounded | `milp/ac_convergence_loop.py:112-115`, `:739-742` | Rounded before apply and read back | yes (D4) |
| Incremental AC fallback | `milp/post_ra_congestion_check.py:148-236`, `iteration_caps.incremental_ac_fallback_max_steps` | Stepwise warm-started apply after a failed direct LF | yes (D8, D36) |
| Convergence criteria 1/3/4, shared tap/MW threshold | `milp/ac_convergence_loop.py:584-840`, `run_pipeline.py:1083-1085` | OR of criteria; MW uses the tap-sum value | yes (D6, D9) |
| Cycle exit and member selection | `milp/ac_convergence_loop.py:844-864`, `:983-1066` | `CYCLIC_REPETITION`, best member re-applied | yes (D7, D24) |
| Statuses `AcVerificationStatus` | `data_model.py:43-87` | 8 statuses incl. `SENSITIVITY_INVALID`, `SOLVER_NON_OPTIMAL`, `NOT_APPLICABLE` | yes (D22-D24, partly) |
| Results describe the original network when nothing applied | `milp/ac_convergence_loop.py:249-288`, `:886-898` | Variables zeroed, slacks = overload | yes (D22) |
| Empty generator read-back stop | `milp/ac_convergence_loop.py:659-668` | Stops before applying | yes (D25) |
| Lost-contingency count at N-X refresh | `milp/ac_convergence_loop.py:766-770` | Column `nx_contingencies_lost_at_refresh` | yes (A1) |
| Graceful "nothing to optimise" exit | `run_pipeline.py:907-919` | Ends after preprocessing when PST, RD and N-X are all absent | no |
| radp default and strict lead-time test | `milp/milp_builder.py:178-198` | radp = timestamp − 60 min; usable only strictly after radp + lead time | no |
| Curative RD "in operation" gate | `milp/milp_builder.py:868-887` | Curative bid fixed to 0 when no GLSK unit has original target_p > 0 | no |
| Curative RD cost on the max over contingencies | `milp/milp_builder.py:956-974`, `:1720-1736` | Pays the worst-case reservation once | no (D31 covers the price only) |
| Curative PST penalty summed over contingencies | `milp/milp_builder.py:1656-1675` | Sum, not max | no |
| Curative PST that is an outage element | `pre_milp/cra_preprocessing.py:79-81` | No curative entry for that contingency | no |
| PST group kind from config | `pre_milp/cra_preprocessing.py:145-253` | blockedGroup/reducedGroup per TSO | yes (D33) |
| Two RAs on one transformer | `milp/milp_builder.py:302-316`, `:335-344` | Modelled once; different penalties: the larger | no |
| Scanned limit anchored to original LF | `milp/milp_builder.py:1513-1519` | max(PATL, original N-0 current) | yes (D29) |
| GLSK renormalisation | `pre_milp/glsk_resolver.py:177-220` | Units not in the network removed, rest rescaled to sum 1 | no |
| RA-count tolerance in the export | `post_milp/n0_results_export.py:605` | RA counted when net volume > 1e-6 MW | no |
| `remaining_overload_count` from MILP slack | `post_milp/n0_results_export.py:998-1008` | Secured branches with N-0 slack > 1e-6 A | yes (A) |
| `objective_residual_eur` | `post_milp/n0_results_export.py:1040-1059` | Objective minus all reported cost components | no |
| `results_iteration_history.csv` | `post_milp/n0_results_export.py:1286-1313` | One row per solve: criteria, statuses, guard counts, timings | no |
| `results_tso_tap_limits.csv` | `post_milp/n0_results_export.py:307-363` | Taps used, limit, headroom, binding per TSO | no |
| `results_curative_pst_groups.csv` | `post_milp/n0_results_export.py:246-304` | Common curative delta per group and contingency | no |
| `results_contingency_status.csv` | `post_milp/nx_results_export.py:219-262` | Converged, skip reason, in MILP, guard result per contingency | yes (A1) |
| Diagnostic inputs `co_flat_list.csv`, `glsk_resolved.csv`, `tatl_data.csv`, `pst_cra_availability.csv`, `lf_nx_initial.csv`, `scanned_element_list.csv` | `output_file_registry.py:13-43` | Preprocessing results written to `output/` | no |

## 7. Spec items the code ignores

Parsed or present in the data but unused, used with a default, or skipped. "Warning" = whether the run logs it.

| Item | Where | What happens | Warning |
|---|---|---|---|
| `RotatingMachineAction.raiseRampRate` / `lowerRampRate` | `pre_milp/ncp_parser.py:971-982` | Parsed into `RDUnit`, never used | no |
| `PowerBidSchedule.activationCost` | `pre_milp/ncp_parser.py:1116-1117` | Parsed, not in the objective | no |
| `PowerBidSchedule.minEnergyBid` / `maxEnergyBid` | `pre_milp/ncp_parser.py:1122-1123` | Parsed, never used | no |
| `PowerBidSchedule.stepSizeCTRD` | `pre_milp/ncp_parser.py:1124` | Parsed, never used | no |
| `PowerBidSchedule.penaltyFactor` | `pre_milp/ncp_parser.py:1119-1120` | Parsed (missing = 0.0), never used | no |
| Bid prices and volumes of other timestamps | `pre_milp/ncp_parser.py:1127-1143` | Volumes kept per timestamp, only `START_HOUR` used; other prices dropped | no |
| PATL of other timestamps | `pre_milp/ncp_parser.py:303-332` | Resolved per timestamp, only `START_HOUR` used | no |
| `normalMustStudy` per timestamp | `pre_milp/ncp_parser.py:398-399` | One value for all timestamps; missing = not studied | no |
| Contingency type (Ordinary / Exceptional / OutOfRange) | `pre_milp/ncp_parser.py:387-391` | Parsed, all treated alike | no |
| `AssessedElementWithContingency` link | `pre_milp/ncp_parser.py:163-167` | Parsed as a plain AE; every secured branch is monitored under every contingency | no |
| `AssessedElementWithRemedialAction` (CRA–XNE link) | `run_pipeline.py:352-354`, `pre_milp/ncp_parser.py:663-672` | AE path never passed, `linked_xne_mrids` always empty, linkage off | no |
| PST operating and relative tap limits | `pre_milp/ncp_parser.py:742-744`, `data_model.py:161-162` | Not read; operating range = CGM hardware range | no |
| `normalPositiveVirtualMargin` | `pre_milp/scanned_elements.py:55` | Not parsed; margin 0 | no |
| PSTGroupKind | `pre_milp/cra_preprocessing.py:145-147` | Not in data; config value used | no |
| Curative RD reservation price | `milp/milp_builder.py:1715-1736` | Not parsed; energy price used | no |
| RA availability reference time (RAART) | `run_pipeline.py:346` | Not read; radp = one hour before the timestamp | no |
| RemedialAction `timeToImplement` of preventive PSTs and RD | `pre_milp/ncp_parser.py:706-710` | Read for every PST but used only for curative PSTs; not read for RD | no |
| AE via DCTieCorridor / PowerTransferCorridor / OperationalLimit only | `pre_milp/ncp_parser.py:187-198` | Skipped | no (INFO) |
| AE on equipment that is not a line or 2W transformer | `pre_milp/ncp_parser.py:210-219` | Skipped | no (INFO) |
| Scanned-only AE | `pre_milp/ncp_parser.py:287-295` | Treated as secured | no (DEBUG) |
| CoMo equipment type "bus" | `pre_milp/cgmes_loader.py:361-387` | Not mapped; equipment dropped as "not found in CGM" | yes |
| `RedispatchRemedialAction` / `CountertradeRemedialAction` | `pre_milp/ncp_parser.py:880-918` | Ignored with their bids | yes |
| PowerShiftKeyStrategy distributions | `pre_milp/glsk_resolver.py:87-118` | Not used | no |
| NCP profiles SSI, CD_OR, ER, PS, RAS, FAP, cross-TSO CO | `pre_milp/ncp_loader.py:25-61` | Skipped | no |
| RA count for PST and curative RAs | `milp/milp_builder.py:1315-1344` | Only preventive RD RAs counted | no |
| RA group limits for curative bids | `milp/milp_builder.py:1391-1412` | Only preventive bids capped | no |
| Missing `normalAvailable` (PST, RD) | `pre_milp/ncp_parser.py:688-689`, `:999-1000` | Not available | no |
| Missing or unknown `RemedialAction.kind` | `pre_milp/ncp_parser.py:691-693`, `:1002-1004` | Preventive | no |
| Missing bid direction / lead time | `pre_milp/ncp_parser.py:1109-1114` | UP / 0 h | no |
| Missing PST or RD RA `penaltyFactor` | `pre_milp/ncp_parser.py:695-703`, `:1008-1016` | 1.0 | yes |
| Missing generator Pmax/Pmin | `pre_milp/cgmes_loader.py:476-488` | 0.0 (unit fixed) | yes |
| Missing or negative bid price | `pre_milp/ncp_parser.py:1131-1143` | 0 | yes |
| Several TATLs on one side | `pre_milp/nx_security_analysis.py:337-343` | No TATL for the branch | yes |
| Curative PST timing missing | `pre_milp/cra_preprocessing.py:62-70` | PST not available as curative RA | yes |

## 8. Open questions for the domain expert

From the code analysis of 2026-09-29, filtered: questions answered by later decisions are removed. Check each against `docs/ASSUMPTIONS.md` before you ask.

1. **RAART / radp.** With no RAART, radp = t - 60 min, so every bid with lead time >= 1 h is unusable. What is the intended meaning, and is 60 min a business rule?
2. **Current-magnitude constraints.** Loading constraints are one-sided upper bounds built from a signed sensitivity (no absolute value). Expected approximation, and how to treat a sign change of the current?
3. **TATL data.** On the mock input 18 of 29 TATLs were below PATL and were raised to PATL. Data issue or expected?
4. **SHS vs CGM PATL.** A 10 % difference triggers a warning. Which source is authoritative; is 10 % a business tolerance?
5. **Excluded AEs.** They can still supply a limit for pruning and `lf_basecase.csv`. Should an excluded AE carry a limit at all?
6. **Scanned margin.** `virtual_load_margin_pct` is 0 as produced. What margin is expected?
7. **Penalty values.** All seven penalty costs are placeholders; one is in EUR/kA and the rest in EUR/A. Real values and units?
8. **Shared tap changers.** In the input every PST tap changer has one preventive and one curative action. What does that mean operationally?
9. **CRA-XNE linkage.** `linked_xne_mrids` holds AE mRIDs while the builder compares branch mRIDs. Do they coincide in real data?
10. **Dataset.** The test dataset has no curative RD, the default mock input has 16 curative RD bids. Which reflects the target?
11. **max_taps_per_tso.** Currently 6 for all (range 5-7). Is it TSO specific in reality?
12. **Convergence thresholds.** `max_change_ra`, `max_change_overload` (1.0 each) have no spec default. One threshold is used for both taps and MW. What values and units?
13. **Loadings above 100 % with zero slack.** Five N-X pairs on mock data show 101-120 % while all slacks are 0. Expected reading of the loading columns?
