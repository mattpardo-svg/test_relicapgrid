> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R4 — Multi-Timestamp Generalisation (PST + RD)

**Goal:** Extend the R1/R2 single-timestamp MILP to the full `N_TIMESTAMPS` window
for **both PST and RD**. Adds the time index to all PST and RD variables and
constraints, introduces PST time-coupling limits (per-timestamp tap limit and
per-timeframe tap limit), and generalises RD's balancing, cost, RA-limit, and
lead-time logic to multiple timestamps.

**Scope decision (resolved — supersedes the earlier "known gap" note):** N-X
multi-timestamp generalisation is **explicitly deferred to a future release**, not
included in R4. Reasoning: R5 (Full RD Optimization) has a hard dependency on RD
already being multi-timestamp — its ramp, min-up/down, and start-up/shutdown
constraints require a `t` index on `rd_net_injection_g` to exist at all. R4 must
therefore deliver PST + RD multi-timestamp to unblock R5 on schedule. N-X, by
contrast, has no downstream dependency — R5's physics constraints apply only to
preventive RD dispatch (per CORNET-4614's Outlook note), leaving curative RD and
N-X security entirely untouched by R5 or R6. Deferring N-X multi-timestamp costs
nothing on the critical path and can land in its own dedicated release whenever
convenient.

**Prerequisite:** R3 complete — N-X security constraints and CRAs working on a
single timestamp. R4 extends the PST+RD MILP (established in R1/R2) to
`N_TIMESTAMPS` consecutive timestamps. R4 does **not** extend N-X to multiple
timestamps — every N-X/CRA increment from R3 remains single-timestamp until a
future release addresses it explicitly.

**Stack:** pypowsybl 1.15.0 (AC LF + AC sensitivity), Pyomo + HiGHS via `highspy`
(`solver_name="appsi_highs"`, `solver_io=None`), rdflib/ElementTree (NCP XML parsing).
No new dependencies beyond R1.

**Solver note:** Use `solver_name="appsi_highs"` with `solver_io=None` — confirmed working
on the current Pyomo/highspy version. `solver_io="python"` raises `NotImplementedError`
and must not be used.

**Side-awareness note (critical — inherits from R1/R2/R3):** All branch current lookups,
PATL comparisons, and sensitivity computations in R4 must be side-aware. Each
AssessedElement's `OperationalLimit` resolves to a Terminal-specific `CurrentLimit`
whose side (1 or 2) is determined by `SequenceNumber` in the EQ file. The resolved side
per AE is available via `ncp_parser.build_current_limit_side_map()` and must be
propagated through:
- `lf_initial[t]` — use `i1` or `i2` per branch per AE, not `max(i1, i2)`
- `patl[branch_mrid][timestamp]` — use the side-specific operational limit
- Sensitivity calls — use `BRANCH_CURRENT_1` or `BRANCH_CURRENT_2` per branch group;
  requires two separate `add_factor_matrix()` calls (one per side group) as established
  in R1.2. Do not collapse to a single blanket `BRANCH_CURRENT_1` call.

**Composability architecture note (inherited from R2/R3 — load-bearing for R4):** R4
must generalise the composable `PstMilpInputs` / `RdMilpInputs` architecture (R2) to
the multi-timestamp case — every Pyomo component gains a `t` index, but the
`hasattr`-gating pattern for optional PST/RD components must be preserved unchanged.
Check the live state of `milp_builder.py`, `milp_solver.py`, and `linearisation.py`
before assuming this document's increments below are complete. R4.1–R4.4 cover PST;
R4.5–R4.8 cover RD; R4.9 is the combined multi-timestamp linearisation loop, gated
by `hasattr` exactly as R2's single-timestamp version was; R4.10 is pipeline
integration (`ENABLE_MULTITIMESTAMP`), wiring R4.1–R4.9 into `run_pipeline.py` as a
real, selectable entry point rather than a smoke-test-only module.

**✓ Completeness loop stale-baseline bug — confirmed fixed.** R3's completeness
loop (`completeness_loop.py`, R3.8) previously had a confirmed bug where, on the
zero-new-congestions exit path, the loop mutated `lf_nx` to the fresh post-RA
baseline but returned without rebuilding the model against it. **Verified directly
against the live code:** `model = build_and_solve_fn()` now runs unconditionally on
every iteration, not gated on `new_constraints_added == 0`, and this is covered by
`test_stops_after_one_rebuild_when_no_new_congestions_found`. This is no longer a
blocker for generalising the completeness loop to run once per timestamp — this
note is retained for historical context only; N-X multi-timestamp generalisation
remains deferred to a future release per the "Scope decision" above, for the
independent reason that nothing downstream requires it, not because of this bug.

**Data shape correction (confirmed from R3):** R3's implementation confirmed that
`lf_initial` (built in R1.1, extended per-timestamp here in R4.1) is actually
**dual-sided per branch** (`{1: i1, 2: i2}`), not a single float per branch as this
document's R4.1 "Outputs" section below states. R4.1 must produce
`lf_initial: dict[t, dict[branch_mrid, dict[int, float]]]`, matching the real,
tested shape `build_lf_initial` already produces in R1.1 — **R1's own MD file likely
needs the same correction** (flagged here for visibility; not corrected in R1's file
in this pass, since this session is scoped to R3/R4).

**Side-map mechanism correction (confirmed from R3):** `current_limit_side_map` is
**not** passed as a separate explicit parameter anywhere in the real, tested R1–R3
code. Each branch's side is read from its already-resolved
`AssessedElement.branch_side` attribute (set once in R0.4). Every reference below to
`current_limit_side_map` as an explicit function input should be understood as "read
`branch_side` off the relevant `AssessedElement`," not "thread a separate map
parameter through every function call."

**Reuse note (flagged by the R2 coding chat on completion):** R2.10's lead-time
logic (`radp` computation, `TIMESTAMP_LIST` search for the earliest usable
timestamp) was already built anticipating multi-timestamp generalisation. Revisit
those functions early in R4 rather than rebuilding equivalent logic from scratch —
`radp` in particular is directly reusable by R5.5's lead/lag time enforcement.

---

## Deferred items (R4 scope)

| Item | Reason deferred |
|------|----------------|
| CORNET-3653/3654 soft constraint slack output per TSO | Covered in R4.3/R4.4; full per-TSO reporting deferred to R5 results pass |
| 15-minute intermediate timestamps | Out of scope for prototype (hourly only) |
| BUC14#115 — RA status from RAC in following RAO iteration | Production process concern; prototype always treats all available RAs as available |
| N-X security constraints and CRAs — multi-timestamp generalisation | No downstream dependency blocks this (R5/R6 do not require N-X to be multi-timestamp); deferred to a future dedicated release to keep R4 focused on unblocking R5's RD requirement |

---

## R4.1 — Multi-timestamp operating point per timestamp

**Spec ref:** CORNET-85 — Considered time grid

**~~Original text referred to "IAM files" and "SteadyStateInstructionProfile / ContingencyProfile"
per timestamp — superseded. The actual NCP input structure uses per-TSO static files
(`{TSO}_SIS.xml`, `{TSO}_CO.xml`), not per-hour IAM files. Time-varying inputs
(PST operating limits, scheduled tap positions, `mustStudy` flags) are extracted
from those static profiles keyed by `atTime`.~~**

**⚠ Two open items confirmed by reading the live parser code — resolve before
implementing the bullets below as written:**

1. **`mustStudy` is not per-timestamp in the real data model.** `parse_contingencies`
   in `ncp_parser.py` implements and documents `must_study` as a single static flag
   per contingency, broadcast identically to every timestamp key — its own docstring
   states the NCP file carries one `normalMustStudy` flag, not a per-timestamp
   series. The bullet below ("Extract `mustStudy[t]`... at `atTime == t`") assumes
   genuine per-timestamp variation that may not exist at the schema level, not just
   on this dataset cut. **Verify against the official ENTSO-E NC Contingency/AE
   profile spec** (not just this codebase) whether `mustStudy` can vary by timestamp
   at all before deciding whether this is a confirmed permanent fact or a parser
   simplification worth revisiting. Until resolved, treat `must_study[t]` as
   `must_study` broadcast identically across all `t` — this does not block R4 since
   N-X is deferred anyway (see "Scope decision" above), but the bullet text below is
   inaccurate as written and should not be implemented literally.
2. **No existing parser reads PST tap position or operating limits from
   `{TSO}_SIS.xml`.** `parse_psts` currently sources `r_0` and operating bounds
   entirely from the static CGM/RA file. `{TSO}_SIS.xml` is wired up today only for
   RD power bids (`parse_rd_units`) and RA-group volume limits (`parse_ra_groups`) —
   never for PSTs. Before implementing the "extract time-varying PST operating
   limits from `{TSO}_SIS.xml`" bullet below, **grep the real `{TSO}_SIS.xml` files
   for any content cross-referencing a known PST/TapChanger mRID from `PSTList`**,
   the same investigation discipline used for R2.3's GLSK check. Two possible
   outcomes: (a) genuine time-varying PST data exists and new parser work is needed,
   or (b) it does not exist and PST tap schedule/operating limits are static across
   the optimisation window in this dataset — a confirmed dataset fact parallel to
   the empty GLSK/power-bid findings from R2/R3, not a bug. **This uncertainty does
   not block R4.3/R4.4**, since those constraints' corrected formula only needs
   `tap_change_scheduled_τ(t)`, which is provably 0 at every timestamp if the
   schedule is static (see R4.3's "Formula correction" note below) — it only
   affects whether R4.1's own "extract... for `atTime == t`" bullet is accurate or
   needs to instead read "confirmed static, same value applied at every `t`."

**What it delivers:**
- For each timestamp `t` in `TIMESTAMP_LIST`:
  - Extract time-varying PST operating limits from `{TSO}_SIS.xml` for `atTime == t`
    **(pending verification — see open item 2 above; may resolve to "apply the same
    static value at every `t`" instead)**:
    `highStepOperatingOnline`, `lowStepOperatingOnline`,
    `highStepRelativeOnline`, `lowStepRelativeOnline`
  - Extract PST scheduled tap position `tap_scheduled[t]` from `{TSO}_SIS.xml`
    (`SteadyStateInstruction.value` at `atTime == t`) **(same pending verification)**
  - Extract `mustStudy[t]` flag per contingency from `{TSO}_CO.xml`
    **(pending verification — see open item 1 above; current parser broadcasts one
    static flag to all `t`, which may be the confirmed-correct behaviour)**
- Apply the scheduled tap positions to the pypowsybl network for each timestamp:
  ```python
  network.update_phase_tap_changers(id=pst_mrid, tap=int(round(tap_scheduled[t])))
  ```
  **Note:** the kwarg is `tap`, not `tap_position` — using the wrong kwarg silently
  does nothing (no exception raised). Confirmed live as a real silent bug.
- Run a base-case AC LF per timestamp:
  ```python
  lf_result = pp.loadflow.run_ac(network)
  ```
- Extract branch currents side-aware (using `ncp_parser.build_current_limit_side_map()`
  to select `i1` or `i2` per branch per AE) — not `max(i1, i2)`
- Compute `pst_tap_bounds[t]` per timestamp from time-varying SIS limits
  (same priority rule as R1.3: online > offline > IGM)
- Restore the network to the base tap schedule after each timestamp's LF
  (avoid carry-over between timestamps)

**Inputs:**
- `TIMESTAMP_LIST`, `N_TIMESTAMPS`, `network` (pypowsybl `Network` from R0.1)
- `NCP_FILES` (from R0.3) — `{TSO}_SIS.xml` and `{TSO}_CO.xml` per TSO
- `PSTList` (from R0.6), `AEFlatList` (from R0.4 — each AE carries its own resolved
  `branch_side`; see "Side-map mechanism correction" note above)

**Outputs:**
- `lf_initial: dict[t, dict[branch_mrid, dict[int, float]]]` — dual-sided current
  in A per branch (`{1: i1, 2: i2}`), keyed by mRID — see "Data shape correction"
  note above; do not implement as a single float per branch
- `pst_tap_bounds: dict[t, dict[pst_mrid, (effective_tap_min, effective_tap_max)]]`
- `tap_scheduled: dict[t, dict[pst_mrid, float]]` — scheduled tap position before RAO per timestamp
- `must_study: dict[t, dict[co_mrid, bool]]` — mustStudy flag per contingency per timestamp
- `lf_basecase_all_ts.csv`: columns `[timestamp, branch_mrid, branch_name, tso, i_ka,
  loading_pct, patl_ka, side, converged]`

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4` and `START_HOUR = "1030Z"`,
- When all four timestamp LF runs are executed,
- Then `lf_initial` has exactly 4 timestamp keys AND all four LF runs report
  `converged == True` AND tap positions are restored to the pre-run baseline after
  each timestamp (no carry-over between timestamps).

**Open question (inherited from R0/R1):** The Organisation-profile TSO resolution
produces TSO-{Name} strings. `mustStudy` is keyed by contingency mRID — no TSO
resolution issue here. But if any per-TSO filtering is needed in R4, use
`eic_resolver.build_tso_name_map()` as in R0.2, not SubGeographicalRegion.

---

## R4.2 — Multi-timestamp MILP variables and N-0 loading constraints

**Spec ref:** CORNET-85, CORNET-1790 — extended to multi-timestamp

**What it delivers:**
- Extend the MILP from R1.5 to cover all `N_TIMESTAMPS` timestamps in a single problem:
  - Variables now indexed by `(t, pst_mrid)` and `(t, branch_mrid)`
  - Per-timestamp N-0 loading constraint (side-aware):
    `I_b,0(t) + Σ_τ S_PST(t)[b,τ] · tap_change_τ(t) ≤ PATL_b(t) + overload_slack_n0(t,b)`
    where `I_b,0(t)` and `PATL_b(t)` use the AE-specific side confirmed in R0.4
  - Per-timestamp tap bounds:
    `effective_tap_min(t) ≤ current_tap + tap_change_τ(t) ≤ effective_tap_max(t)`
  - Per-timestamp PST group equality (R1.4 logic applied per timestamp)
    — on the current dataset this produces no constraints (no CORNET-21 groups in NCP)
- Recompute sensitivity `S_PST[t]` for each timestamp using `lf_initial[t]`
  via the confirmed pypowsybl sensitivity API:
  ```python
  sa = pp.sensitivity.create_ac_analysis()
  sa.add_factor_matrix(
      functions_ids=branch_mrids_side1,
      variables_ids=pst_mrids,
      contingencies_ids=[],
      contingency_context_type=pp.sensitivity.ContingencyContextType.NONE,
      sensitivity_function_type=pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_1,
      sensitivity_variable_type=pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE,
      matrix_id='psdf_n0_side1_t{t}'
  )
  # Repeat for BRANCH_CURRENT_2 for branches whose AE resolves to side 2
  result = sa.run(network)
  matrix = result.get_sensitivity_matrix('psdf_n0_side1_t{t}')
  # matrix.index = pst_mRIDs, matrix.columns = branch_mRIDs
  # lookup: matrix.loc[pst_mrid, branch_mrid]
  ```
  **Note:** sensitivity values are in A/degree (not A/tap). Convert using
  `degrees_per_tap` from `network.get_phase_tap_changer_steps()` column `alpha`.
  Use averaged linear conversion across the tap range (exact for Linear type,
  approximation for Tabular/Asymmetrical/Symmetrical — flag non-uniformity in log).
  **Conversion timing (confirmed from R1.2/R3.1's real behaviour):** the A/degree
  to A/tap conversion happens later, at the point where sensitivity values are used
  to build MILP constraints (inside `_add_pst_block` in `milp_builder.py`) — not at
  sensitivity-computation time. Store `S_PST[t]` as raw A/degree values here,
  consistent with R1.2 and R3.1.

**Inputs:**
- `lf_initial[t]`, `pst_tap_bounds[t]`, `S_PST[t]` for each timestamp
- `AEFlatList`, `pst_group_equality_pairs` (from R1.4) — each AE carries its own
  resolved `branch_side`; no separate side-map parameter is threaded through (see
  R4's preamble "Side-map mechanism correction" note)
- RAO control parameters

**Outputs:**
- `milp_model` — multi-timestamp Pyomo `ConcreteModel` (in-memory)

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4` and `|PSTList_preventive| = P` and `|AEFlatList_monitored| = B`,
- When the multi-timestamp MILP is built,
- Then the total number of PST tap-change variable pairs equals `2 × P × 4` AND
  loading constraints equal `B × 4`.

**Dataset note:** All PST RAs in the current ReliCapGrid NCP are curative. P = 0
preventive PSTs on live data without a diagnostic override. The acceptance criterion
above uses a synthetic/override dataset for testing.

---

## R4.3 — PST tap-change limit per timestamp (CORNET-3653)

**Spec ref:** CORNET-3653 — Limitation of PST tap changes per time stamp

**⚠ Scope decision (dated, recorded here — supersedes a code-only docstring
note): R4.3 and R4.4 are NOT wired into the combined multi-timestamp
linearisation loop (R4.9) or into `run_pipeline.py` (R4.10) in this release.**
Both constraints are correct and independently tested — verified via the smoke
test and their own unit test suites — but they do not participate in the
per-iteration MILP rebuild inside `run_multitimestamp_post_rao_linearisation_loop`,
and are not reachable through the real pipeline entry point. This was originally
noted only in R4.9's module docstring at the time R4.9 was first built ("It does
NOT thread through R4.3/R4.4's tap-change-limit blocks... a real but separate
extension, not silently included here") — that was a genuine contemporaneous
decision, but it lived only in code, not in this spec of record, until this
correction. **Reasoning for staying deferred:** wiring R4.3/R4.4 into the combined
loop requires the loop's per-iteration tap refresh to correctly interact with a
soft slack constraint across iterations — genuinely new design and test surface,
not a small fix. Rather than expand R4 further while it is otherwise ready to
close, this is deliberately left as a follow-on increment. **Acceptance criterion
for this scope decision:** R4.3 and R4.4 must each independently pass their own
unit tests and smoke-test checks (already true); they are explicitly not required
to be exercised by any R4.9 or R4.10 test, and no R4.9/R4.10 test should assume
their constraints are present in the combined loop's solved model.

**Formula correction (confirmed against the spec text directly):** Earlier drafts
of this increment summed `|tap_scheduled_τ(t) + tap_change_τ(t)|` — treating
`tap_scheduled_τ(t)` as the **absolute** scheduled tap position from R4.1. This is
wrong. CORNET-3653's own text defines a tap change as a movement magnitude ("One
tap change is defined as the change of one PST step in either direction... The
change from tap position 5 to tap position 8 equals **three** tap changes"), and
CORNET-3654's formula sums this same term **across every timestamp in the entire
optimisation timeframe** against a total tap-change budget — which only makes
dimensional sense if the term is a per-timestamp movement, not an absolute
position. The corrected term is `tap_change_scheduled_τ(t)`, defined as the
schedule's own movement at timestamp `t`:
```
tap_change_scheduled_τ(t) = tap_scheduled_τ(t) − tap_scheduled_τ(t-1)
```
(or `tap_scheduled_τ(t) − r_0_τ` for the first timestamp, relative to the
pre-optimisation-window tap position). **This sidesteps the open question of
whether genuine time-varying PST tap-schedule data exists in `{TSO}_SIS.xml`**
(see R4.1's open item): if the schedule is confirmed static across all timestamps
in this dataset, `tap_change_scheduled_τ(t) = 0` for every `t` by definition of a
constant sequence having zero deltas, and the constraint below correctly reduces
to `|tap_change_τ(t)| ≤ max_taps_per_timestamp_tso[k]` — depending only on the
RAO's own decision variable, which is already fully defined regardless of the
SIS.xml investigation's outcome.

**What it delivers:**
- For each TSO `k` and each timestamp `t`, add a soft constraint:
  `Σ_{τ ∈ TSO_k} |tap_change_scheduled_τ(t) + tap_change_τ(t)| − tap_limit_slack_per_timestamp[t,k]
   ≤ max_taps_per_timestamp_tso[k]`
- Linearise the absolute value: introduce auxiliary variables
  `abs_tap_change[t,τ]` with `abs_tap_change ≥ tap_change` and `abs_tap_change ≥ -tap_change`
- `tap_limit_slack_per_timestamp[t,k] ≥ 0` — penalised in objective
  with `pst_limit_per_timestamp_penalty`
- If `max_taps_per_timestamp_tso` is not defined for a TSO, skip the constraint for that TSO

**Naming note:** Use full descriptive names throughout — `tap_change_scheduled`,
`tap_limit_slack_per_timestamp`, `max_taps_per_timestamp_tso`,
`pst_limit_per_timestamp_penalty` — not `tap_scheduled` (that name is reserved for
R4.1's absolute position, a different quantity), `A_slack_TS`, `maxTapsTS_TSO`,
`PSTlimitTS_penalty`.

**Inputs:**
- `tap_scheduled[t]` (from R4.1 — used only to derive `tap_change_scheduled_τ(t)`
  via consecutive-timestamp differencing, not used directly in the constraint),
  `PSTList` (TSO assignment per PST, `r_0` for the pre-window baseline)
- RAO control parameters: `max_taps_per_timestamp_tso: dict[tso, int]`,
  `pst_limit_per_timestamp_penalty: float`

**Outputs:**
- Additional variables and constraints added to `milp_model`
- `results_pst_tap_limits.csv`: columns `[tso, timestamp, tap_change_scheduled,
  total_tap_changes, limit_per_timestamp, slack_per_timestamp, penalty_cost_eur]`

**Acceptance criteria:**
- Given `max_taps_per_timestamp_tso = 3` for a TSO with 2 PSTs and
  `pst_limit_per_timestamp_penalty` is very large,
- When the MILP is solved,
- Then the total tap **movements** (scheduled + RAO-determined) for that TSO in any
  single timestamp do not exceed 3 AND a TSO without a defined limit has no
  constraint applied.
- Given a PST with a static schedule (`tap_scheduled_τ(t)` identical at every `t`),
- When `tap_change_scheduled_τ(t)` is computed,
- Then it equals 0 for every timestamp, and the constraint depends only on
  `tap_change_τ(t)`.

---

## R4.4 — PST tap-change limit per optimisation timeframe (CORNET-3654)

**Spec ref:** CORNET-3654 — Limitation of PST tap changes per optimisation timeframe

**Formula correction:** Same correction as R4.3 — `tap_change_scheduled_τ(t)` (the
schedule's own movement at timestamp `t`, computed via consecutive-timestamp
differencing) replaces the earlier draft's `tap_scheduled_τ(t)` (an absolute
position). See R4.3's "Formula correction" note above for the full derivation and
spec citation.

**What it delivers:**
- For each PST `τ`, add a soft constraint over all timestamps:
  `Σ_t |tap_change_scheduled_τ(t) + tap_change_τ(t)| − tap_limit_slack_per_timeframe[τ]
   ≤ max_taps_per_timeframe[τ]`
- `tap_limit_slack_per_timeframe[τ] ≥ 0` — penalised with
  `pst_limit_per_timeframe_penalty`
- `max_taps_per_timeframe[τ]` is conceptually intended to come from
  `GridStateAlteration.maximumPerDay` in the NCP RA profile (`{TSO}_RA.xml`) — see
  the "⚠ Confirmed not parsed" note below for the actual current source
- If `max_taps_per_timeframe` is not defined for a PST, skip the constraint for that PST

**⚠ Confirmed not parsed — this was stated incorrectly in earlier drafts of this
document, not merely stale.** Earlier drafts said `max_taps_per_timeframe` "comes
from `GridStateAlteration.maximumPerDay`... parsed in R0.6 and stored in `PSTList`."
This was checked directly by grepping every source and test file in the codebase:
**there is no RDF/XML parse call for `maximumPerDay` anywhere.** Every occurrence of
`max_taps_per_timeframe` in the codebase is either documentation, a log message, or
a hardcoded literal in a test fixture (e.g. `{"PST1": 5}`). This was inaccurate when
originally written, not something that became true later and then drifted stale —
confirmed during pipeline integration, when the question "is this ever exercised
against real data" was asked directly rather than assumed. **Decision made during
pipeline integration:** treat `max_taps_per_timeframe` as override-only until real
`{TSO}_RA.xml` access is available to verify the actual CIM predicate against real
data — the same verification-first discipline that caught the `price` field's real
CIM location (R4.5) is deliberately being applied here rather than guessing at the
predicate without a real file to check it against. `run_pipeline.py` logs a loud
warning on every run where `ENABLE_MULTITIMESTAMP=True` and no override is supplied,
stating explicitly that this limit is not sourced from real data.

**Naming note:** Use `tap_change_scheduled`, `tap_limit_slack_per_timeframe`,
`max_taps_per_timeframe`, `pst_limit_per_timeframe_penalty` — not `tap_scheduled`
(reserved for R4.1's absolute position), `A_slack_OT`, `maxTapsOT`,
`PSTlimitOT_penalty`.

**Inputs:**
- `tap_scheduled[t]` (from R4.1 — used only to derive `tap_change_scheduled_τ(t)`),
  `PSTList` (`r_0` for the pre-window baseline)
- `max_taps_per_timeframe` — **override-only control parameter, not currently
  parsed from any real NCP file** (see "⚠ Confirmed not parsed" above); pending a
  real `{TSO}_RA.xml` file to verify the `GridStateAlteration.maximumPerDay`
  predicate before a real parser can be written
- RAO control parameters: `pst_limit_per_timeframe_penalty: float`

**Outputs:**
- Additional variables and constraints added to `milp_model`
- **⚠ Corrected — earlier drafts of this document described a single merged
  extension of `results_pst_tap_limits.csv`. The actual implementation
  deliberately splits this into two separate files**, a documented architectural
  decision made in the code to avoid an awkward merge across two different grains
  (per-timestamp rows from R4.3 vs. per-PST-per-timeframe rows from this
  increment, which do not share a natural row key):
  - `results_pst_tap_limits.csv` — R4.3's per-timestamp output, unchanged by this
    increment
  - `results_pst_tap_limits_timeframe.csv` — new, separate file for this
    increment's output: columns `[pst_mrid, tso, total_tap_changes_timeframe,
    limit_per_timeframe, slack_per_timeframe, penalty_cost_eur]`

**Acceptance criteria:**
- Given a PST with `max_taps_per_timeframe = 5` (supplied via override) and
  `pst_limit_per_timeframe_penalty` is very large,
- When the MILP is solved over `N_TIMESTAMPS = 4`,
- Then `Σ_t |tap_change_scheduled(t) + tap_change(t)|` for that PST does not exceed 5
  AND a PST without `max_taps_per_timeframe` defined has no timeframe constraint applied.
- Given a PST with a static schedule across all 4 timestamps,
- When the timeframe constraint is evaluated,
- Then `Σ_t |tap_change_scheduled(t) + tap_change(t)| = Σ_t |tap_change(t)|`,
  depending only on the RAO's own decisions.

---

## R4.5 — Multi-timestamp RD operating point per timestamp

**Spec ref:** CORNET-85 — Considered time grid (extended to RD)

**Implementation notes (confirmed against live code, added post-implementation):**

- **`available_mw` is genuinely real per-timestamp data already** — R0.7's
  `PowerBidScheduleTimePoint.atTime` parsing already provides this; no synthesis
  or new parser work was needed. `build_power_bid_schedule_multitimestamp` simply
  organises existing data by timestamp.
- **`target_p` (pre-RAO generator dispatch) is confirmed static across all
  timestamps in the current pipeline** — R4.1 only varies PST tap schedule, never
  generator dispatch, so `rd_schedule[t]` is correctly implemented as a broadcast
  of the same value across all `t`. This is expected pipeline behaviour, not a bug.
- **GLSK is resolvable per real timestamp with zero new parser work** —
  `resolve_glsk` (R2.3) already accepts a `timestamp` argument;
  `build_glsk_multitimestamp` loops the existing function across `t` and TSOs. No
  separate `glsk_per_timestamp` construction logic was needed beyond this loop.
- **✓ `price` schema-vs-scalar finding — confirmed fixed.** `PowerBid.price_eur_mw`
  was originally parsed by R0.7 as a single static scalar per bid, despite the
  official ENTSO-E NC PowerSchedule Profile Specification (Table 8, `PowerTimePoint`
  class) defining `price` structurally alongside `p` inside `PowerTimePoint` — i.e.
  a genuine per-timestamp field in the CIM data model, exactly like `available_mw`.
  Given `available_mw` was already correctly parsed per-`atTime` from the same
  `PowerTimePoint` class, this was identified as a real, fixable gap in
  `parse_rd_units`, not a dataset limitation. **Fixed during pipeline integration:**
  `parse_rd_units` now populates a real `price_eur_mw_by_timestamp` field instead of
  discarding the per-timestamp `price_map` it was already computing internally.
  `build_power_bid_schedule_multitimestamp`'s `price` output now reflects genuine
  per-timestamp variation on real data where it exists, not a repeated static
  value. The `price_override` parameter (below) remains available for tests that
  need to force variation on datasets where real prices happen to be flat.
- **`price_override` was implemented as an explicit, opt-in parameter** to
  `build_power_bid_schedule_multitimestamp` rather than silently synthesising or
  mutating parsed data — consistent with how every other "real data doesn't
  exercise this path" finding has been handled since R2/R3 (empty GLSK, empty
  power bids, etc.). Originally needed to force price variation while the R0.7 gap
  above was still open; now used for test scenarios requiring guaranteed variation
  regardless of what the live dataset happens to contain.

**What it delivers:**
- For each timestamp `t` in `TIMESTAMP_LIST`, extract the time-varying RD inputs
  established in R2 but not yet generalised across timestamps:
  - Power bid availability and price (`PowerBidSchedule` fields from R2's parsing,
    from `{TSO}_SIS.xml`) at `atTime == t`
  - GLSK participation factors (`glsk`, from R2.3) — confirm whether these vary by
    timestamp in the real data or are static across the optimisation window; the
    current dataset's near-empty GLSK finding from R2/R3 means this may not be
    verifiable against live data and should use the synthetic dataset instead
  - Generating unit `target_p` (pre-RAO schedule) per timestamp, read from the
    per-timestamp network state established in R4.1 (reuse, do not rebuild)
- No new tap-application or LF-running logic here — R4.1 already runs the
  per-timestamp base-case LF for the shared network state; this increment only
  extracts and organises the RD-specific per-timestamp inputs from data already
  available after R4.1 runs

**Inputs:**
- `TIMESTAMP_LIST`, `N_TIMESTAMPS`
- `NCP_FILES` (from R0.3) — `{TSO}_SIS.xml` per TSO
- `RDList`, `PowerBidList` (from R0.7), `glsk` (from R2.3)
- `lf_initial[t]` (from R4.1 — reused, not recomputed)

**Outputs:**
- `rd_schedule: dict[t, dict[gu_mrid, float]]` — pre-RAO production per unit per
  timestamp; **confirmed static (broadcast) across all `t` in the current pipeline**
  (see implementation notes above)
- `power_bid_schedule: dict[t, dict[bid_mrid, {available_mw, price}]]` —
  `available_mw` is genuinely per-timestamp (confirmed). `price` is genuinely
  per-timestamp as well, following the R0.7 fix confirmed above: it reflects real
  variation where the live dataset has real variation, and `price_override`
  remains available to force variation in test scenarios regardless of what the
  live dataset happens to contain.
- `glsk_per_timestamp: dict[t, dict[ra_mrid, dict[gu_mrid, float]]]` — built via
  `resolve_glsk` (R2.3) looped per timestamp; confirmed to work with zero new
  parser logic

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4` with either real per-timestamp price data (following the
  R0.7 fix) or `price_override` supplying distinct bid prices at two or more
  timestamps,
- When `power_bid_schedule` is built,
- Then it contains exactly 4 timestamp keys AND at least two timestamps have
  differing `price` for the same `bid_mrid` (confirming genuine per-timestamp
  variation, not a repeated single-timestamp value).

---

## R4.6 — Multi-timestamp RD MILP variables, Pmax/Pmin, and N-0 loading constraint extension

**Spec ref:** CORNET-36, CORNET-37, CORNET-1790 — extended to multi-timestamp
(parallel to R4.2 for PST)

**Composability note:** Only added when `rd_inputs is not None`
(`enable_rd_remedial_actions=True`) — same `hasattr`-gating as R2.4/R2.5.

**What it delivers:**
- Extend `rd_volume_upward[bid_mrid]` / `rd_volume_downward[bid_mrid]` (from R2.4)
  with a `t` index: `rd_volume_upward[t, bid_mrid]`, `rd_volume_downward[t, bid_mrid]`
- Extend Pmax/Pmin constraints per timestamp using `rd_schedule[t]` (from R4.5) and
  the per-timestamp `target_p`/`max_p`/`min_p` from the network state
- Recompute RD sensitivity per timestamp using the same confirmed pypowsybl API
  pattern as R2.1 (`INJECTION_ACTIVE_POWER`), evaluated at `lf_initial[t]`:
  `sensitivity_rd_n0[t]: dict[(branch_mrid, gu_mrid), float]`
- Extend `rd_net_injection_g` and `rd_effect_on_branch` Expressions (from R2.4) with
  a `t` index — these become `rd_net_injection_g[t, gu_mrid]` and
  `rd_effect_on_branch[t, branch_mrid]`
- Extend the combined `xne_loading_n0` constraint (R2.5, generalised for PST in
  R4.2) so that both `pst_effect_on_branch[t, branch_mrid]` and
  `rd_effect_on_branch[t, branch_mrid]` are summed per timestamp — this is the same
  single constraint-builder R2.5 established, now with a `t` index on all three
  terms (initial current, PST effect, RD effect)

**Inputs:**
- `rd_schedule[t]`, `power_bid_schedule[t]` (from R4.5)
- `lf_initial[t]` (from R4.1)
- `RDList`, `PowerBidList`, `glsk` (or `glsk_per_timestamp`, from R4.5)
- `AEFlatList`

**Outputs:**
- `milp_model` — updated with per-timestamp RD variables, Pmax/Pmin constraints,
  and RD terms in the combined loading constraint

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4` and `|PowerBidList| = D` available RD bids,
- When the multi-timestamp MILP is built with RD enabled,
- Then the total number of RD volume variable pairs equals `2 × D × 4` AND every
  `xne_loading_n0[t, branch_mrid]` constraint includes both PST and RD terms when
  both `pst_inputs` and `rd_inputs` are provided, and only RD terms when
  `pst_inputs is None`.

---

## R4.7 — Multi-timestamp RD balancing, costs, and RA/group limits

**Spec ref:** CORNET-73, CORNET-4606, BUC14#119, CORNET-3649, CORNET-4838 —
extended to multi-timestamp (parallel to R2.6–R2.9, generalised)

**Composability note:** Only added when `rd_inputs is not None`. Balancing and
limit logic (RA count, group volume) is unchanged from R2.6/R2.8/R2.9 in
substance — this increment only adds the `t` index that was implicitly `1`
throughout R2.

**✓ Behavioral divergence from R2.7 — confirmed, and now genuinely realised on
real data.** Unlike balancing/RA-count/group-limits, the cost term was never a
mechanical generalisation of R2.7. R2.7 uses `PowerBid.price_eur_mw`, a static
scalar. R4.7 uses `power_bid_schedule_multitimestamp[t][bid_mrid]["price"]` —
R4.5's per-timestamp price output. At the time this increment was first
implemented, real per-timestamp price data was a repeated static value pending
R0.7's parser fix; **that fix has since landed** (see R4.5's implementation notes),
so R4.7's cost term now reads genuine per-timestamp pricing on real data where the
dataset has real variation, not just structurally-ready-but-numerically-static
behaviour. Anyone comparing R2.7 and R4.7 side by side should still not assume they
are identical modulo indexing — R4.7 reads from a different, timestamp-aware
source; the two only coincided numerically before the R0.7 fix, on datasets with
flat pricing.

**⚠ Confirmed post-implementation bugs, found and fixed during MD review — worth
recording precisely since both slipped past this increment's own test suite:**

1. **`results_ra_count_multits.csv` and `results_ra_groups_multits.csv` were never
   implemented**, despite being named explicitly in this increment's Outputs
   section below. The underlying MILP constraints
   (`_add_multitimestamp_ra_activation_and_count_constraints`,
   `_add_multitimestamp_ra_group_volume_constraints`) were built correctly; the
   extraction/CSV-export functions for their results were not — this was missed
   because R4.7's own test file never tested results-extraction or CSV output at
   all, only the MILP constraints and solved values. **Root cause identified as a
   pattern, not an isolated miss**: R4.9 had the identical blind spot for
   `results_rd_multits.csv` (below) — results-extraction/CSV output was never part
   of the test-writing discipline at either increment.
2. **Building the missing extraction functions was not sufficient on its own** —
   `run_multitimestamp_post_rao_linearisation_loop` (R4.9) never accepted
   RA-count/group-volume parameters at all, so the functions existed but nothing
   called them. This is a third, distinct failure mode worth naming explicitly —
   not "function missing" (finding 1 above) and not "function has wrong values"
   (finding 3 below), but "function exists and is correct, yet nothing invokes it
   in the actual pipeline path." A future reader confirming "does this function
   exist and pass its own tests" could get a clean answer while the real pipeline
   output is still missing the file. Fixed by threading the parameters through
   `run_multitimestamp_post_rao_linearisation_loop` and wiring in the calls, with a
   new end-to-end test proving the loop itself produces both files, not just that
   the extraction functions work when called directly.
3. **`results_rd_multits.csv` silently wrote blank cells for 4 of its 9 spec'd
   columns** (`price_eur_mw`, `rd_penalty_factor`, `penalty_cost_eur`,
   `rd_cost_eur`) — `_extract_rd_results_for_timestamp` never populated them, and
   the CSV writer's fallback silently wrote empty values with no error. Not caught
   because R4.9's own RD-related tests only exercised the PST-only early-return
   path, never an RD-enabled run through to CSV output. Fixed by threading
   `power_bid_schedule_multitimestamp` (already available to the caller) down into
   the extraction function and mirroring `milp_solver.extract_rd_results`'s exact
   formula. A pre-existing `tso` field computation that "worked by accident" was
   also corrected as part of this fix.

All three fixes verified with tests written to fail against the pre-fix code
first, then pass against the fix — not just tests confirming the fixed behaviour
in isolation. 456 passed, 43 skipped, no regressions, as of this correction.

**⚠ This same bug category recurred elsewhere and was found in a subsequent
review pass — see R4.8 and R4.9 below for two more instances (`results_lead_times_multits.csv`
never invoked, `results_lf_post_multits.csv` never implemented at all), confirmed
**not yet fixed** at the time this note was written. Naming the pattern here did
not, on its own, guarantee every instance of it had been found — worth remembering
that "identified the pattern" and "found every occurrence of the pattern" are
different claims.**

**What it delivers:**
- Balancing constraint per timestamp (R2.6 generalised):
  `Σ_g rd_net_injection_g[t, g] = 0` for each `t` in `TIMESTAMP_LIST`
- Cost terms per timestamp summed into the objective (structurally generalised
  from R2.7, with the source-of-price divergence noted above):
  `Σ_t Σ_b rd_cost_per_bid[t, b]` using `power_bid_schedule[t]`'s per-timestamp price
- RA count limits (R2.8 generalised): the per-timestamp constraint
  (`ra_activated[t, ra_mrid]`, BUC14#119) now has a genuine multiple-timestamp
  meaning it lacked in R2 (where "per timestamp" and "per timeframe" collapsed to
  the same single timestamp); the per-timeframe constraint (CORNET-3649) now sums
  across all 4 real timestamps rather than trivially equalling the per-timestamp count
- Group volume limits per timestamp (R2.9 generalised):
  `Σ_{b ∈ group} rd_volume_upward[t, b] ≤ max_regulating_up[t, group]` using
  time-varying limits from `{TSO}_SIS.xml` if the synthetic dataset varies them,
  else a static limit applied identically at each `t`

**Inputs:**
- `milp_model` (from R4.6), `power_bid_schedule[t]` (from R4.5)
- RAO control parameters (same names as R2.7–R2.9, now applied per `t`)

**Outputs:**
- Updated `milp_model` with per-timestamp balancing, cost, RA-count, and
  group-volume constraints
- `results_rd_multits.csv`: columns `[ra_mrid, bid_mrid, tso, timestamp,
  rd_volume_net_mw, price_eur_mw, rd_penalty_factor, penalty_cost_eur, rd_cost_eur]`
- `results_ra_count_multits.csv`, `results_ra_groups_multits.csv` — multi-timestamp
  extensions of R2.8/R2.9's single-timestamp outputs

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4` and at least one RD unit activated at two or more
  timestamps,
- When the MILP is solved,
- Then `|Σ_g rd_net_injection_g[t, g]| < 0.01 MW` for **every** timestamp `t`
  independently (not just summed across all timestamps) AND a per-timeframe RA
  count limit correctly aggregates activations across all 4 timestamps, distinct
  from any single timestamp's own count.

---

## R4.8 — Multi-timestamp RD lead time enforcement

**Spec ref:** CORNET-3616, CORNET-3447 — extended to multi-timestamp (parallel to R2.10)

**Composability note:** Only applies when `rd_inputs is not None`. This increment
is primarily a **reuse** exercise, not new logic — R2.10's `radp` computation and
earliest-usable-timestamp search were already built anticipating this generalisation
(flagged explicitly by the R2 coding chat on completion). Confirm this reuse works
correctly with 4 real timestamps rather than the single timestamp R2.10 was tested
against; do not rebuild the `radp`/ceiling-to-next-timestamp logic from scratch.

**What it delivers:**
- Reuse `radp` computation from R2.10 unchanged
- For each bid with `bid_lead_time_hours > 0`, apply the same ceiling-to-next-timestamp
  rule established and corrected in R2.10 (first usable timestamp is strictly after
  `radp + bid_lead_time_hours`, not at-or-before) against the real `TIMESTAMP_LIST`
  of 4 timestamps rather than R2.10's single-timestamp test case
- Fix `rd_volume_upward[t, bid_mrid]` / `rd_volume_downward[t, bid_mrid]` upper
  bounds to 0 via `model.variable.setub(0.0)` for every `t` before the computed
  earliest usable timestamp

**Inputs:**
- `PowerBidList` (`bid_lead_time_hours` per bid)
- `TIMESTAMP_LIST` (now genuinely 4 timestamps, not 1)
- RAO control parameter: `raart` (reused from R2.10)

**Outputs:**
- Updated variable bounds in `milp_model` across all `N_TIMESTAMPS`
- `results_lead_times_multits.csv`: columns `[bid_mrid, ra_mrid,
  bid_lead_time_hours, radp, earliest_usable_timestamp]`

**⚠ Confirmed unfixed gap — "function exists, nothing calls it," same category as
R4.7's finding 2 above.** `extract_lead_time_results_multitimestamp` is called (in
the smoke test, to compute and log rows), but `write_lead_time_results_multitimestamp_csv`
— which exists — is never invoked anywhere, by either the smoke test or
`run_pipeline.py`. **`results_lead_times_multits.csv` is never actually written to
disk.** This was found in a review pass after R4.7's identical failure mode was
named and fixed, which means naming the pattern did not by itself surface every
occurrence of it. Not yet fixed as of this note. Needs: wire the writer call into
`run_multitimestamp_post_rao_linearisation_loop` (R4.9) or `run_pipeline.py`
directly, with a test proving the file is actually produced end-to-end — not just
that the extraction and writer functions individually pass their own unit tests.

**Acceptance criteria:**
- Given a synthetic 4-timestamp dataset with `radp` and `bid_lead_time_hours` set
  so that the earliest usable timestamp falls on the 3rd of the 4 timestamps,
- When lead time enforcement is applied,
- Then `rd_volume_upward`/`rd_volume_downward` upper bounds are 0 for the first two
  timestamps AND non-zero values are permitted from the 3rd timestamp onwards —
  confirming the R2.10 logic generalises correctly beyond the single-timestamp case
  it was originally tested against.

---

## R4.9 — Combined PST+RD multi-timestamp linearisation loop and results output

**Spec ref:** CORNET-12, CORNET-4850 — extended to multi-timestamp
(supersedes the earlier PST-only draft of this increment)

**⚠ Confirmed correctness bug (not an output bug) — `raart` was never threaded
into this loop's MILP build call.** Every other bug found and fixed during this
release's post-implementation review (the two missing/uncalled CSV writers,
the four blank `results_rd_multits.csv` columns) affected only what got written
to disk after a correct solve. This one is different in kind: `raart` — the RAO
control parameter R4.8's lead-time constraint depends on to compute `radp` — was
never passed from `run_multitimestamp_post_rao_linearisation_loop`'s call into
`build_multitimestamp_n0_pst_milp_model`, meaning **the lead-time constraint
itself used the default `radp` on every run through the loop, regardless of what
`raart` was actually set to.** This is a genuine solve-level correctness bug, not
a reporting gap. Confirmed fixed and proven at the solve level — not just via CSV
inspection — by `test_raart_actually_changes_which_timestamps_get_bound_to_zero_in_the_solve`,
which inspects `final_rd_results` (populated from `pyo.value()` on the *solved*
model) rather than the exported CSV, using a deliberately non-default `raart` and
a balanceable UP/DOWN bid pair (a single-direction bid cannot distinguish this fix
from the pre-fix state, since the balancing constraint forces it to zero
regardless of the lead-time bound — the same confound that recurred three times
across this release's RD-related tests; see the shared
`make_balanceable_rd_bid_pair()` fixture added to address this pattern).
**Confirmed isolated to this loop wrapper** — `test_r4_8_multitimestamp_rd_lead_time.py`
calls `build_multitimestamp_n0_pst_milp_model` directly and only ever checks the
`.ub` bound attribute, never solving the model, so R4.8's own original acceptance
tests never exercised this code path and remain fully valid; they simply never
could have caught this bug regardless of its presence.

**A second instance of the identical bug was found in `run_pipeline.py`'s real
`_run_multitimestamp_pipeline`** — it also never passed `RAART` into its call to
this loop, meaning even after fixing the loop's own signature, the production
pipeline entry point (R4.10) would have kept silently defaulting. Fixed together;
proven via `test_raart_reaches_the_loop_call_with_the_correct_keyword`, which uses
a deliberately non-default `RAART` value (not `None`) specifically because testing
against the default would make "argument never passed" and "default explicitly
passed" indistinguishable — exactly the ambiguity that could have let this second
instance go uncaught the same way the first one did.

**Composability note:** This is the single linearisation loop for the whole
multi-timestamp MILP — not two separate loops. PST refresh logic only runs when
`pst_inputs is not None`; RD refresh logic only runs when `rd_inputs is not None`;
both run together when both are enabled. Same `hasattr`-gating discipline as every
other increment in R2–R4.

**What it delivers:**
- Extend the R1.7/R2 linearisation loop to operate over all `N_TIMESTAMPS`, for
  whichever RA types are enabled:
  - After each MILP solve, if `pst_inputs is not None`: apply tap changes to the
    pypowsybl network per timestamp:
    ```python
    network.update_phase_tap_changers(id=pst_mrid, tap=int(round(result_tap_position)))
    ```
    **Critical:** the kwarg is `tap`, not `tap_position`. Wrong kwarg silently does
    nothing — confirmed live bug in R1.7 before fix, and confirmed again as a risk
    during R3. Verify with a diagnostic read-back after every apply call, at every
    timestamp, in every iteration.
  - Re-run `pp.loadflow.run_ac(network)` for each timestamp (this single LF call
    reflects both PST tap changes and RD injection changes simultaneously — there
    is one network state per timestamp, not separate PST and RD network states)
  - Extract updated side-aware branch currents from `network.get_lines_results()`
    and `network.get_2_windings_transformers_results()`
  - Update `lf_initial[t]` baseline explicitly before rebuilding sensitivity for the
    next iteration, for **both** PST and RD sensitivity recomputation — failing to
    update the baseline causes silent oscillation (confirmed live in R1.7, and the
    same class of bug was independently confirmed in R3's completeness loop). Always
    refresh from the post-LF result, never reuse a stale per-PST `current_tap` or
    per-unit `target_p` field.
  - Compute `total_tap_change_sum = Σ_t Σ_τ |tap_change_result_τ(t)|` (0 if PST
    disabled) and `total_rd_volume_change_sum = Σ_t Σ_b |rd_volume_change_result[t,b]|`
    (0 if RD disabled)
  - Check termination: `(total_tap_change_sum + total_rd_volume_change_sum) <
    max_change_ra_sum_threshold` OR iteration count ≥ `max_linearisation_iterations`
  - No damping or best-iterate fallback — termination is the two conditions above
    only, consistent with the spec as written and with R1.7/R3's established
    behaviour. If a stable N-cycle is observed, it will exhaust
    `max_linearisation_iterations` and return the last iterate.
- On termination, export the full multi-timestamp results for whichever RA types
  were enabled

**Inputs:**
- `pst_results[t]` (if PST enabled), `rd_results[t]` (if RD enabled)
- `network` (pypowsybl `Network`)
- RAO control parameters: `max_change_ra_sum_threshold: float` (default 1.0),
  `max_linearisation_iterations: int` (default 10)

**Outputs:**
- `results_pst_multits.csv` (if PST enabled): columns `[pst_mrid, pst_name, tso,
  timestamp, current_tap_position, tap_change_result, result_tap_position,
  penalty_cost_eur]`
- `results_rd_multits.csv` (if RD enabled, extends R4.7's output with final
  post-loop values) — **confirmed complete as of the post-implementation fix
  described in R4.7: all 9 spec'd columns are populated, not just the volume
  fields**
- `results_ra_count_multits.csv`, `results_ra_groups_multits.csv` (if RD enabled) —
  **only genuinely produced as of the post-implementation fix described in R4.7**;
  building the extraction functions alone was not sufficient, since this loop is
  what actually calls them — see R4.7's "Confirmed post-implementation bugs" note
  for the full account of why this required threading new parameters through this
  function, not just fixing the extraction functions themselves
- `results_lf_post_multits.csv`: columns `[timestamp, branch_mrid, branch_name, tso,
  side, i_ka_before, i_ka_after, loading_pct_before, loading_pct_after, patl_ka]`
  — **⚠ Confirmed unfixed gap, more severe than a missing wiring step: this file
  was never implemented at all.** Confirmed by grepping
  `multitimestamp_linearisation.py`, the smoke test, and the R4.9 test file for any
  trace of it — zero matches anywhere. No extraction function, no writer function,
  nothing exists for this output, despite being named explicitly in this section.
  Not yet fixed as of this note. This is a different failure mode from the
  "function exists, nothing calls it" pattern found elsewhere in R4.7/R4.8 — here
  there is no function to call in the first place. Needs: a new extraction
  function (per-timestamp before/after branch loading, mirroring R4.1's
  `lf_basecase_all_ts.csv` pattern) and writer, wired into
  `run_multitimestamp_post_rao_linearisation_loop`, with an end-to-end test
  proving the file is produced with the correct row count and columns.
- Console log: per-iteration `total_tap_change_sum`, `total_rd_volume_change_sum`,
  termination reason, total iterations

**Acceptance criteria:**
- Given `N_TIMESTAMPS = 4`, both PST and RD enabled, and at least one XNE
  overloaded in at least one timestamp,
- When the multi-timestamp MILP solves and the loop terminates,
- Then `results_pst_multits.csv` has exactly `|PSTList_activated| × N_TIMESTAMPS`
  rows AND `results_rd_multits.csv` has exactly `|PowerBidList_activated| ×
  N_TIMESTAMPS` rows AND the loop terminates within `max_linearisation_iterations`
  iterations AND `lf_initial[t]` is refreshed from the post-LF result at every
  iteration for every timestamp.
- Given PST disabled (`pst_inputs is None`) and RD enabled,
- When the loop runs,
- Then no tap application occurs at any timestamp, `total_tap_change_sum` is always
  0, and only RD refresh logic executes.
- Given RD is enabled and the loop completes,
- When `results_ra_count_multits.csv` and `results_ra_groups_multits.csv` are
  checked,
- Then both files exist and contain real extracted values — not just that the
  underlying extraction functions pass their own unit tests in isolation.

---

## R4.10 — Pipeline integration (`ENABLE_MULTITIMESTAMP`)

**Spec ref:** No direct CORNET item — prototype integration increment, added to
this document after the fact because without it the MD did not describe what R4
actually delivers as a usable pipeline entry point, only as a smoke-tested module.

**Context:** R4.1–R4.9 were implemented and fully tested but lived only in
`smoke_test_r4_multitimestamp.py` — `run_pipeline.py` itself was untouched and
still called only the single-timestamp `build_n0_milp_model` path. This increment
wires the multi-timestamp path into `run_pipeline.py` as a real, selectable entry
point.

**What it delivers:**
- New module constant `ENABLE_MULTITIMESTAMP: bool` (default `False`), following
  the existing `ENABLE_PST_REMEDIAL_ACTIONS` / `ENABLE_RD_REMEDIAL_ACTIONS`
  ALL-CAPS naming convention. When `True`, `run_pipeline.py` branches to the new
  multi-timestamp path; when `False` (default), the untouched R1-era single-timestamp
  path runs exactly as before.
- **Scope-boundary hard guard, `_check_multitimestamp_compatibility`.** The
  multi-timestamp path (`multitimestamp_milp_builder.py`) is a strict subset of
  `build_n0_milp_model`'s scope — N-0 PST+RD only. It has no curative PST block, no
  curative RD block, no N-X block, and no scanned-element (R2.12) constraint.
  Combining `ENABLE_MULTITIMESTAMP=True` with an incompatible configuration must
  fail loudly, not just log a line that could scroll past unread. Confirmed during
  implementation that curative PST, curative RD, and N-X analysis all collapse to
  a single gate (`nx_inputs is not None`) inside `build_n0_milp_model`, and that
  `run_pipeline.py` never constructs an `NxMilpInputs` object at all today — so
  there is currently no flag-based configuration that could combine
  `ENABLE_MULTITIMESTAMP` with curative/N-X. **Scanned-element support is the one
  real, live risk**: it is not flag-gated at all, but purely data-driven
  (`AEType.SCANNED` classification on any `AssessedElement` in `ae_flat_list`
  automatically triggers a scanned-element constraint inside `build_n0_milp_model`,
  regardless of any boolean). The guard checks this directly — is `AEType.SCANNED`
  present in `ae_flat_list` — and raises if so while `ENABLE_MULTITIMESTAMP=True`.
  A documented placeholder is retained for curative/N-X, structured so that if a
  future maintainer wires `nx_inputs` into `run_pipeline.py`, the guard forces an
  explicit extension rather than allowing a silent combination.
- **Two override-only/unverified-data warnings, firing on every applicable run —
  not once at startup:**
  1. `max_taps_per_timeframe` (R4.4) — since `GridStateAlteration.maximumPerDay`
     is confirmed never parsed from real data anywhere in the codebase (see R4.4's
     "Confirmed not parsed" note), a loud warning fires whenever
     `ENABLE_MULTITIMESTAMP=True` and no override is supplied, stating plainly that
     this limit is not sourced from real data.
  2. `tap_change_scheduled_multitimestamp` (R4.1/R4.3/R4.4) — since it is
     genuinely unconfirmed whether real time-varying PST tap-schedule data exists
     anywhere in `{TSO}_SIS.xml` (no real NCP data was ever available to check this
     against during R4's implementation), a warning fires stating that this term
     defaults to 0 everywhere and that PST tap-change-limit behaviour reflects only
     the RAO's own decisions, not a genuine pre-existing schedule, until this is
     checked against real data.
- **`build_pipeline_context()` extraction.** `run_pipeline.py`'s R0 preprocessing
  section (CGM load, TSO resolution, NCP parsing) was previously inline inside
  `main()`, with no callable function for the smoke test to reuse — the smoke test
  maintained its own independent, duplicate `build_r4_context()`. This was
  identified as the same duplication risk flagged in the original integration
  instructions: two implementations of the same setup logic that could silently
  drift apart. Fixed by extracting the R0 section into `build_pipeline_context()`,
  having `main()` call it, and having the smoke test call the same function
  instead of maintaining its own copy — the smoke test now exercises the actual
  integration code path, not a parallel reimplementation of it.

**Naming note:** `ENABLE_MULTITIMESTAMP` (ALL-CAPS module constant, matching
existing convention) — not `enable_multitimestamp` or `ENABLE_MULTI_TIMESTAMP`.

**Inputs:**
- `ae_flat_list` (from R0.4 — checked directly by the compatibility guard for
  `AEType.SCANNED` presence)
- All R4.1–R4.9 preprocessing and MILP-building functions
- RAO control parameters: `ENABLE_MULTITIMESTAMP: bool` (default `False`)

**Outputs:**
- `run_pipeline.py` gains a real, selectable multi-timestamp entry point
- All R4.1–R4.9 result CSVs, produced via the real pipeline path rather than only
  via the smoke test
- Two warning log lines (per the items above) on every `ENABLE_MULTITIMESTAMP=True`
  run without the relevant overrides supplied

**Acceptance criteria:**
- Given `ENABLE_MULTITIMESTAMP=True` and `ae_flat_list` contains at least one
  `AEType.SCANNED` element,
- When `run_pipeline.py` is run,
- Then `_check_multitimestamp_compatibility` raises a clear error before any
  preprocessing or MILP-building begins, naming the incompatible scanned-element
  configuration explicitly.
- Given `ENABLE_MULTITIMESTAMP=True`, `ae_flat_list` contains no scanned elements,
  and no `max_taps_per_timeframe` override is supplied,
- When `run_pipeline.py` is run,
- Then both the `maximumPerDay`-not-parsed warning and the PST-tap-schedule
  unconfirmed-data warning are logged, and the pipeline proceeds to completion.
- Given `ENABLE_MULTITIMESTAMP=False` (the default),
- When `run_pipeline.py` is run,
- Then behaviour is identical to the pre-R4 single-timestamp pipeline — no
  regression to the R1-era path.
- Given the smoke test and `run_pipeline.py`'s `main()` both call
  `build_pipeline_context()`,
- When either is run against the same real dataset,
- Then both produce identical R0 preprocessing output — confirming the smoke test
  exercises the actual integration path, not an independent copy of it.
