# rao-prototype
RAO prototype using ReliCapGrid CGMES + NCP, pypowsybl, HiGHS
