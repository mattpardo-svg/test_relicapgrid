"""One coherent operating-point state (tests T1-T6, cost, revert).

The MILP build and solve are real; the network functions of milp.ac_convergence_loop are
replaced by a LINEAR fake grid whose response can be scaled against the model's
sensitivities, so the loop needs several iterations. Currents in A, PATL 1.0 kA:
  B1 N-0 base 1250 A (250 A over). PST1: -50 A per tap. GU1: -5 A per MW.
  CO1: B2 N-X base 1100 A (100 A over). PST1: -40 A/tap, GU1: -2 A/MW.
"""

import copy
import dataclasses
import sys
from pathlib import Path

import pytest

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"
if str(REPO_SRC) not in sys.path:
    sys.path.insert(0, str(REPO_SRC))

from data_model import (  # noqa: E402
    AEType, AssessedElement, BidDirection, PowerBid, PST, RAKind, RDUnit,
)
from milp import ac_convergence_loop as acl  # noqa: E402
from milp.milp_builder import NxMilpInputs  # noqa: E402
from milp.operating_point_state import OperatingPointState  # noqa: E402

from helpers import BASE_N0, BASE_NX, FakeGrid, GU_A_PER_MW_N0, GU_A_PER_MW_NX, PST_A_PER_TAP_N0, PST_A_PER_TAP_NX, Scenario, TIMESTAMP, _ae, _bid, _pst, _rd, export_status  # noqa: E402














# =========================================================================== T1
class TestBaselineIdentity:
    """T1 — at EVERY MILP build, PST r0, GU target_p, the N-0 load flow and the N-X
    load flow equal the current applied network state."""

    def test_every_build_starts_from_the_applied_state(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7, with_nx=True)
        scenario.run()
        assert len(scenario.builds) >= 3, "need several builds for the identity to mean anything"
        for index, build in enumerate(scenario.builds, start=1):
            assert build["model_r0"] == build["grid_taps"], f"build {index}: PST r0 is not the applied tap"
            assert build["model_target_p"] == build["grid_target_p"], (
                f"build {index}: GU target_p is not the applied value"
            )
            assert build["model_n0_lf"] == build["grid_n0_lf"], f"build {index}: N-0 load flow is stale"
            assert build["model_nx_lf"] == build["grid_nx_lf"], f"build {index}: N-X load flow is stale"
        # the loop really moved things, otherwise the identity above would be trivial
        assert scenario.builds[-1]["grid_taps"] != scenario.builds[0]["grid_taps"]
        assert scenario.builds[-1]["grid_target_p"] != scenario.builds[0]["grid_target_p"]


# =========================================================================== T2
class TestCumulativeIdentity:
    """T2 — final = original + the sum of every iteration's delta, for every PST and
    RD bid, and the reported rows agree."""

    def test_final_equals_original_plus_sum_of_deltas(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7)
        state, (lf, model, pst_rows, reason) = scenario.run()
        builds = scenario.builds
        assert len(builds) >= 3
        grid = scenario.grid

        # per-iteration deltas as seen by the grid between consecutive builds (+ the last solve)
        tap_states = [b["grid_taps"]["PST1"] for b in builds] + [grid.taps["PST1"]]
        mw_states = [b["grid_target_p"]["GU1"] for b in builds] + [grid.target_p["GU1"]]
        tap_deltas = [b - a for a, b in zip(tap_states, tap_states[1:])]
        mw_deltas = [b - a for a, b in zip(mw_states, mw_states[1:])]

        row = pst_rows["PST1"]
        assert row["original_tap_position"] == 0
        assert row["result_tap_position"] == 0 + sum(tap_deltas) == grid.taps["PST1"]
        assert row["tap_change_result"] == sum(tap_deltas)
        assert state.cumulative_signed_volume_mw["BID1"] == pytest.approx(sum(mw_deltas), abs=1e-6)
        assert grid.target_p["GU1"] == pytest.approx(50.0 + sum(mw_deltas), abs=1e-6)

        from post_milp import n0_results_export as export
        rd_rows = export.extract_rd_results(
            model, scenario.rd_list, scenario.bid_list, 10.0,
            export_status(), "x",
        )
        assert rd_rows["BID1"]["rd_volume_net_mw"] == pytest.approx(sum(mw_deltas), abs=1e-6)
        gu_rows = export.extract_results_generating_units(
            model, scenario.rd_list, export_status(), "x",
            generator_data=scenario.generator_data(), glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU2": 1.0}}, rd_results=rd_rows,
        )
        assert gu_rows["GU1"]["initial_production_mw"] == 50.0
        assert gu_rows["GU1"]["rd_volume_net_mw"] == pytest.approx(sum(mw_deltas), abs=1e-6)
        assert gu_rows["GU1"]["result_production_mw"] == pytest.approx(grid.target_p["GU1"], abs=1e-6)




# =========================================================================== T3
class TestFixedPoint:
    """T3 — re-solving at the converged state changes nothing beyond the thresholds."""

    def test_resolve_at_converged_state_is_within_thresholds(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        state, (_, _, _, reason) = scenario.run()
        assert "stabilized" in reason
        solves_before = len(state.solve_history)
        builds_before = len(scenario.builds)

        _, (_, _, _, reason_again) = scenario.run(state=state)

        assert len(scenario.builds) == builds_before + 1, "a converged state must be accepted after ONE more solve"
        last = state.solve_history[-1]
        assert last["sum_abs_tap_change"] < 1.0
        assert last["sum_abs_rd_change_mw"] < 1.0
        assert last["converged"] is True
        assert len(state.solve_history) == solves_before + 1
        assert "stabilized" in reason_again


# =========================================================================== T4
class TestApplyThenCheck:
    """T4 — the final network state equals the reported final values and a load flow
    exists on exactly that state, including when the iteration budget runs out."""

    def test_converging_iteration_is_applied_and_load_flowed(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        state, (lf, model, pst_rows, reason) = scenario.run()
        grid = scenario.grid
        assert pst_rows["PST1"]["result_tap_position"] == grid.taps["PST1"]
        assert lf == grid.n0_lf(), "the returned load flow is not the one of the final network state"
        # one load flow per solve, including the converging one
        assert grid.load_flow_calls == len(scenario.builds)
        assert state.current_tap_by_pst == grid.taps
        assert state.current_target_p_by_gu == grid.target_p
        assert grid.load_flow_calls == len(state.solve_history)

    def test_max_iterations_ending_applies_and_load_flows_the_last_solution(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7, loop_overrides={"max_linearisation_iterations": 2})
        state, (lf, model, pst_rows, reason) = scenario.run()
        grid = scenario.grid
        assert reason == "max iterations reached"
        assert len(scenario.builds) == 2
        assert grid.load_flow_calls == 2
        # the second solution moved something and it IS on the network
        assert grid.taps != scenario.builds[1]["grid_taps"] or grid.target_p != scenario.builds[1]["grid_target_p"]
        assert pst_rows["PST1"]["result_tap_position"] == grid.taps["PST1"]
        assert lf == grid.n0_lf()
        assert state.current_lf_n0 == grid.n0_lf()
        assert state.solve_history[-1]["solution_applied"] is True


# =========================================================================== T5
class TestCumulativeTapLimit:
    """T5 — the per-TSO tap limit applies to the cumulative change against the ORIGINAL
    network."""

    def test_iteration_two_gets_zero_headroom_after_iteration_one_used_the_limit(self, monkeypatch):
        scenario = Scenario(
            monkeypatch, physics_scale=0.7, tap_bounds=(-10, 10), loop_overrides={"max_taps_per_tso": 3},
        )
        state, (_, model, pst_rows, _) = scenario.run()
        taps_after_each_solve = [b["grid_taps"]["PST1"] for b in scenario.builds][1:] + [scenario.grid.taps["PST1"]]
        assert taps_after_each_solve[0] == 3, "iteration 1 should use the whole limit"
        assert len(scenario.builds) >= 2
        for tap in taps_after_each_solve:
            assert abs(tap - 0) <= 3, f"cumulative tap change {tap} exceeds the per-TSO limit 3"
        assert abs(pst_rows["PST1"]["tap_change_result"]) <= 3

    def test_exporter_reports_cumulative_taps_against_the_limit(self, monkeypatch):
        scenario = Scenario(
            monkeypatch, physics_scale=0.7, tap_bounds=(-10, 10), loop_overrides={"max_taps_per_tso": 3},
        )
        _, (_, model, _, _) = scenario.run()
        from post_milp import n0_results_export as export
        rows = export.extract_tso_tap_limit_results(model, scenario.pst_list)
        assert rows and rows[0]["tap_total"] == pytest.approx(abs(scenario.grid.taps["PST1"]), abs=1e-6)
        assert rows[0]["tap_total"] <= rows[0]["max_taps_per_tso"] + 1e-6


# =========================================================================== T6
class TestCumulativeRdHeadroom:
    """T6 — a bid used in an earlier iteration cannot exceed its total availability; the
    RA count counts it once."""

    def _scenario(self, monkeypatch, with_ra_limit=True):
        overrides = (
            {"max_ra_count_per_timestamp_tso": {"T": 2}, "ra_limit_constraint_hard": True}
            if with_ra_limit else {}
        )
        return Scenario(
            monkeypatch, physics_scale=0.7, bid_available_mw=25.0, tap_bounds=(-3, 3),
            loop_overrides=overrides,
        )

    # without the RA-count block there is no big-M link: ONLY the variable bounds enforce the headroom
    @pytest.mark.parametrize("with_ra_limit", [True, False], ids=["with-ra-limit", "bounds-only"])
    def test_bid_never_exceeds_total_availability_over_the_iterations(self, monkeypatch, with_ra_limit):
        scenario = self._scenario(monkeypatch, with_ra_limit)
        state, _ = scenario.run()
        assert len(scenario.builds) >= 3
        for build in scenario.builds:
            assert build["grid_target_p"]["GU1"] - 50.0 <= 25.0 + 1e-6
        assert scenario.grid.target_p["GU1"] - 50.0 == pytest.approx(25.0, abs=1e-6), "headroom must be fully used"
        assert state.cumulative_signed_volume_mw["BID1"] == pytest.approx(25.0, abs=1e-6)

    def test_ra_activation_is_counted_once_across_iterations(self, monkeypatch):
        scenario = self._scenario(monkeypatch)
        _, (_, model, _, _) = scenario.run()
        from post_milp import n0_results_export as export
        counts = export.extract_ra_count_results(
            model, scenario.rd_list, scenario.bid_list, export_status(), "x",
            max_ra_count_per_timestamp_tso={"T": 2},
        )
        assert counts["T"]["activated_ra_count"] == 2.0
        assert counts["T"]["slack_per_timestamp"] in (0.0, None)


# ============================================================ cost (extra test)
class TestObjectiveIsTheCostOfTheCumulativeChanges:
    @pytest.mark.parametrize("tap_bounds", [(-3, 3), (-10, 10)], ids=["rd-driven", "pst-driven"])
    def test_objective_equals_cost_of_cumulative_changes_after_several_iterations(self, monkeypatch, tap_bounds):
        import pyomo.environ as pyo
        scenario = Scenario(
            monkeypatch, physics_scale=0.7, tap_bounds=tap_bounds, loop_overrides={"max_taps_per_tso": 100},
        )
        _, (_, model, pst_rows, _) = scenario.run()
        grid = scenario.grid
        assert len(scenario.builds) >= 3

        cumulative_taps = abs(grid.taps["PST1"] - 0)
        cumulative_mw = abs(grid.target_p["GU1"] - 50.0) + abs(grid.target_p["GU2"] - 50.0)  # both bids are priced
        # PST: penalty_factor 1 x reference 10 per tap. RD: (penalty_factor 1 x reference 10 + price 10) per MW.
        expected_cost = 10.0 * cumulative_taps + (10.0 + 10.0) * cumulative_mw
        slack_penalty = 1000.0 * sum(pyo.value(model.overload_slack_n0[b]) for b in model.branch_ids)
        assert pyo.value(model.objective) == pytest.approx(expected_cost + slack_penalty, rel=1e-6, abs=1e-4)

        from post_milp import n0_results_export as export
        rd_rows = export.extract_rd_results(model, scenario.rd_list, scenario.bid_list, 10.0, export_status(), "x")
        summary = export.extract_results_summary(
            model, float(pyo.value(model.objective)), pst_list=scenario.pst_list,
            penalty_reference_pst_pra=10.0, rd_results=rd_rows,
        )
        assert summary["sum_pst_penalty_cost_eur"] == pytest.approx(10.0 * cumulative_taps, abs=1e-6)
        assert summary["sum_rd_cost_eur"] == pytest.approx(20.0 * cumulative_mw, abs=1e-6)
        assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)
        assert pst_rows["PST1"]["penalty_cost_eur"] == pytest.approx(10.0 * cumulative_taps, abs=1e-6)


# ================================================================ revert statuses
class TestLoadFlowFailureReverts:
    def test_failure_at_iteration_one_reverts_to_the_original_network(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        scenario.grid.fail_load_flow_on_calls = {1}
        state, (lf, model, pst_rows, reason) = scenario.run()
        assert reason == "load flow non-convergent"
        assert scenario.grid.taps == scenario.grid.original_taps
        assert scenario.grid.target_p == scenario.grid.original_target_p
        assert state.current_tap_by_pst == state.original_tap_by_pst
        from data_model import AcVerificationStatus
        assert AcVerificationStatus.from_termination_reason(reason) == AcVerificationStatus.REVERTED_NON_CONVERGENT

    def test_failure_at_iteration_two_reverts_to_the_last_converged_state(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7)
        scenario.grid.fail_load_flow_on_calls = {2}
        state, (lf, model, pst_rows, reason) = scenario.run()
        grid = scenario.grid
        assert reason == "load flow non-convergent - reverted to last converged state"
        # the network holds what iteration 1 left, NOT the original and NOT iteration 2's proposal
        assert grid.taps["PST1"] == scenario.builds[1]["grid_taps"]["PST1"] != 0
        assert grid.target_p == scenario.builds[1]["grid_target_p"]
        assert state.current_tap_by_pst == grid.taps
        assert pst_rows["PST1"]["result_tap_position"] == grid.taps["PST1"]
        assert lf == grid.n0_lf()
        assert state.solve_history[-1]["solution_applied"] is False
        from data_model import AcVerificationStatus
        assert AcVerificationStatus.from_termination_reason(reason) == (
            AcVerificationStatus.REVERTED_TO_LAST_CONVERGED_STATE
        )


# ============================================ ac_iteration labelling (Step 3b)
class TestAcIterationLabelling:
    def test_every_applied_iteration_gets_its_own_number(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7)
        records: list[dict] = []
        state, _ = scenario.run(iteration_records=records)
        assert len(records) == len(scenario.builds) >= 3
        assert [r["ac_iteration"] for r in records] == list(range(1, len(records) + 1))
        assert all(r["solution_applied_to_network"] is True for r in records)

    def test_non_convergent_iteration_is_recorded_as_not_applied_with_its_own_number(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7)
        scenario.grid.fail_load_flow_on_calls = {2}
        records: list[dict] = []
        scenario.run(iteration_records=records)
        assert [(r["ac_iteration"], r["solution_applied_to_network"]) for r in records] == [(1, True), (2, False)]

    def test_lf_post_rows_chain_and_the_failed_iteration_shows_after_equal_before(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7)
        scenario.grid.fail_load_flow_on_calls = {3}
        lf_post: list[dict] = []
        scenario.run(lf_post_iteration_records=lf_post)
        assert [r["ac_iteration"] for r in lf_post] == [1, 2, 3]
        for earlier, later in zip(lf_post, lf_post[1:]):
            assert later["lf_before"] == earlier["lf_after"], "before of k+1 is the after of k"
        assert lf_post[-1]["solution_applied_to_network"] is False
        assert lf_post[-1]["lf_after"] == lf_post[-1]["lf_before"]
