"""
test_rao_data_model.py — Unit tests for data_model.py

Tests every dataclass and enum defined in data_model.py.
No external data files required.
"""
import pytest
from data_model import (
    AEType, ContingencyType, RAKind, BidDirection,
    AssessedElement, Contingency, PST, RDUnit, PowerBid, ScannedElement, select_by_side,
)


# ---------------------------------------------------------------------------
# Enum tests
# ---------------------------------------------------------------------------

class TestEnums:
    def test_ae_type_values(self):
        assert AEType.SECURED  == "secured"
        assert AEType.SCANNED  == "scanned"
        assert AEType.EXCLUDED == "excluded"

    def test_contingency_type_values(self):
        assert ContingencyType.ORDINARY    == "OrdinaryContingency"
        assert ContingencyType.EXCEPTIONAL == "ExceptionalContingency"

    def test_ra_kind_values(self):
        assert RAKind.PREVENTIVE == "preventive"
        assert RAKind.CURATIVE   == "curative"

    def test_bid_direction_values(self):
        assert BidDirection.UP   == "up"
        assert BidDirection.DOWN == "down"

    def test_enums_are_str_subclass(self):
        assert isinstance(AEType.SECURED, str)
        assert isinstance(RAKind.CURATIVE, str)


# ---------------------------------------------------------------------------
# AssessedElement
# ---------------------------------------------------------------------------

class TestAssessedElement:
    def _make(self, **kwargs):
        defaults = dict(
            mrid="ae-1", name="Line BE-FR", tso="TSO-Belgovia",
            ae_type=AEType.SECURED, branch_mrid="branch-1",
            secured_for_region="CORE", scanned_for_region=None,
            exclusion_reason=None,
            patl_ka={"1030Z": 1.2, "1130Z": 1.1},
        )
        defaults.update(kwargs)
        return AssessedElement(**defaults)

    def test_basic_instantiation(self):
        ae = self._make()
        assert ae.mrid == "ae-1"
        assert ae.ae_type == AEType.SECURED
        assert ae.patl_ka["1030Z"] == 1.2

    def test_scanned_type(self):
        ae = self._make(
            ae_type=AEType.SCANNED,
            secured_for_region=None,
            scanned_for_region="CORE",
            exclusion_reason="SecuredExclusionReasonKind.nonNativeCapacityCalculationRegion",
        )
        assert ae.ae_type == AEType.SCANNED

    def test_excluded_type(self):
        ae = self._make(
            ae_type=AEType.EXCLUDED,
            secured_for_region=None,
            exclusion_reason="SecuredExclusionReasonKind.nonNativeCapacityCalculationRegion",
        )
        assert ae.ae_type == AEType.EXCLUDED

    def test_optional_fields_none(self):
        ae = self._make(branch_mrid=None, secured_for_region=None,
                        scanned_for_region=None, exclusion_reason=None)
        assert ae.branch_mrid is None

    def test_patl_ka_multi_timestamp(self):
        ae = self._make(patl_ka={"1030Z": 1.0, "1130Z": 1.1, "1230Z": 1.2, "1330Z": 1.3})
        assert len(ae.patl_ka) == 4
        assert ae.patl_ka["1330Z"] == 1.3

    def test_branch_side_defaults_to_1(self):
        """branch_side defaults to 1 when not provided, as parse_assessed_elements does when an
        AE's CurrentLimit side cannot be resolved."""
        ae = self._make()
        assert ae.branch_side == 1

    def test_branch_side_explicit_2(self):
        """CurrentLimits are side-specific and the side varies per AE: some branches
        resolve to side 2."""
        ae = self._make(branch_side=2)
        assert ae.branch_side == 2

    def test_branch_side_only_valid_values(self):
        """branch_side should only ever be 1 or 2 (ACDCTerminal.sequenceNumber
        convention) — this test documents the expected value set rather than
        enforcing it at the dataclass level (no runtime validation exists),
        since ncp_parser.build_current_limit_side_map already rejects and
        logs any sequenceNumber outside {1, 2} before it would ever reach
        this field."""
        ae_side1 = self._make(branch_side=1)
        ae_side2 = self._make(branch_side=2)
        assert ae_side1.branch_side in (1, 2)
        assert ae_side2.branch_side in (1, 2)


# ---------------------------------------------------------------------------
# Contingency
# ---------------------------------------------------------------------------

class TestContingency:
    def test_basic_instantiation(self):
        co = Contingency(
            mrid="co-1", name="N-1 Line A", tso="TSO-Belgovia",
            contingency_type=ContingencyType.ORDINARY,
            must_study={"1030Z": True, "1130Z": False},
            equipment_mrids=["eq-1", "eq-2"],
        )
        assert co.contingency_type == ContingencyType.ORDINARY
        assert co.must_study["1030Z"] is True
        assert co.must_study["1130Z"] is False
        assert len(co.equipment_mrids) == 2
        assert co.tso == "TSO-Belgovia"

    def test_exceptional_contingency(self):
        co = Contingency(
            mrid="co-2", name="Exceptional", tso="TSO-Belgovia",
            contingency_type=ContingencyType.EXCEPTIONAL,
            must_study={"1030Z": True},
            equipment_mrids=["eq-1"],
        )
        assert co.contingency_type == ContingencyType.EXCEPTIONAL

    def test_tso_distinguishes_contingencies_from_different_tsos(self):
        co1 = Contingency(
            mrid="co-1", name="N-1 A", tso="TSO-Belgovia",
            contingency_type=ContingencyType.ORDINARY,
            must_study={"1030Z": True}, equipment_mrids=["eq-1"],
        )
        co2 = Contingency(
            mrid="co-2", name="N-1 B", tso="TSO-Espheim",
            contingency_type=ContingencyType.ORDINARY,
            must_study={"1030Z": True}, equipment_mrids=["eq-2"],
        )
        assert co1.tso != co2.tso


# ---------------------------------------------------------------------------
# PST
# ---------------------------------------------------------------------------

class TestPST:
    def _make(self, **kwargs):
        defaults = dict(
            mrid="pst-1", name="PST Zeebrugge", tso="TSO-Belgovia",
            available=True, kind=RAKind.PREVENTIVE, penalty_factor=0.5,
            low_step=-17, high_step=17, r0=0, operating_tap_min=-10, operating_tap_max=10,
            group_id=None,
        )
        defaults.update(kwargs)
        return PST(**defaults)

    def test_basic_instantiation(self):
        pst = self._make()
        assert pst.low_step <= pst.r0 <= pst.high_step

    def test_tap_bounds_respected(self):
        pst = self._make(low_step=-17, high_step=17, r0=5, operating_tap_min=-10, operating_tap_max=10)
        assert pst.low_step  <= pst.operating_tap_min
        assert pst.operating_tap_max    <= pst.high_step
        assert pst.low_step  <= pst.r0 <= pst.high_step

    def test_group_id_present(self):
        pst = self._make(group_id="gsara-abc-123")
        assert pst.group_id == "gsara-abc-123"

    def test_curative_kind(self):
        pst = self._make(kind=RAKind.CURATIVE)
        assert pst.kind == RAKind.CURATIVE


# ---------------------------------------------------------------------------
# RDUnit
# ---------------------------------------------------------------------------

class TestRDUnit:
    def _make(self, **kwargs):
        defaults = dict(
            mrid="rd-1", name="Unit Alpha", tso="TSO-Belgovia",
            gu_mrid="gu-1", gu_name="Plant Alpha",
            available=True, kind=RAKind.PREVENTIVE,
            initial_p=100.0, max_p=200.0, min_p=50.0,
            raise_ramp_rate=5.0, lower_ramp_rate=3.0,
        )
        defaults.update(kwargs)
        return RDUnit(**defaults)

    def test_basic_instantiation(self):
        rd = self._make()
        assert rd.min_p <= rd.initial_p <= rd.max_p

    def test_optional_ramp_rates_none(self):
        rd = self._make(raise_ramp_rate=None, lower_ramp_rate=None)
        assert rd.raise_ramp_rate is None
        assert rd.lower_ramp_rate is None

    def test_curative_rd(self):
        rd = self._make(kind=RAKind.CURATIVE)
        assert rd.kind == RAKind.CURATIVE


# ---------------------------------------------------------------------------
# PowerBid
# ---------------------------------------------------------------------------

class TestPowerBid:
    def _make(self, **kwargs):
        defaults = dict(
            mrid="bid-1", ra_mrid="rd-1", direction=BidDirection.UP,
            available_mw={"1030Z": 80.0, "1130Z": 80.0},
            price_eur_mw=10.0, penalty_factor=1.0, lead_time_h=0.25,
            activation_cost_eur=None, min_energy_mwh=None,
            max_energy_mwh=None, step_size_mw=None,
        )
        defaults.update(kwargs)
        return PowerBid(**defaults)

    def test_basic_instantiation(self):
        bid = self._make()
        assert bid.direction == BidDirection.UP
        assert bid.available_mw["1030Z"] == 80.0

    def test_down_direction(self):
        bid = self._make(direction=BidDirection.DOWN)
        assert bid.direction == BidDirection.DOWN

    def test_optional_fields_none(self):
        bid = self._make()
        assert bid.activation_cost_eur is None
        assert bid.min_energy_mwh is None
        assert bid.step_size_mw is None

    def test_optional_fields_set(self):
        bid = self._make(
            activation_cost_eur=500.0, min_energy_mwh=10.0,
            max_energy_mwh=100.0, step_size_mw=5.0,
        )
        assert bid.activation_cost_eur == 500.0
        assert bid.step_size_mw == 5.0


# ---------------------------------------------------------------------------
# ScannedElement
# ---------------------------------------------------------------------------

class TestScannedElement:
    def _make(self, **kwargs):
        defaults = dict(
            mrid="ae-2", name="Line RU-BG", tso="TSO-Belgovia",
            branch_mrid="branch-2", virtual_load_margin_pct=10,
            patl_cgm_ka={"1030Z": 1.0},
            patl_scanned_ka={"1030Z": 1.1},
            effective_limit_ka={"1030Z": 1.1},
        )
        defaults.update(kwargs)
        return ScannedElement(**defaults)

    def test_basic_instantiation(self):
        sc = self._make()
        assert sc.patl_scanned_ka["1030Z"] == 1.1
        assert sc.effective_limit_ka["1030Z"] == 1.1

    def test_defaults(self):
        sc = self._make()
        assert sc.soft is False
        assert sc.penalty == 0.0

    def test_soft_penalty(self):
        sc = self._make(soft=True, penalty=999.0)
        assert sc.soft is True
        assert sc.penalty == 999.0

    def test_zero_margin(self):
        sc = self._make(
            virtual_load_margin_pct=0,
            patl_cgm_ka={"1030Z": 1.0},
            patl_scanned_ka={"1030Z": 1.0},
            effective_limit_ka={"1030Z": 1.0},
        )
        assert sc.patl_scanned_ka["1030Z"] == sc.patl_cgm_ka["1030Z"]


# ---------------------------------------------------------------------------
# select_by_side
# ---------------------------------------------------------------------------

class TestSelectBySide:
    def test_returns_requested_side_when_present(self):
        assert select_by_side({1: 10.0, 2: 20.0}, 1) == 10.0
        assert select_by_side({1: 10.0, 2: 20.0}, 2) == 20.0

    def test_falls_back_to_other_side_when_missing(self):
        assert select_by_side({1: 10.0}, 2) == 10.0
        assert select_by_side({2: 20.0}, 1) == 20.0

    def test_returns_none_when_no_side_present(self):
        assert select_by_side({}, 1) is None
