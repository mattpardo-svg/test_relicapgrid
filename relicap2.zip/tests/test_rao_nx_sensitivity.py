"""tests/test_rao_nx_sensitivity.py - unit tests for nx_sensitivity.py: sensitivity
computation and CSV files, the N-X loading filter and the sensitivity pruning filter.
"""

import logging
import math
import sys
import pandas as pd
import pytest

from pathlib import Path
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit
from pre_milp.nx_sensitivity import (
    _get_available_pst_ids_nx,
    _get_available_rd_gu_ids_nx,
    compute_sensitivity_pst_nx,
    compute_sensitivity_rd_nx,
    write_sensitivity_nx_csv,
    write_sensitivity_rd_nx_csv,
)
from helpers import (
    _make_ae_nx_filters as _make_ae_nx_filters_and_scanned_elements,
    _make_contingency as _make_contingency_nx_filters_and_scanned_elements,
    _make_pst_nx_filters as _make_pst_nx_filters_and_scanned_elements,
)

# ---------------------------------------------------------------------------
# Test fixtures / builders
# ---------------------------------------------------------------------------

def _make_ae(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED):
    return AssessedElement(
        mrid=mrid, name="a", tso="TSO", ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


def _make_pst(mrid, available=True, kind=RAKind.PREVENTIVE):
    return PST(
        mrid=mrid, name="pst", tso="TSO", available=available, kind=kind,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd(mrid, gu_mrid, available=True, kind=RAKind.PREVENTIVE):
    return RDUnit(
        mrid=mrid, name="rd", tso="TSO", gu_mrid=gu_mrid, gu_name="gu",
        available=available, kind=kind, initial_p=10.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_contingency(mrid, equipment_mrids, must_study=True, timestamp="1030Z"):
    return Contingency(
        mrid=mrid, name=f"CO {mrid}", tso="TSO",
        contingency_type=ContingencyType.ORDINARY,
        must_study={timestamp: must_study},
        equipment_mrids=equipment_mrids,
    )


# ---------------------------------------------------------------------------
# Dummy pypowsybl stand-ins
# ---------------------------------------------------------------------------

class DummyContingencyContextType:
    NONE = "NONE"
    SPECIFIC = "SPECIFIC"
    ALL = "ALL"


class DummySensitivityFunctionType:
    BRANCH_CURRENT_1 = "BRANCH_CURRENT_1"
    BRANCH_CURRENT_2 = "BRANCH_CURRENT_2"


class DummySensitivityVariableType:
    TRANSFORMER_PHASE = "TRANSFORMER_PHASE"
    INJECTION_ACTIVE_POWER = "INJECTION_ACTIVE_POWER"


class DummySensitivityResult:
    def __init__(self, matrices: dict):
        # matrices: dict[(matrix_id, contingency_id), DataFrame]
        self._matrices = matrices

    def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
        return self._matrices.get((matrix_id, contingency_id))


class DummySensitivityAnalysis:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.single_element_contingencies = []   # list of (element_id, contingency_id)
        self.multiple_element_contingencies = []  # list of (element_ids, contingency_id)
        self.add_factor_matrix_calls = []         # list of kwargs dicts

    def add_single_element_contingency(self, element_id, contingency_id):
        self.single_element_contingencies.append((element_id, contingency_id))

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        self.multiple_element_contingencies.append((list(element_ids), contingency_id))

    def add_factor_matrix(self, **kwargs):
        self.add_factor_matrix_calls.append(kwargs)

    def run(self, network, parameters=None):
        return DummySensitivityResult(self._matrices)


class DummySensitivityModule:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.ContingencyContextType = DummyContingencyContextType
        self.SensitivityFunctionType = DummySensitivityFunctionType
        self.SensitivityVariableType = DummySensitivityVariableType
        self.last_analysis = None

    def create_ac_analysis(self):
        self.last_analysis = DummySensitivityAnalysis(self._matrices)
        return self.last_analysis


class DummySecurityAnalysisResult:
    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self.post_contingency_results = post_contingency_results
        self.branch_results = branch_results


class DummySecurityAnalysis:
    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results
        self.single_element_contingencies = []
        self.multiple_element_contingencies = []
        self.monitored_branch_ids = None

    def add_single_element_contingency(self, element_id, contingency_id):
        self.single_element_contingencies.append((element_id, contingency_id))

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        self.multiple_element_contingencies.append((list(element_ids), contingency_id))

    def add_monitored_elements(self, branch_ids):
        self.monitored_branch_ids = list(branch_ids)

    def run_ac(self, network, parameters=None):
        return DummySecurityAnalysisResult(self._post_contingency_results, self._branch_results)


class DummySecurityModule:
    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results
        self.last_analysis = None

    def create_analysis(self):
        self.last_analysis = DummySecurityAnalysis(self._post_contingency_results, self._branch_results)
        return self.last_analysis


class DummyLoadflowModule:
    """Minimal stand-in for pypowsybl.loadflow, reached by attribute access (as the code
    under test uses it)."""
    class Parameters:
        """Spy: records the kwargs of its latest construction at class level, so tests can
        check that use_reactive_limits reaches the construction."""
        last_kwargs = None

        def __init__(self, **kwargs):
            DummyLoadflowModule.Parameters.last_kwargs = kwargs
            for key, value in kwargs.items():
                setattr(self, key, value)


class DummyPypowsyblModule:
    def __init__(self, sensitivity_matrices=None, post_contingency_results=None, branch_results=None):
        self.sensitivity = DummySensitivityModule(sensitivity_matrices or {})
        self.security = DummySecurityModule(post_contingency_results or {}, branch_results)
        self.loadflow = DummyLoadflowModule()


# ---------------------------------------------------------------------------
# _get_available_pst_ids_nx
# ---------------------------------------------------------------------------

class TestGetAvailablePstIdsNx:
    def test_includes_both_preventive_and_curative(self):
        """One preventive and one curative available PST: BOTH are N-X candidates (curative
        terms need N-X sensitivities too)."""
        pst_list = [
            _make_pst("pst-1", available=True, kind=RAKind.PREVENTIVE),
            _make_pst("pst-2", available=True, kind=RAKind.CURATIVE),
        ]
        result = _get_available_pst_ids_nx(pst_list)
        assert set(result) == {"pst-1", "pst-2"}

    def test_excludes_unavailable_pst(self):
        pst_list = [_make_pst("pst-1", available=False)]
        assert _get_available_pst_ids_nx(pst_list) == []

    def test_same_physical_pst_preventive_and_curative_deduplicated(self):
        """A PST with a preventive and a curative RA (two PST objects, one mrid) is returned
        once: a duplicate ID makes pypowsybl return a duplicate matrix row, and matrix.loc
        then returns a Series instead of a scalar."""
        pst_list = [
            _make_pst("pst-1", available=True, kind=RAKind.PREVENTIVE),
            _make_pst("pst-1", available=True, kind=RAKind.CURATIVE),
            _make_pst("pst-2", available=True, kind=RAKind.CURATIVE),
        ]
        result = _get_available_pst_ids_nx(pst_list)
        assert result == ["pst-1", "pst-2"]

    def test_excludes_three_winding_transformer_pst_when_network_provided(self):
        pst_list = [_make_pst("pst-2w"), _make_pst("pst-3w")]

        class FakeIndex(list):
            pass

        class FakeTwoWindingsTransformers:
            index = FakeIndex(["pst-2w"])

        class FakeNetwork:
            def get_2_windings_transformers(self):
                return FakeTwoWindingsTransformers()

        result = _get_available_pst_ids_nx(pst_list, network=FakeNetwork())
        assert result == ["pst-2w"]


# ---------------------------------------------------------------------------
# _get_available_rd_gu_ids_nx
# ---------------------------------------------------------------------------

class TestGetAvailableRdGuIdsNx:
    def test_includes_both_preventive_and_curative_deduplicated(self):
        """Given a preventive RD unit and a curative RD unit sharing the
        same generating unit, When resolving N-X RD candidates, Then the
        shared gu_mrid appears once."""
        rd_list = [
            _make_rd("rd-1", "gu-1", kind=RAKind.PREVENTIVE),
            _make_rd("rd-2", "gu-1", kind=RAKind.CURATIVE),
            _make_rd("rd-3", "gu-2", kind=RAKind.CURATIVE),
        ]
        result = _get_available_rd_gu_ids_nx(rd_list)
        assert result == ["gu-1", "gu-2"]

    def test_excludes_unavailable_rd(self):
        rd_list = [_make_rd("rd-1", "gu-1", available=False)]
        assert _get_available_rd_gu_ids_nx(rd_list) == []


# ---------------------------------------------------------------------------
# compute_sensitivity_pst_nx
# ---------------------------------------------------------------------------

class TestComputeSensitivityPstNx:
    def test_one_factor_matrix_per_side_covers_all_contingencies(self, monkeypatch):
        """Two must-study contingencies: one add_factor_matrix call (side 1 only here) with
        ContingencyContextType.ALL; each contingency's values are read with its own id."""
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [
            _make_contingency("co-1", ["eq-1"]),
            _make_contingency("co-2", ["eq-2"]),
        ]
        pst_list = [_make_pst("pst-1")]

        matrices = {
            ("nx_side1", "co-1"): pd.DataFrame([[10.0]], index=["pst-1"], columns=["b1"]),
            ("nx_side1", "co-2"): pd.DataFrame([[20.0]], index=["pst-1"], columns=["b1"]),
        }
        fake_pp = DummyPypowsyblModule(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        result = compute_sensitivity_pst_nx(
            object(), co_flat_list, pst_list, ae_flat_list, "1030Z",
            lf_nx={"co-1": {"b1": {1: 100.0}}, "co-2": {"b1": {1: 100.0}}},
            lf_initial={"b1": {1: 50.0}},
        )

        analysis = fake_pp.sensitivity.last_analysis
        assert len(analysis.add_factor_matrix_calls) == 1
        call = analysis.add_factor_matrix_calls[0]
        assert call["contingencies_ids"] == [] and call["contingency_context_type"] == "ALL"

        assert result == {
            "co-1": {("b1", "pst-1"): 10.0},
            "co-2": {("b1", "pst-1"): 20.0},
        }

    def test_value_is_raw_a_per_degree_not_converted_to_a_per_tap(self, monkeypatch):
        """The stored value is the raw TRANSFORMER_PHASE value (A/degree); the A/tap
        conversion happens in the MILP builder with pst_degrees_per_tap."""
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        pst_list = [_make_pst("pst-1")]

        matrices = {
            ("nx_side1", "co-1"): pd.DataFrame([[7.5]], index=["pst-1"], columns=["b1"]),
        }
        fake_pp = DummyPypowsyblModule(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        result = compute_sensitivity_pst_nx(
            object(), co_flat_list, pst_list, ae_flat_list, "1030Z",
            lf_nx={"co-1": {"b1": {1: 100.0}}}, lf_initial={"b1": {1: 50.0}},
        )

        assert result["co-1"][("b1", "pst-1")] == 7.5

    def test_raises_on_no_available_psts(self, monkeypatch):
        fake_pp = DummyPypowsyblModule()
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        ae_flat_list = [_make_ae("ae-1", "b1")]
        with pytest.raises(ValueError, match="PST"):
            compute_sensitivity_pst_nx(
                object(), co_flat_list, [], ae_flat_list, "1030Z",
                lf_nx={"co-1": {"b1": {1: 100.0}}}, lf_initial={"b1": {1: 50.0}},
            )


# ---------------------------------------------------------------------------
# compute_sensitivity_rd_nx
# ---------------------------------------------------------------------------

class TestComputeSensitivityRdNx:
    def test_returns_ampere_per_mw_per_contingency(self, monkeypatch):
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        rd_list = [_make_rd("rd-1", "gu-1")]

        matrices = {
            ("nx_side1", "co-1"): pd.DataFrame([[0.3]], index=["gu-1"], columns=["b1"]),
        }
        fake_pp = DummyPypowsyblModule(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        result = compute_sensitivity_rd_nx(
            object(), co_flat_list, rd_list, ae_flat_list, "1030Z",
            lf_nx={"co-1": {"b1": {1: 100.0}}}, lf_initial={"b1": {1: 50.0}},
        )

        assert result == {"co-1": {("b1", "gu-1"): 0.3}}

    def test_raises_on_no_available_rd_units(self, monkeypatch):
        fake_pp = DummyPypowsyblModule()
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        ae_flat_list = [_make_ae("ae-1", "b1")]
        with pytest.raises(ValueError, match="RD"):
            compute_sensitivity_rd_nx(
                object(), co_flat_list, [], ae_flat_list, "1030Z",
                lf_nx={"co-1": {"b1": {1: 100.0}}}, lf_initial={"b1": {1: 50.0}},
            )


# ---------------------------------------------------------------------------
# write_sensitivity_nx_csv / write_sensitivity_rd_nx_csv
# ---------------------------------------------------------------------------

class TestSensitivityNxCsvExport:
    def test_write_sensitivity_nx_csv_writes_header_and_rows(self, tmp_path):
        sensitivity_pst_nx = {"co-1": {("b1", "pst-1"): 12.5}}
        output_path = tmp_path / "sensitivity_pst_nx.csv"
        write_sensitivity_nx_csv(sensitivity_pst_nx, {"b1": 1}, {}, output_path, "1030Z")
        content = output_path.read_text(encoding="utf-8")
        assert "di_ds_ampere_per_degree" in content.splitlines()[0]
        assert "12.5" in content

    def test_write_sensitivity_rd_nx_csv_writes_header_and_rows(self, tmp_path):
        sensitivity_rd_nx = {"co-1": {("b1", "gu-1"): 0.42}}
        output_path = tmp_path / "sensitivity_rd_nx.csv"
        write_sensitivity_rd_nx_csv(sensitivity_rd_nx, {"b1": 1}, output_path, "1030Z")
        content = output_path.read_text(encoding="utf-8")
        assert "di_dp_ampere_per_mw" in content.splitlines()[0]
        assert "0.42" in content

    def test_empty_input_still_writes_header_only(self, tmp_path):
        output_path = tmp_path / "sensitivity_pst_nx.csv"
        write_sensitivity_nx_csv({}, {}, {}, output_path, "1030Z")
        content = output_path.read_text(encoding="utf-8")
        assert len(content.splitlines()) == 1


# ===========================================================================
# N-X loading threshold and sensitivity pruning filters
# ===========================================================================

class DummySensitivityAnalysis_nx_filters_and_scanned_elements:
    def __init__(self, matrices: dict):
        self._matrices = matrices

    def add_single_element_contingency(self, *a, **k):
        pass

    def add_multiple_elements_contingency(self, *a, **k):
        pass

    def add_factor_matrix(self, **kwargs):
        pass

    def run(self, network, parameters=None):
        return DummySensitivityResult(self._matrices)


class DummySensitivityModule_nx_filters_and_scanned_elements:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.ContingencyContextType = DummyContingencyContextType
        self.SensitivityFunctionType = DummySensitivityFunctionType
        self.SensitivityVariableType = DummySensitivityVariableType

    def create_ac_analysis(self):
        return DummySensitivityAnalysis_nx_filters_and_scanned_elements(self._matrices)


class DummyPypowsyblModule_nx_filters_and_scanned_elements:
    def __init__(self, sensitivity_matrices=None):
        self.sensitivity = DummySensitivityModule_nx_filters_and_scanned_elements(sensitivity_matrices or {})
        self.loadflow = type("Loadflow", (), {"Parameters": staticmethod(lambda **kwargs: dict(kwargs))})()


class TestFilter1LoadingThreshold:
    def test_branch_below_threshold_dropped_from_sensitivity_dict(self, monkeypatch):
        """Given a branch whose N-X loading (lf_nx / patl) is below
        min_loading_threshold_pct_nx, When compute_sensitivity_pst_nx
        runs, Then that (branch, contingency) pair has NO entries at all
        in the returned dict — dropped entirely, not zeroed."""
        import pandas as pd
        from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0)]  # 1000 A PATL
        co_list = [_make_contingency_nx_filters_and_scanned_elements("CO1", ["eq1"])]
        pst_list = [_make_pst_nx_filters_and_scanned_elements("PST1")]

        matrices = {
            ("nx_side1", "CO1"): pd.DataFrame([[5.0]], index=["PST1"], columns=["B1"]),
        }
        fake_pp = DummyPypowsyblModule_nx_filters_and_scanned_elements(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        lf_nx = {"CO1": {"B1": {1: 100.0}}}  # 10% loading — below a 50% threshold
        result = compute_sensitivity_pst_nx(
            object(), co_list, pst_list, ae_list, "1030Z",
            lf_nx=lf_nx, lf_initial={"B1": {1: 100.0}},
            min_loading_threshold_pct_nx=50.0,
        )

        assert result["CO1"] == {}

    def test_branch_above_threshold_kept(self, monkeypatch):
        import pandas as pd
        from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0)]
        co_list = [_make_contingency_nx_filters_and_scanned_elements("CO1", ["eq1"])]
        pst_list = [_make_pst_nx_filters_and_scanned_elements("PST1")]

        matrices = {
            ("nx_side1", "CO1"): pd.DataFrame([[5.0]], index=["PST1"], columns=["B1"]),
        }
        fake_pp = DummyPypowsyblModule_nx_filters_and_scanned_elements(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        lf_nx = {"CO1": {"B1": {1: 900.0}}}  # 90% loading — above a 50% threshold
        result = compute_sensitivity_pst_nx(
            object(), co_list, pst_list, ae_list, "1030Z",
            lf_nx=lf_nx, lf_initial={"B1": {1: 500.0}},
            min_loading_threshold_pct_nx=50.0,
        )

        assert result["CO1"] == {("B1", "PST1"): 5.0}

    def test_default_threshold_zero_is_a_no_op(self, monkeypatch):
        """Matches this codebase's established convention: default 0.0 is
        a no-op, every branch passes regardless of loading."""
        import pandas as pd
        from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0)]
        co_list = [_make_contingency_nx_filters_and_scanned_elements("CO1", ["eq1"])]
        pst_list = [_make_pst_nx_filters_and_scanned_elements("PST1")]

        matrices = {
            ("nx_side1", "CO1"): pd.DataFrame([[5.0]], index=["PST1"], columns=["B1"]),
        }
        fake_pp = DummyPypowsyblModule_nx_filters_and_scanned_elements(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        lf_nx = {"CO1": {"B1": {1: 1.0}}}  # negligible loading
        result = compute_sensitivity_pst_nx(
            object(), co_list, pst_list, ae_list, "1030Z",
            lf_nx=lf_nx, lf_initial={"B1": {1: 1.0}},
        )  # min_loading_threshold_pct_nx defaults to 0.0

        assert result["CO1"] == {("B1", "PST1"): 5.0}

    def test_scanned_branch_filtered_against_effective_limit_not_patl(self, monkeypatch):
        """Filter 1 compares a SCANNED branch against its effective limit
        (_get_monitored_branch_limits_and_ae_types), not its PATL."""
        import pandas as pd
        from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx

        # SCANNED branch: PATL 1.0 kA; lf_initial raises the effective limit above it, so a
        # loading that passes against the PATL fails against the effective limit
        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
        co_list = [_make_contingency_nx_filters_and_scanned_elements("CO1", ["eq1"])]
        pst_list = [_make_pst_nx_filters_and_scanned_elements("PST1")]

        matrices = {
            ("nx_side1", "CO1"): pd.DataFrame([[5.0]], index=["PST1"], columns=["B1"]),
        }
        fake_pp = DummyPypowsyblModule_nx_filters_and_scanned_elements(sensitivity_matrices=matrices)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        # effective limit ~2000 A (PATL 1000 A); lf_nx 1100 A is 110% of PATL but 55% of the
        # effective limit -> fails a 60% threshold only if the effective limit is used
        lf_nx = {"CO1": {"B1": {1: 1100.0}}}
        result = compute_sensitivity_pst_nx(
            object(), co_list, pst_list, ae_list, "1030Z",
            lf_nx=lf_nx, lf_initial={"B1": {1: 2000.0}},
            min_loading_threshold_pct_nx=60.0,
        )

        assert result["CO1"] == {}


# ---------------------------------------------------------------------------
# Filter 2 (sensitivity magnitude pruning)
# ---------------------------------------------------------------------------

class TestFilter2SensitivityPruning:
    def test_weak_sensitivity_pruned_but_branch_retained(self):
        """One weak and one strong PST sensitivity on a branch: the weak one is dropped, the
        branch keeps the strong one (the branch is never removed)."""
        from pre_milp.nx_sensitivity import prune_sensitivity_pst_nx

        sensitivity_pst_nx = {
            "CO1": {("B1", "PST1"): 0.5, ("B1", "PST2"): 50.0},
        }
        limit_by_branch = {"B1": 1000.0}  # patl_ampere

        result = prune_sensitivity_pst_nx(
            sensitivity_pst_nx, limit_by_branch, sensitivity_threshold_pct_pst_nx=1.0,
        )
        # threshold_ampere = 1.0 * 1000 / 100 = 10.0 -> PST1 (0.5) pruned, PST2 (50.0) kept
        assert result["CO1"] == {("B1", "PST2"): 50.0}

    def test_all_ras_pruned_leaves_branch_present_with_empty_entries(self):
        """A branch passing Filter 1 with EVERY RA pruned by Filter 2 keeps an empty
        per-contingency dict (its constraint is built from branch_limits/lf_nx)."""
        from pre_milp.nx_sensitivity import prune_sensitivity_pst_nx

        sensitivity_pst_nx = {"CO1": {("B1", "PST1"): 0.1}}
        limit_by_branch = {"B1": 1000.0}

        result = prune_sensitivity_pst_nx(
            sensitivity_pst_nx, limit_by_branch, sensitivity_threshold_pct_pst_nx=50.0,
        )
        assert result["CO1"] == {}
        assert "CO1" in result  # the contingency key itself survives

    def test_default_threshold_zero_is_a_no_op(self):
        from pre_milp.nx_sensitivity import prune_sensitivity_rd_nx

        sensitivity_rd_nx = {"CO1": {("B1", "GU1"): 0.001}}
        limit_by_branch = {"B1": 1000.0}

        result = prune_sensitivity_rd_nx(sensitivity_rd_nx, limit_by_branch, sensitivity_threshold_pct_rd_nx=0.0)
        assert result["CO1"] == {("B1", "GU1"): 0.001}

# ===========================================================================
# ALL-context factor matrices and numpy read-back = per-contingency matrices and .loc
# ===========================================================================

def _entries_by_loc(matrix):
    """Per-cell .loc read of one matrix (reference): first value for a duplicate label."""
    entries = {}
    for branch_mrid in [str(b) for b in matrix.columns]:
        for variable_mrid in [str(v) for v in matrix.index]:
            value = matrix.loc[variable_mrid, branch_mrid]
            if hasattr(value, "__len__") and not isinstance(value, str):
                value = value.iloc[0] if hasattr(value, "iloc") else value[0]
            entries[(branch_mrid, variable_mrid)] = float(value)
    return entries


def _same_entries(a, b):
    return list(a) == list(b) and all(
        (math.isnan(a[k]) and math.isnan(b[k])) or a[k] == b[k] for k in a
    )


@pytest.mark.parametrize("matrix", [
    pd.DataFrame([[1.0, 2.0], [3.0, 4.0]], index=["p1", "p2"], columns=["b1", "b2"]),
    pd.DataFrame([[1.0, float("nan")], [3.0, 4.0], [5.0, 6.0]], index=["p1", "p2", "p1"], columns=["b1", "b2"]),
    pd.DataFrame([[1.0, 2.0, 7.0], [3.0, float("nan"), 8.0]], index=["g1", "g2"], columns=["b1", "b2", "b1"]),
], ids=["plain", "duplicate_row_and_nan", "duplicate_column_and_nan"])
def test_numpy_read_back_equals_the_per_cell_loc_read(matrix, caplog):
    from pre_milp.nx_sensitivity import _matrix_entries
    with caplog.at_level(logging.WARNING):
        entries = _matrix_entries(matrix, "co-1", "compute_sensitivity_pst_nx", "PST")
    assert _same_entries(entries, _entries_by_loc(matrix))
    duplicated = matrix.index.duplicated().any() or matrix.columns.duplicated().any()
    assert any("instead of one" in r.message for r in caplog.records) == duplicated


def _per_contingency_reference(network, contingencies, branch_sides, variable_ids, variable_type):
    """The per-contingency layout (one SPECIFIC factor matrix per contingency and side), read
    with .loc: the reference for the ALL-context analysis."""
    import pypowsybl as pp
    from pre_milp.lf_parameters import build_loadflow_parameters
    from pre_milp.nx_security_analysis import _register_contingencies
    analysis = pp.sensitivity.create_ac_analysis()
    _register_contingencies(analysis, contingencies)
    function_types = {1: pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_1,
                      2: pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_2}
    matrix_ids = {}
    for contingency in contingencies:
        for side in (1, 2):
            branches = sorted(b for b, s in branch_sides.items() if s == side)
            if not branches:
                continue
            matrix_id = f"ref_{contingency.mrid}_side{side}"
            analysis.add_factor_matrix(
                functions_ids=branches, variables_ids=variable_ids, contingencies_ids=[contingency.mrid],
                contingency_context_type=pp.sensitivity.ContingencyContextType.SPECIFIC,
                sensitivity_function_type=function_types[side], sensitivity_variable_type=variable_type,
                matrix_id=matrix_id,
            )
            matrix_ids.setdefault(contingency.mrid, []).append(matrix_id)
    result = analysis.run(network, parameters=build_loadflow_parameters(False, None))
    reference = {}
    for contingency in contingencies:
        per_contingency = {}
        for matrix_id in matrix_ids.get(contingency.mrid, []):
            per_contingency.update(_entries_by_loc(result.get_sensitivity_matrix(matrix_id, contingency.mrid)))
        reference[contingency.mrid] = per_contingency
    return reference


def _all_pairs_inputs(branches, contingencies, sides):
    ae_flat_list = [_make_ae(f"ae-{b}", b, branch_side=sides[b]) for b in branches]
    lf_nx = {c.mrid: {b: {1: 1.0, 2: 1.0} for b in branches} for c in contingencies}
    lf_initial = {b: {1: 1.0, 2: 1.0} for b in branches}
    return ae_flat_list, lf_nx, lf_initial


def test_all_context_rd_sensitivities_equal_the_per_contingency_matrices_on_ieee14():
    """IEEE 14: every line as a contingency, branches on side 1 and side 2, every generator."""
    import pypowsybl as pp
    from pre_milp.nx_sensitivity import compute_sensitivity_rd_nx
    network = pp.network.create_ieee14()
    lines = list(network.get_lines().index)
    branches = lines + list(network.get_2_windings_transformers().index)
    sides = {b: (2 if i % 3 == 0 else 1) for i, b in enumerate(branches)}
    contingencies = sorted((_make_contingency(f"co-{line}", [line]) for line in lines), key=lambda c: c.mrid)
    generators = list(network.get_generators().index)
    rd_list = [_make_rd(f"rd-{g}", g) for g in generators]
    ae_flat_list, lf_nx, lf_initial = _all_pairs_inputs(branches, contingencies, sides)

    new = compute_sensitivity_rd_nx(network, contingencies, rd_list, ae_flat_list, "1030Z",
                                    lf_nx=lf_nx, lf_initial=lf_initial)
    reference = _per_contingency_reference(network, contingencies, sides, sorted(generators),
                                           pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER)
    assert list(new) == list(reference)
    for contingency_mrid in reference:
        assert _same_entries(new[contingency_mrid], reference[contingency_mrid]), contingency_mrid


def test_all_context_pst_sensitivities_equal_the_per_contingency_matrices_on_the_fixture_network():
    """The fixture CGM (it has phase shifters): TRANSFORMER_PHASE variables, side 1 and side 2."""
    import pypowsybl as pp
    from helpers import FIXTURE_CGM_ZIP
    from pre_milp import cgmes_loader
    from pre_milp.nx_sensitivity import compute_sensitivity_pst_nx, _get_available_pst_ids_nx
    network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
    cgmes_loader.run_initial_loadflow(network)
    lines = list(network.get_lines().index)
    branches = lines[:40]
    sides = {b: (2 if i % 4 == 0 else 1) for i, b in enumerate(branches)}
    contingencies = sorted((_make_contingency(f"co-{line}", [line]) for line in lines[:12]), key=lambda c: c.mrid)
    pst_list = [_make_pst(str(t)) for t in network.get_phase_tap_changers().index]
    pst_ids = _get_available_pst_ids_nx(pst_list, network=network)
    assert pst_ids
    ae_flat_list, lf_nx, lf_initial = _all_pairs_inputs(branches, contingencies, sides)

    new = compute_sensitivity_pst_nx(network, contingencies, pst_list, ae_flat_list, "1030Z",
                                     lf_nx=lf_nx, lf_initial=lf_initial)
    reference = _per_contingency_reference(network, contingencies, sides, pst_ids,
                                           pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE)
    assert list(new) == list(reference)
    for contingency_mrid in reference:
        assert _same_entries(new[contingency_mrid], reference[contingency_mrid]), contingency_mrid

# ===========================================================================
# PST and RD N-X sensitivities from one analysis = two separate analyses
# ===========================================================================

def _ieee14_with_phase_shifters():
    import pypowsybl as pp
    network = pp.network.create_ieee14()
    transformers = ["T4-7-1", "T4-9-1"]
    ptc = pd.DataFrame(index=pd.Series(name="id", data=transformers),
                       columns=["target_deadband", "regulation_mode", "low_tap", "tap"],
                       data=[[0, "CURRENT_LIMITER", 0, 1]] * 2)
    steps = pd.DataFrame(index=pd.Series(name="id", data=[t for t in transformers for _ in range(3)]),
                         columns=["b", "g", "r", "x", "rho", "alpha"],
                         data=[[0, 0, 0, 0, 1, a] for _ in transformers for a in (-5, 0, 5)])
    network.create_phase_tap_changers(ptc, steps)
    return network


def _fixture_network():
    from helpers import FIXTURE_CGM_ZIP
    from pre_milp import cgmes_loader
    network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
    cgmes_loader.run_initial_loadflow(network)
    return network


def _combined_and_separate(network, branches, contingency_lines, with_pst, with_rd):
    from pre_milp.nx_sensitivity import compute_sensitivities_nx
    sides = {b: (2 if i % 3 == 0 else 1) for i, b in enumerate(branches)}
    contingencies = sorted((_make_contingency(f"co-{line}", [line]) for line in contingency_lines),
                           key=lambda c: c.mrid)
    pst_list = [_make_pst(str(t)) for t in network.get_phase_tap_changers().index]
    rd_list = [_make_rd(f"rd-{g}", g) for g in list(network.get_generators().index)[:30]]
    ae_flat_list, lf_nx, lf_initial = _all_pairs_inputs(branches, contingencies, sides)
    common = dict(lf_nx=lf_nx, lf_initial=lf_initial)

    guards, references = ({}, {}), ({}, {})
    combined = compute_sensitivities_nx(
        network, contingencies, pst_list, rd_list, ae_flat_list, "1030Z", **common,
        with_pst=with_pst, with_rd=with_rd, pst_guard_out=guards[0], rd_guard_out=guards[1],
        pst_reference_out=references[0], rd_reference_out=references[1],
    )
    separate_guards, separate_references = ({}, {}), ({}, {})
    separate = (
        compute_sensitivity_pst_nx(network, contingencies, pst_list, ae_flat_list, "1030Z", **common,
                                   guard_out=separate_guards[0], reference_out=separate_references[0])
        if with_pst else {},
        compute_sensitivity_rd_nx(network, contingencies, rd_list, ae_flat_list, "1030Z", **common,
                                  guard_out=separate_guards[1], reference_out=separate_references[1])
        if with_rd else {},
    )
    return combined, separate, (guards, references), (separate_guards, separate_references)


def _assert_same_guards_and_references(a, b):
    """Guard results equal; reference currents equal per contingency (NaN equals NaN)."""
    (guards_a, references_a), (guards_b, references_b) = a, b
    assert guards_a == guards_b
    for kind in (0, 1):
        assert list(references_a[kind]) == list(references_b[kind])
        for contingency_mrid, per_branch in references_a[kind].items():
            assert _same_entries(per_branch, references_b[kind][contingency_mrid]), contingency_mrid


def _assert_same_sensitivities(a, b):
    assert list(a) == list(b)
    for contingency_mrid in a:
        assert _same_entries(a[contingency_mrid], b[contingency_mrid]), contingency_mrid


@pytest.mark.parametrize("with_pst, with_rd", [(True, True), (True, False), (False, True)])
def test_one_analysis_for_pst_and_rd_equals_two_analyses_on_ieee14(with_pst, with_rd):
    network = _ieee14_with_phase_shifters()
    lines = list(network.get_lines().index)
    branches = lines + list(network.get_2_windings_transformers().index)
    combined, separate, combined_out, separate_out = _combined_and_separate(
        network, branches, lines, with_pst, with_rd,
    )
    for kind in (0, 1):
        _assert_same_sensitivities(combined[kind], separate[kind])
    _assert_same_guards_and_references(combined_out, separate_out)


def test_one_analysis_for_pst_and_rd_equals_two_analyses_on_the_fixture_network():
    network = _fixture_network()
    lines = list(network.get_lines().index)
    combined, separate, combined_out, separate_out = _combined_and_separate(
        network, lines[:40], lines[:12], True, True,
    )
    assert combined[0] and combined[1]
    for kind in (0, 1):
        _assert_same_sensitivities(combined[kind], separate[kind])
    _assert_same_guards_and_references(combined_out, separate_out)
