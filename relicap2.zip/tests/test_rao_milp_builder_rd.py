"""tests/test_rao_milp_builder_rd.py - tests for the RD blocks of milp_builder.py.

Sections: preventive and curative RD blocks, RD availability, curative RD cost, curative RD lead time, curative RD without preventive RD.
"""

import sys
import pyomo.environ as pyo
import pytest

from pathlib import Path
from data_model import (
    AcVerificationStatus,
    AEType,
    AssessedElement,
    BidDirection,
    PST,
    PowerBid,
    RAKind,
    RDUnit,
)
from milp.milp_builder import (
    PstMilpInputs,
    RdMilpInputs,
    build_n0_milp_model,
    NxMilpInputs,
    _compute_radp,
    _timestamp_is_usable,
    _compute_earliest_usable_timestamp,
)
from helpers import (
    _bid_rd_cost as _bid,
    _unit,
    _make_ae,
    BIDS,
    PENALTY_FACTOR,
    REFERENCE as REFERENCE_curative_rd_cost,
    _solved_model,
)

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_costs(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_costs(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_costs(mrid: str, gu_mrid: str, tso: str = "TestTSO", penalty_factor: float = 1.0) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=penalty_factor,
    )


def _make_bid_costs(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict, price_eur_mw: float = 10.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_pst_only_has_no_rd_cost_terms():
    """Given a PST-only workflow, When the model is built, Then no RD cost
    terms exist (structurally confirmed via absence of rd_volume_upward)."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_costs("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")


def test_rd_empty_glsk_guard_has_no_rd_cost_terms():
    """RD inputs with the empty-GLSK guard firing: no RD cost terms."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_costs("RA1", "GU1")],
        bid_list=[_make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        penalty_reference_rd_pra=5.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")


def test_cheaper_bid_preferred_when_both_resolve_the_same_congestion():
    """Two RD units relieving the same branch equally, at 10 and 20 EUR/MW: a real solve
    prefers the cheaper bid. GU3 (zero sensitivity, zero cost) is the balancing partner."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_costs("RA_CHEAP", "GU_CHEAP"),
            _make_rd_unit_costs("RA_EXPENSIVE", "GU_EXPENSIVE"),
            _make_rd_unit_costs("RA_BALANCE", "GU_BALANCE"),
        ],
        bid_list=[
            _make_bid_costs("BID_CHEAP", "RA_CHEAP", BidDirection.UP, {"1030Z": 30.0}, price_eur_mw=10.0),
            _make_bid_costs("BID_EXPENSIVE", "RA_EXPENSIVE", BidDirection.UP, {"1030Z": 30.0}, price_eur_mw=20.0),
            _make_bid_costs("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 60.0}, price_eur_mw=0.0),
        ],
        glsk={"RA_CHEAP": {"GU_CHEAP": 1.0}, "RA_EXPENSIVE": {"GU_EXPENSIVE": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        # GU_CHEAP and GU_EXPENSIVE have IDENTICAL sensitivity to BRANCH1, only the price
        # differs; GU_BALANCE has none (pure balancing partner)
        sensitivity_rd_n0_pruned={
            ("BRANCH1", "GU_CHEAP"): -10.0,
            ("BRANCH1", "GU_EXPENSIVE"): -10.0,
        },
        generator_data={
            "GU_CHEAP": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_CHEAP"},
            "GU_EXPENSIVE": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_EXPENSIVE"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        penalty_reference_rd_pra=0.0,  # isolate price effect — no penalty component
    )

    # 1050 A against 1000 A PATL -> 50 A overload; either unit alone could
    # supply the needed 5 MW (10 A/MW), so the solver has a genuine choice.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    cheap_volume = pyo.value(model.rd_volume_upward["BID_CHEAP"])
    expensive_volume = pyo.value(model.rd_volume_upward["BID_EXPENSIVE"])

    assert cheap_volume >= 5.0 - 1e-6  # cheap bid fully dispatched to clear the overload
    assert expensive_volume < 1e-6      # expensive bid left untouched


def test_extract_rd_results_writes_empty_csv_when_rd_inert(tmp_path):
    """A model without RD components (empty-GLSK guard): extract_rd_results still creates the
    CSV, header row only."""
    from post_milp.n0_results_export import extract_rd_results

    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_costs("RA1", "GU1")],
        bid_list=[_make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},  # empty-GLSK guard fires
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    assert not hasattr(model, "rd_volume_upward")  # confirm guard fired

    output_path = tmp_path / "results_preventive_rd.csv"
    result = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=100.0, timestamp="1030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists(), "results_preventive_rd.csv must be written even when RD is inert"
    with open(output_path) as f:
        header = f.readline().strip()
    assert "ra_mrid" in header  # header row present, even with zero data rows


def test_rd_penalty_factor_and_per_tso_override_affect_extracted_cost():
    """Given a bid with rd_penalty_factor=2.0 on an RA whose TSO has a
    penalty_reference_rd_pra_per_tso override, When the model is solved and
    results are extracted via extract_rd_results, Then the extracted
    penalty_cost_eur reflects the RA-level penalty_factor and the
    TSO-specific override — not the PowerBid-level penalty_factor (a
    different field, unused here) and not the global default."""
    from post_milp.n0_results_export import extract_rd_results

    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_costs("RA1", "GU1", tso="TSO-Special", penalty_factor=2.0),
            _make_rd_unit_costs("RA2", "GU2", tso="TSO-Special"),  # balancing partner
        ],
        bid_list=[
            # bid caps EXACTLY match the 3 MW needed: one deterministic optimal dispatch
            _make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 3.0}, price_eur_mw=0.0),
            _make_bid_costs("BID2", "RA2", BidDirection.DOWN, {"1030Z": 3.0}, price_eur_mw=0.0),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},  # GU2: no entry, 0 sensitivity
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
        penalty_reference_rd_pra=100.0,  # global default -- should NOT be used
        penalty_reference_rd_pra_per_tso={"TSO-Special": 5.0},  # should be used instead
    )

    # 1030 A against 1000 A PATL -> 30 A overload -> exactly 3 MW needed
    # (10 A/MW), matching BID1's 3.0 MW cap exactly.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1030.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    rd_results = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=rd_inputs.penalty_reference_rd_pra,
        penalty_reference_rd_pra_per_tso=rd_inputs.penalty_reference_rd_pra_per_tso,
        timestamp="1030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "BID1" in rd_results
    assert abs(rd_results["BID1"]["rd_volume_net_mw"] - 3.0) < 1e-6
    # penalty_factor(2.0) * per_tso_override(5.0) * volume(3.0) = 30.0 --
    # NOT penalty_reference_rd_pra(100.0), confirming the override is used.
    expected_penalty_cost = 2.0 * 5.0 * 3.0
    assert abs(rd_results["BID1"]["penalty_cost_eur"] - expected_penalty_cost) < 1e-6


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_balancing(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_balancing(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_balancing(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_balancing(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_pst_only_has_no_balancing_constraint():
    """Given a PST-only workflow, When the model is built, Then no
    rd_balancing_n0 constraint is added."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_balancing("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "rd_balancing_n0")


def test_rd_empty_glsk_guard_has_no_balancing_constraint():
    """Given RD inputs are provided but the empty-GLSK guard fires (no
    rd_net_injection_g on the model), When the model is built, Then no
    rd_balancing_n0 constraint is added — hasattr(model,
    'rd_net_injection_g') correctly gates this even though rd_inputs
    itself is not None."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1")],
        bid_list=[_make_bid_balancing("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},  # real dataset shape: empty participation
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_net_injection_g")
    assert not hasattr(model, "rd_balancing_n0")


def test_rd_only_balancing_constraint_exists_and_holds_when_solved():
    """RD-only model with GU1 (on the overloaded branch) and GU2 (no sensitivity entry):
    rd_balancing_n0 exists, GU1 resolves the branch and |sum(rd_net_injection_g)| < 0.01 MW,
    so GU2 moves opposite GU1 only to balance."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1"), _make_rd_unit_balancing("RA2", "GU2")],
        bid_list=[
            _make_bid_balancing("BID_UP_1", "RA1", BidDirection.UP, {"1030Z": 30.0}),
            _make_bid_balancing("BID_DOWN_2", "RA2", BidDirection.DOWN, {"1030Z": 30.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        # GU2 has NO sensitivity entry (0.0 via .get() in rd_effect_on_branch): it affects only
        # the balance sum
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # Overloaded by 50 A -> needs 5 MW upward from GU1 to clear.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "rd_balancing_n0")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    net_gu1 = pyo.value(model.rd_net_injection_g["GU1"])
    net_gu2 = pyo.value(model.rd_net_injection_g["GU2"])

    assert net_gu1 >= 5.0 - 1e-6  # GU1 dispatched enough to clear the branch
    assert abs(net_gu1 + net_gu2) < 0.01  # balancing forces GU2 to offset GU1
    assert abs(net_gu2 - (-net_gu1)) < 1e-6  # GU2 moved opposite, purely to balance

    overload_1 = pyo.value(model.overload_slack_n0["BRANCH1"])
    assert overload_1 < 1e-6


def test_pst_and_rd_together_balancing_constraint_only_covers_rd():
    """Given a PST+RD workflow, When the model is built, Then
    rd_balancing_n0 exists and sums only over gu_ids (RD generating units),
    not PST taps — PST is entirely absent from this constraint's terms."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_balancing("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -5.0},
        pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
    )
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1")],
        bid_list=[_make_bid_balancing("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "rd_balancing_n0")
    balancing_expr_vars = {v.name for v in model.rd_balancing_n0.body.args} if hasattr(model.rd_balancing_n0.body, "args") else set()
    # the balancing constraint has no tap terms: one (RD-scoped) balancing constraint even
    # with PST present
    assert len(list(model.component_objects(pyo.Constraint))) >= 1
    assert "rd_balancing_n0" in [c.name for c in model.component_objects(pyo.Constraint)]


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


REPO_ROOT = Path(__file__).resolve().parents[1]


def _make_ae_r36(branch_mrid: str, side: int = 1, patl_ka: float = 1.0,
             ae_type=AEType.SECURED, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_rd_unit_r36(mrid: str, gu_mrid: str, kind=RAKind.PREVENTIVE,
                   linked_contingency_mrids=None, linked_xne_mrids=None) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=linked_contingency_mrids or [],
        linked_xne_mrids=linked_xne_mrids or [],
    )


def _make_bid_r36(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


# ---------------------------------------------------------------------------
# _add_rd_block — preventive-filter correction
# ---------------------------------------------------------------------------

def test_add_rd_block_excludes_curative_bids_from_preventive_variables():
    """A preventive and a curative RD unit/bid with the same GLSK, rd_inputs only (no
    nx_inputs): preventive rd_volume_upward/downward exist only for the preventive bid."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_r36("RD1", "GU1", kind=RAKind.PREVENTIVE),
            _make_rd_unit_r36("RD2", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"]),
        ],
        bid_list=[
            _make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 50.0}),
            _make_bid_r36("BID2", "RD2", BidDirection.UP, {"1030Z": 30.0}),
        ],
        glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): 0.3},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert list(model.bid_ids) == ["BID1"]
    assert "BID2" not in list(model.bid_ids)


# ---------------------------------------------------------------------------
# Curative RD MILP block — synthetic
# ---------------------------------------------------------------------------

def _base_rd_inputs_r36(kind=RAKind.CURATIVE, linked_contingency_mrids=None, target_p=50.0):
    return RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=kind, linked_contingency_mrids=linked_contingency_mrids or ["CO1"])],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": target_p, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )


def test_curative_rd_gated_independently_of_preventive_rd_success():
    """rd_inputs with ONLY a curative bid (_add_rd_block's empty-bid guard returns False) and
    nx_inputs: the curative RD variables still exist (gated only on rd_inputs)."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = _base_rd_inputs_r36()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")  # preventive block never fired (no preventive bids)
    assert hasattr(model, "curative_rd_volume_upward")
    assert ("BID1", "CO1") in list(model.curative_bid_contingency_pairs)


def test_generator_not_in_operation_fixes_curative_volume_to_zero():
    """A curative RD unit with target_p == 0 at this timestamp: curative_rd_volume_upward == 0
    in every contingency."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = _base_rd_inputs_r36(target_p=0.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert model.curative_rd_volume_upward["BID1", "CO1"].fixed
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"]) == 0.0
    assert model.curative_rd_volume_downward["BID1", "CO1"].fixed


def test_generator_in_operation_allows_activation_up_to_bid_bound():
    """The second half of the same acceptance criteria: a unit with
    initial_production > 0 CAN be activated curatively up to its
    max_curative_rd_volume_upward (here, the bid's own available_mw)."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0)]
    rd_inputs = _base_rd_inputs_r36(target_p=50.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},  # 50A overload
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},  # A per MW
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert not model.curative_rd_volume_upward["BID1", "CO1"].fixed
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == 40.0  # bid's available_mw

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    # 5 MW * 10 A/MW = 50A clears the overload; bounded by 40 MW available.
    curative_volume = pyo.value(model.curative_rd_volume_upward["BID1", "CO1"])
    assert curative_volume > 0.0
    assert curative_volume <= 40.0 + 1e-6
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_max_curative_rd_volume_bounds_across_contingencies():
    """One bid linked to two contingencies needing different curative volumes:
    max_curative_rd_volume_upward is at least the larger of the two (a max, not a sum)."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1", "CO2"])],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={
            "CO1": {"BRANCH1": {1: 1050.0}},  # needs 5 MW
            "CO2": {"BRANCH1": {1: 1020.0}},  # needs 2 MW
        },
        sensitivity_pst_nx={},
        sensitivity_rd_nx={
            "CO1": {("BRANCH1", "GU1"): -10.0},
            "CO2": {("BRANCH1", "GU1"): -10.0},
        },
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    volume_co1 = pyo.value(model.curative_rd_volume_upward["BID1", "CO1"])
    volume_co2 = pyo.value(model.curative_rd_volume_upward["BID1", "CO2"])
    max_volume = pyo.value(model.max_curative_rd_volume_upward["BID1"])

    assert max_volume >= volume_co1 - 1e-6
    assert max_volume >= volume_co2 - 1e-6
    assert volume_co1 >= 5.0 - 1e-6
    assert volume_co2 >= 2.0 - 1e-6


def test_combined_pmax_pmin_respects_preventive_plus_curative():
    """A preventive and a curative bid on one generating unit: the COMBINED preventive +
    curative injection respects Pmax."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0), _make_ae_r36("BRANCH2", patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_r36("RD1", "GU1", kind=RAKind.PREVENTIVE),
            _make_rd_unit_r36("RD2", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"]),
        ],
        bid_list=[
            _make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0}),
            _make_bid_r36("BID2", "RD2", BidDirection.UP, {"1030Z": 40.0}),
        ],
        glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH2", "GU1"): 0.0},
        generator_data={"GU1": {"target_p": 90.0, "max_p": 100.0, "min_p": 0.0}},  # only 10 MW headroom
        penalty_reference_rd_pra=0.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1200.0}}},  # wants a LOT of curative help
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}, "BRANCH2": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    preventive_volume = pyo.value(model.rd_volume_upward["BID1"])
    curative_volume = pyo.value(model.curative_rd_volume_upward["BID2", "CO1"])
    # Combined injection must not exceed the 10 MW headroom to max_p=100:
    assert preventive_volume + curative_volume <= 10.0 + 1e-6


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_leadtime(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_rd_unit_leadtime(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_leadtime(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict,
              price_eur_mw: float = 0.0, lead_time_h: float = 0.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=lead_time_h,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


# ---------------------------------------------------------------------------
# Time-arithmetic helpers
# ---------------------------------------------------------------------------

def test_compute_radp_uses_raart_directly_when_given():
    """Given raart is provided, When radp is computed, Then radp = raart
    exactly, per the spec's own acceptance-criteria example."""
    assert _compute_radp("2200Z", "0030Z") == "2200Z"


def test_compute_radp_defaults_to_one_hour_before_timestamp():
    """raart None: radp is one hour before `timestamp` (hourly timestamp list)."""
    assert _compute_radp(None, "1030Z") == "0930Z"


def test_compute_radp_default_wraps_across_midnight():
    """Given raart is None and timestamp is close to midnight, When radp
    is computed, Then day wraparound is handled correctly."""
    assert _compute_radp(None, "0030Z") == "2330Z"


def test_timestamp_usable_spec_confirmed_boundary_example():
    """RADP=23:30, lead_time=3h -> cutoff 02:30, exactly on the 0230Z boundary -> 0230Z is
    blocked, the first usable timestamp is 0330Z."""
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]
    radp = "2330Z"
    lead = 3.0

    results = {t: _timestamp_is_usable(radp, lead, t) for t in timestamp_list}
    assert results == {"0030Z": False, "0130Z": False, "0230Z": False, "0330Z": True}
    assert _compute_earliest_usable_timestamp(radp, lead, timestamp_list) == "0330Z"


def test_timestamp_usable_second_confirmed_example():
    """RADP=22:00, lead_time=3h -> cutoff 01:00 (not on a boundary) -> the first timestamp
    strictly after it is 0130Z."""
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]
    radp = "2200Z"
    lead = 3.0

    assert _timestamp_is_usable(radp, lead, "0030Z") is False
    assert _timestamp_is_usable(radp, lead, "0130Z") is True
    assert _compute_earliest_usable_timestamp(radp, lead, timestamp_list) == "0130Z"


def test_earliest_usable_timestamp_none_when_lead_time_exceeds_list():
    """Given a lead time so long that no timestamp in the list is usable,
    When earliest usable timestamp is computed, Then it returns None
    rather than raising or returning a bogus value."""
    timestamp_list = ["0030Z", "0130Z"]
    result = _compute_earliest_usable_timestamp("0030Z", 100.0, timestamp_list)
    assert result is None


def test_zero_lead_time_is_usable_at_any_timestamp_strictly_after_radp():
    """bid_lead_time_hours=0: usable at any timestamp STRICTLY after radp; a timestamp equal
    to radp is not usable."""
    assert _timestamp_is_usable("0030Z", 0.0, "0030Z") is False
    assert _timestamp_is_usable("0030Z", 0.0, "0130Z") is True


# ---------------------------------------------------------------------------
# MILP-level: bounds actually tightened for the single build_n0_milp_model timestamp
# ---------------------------------------------------------------------------

def test_bid_with_unmet_lead_time_gets_zero_upper_bounds():
    """A bid whose lead time is not met at the model's `timestamp`: both upper bounds are 0.0,
    whatever its available_mw."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0230Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            # lead_time_h=3, raart="2330Z" (fixed via RdMilpInputs.raart) ->
            # at timestamp="0230Z", cutoff falls exactly on 0230Z -> blocked.
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0230Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0230Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    model = build_n0_milp_model(
        ae_list, "0230Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 0.0
    assert model.rd_volume_downward["BID1"].ub == 0.0


def test_bid_with_met_lead_time_keeps_available_mw_bound():
    """Given a bid whose lead time IS satisfied by the model's own
    `timestamp`, When the model is built, Then its upper bound remains
    the normal available_mw-derived bound, unaffected by lead time logic."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0330Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            # same lead_time_h=3, raart="2330Z", timestamp="0330Z": strictly after the 02:30
            # cutoff -> usable
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0330Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0330Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    model = build_n0_milp_model(
        ae_list, "0330Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 20.0
    assert model.rd_volume_downward["BID1"].ub == 0.0


def test_bid_with_no_lead_time_is_unaffected():
    """A bid with lead_time_h=0 (default): bounds come from available_mw only."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1")],
        bid_list=[_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}, lead_time_h=0.0)],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 20.0


def test_solved_model_respects_lead_time_bound():
    """A bid blocked by lead time and a balancing partner: solved, the blocked bid dispatches
    0.0 and does not resolve the overload."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0230Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0230Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0230Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    # 50 A overload -> 5 MW needed; BID1 could supply it but is blocked.
    model = build_n0_milp_model(
        ae_list, "0230Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    assert pyo.value(model.rd_volume_upward["BID1"]) == 0.0
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) > 1e-6  # unresolved, as expected


# ---------------------------------------------------------------------------
# extract_lead_time_results
# ---------------------------------------------------------------------------

def test_extract_lead_time_results_empty_bid_list_writes_header_only_csv(tmp_path):
    """Given bid_list is empty, When extract_lead_time_results is called
    with an output_path, Then it returns {} AND still writes a
    header-only CSV."""
    from post_milp.n0_results_export import extract_lead_time_results

    output_path = tmp_path / "results_lead_times.csv"
    result = extract_lead_time_results(
        bid_list=[], timestamp_list=["0030Z", "0130Z"], timestamp="0030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists()
    with open(output_path) as f:
        header = f.readline().strip()
    assert "bid_mrid" in header


def test_extract_lead_time_results_reports_confirmed_spec_example():
    """radp=23:30 via raart, lead_time=3h: earliest_usable_timestamp is 0330Z, as
    _compute_earliest_usable_timestamp."""
    from post_milp.n0_results_export import extract_lead_time_results

    bid_list = [_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0330Z": 20.0}, lead_time_h=3.0)]
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]

    results = extract_lead_time_results(
        bid_list=bid_list, timestamp_list=timestamp_list, raart="2330Z", timestamp="0030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert results["BID1"]["radp"] == "2330Z"
    assert results["BID1"]["bid_lead_time_hours"] == 3.0
    assert results["BID1"]["earliest_usable_timestamp"] == "0330Z"


def test_extract_lead_time_results_zero_lead_time_bid_reported_too():
    """Given a bid with no lead time restriction, When results are
    extracted, Then it is still reported (not omitted), consistent with
    the 'report everything, not just restricted bids' convention."""
    from post_milp.n0_results_export import extract_lead_time_results

    bid_list = [_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0030Z": 20.0}, lead_time_h=0.0)]
    timestamp_list = ["0030Z", "0130Z"]

    results = extract_lead_time_results(
        bid_list=bid_list, timestamp_list=timestamp_list, raart="0030Z", timestamp="0030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "BID1" in results
    assert results["BID1"]["bid_lead_time_hours"] == 0.0


# ===========================================================================
# RD availability
# ===========================================================================

REFERENCE = 10.0


def _units_and_bids(kind, off_available=False):
    """RD_OFF is the CHEAPER one (price 1) but unavailable; RD_OK costs 50."""
    rd_list, bid_list, glsk, generator_data = [], [], {}, {}
    for suffix, price, available in (("OK", 50.0, True), ("OFF", 1.0, off_available)):
        unit = _unit(f"RD_{suffix}", f"GU_{suffix}")
        unit.kind = kind
        unit.available = available
        rd_list.append(unit)
        bid_list.append(_bid(f"BID_{suffix}", f"RD_{suffix}", BidDirection.UP, price))
        glsk[f"RD_{suffix}"] = {f"GU_{suffix}": 1.0}   # the unavailable unit HAS a GLSK entry here
        generator_data[f"GU_{suffix}"] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
    return rd_list, bid_list, glsk, generator_data


def _solve(model):
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def _preventive_model(off_available=False, **rd_kwargs):
    """N-0: BRANCH1 overloaded by 10 A; each MW up on either unit gives -1 A."""
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.PREVENTIVE, off_available)
    # preventive RD must balance: a free-priced DOWN unit with no effect on the branch
    down_unit = _unit("RD_DN", "GU_DN")
    down_unit.kind = RAKind.PREVENTIVE
    rd_list.append(down_unit)
    bid_list.append(_bid("BID_DN", "RD_DN", BidDirection.DOWN, 0.0))
    glsk["RD_DN"] = {"GU_DN": 1.0}
    generator_data["GU_DN"] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned={("BRANCH1", "GU_OK"): -1.0, ("BRANCH1", "GU_OFF"): -1.0},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE, **rd_kwargs,
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 1010.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs,
    )


def _curative_model(off_available=False):
    """N-X: BRANCH1 overloaded by 10 A under CO1; each MW up gives -1 A."""
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.CURATIVE, off_available)
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1010.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_OK"): -1.0, ("BRANCH1", "GU_OFF"): -1.0}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )


# ---- preventive --------------------------------------------------------------

def test_available_cheaper_unit_is_used_control_case():
    model = _solve(_preventive_model(off_available=True))
    assert pyo.value(model.rd_volume_upward["BID_OFF"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx((10.0 + 1.0) * 10.0 + 10.0 * 10.0, abs=1e-6)


def test_unavailable_preventive_rd_gets_no_bid_variables_and_no_cost():
    """An unavailable (cheaper) unit's bid gets no variables: the available unit at 60 EUR/MW
    is dispatched, not the unavailable one at 11."""
    model = _solve(_preventive_model())
    assert sorted(model.bid_ids) == ["BID_DN", "BID_OK"]
    assert pyo.value(model.rd_volume_upward["BID_OK"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx((10.0 + 50.0) * 10.0 + 10.0 * 10.0, abs=1e-6)


def test_unavailable_preventive_rd_has_no_ra_count_variable():
    """ra_activated (and so the TSO's RA count) does not include the unavailable RA."""
    model = _preventive_model(max_ra_count_per_timestamp_tso={"TestTSO": 5})
    assert sorted(model.ra_mrids) == ["RD_DN", "RD_OK"]


def test_unavailable_preventive_rd_is_not_in_the_group_volume_limit():
    """The group cap does not sum the unavailable unit's bid."""
    model = _preventive_model(
        ra_groups={"GROUP1": {"ra_mrids": ["RD_OK", "RD_OFF"], "max_regulating_up": 100.0,
                              "max_regulating_down": None}},
    )
    (constraint,) = [c for c in model.ra_group_volume_upward_limit.values()]
    assert "BID_OFF" not in str(constraint.body) and "BID_OK" in str(constraint.body)


# ---- curative ----------------------------------------------------------------

def test_available_cheaper_curative_unit_is_used_control_case():
    model = _solve(_curative_model(off_available=True))
    assert pyo.value(model.curative_rd_volume_upward["BID_OFF", "CO1"]) == pytest.approx(10.0, abs=1e-6)


def test_unavailable_curative_rd_gets_no_variables_and_no_cost():
    """An unavailable curative bid gets no variables (it would relieve the overload at 11
    EUR/MW instead of 60)."""
    model = _solve(_curative_model())
    assert sorted(model.curative_bid_contingency_pairs) == [("BID_OK", "CO1")]
    assert list(model.bid_ids_curative) == ["BID_OK"]
    assert pyo.value(model.objective) == pytest.approx((10.0 + 50.0) * 10.0, abs=1e-6)


def test_curative_block_absent_when_the_only_curative_unit_is_unavailable():
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.CURATIVE)
    rd_list, bid_list = rd_list[1:], bid_list[1:]          # only RD_OFF (unavailable)
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1010.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_OFF"): -1.0}}, penalty_cost_overload_nx_patl=1000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert not hasattr(model, "curative_bid_contingency_pairs")


# ===========================================================================
# Curative RD cost
# ===========================================================================

# (bid, direction, price EUR/MW, MW needed in CO1, MW needed in CO2)
# The binding contingency differs inside each direction, so dropping ANY max-linking row
# changes the optimum.


def test_curative_rd_cost_uses_own_price_and_max_over_contingencies():
    model = _solved_model()
    expected_cost = 0.0
    for bid_mrid, direction, price, need_co1, need_co2 in BIDS:
        active = (model.max_curative_rd_volume_upward if direction == BidDirection.UP
                  else model.max_curative_rd_volume_downward)
        assert pyo.value(active[bid_mrid]) == pytest.approx(max(need_co1, need_co2), abs=1e-6), bid_mrid
        expected_cost += (PENALTY_FACTOR * REFERENCE_curative_rd_cost + price) * max(need_co1, need_co2)
    assert expected_cost == pytest.approx(240 + 320 + 420 + 350)
    assert pyo.value(model.objective) == pytest.approx(expected_cost, abs=1e-6)


def test_curative_rd_inactive_direction_contributes_zero():
    model = _solved_model()
    for bid_mrid, direction, *_ in BIDS:
        inactive = (model.max_curative_rd_volume_downward if direction == BidDirection.UP
                    else model.max_curative_rd_volume_upward)
        assert pyo.value(inactive[bid_mrid]) == pytest.approx(0.0, abs=1e-9), bid_mrid


# ===========================================================================
# Curative RD lead time
# ===========================================================================

AVAILABLE_MW = 40.0


def _model(lead_time_h, raart=None, direction=BidDirection.UP):
    unit = RDUnit(
        mrid="RD1", name="RD1", tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=True,
        kind=RAKind.CURATIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )
    bid = PowerBid(
        mrid="BID1", ra_mrid="RD1", direction=direction, available_mw={"1030Z": AVAILABLE_MW},
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=lead_time_h,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )
    rd_inputs = RdMilpInputs(
        rd_list=[unit], bid_list=[bid], glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0, raart=raart,
    )
    sign = -10.0 if direction == BidDirection.UP else 10.0
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},  # 50 A over PATL
        sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): sign}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    return model


def _solve_curative_rd_lead_time(model):
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"


def test_blocked_timestamp_forces_curative_volumes_to_zero():
    """raart 1000Z + 3 h = 1300Z > 1030Z -> blocked: both curative bounds are 0 and the model
    does not use the bid (available_mw is 40)."""
    model = _model(lead_time_h=3.0, raart="1000Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == 0.0
    assert pyo.value(model.curative_rd_volume_downward["BID1", "CO1"].ub) == 0.0
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    # the blocked bid cannot relieve the overload
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_blocked_down_bid_is_also_forced_to_zero():
    model = _model(lead_time_h=3.0, raart="1000Z", direction=BidDirection.DOWN)
    assert pyo.value(model.curative_rd_volume_downward["BID1", "CO1"].ub) == 0.0
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_variables_and_rows_stay_in_the_model_when_blocked():
    model = _model(lead_time_h=3.0, raart="1000Z")
    assert ("BID1", "CO1") in list(model.curative_bid_contingency_pairs)
    assert ("GU1", "CO1") in list(model.combined_pmax_pmin_constraint.keys())
    assert "BID1" in list(model.bid_ids_curative)
    assert not model.curative_rd_volume_upward["BID1", "CO1"].fixed  # bound, not fix


def test_lead_time_zero_is_unchanged():
    model = _model(lead_time_h=0.0, raart="1000Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == AVAILABLE_MW
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_satisfied_lead_time_is_unchanged():
    """raart 0500Z + 3 h = 0800Z < 1030Z -> usable."""
    model = _model(lead_time_h=3.0, raart="0500Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == AVAILABLE_MW
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


@pytest.mark.parametrize("lead_time_h, usable", [(0.5, True), (1.0, False), (3.0, False)])
def test_default_radp_is_one_hour_before_and_cutoff_on_boundary_blocks(lead_time_h, usable):
    """No raart -> radp 0930Z. 0.5 h -> cutoff 1000Z < 1030Z usable; 1 h ->
    cutoff exactly 1030Z blocks that timestamp (strict >, same as preventive)."""
    model = _model(lead_time_h=lead_time_h, raart=None)
    expected_ub = AVAILABLE_MW if usable else 0.0
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == expected_ub


# ===========================================================================
# Curative RD without preventive RD
# ===========================================================================

def _unit_curative_rd_without_preventive_rd(kind, available=True, mrid="RD1"):
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=available,
        kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )


# ---- 2. builder level --------------------------------------------------------

def _curative_only_rd_model(with_rd_inputs=True):
    rd_inputs = RdMilpInputs(
        rd_list=[_unit_curative_rd_without_preventive_rd(RAKind.CURATIVE)],
        bid_list=[PowerBid(
            mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP, available_mw={"1030Z": 40.0},
            price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
            activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
        )],
        glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    ) if with_rd_inputs else None
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},
        penalty_cost_overload_nx_patl=1000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def test_curative_only_rd_scenario_solves_uses_bid_and_nx_block_links_it():
    with_rd = _curative_only_rd_model(True)
    without_rd = _curative_only_rd_model(False)

    # no preventive RD anywhere in the model
    assert not hasattr(with_rd, "rd_volume_upward")
    assert not hasattr(with_rd, "rd_net_injection_g")
    # the curative bid is used: 5 MW x 10 A/MW clears the 50 A overload
    used = pyo.value(with_rd.curative_rd_volume_upward["BID1", "CO1"])
    assert used == pytest.approx(5.0, abs=1e-6)
    # the N-X PATL row links it: with the bid the slack is 0, without it 50 A
    assert pyo.value(with_rd.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(without_rd.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)
    # cost = (penalty_factor*ref + price) * max volume = (10 + 10) * 5
    assert pyo.value(with_rd.objective) == pytest.approx(100.0, abs=1e-6)
