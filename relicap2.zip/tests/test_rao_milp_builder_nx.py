"""tests/test_rao_milp_builder_nx.py - tests for the N-X blocks of milp_builder.py.
"""

import sys
import pyomo.environ as pyo
import pytest
import logging

from pathlib import Path
from data_model import (
    AEType,
    AssessedElement,
    BidDirection,
    PST,
    PowerBid,
    RAKind,
    RDUnit,
    Contingency,
    ContingencyType,
)
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from helpers import (
    _make_ae_mb_nx as _make_ae,
    _make_pst_mb_nx as _make_pst,
    _make_pst_inputs,
    _make_ae_nx_filters as _make_ae_nx_filters_and_scanned_elements,
    _make_contingency,
    _make_pst_nx_filters as _make_pst_nx_filters_and_scanned_elements,
)

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_rd_unit(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def _make_rd_inputs(bid_mrid="BID1", ra_mrid="RD1", gu_mrid="GU1", branch="BRANCH1",
                     sensitivity_n0=0.3, available_mw=50.0):
    return RdMilpInputs(
        rd_list=[_make_rd_unit(ra_mrid, gu_mrid)],
        bid_list=[_make_bid(bid_mrid, ra_mrid, BidDirection.UP, {"1030Z": available_mw})],
        glsk={ra_mrid: {gu_mrid: 1.0}},
        sensitivity_rd_n0_pruned={(branch, gu_mrid): sensitivity_n0},
        generator_data={gu_mrid: {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )


# ---------------------------------------------------------------------------
# nx_inputs=None — backward compatibility
# ---------------------------------------------------------------------------

def test_nx_inputs_none_adds_no_nx_components():
    """Without nx_inputs the model has no N-X Var or Constraint at all (the N-0 model)."""
    ae_list = [_make_ae("BRANCH1")]
    pst_inputs = _make_pst_inputs()

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "nx_patl_overload_slack")
    assert not hasattr(model, "nx_patl_loading")
    assert not hasattr(model, "nx_branch_contingency_pairs")


# ---------------------------------------------------------------------------
# PST-only N-X
# ---------------------------------------------------------------------------

def test_pst_only_nx_has_no_rd_term():
    """Given PST-only workflow with nx_inputs, When the N-X constraint is
    built, Then it includes the PST term and has zero RD components
    (mirrors N-0's own PST-only isolation)."""
    ae_list = [_make_ae("BRANCH1")]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert hasattr(model, "nx_patl_overload_slack")
    assert ("BRANCH1", "CO1") in list(model.nx_branch_contingency_pairs)
    assert not hasattr(model, "rd_net_injection_g")

    # the constraint body omits the RD term for a PST-only workflow (no zeroed RD reference)
    body = model.nx_patl_loading["BRANCH1", "CO1"].body
    assert body is not None


# ---------------------------------------------------------------------------
# RD-only N-X
# ---------------------------------------------------------------------------

def test_rd_only_nx_has_no_pst_term():
    """Given RD-only workflow with nx_inputs, When the N-X constraint is
    built, Then it includes the RD term and has zero PST components."""
    ae_list = [_make_ae("BRANCH1")]
    rd_inputs = _make_rd_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert hasattr(model, "nx_patl_overload_slack")
    assert not hasattr(model, "tap_change_upward")
    assert hasattr(model, "rd_net_injection_g")


# ---------------------------------------------------------------------------
# PST+RD together
# ---------------------------------------------------------------------------

def test_pst_and_rd_nx_both_present():
    """Given both PST and RD are enabled with nx_inputs, When the N-X
    constraint is built, Then both terms are present together."""
    ae_list = [_make_ae("BRANCH1")]
    pst_inputs = _make_pst_inputs()
    rd_inputs = _make_rd_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0,
        pst_inputs=pst_inputs, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert hasattr(model, "tap_change_upward")
    assert hasattr(model, "rd_net_injection_g")
    assert ("BRANCH1", "CO1") in list(model.nx_branch_contingency_pairs)


# ---------------------------------------------------------------------------
# min_loading_threshold_pct_nx pre-filter
# ---------------------------------------------------------------------------

def test_min_loading_threshold_pct_nx_excludes_lightly_loaded_pairs():
    """Given a (branch, contingency) pair whose N-X loading is below
    min_loading_threshold_pct_nx, When the N-X constraint is built, Then
    that pair is excluded — independent of N-0's own
    min_loading_threshold_pct (a branch could clear N-0's filter and
    still be excluded here, or vice versa, since they compare different
    loadings)."""
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]  # 1000 A PATL
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 100.0}}},  # 10% loading — below threshold
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        min_loading_threshold_pct_nx=50.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert list(model.nx_branch_contingency_pairs) == []


def test_min_loading_threshold_pct_nx_includes_heavily_loaded_pairs():
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},  # 90% loading — above threshold
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        min_loading_threshold_pct_nx=50.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert ("BRANCH1", "CO1") in list(model.nx_branch_contingency_pairs)


# ---------------------------------------------------------------------------
# Only lf_nx's own contingency keys get constraints
# ---------------------------------------------------------------------------

def test_only_contingencies_present_in_lf_nx_get_constraints():
    """lf_nx has CO1 but not CO2 (e.g. non-convergent): only CO1 gives a pair; the builder
    trusts lf_nx's keys."""
    ae_list = [_make_ae("BRANCH1")]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    pairs = list(model.nx_branch_contingency_pairs)
    assert pairs == [("BRANCH1", "CO1")]


# ---------------------------------------------------------------------------
# Scanned branches never get an N-X constraint
# ---------------------------------------------------------------------------

def test_scanned_branch_excluded_from_nx_constraint():
    """A SCANNED branch in lf_nx gets no N-X PATL constraint (SECURED only, as
    xne_loading_n0)."""
    ae_list = [_make_ae("BRANCH1", ae_type=AEType.SCANNED)]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert list(model.nx_branch_contingency_pairs) == []


# ---------------------------------------------------------------------------
# End-to-end solve
# ---------------------------------------------------------------------------

def test_nx_only_overload_resolved_by_pst_tap_change_end_to_end():
    """A branch fine at N-0 but overloaded after one contingency, and a PST that relieves it:
    solved with appsi_highs, the PST clears the N-X overload at minimum cost and no N-0
    slack is used."""
    # N-0: 500 A against 1000 A PATL -> no N-0 overload at all.
    # N-X (CO1): 1050 A against the SAME 1000 A PATL -> 50 A overload.
    # PST N-X sensitivity: -10 A per (degree*tap) equivalent (degrees_per_tap=1.0)
    # -> need >= 5 tap-steps upward to clear the 50 A N-X overload exactly.
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs(sensitivity_n0=0.0, degrees_per_tap=1.0)  # zero N-0 sensitivity — irrelevant at N-0
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    net_tap_change = pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])
    assert net_tap_change == pytest.approx(5.0, abs=1e-6)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) == pytest.approx(0.0, abs=1e-6)


# ---------------------------------------------------------------------------
# N-X TATL loading constraint
# ---------------------------------------------------------------------------

def test_tatl_data_none_adds_no_tatl_components():
    """Without tatl_data the model has the PATL N-X components and no TATL components."""
    ae_list = [_make_ae("BRANCH1")]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert hasattr(model, "nx_patl_overload_slack")
    assert not hasattr(model, "nx_tatl_overload_slack")
    assert not hasattr(model, "nx_tatl_loading")


def test_tatl_and_patl_constraints_coexist_independently():
    """Given a branch with BOTH a PATL and a TATL, and an N-X current that
    violates the tighter TATL but not (yet, by itself) the looser PATL
    check, When the N-X model is built, Then BOTH constraints exist for
    that (branch, contingency) pair, as two SEPARATE constraints — not
    merged into one using the tighter limit."""
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]  # 1000 A PATL
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        tatl_data={"BRANCH1": {"tatl_limit_ampere": 800.0, "tatl_duration_seconds": 1200, "side": 1}},
        penalty_cost_overload_nx_tatl=5000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert ("BRANCH1", "CO1") in list(model.nx_branch_contingency_pairs)
    assert ("BRANCH1", "CO1") in list(model.nx_tatl_branch_contingency_pairs)
    # Two INDEPENDENT constraints, not one merged constraint:
    assert model.nx_patl_loading["BRANCH1", "CO1"] is not model.nx_tatl_loading["BRANCH1", "CO1"]


def test_tatl_constraint_has_no_loading_threshold_prefilter():
    """Given min_loading_threshold_pct_nx is set high enough to exclude
    the PATL pair, When the TATL constraint is built, Then the TATL pair
    is STILL included — the TATL rule has no
    min_loading_threshold_pct, so the TATL constraint applies
    unconditionally to every branch that has a TATL and a usable
    contingency, independent of the PATL-side threshold filter."""
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 100.0}}},  # 10% loading — would fail a 50% PATL threshold
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        min_loading_threshold_pct_nx=50.0,
        tatl_data={"BRANCH1": {"tatl_limit_ampere": 800.0, "tatl_duration_seconds": 1200, "side": 1}},
        penalty_cost_overload_nx_tatl=5000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    # PATL pair excluded by the threshold...
    assert list(model.nx_branch_contingency_pairs) == []
    # ...but the TATL pair is NOT, since TATL has no such pre-filter.
    assert ("BRANCH1", "CO1") in list(model.nx_tatl_branch_contingency_pairs)


def test_only_branches_with_tatl_data_get_tatl_constraint():
    """Given tatl_data only covers BRANCH1 (not BRANCH2, which has no
    TATL defined), When the model is built, Then only BRANCH1 gets a TATL
    constraint — BRANCH2 still gets its PATL constraint as normal."""
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0), _make_ae("BRANCH2", patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1")],
        pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0, ("BRANCH2", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5},
        penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}, "BRANCH2": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0, ("BRANCH2", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        tatl_data={"BRANCH1": {"tatl_limit_ampere": 800.0, "tatl_duration_seconds": 1200, "side": 1}},
        penalty_cost_overload_nx_tatl=5000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}, "BRANCH2": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    tatl_pairs = list(model.nx_tatl_branch_contingency_pairs)
    assert tatl_pairs == [("BRANCH1", "CO1")]
    patl_pairs = list(model.nx_branch_contingency_pairs)
    assert set(patl_pairs) == {("BRANCH1", "CO1"), ("BRANCH2", "CO1")}


def test_tatl_overload_resolved_by_pst_tap_change_end_to_end():
    """A TATL tighter than the PATL, an N-X current violating only the TATL, and a PST: the
    solve clears the TATL overload at minimum cost and the PATL slack stays 0."""
    # PATL = 1000 A, TATL = 900 A. N-X current = 950 A.
    # -> PATL: 950 <= 1000, no PATL overload at all (patl slack should stay 0).
    # -> TATL: 950 > 900, 50 A TATL overload needing resolution.
    # PST TATL sensitivity: -10 A per (degree*tap) equivalent (degrees_per_tap=1.0)
    # -> need >= 5 tap-steps upward to clear the 50 A TATL overload exactly.
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs(sensitivity_n0=0.0, degrees_per_tap=1.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 950.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
        tatl_data={"BRANCH1": {"tatl_limit_ampere": 900.0, "tatl_duration_seconds": 1200, "side": 1}},
        penalty_cost_overload_nx_tatl=10_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    net_tap_change = pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])
    assert net_tap_change == pytest.approx(5.0, abs=1e-6)
    assert pyo.value(model.nx_tatl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_tatl_overload_left_as_slack_when_no_ra_available():
    """A TATL overload with no PST/RD sensitivity for the pair is absorbed entirely by
    nx_tatl_overload_slack, equal to the violation."""
    ae_list = [_make_ae("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs(sensitivity_n0=0.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 950.0}}},
        sensitivity_pst_nx={"CO1": {}},  # no sensitivity at all for this branch — RA cannot help
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
        tatl_data={"BRANCH1": {"tatl_limit_ampere": 900.0, "tatl_duration_seconds": 1200, "side": 1}},
        penalty_cost_overload_nx_tatl=10_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    assert pyo.value(model.nx_tatl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


# ===========================================================================
# N-X pruning and scanned elements in the model
# ===========================================================================

# ---------------------------------------------------------------------------
# End-to-end: a branch that survives Filter 1 with every RA pruned by Filter 2 keeps a
# slack-only constraint
# ---------------------------------------------------------------------------

def test_branch_with_all_sensitivity_pruned_still_gets_slack_only_constraint():
    """A branch that clears Filter 1 but has every RA pruned by Filter 2 (an EMPTY sensitivity
    dict for the pair) still gets its nx_patl_overload_slack variable and constraint, in the
    real build; solved, the overload is absorbed by the slack."""
    from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model

    ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_nx_filters_and_scanned_elements("PST1")],
        pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1050.0}}},  # 5% overload, clears Filter 1
        sensitivity_pst_nx={"CO1": {}},      # Filter 2 pruned everything for this branch
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert ("B1", "CO1") in list(model.nx_branch_contingency_pairs)

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


# ---------------------------------------------------------------------------
# N-X scanned-element constraint
# ---------------------------------------------------------------------------

class TestNxScannedElementConstraint:
    def test_no_scanned_branches_correctly_computes_empty_not_absent(self):
        """With only SECURED branches, nx_scanned_overload_slack and
        nx_scanned_branch_contingency_pairs still exist, with an EMPTY Set (built
        unconditionally like PATL; TATL depends on tatl_data)."""
        from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0)]
        pst_inputs = PstMilpInputs(
            pst_list=[_make_pst_nx_filters_and_scanned_elements("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
            pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={},
            pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
        )
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"B1": {1: 900.0}}},
            sensitivity_pst_nx={"CO1": {("B1", "PST1"): -10.0}},
            sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=500.0,
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"B1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
        )
        assert hasattr(model, "nx_scanned_overload_slack")
        assert list(model.nx_scanned_branch_contingency_pairs) == []

    def test_scanned_branch_gets_constraint_against_effective_limit(self):
        """A SCANNED branch overloaded after a contingency, with a PST to relieve it, gets a
        nx_scanned_overload_slack constraint against its effective limit; solved to 0 slack."""
        from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
        pst_inputs = PstMilpInputs(
            pst_list=[_make_pst_nx_filters_and_scanned_elements("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
            pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("B1", "PST1"): 0.0},
            pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
        )
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"B1": {1: 1050.0}}},
            sensitivity_pst_nx={"CO1": {("B1", "PST1"): -10.0}},
            sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1_000_000.0,
            penalty_cost_overload_nx_scanned=1_000_000.0,
        )
        # lf_initial equal to patl (1000A) -> effective_limit = max(patl, initial) = 1000A,
        # same numeric value as patl here for a clean, checkable expectation.
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"B1": {1: 1000.0}},
            penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
        )

        assert ("B1", "CO1") in list(model.nx_scanned_branch_contingency_pairs)
        assert not hasattr(model, "nx_branch_contingency_pairs") or (
            "B1", "CO1"
        ) not in list(getattr(model, "nx_branch_contingency_pairs", []))

        solver = pyo.SolverFactory("appsi_highs")
        result = solver.solve(model)
        assert str(result.solver.termination_condition) == "optimal"
        assert pyo.value(model.nx_scanned_overload_slack["B1", "CO1"]) == pytest.approx(0.0, abs=1e-6)

    def test_scanned_branch_has_no_tatl_equivalent(self):
        """Confirmed modelling decision: scanned branches never get a
        TATL-style second constraint, regardless of tatl_data content —
        only one N-X constraint exists per scanned branch/contingency."""
        from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model

        ae_list = [_make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
        pst_inputs = PstMilpInputs(
            pst_list=[_make_pst_nx_filters_and_scanned_elements("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
            pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={},
            pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
        )
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"B1": {1: 900.0}}},
            sensitivity_pst_nx={"CO1": {("B1", "PST1"): -10.0}},
            sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=500.0,
            # Even if tatl_data somehow contained an entry for this branch,
            # it must not produce a TATL constraint for a SCANNED branch:
            tatl_data={"B1": {"tatl_limit_ampere": 800.0, "tatl_duration_seconds": 1200, "side": 1}},
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"B1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
        )
        # tatl_data's entry is for a SCANNED branch; the TATL constraint is SECURED-only, so
        # B1 has no TATL pair:
        tatl_pairs = list(getattr(model, "nx_tatl_branch_contingency_pairs", []))
        assert ("B1", "CO1") not in tatl_pairs


# ===========================================================================
# N-X pairs without usable data
# ===========================================================================

# ---------------------------------------------------------------------------
# an N-X pair with PATL <= 0 is excluded as on the N-0 side
# ---------------------------------------------------------------------------

def _nx_model_with_zero_patl_branch():
    import helpers as N
    from milp.milp_builder import NxMilpInputs, build_n0_milp_model
    ae_list = [N._make_ae_mb_nx("GOOD", patl_ka=1.0), N._make_ae_mb_nx("ZERO", patl_ka=0.0)]
    pst_inputs = N._make_pst_inputs(branch="GOOD")
    pst_inputs.sensitivity_pst_n0_pruned[("ZERO", "PST1")] = 5.0
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"GOOD": {1: 900.0}, "ZERO": {1: 50.0}},
               "CO2": {"GOOD": {1: 900.0}, "ZERO": {1: 60.0}}},
        sensitivity_pst_nx={"CO1": {("GOOD", "PST1"): -10.0, ("ZERO", "PST1"): -10.0},
                            "CO2": {("GOOD", "PST1"): -10.0, ("ZERO", "PST1"): -10.0}},
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=500.0,
    )
    return build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"GOOD": {1: 500.0}, "ZERO": {1: 40.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )


def test_a_branch_with_patl_zero_has_no_nx_pair_and_one_warning_per_branch(caplog):
    with caplog.at_level(logging.WARNING):
        model = _nx_model_with_zero_patl_branch()
    pairs = set(model.nx_branch_contingency_pairs)
    assert pairs == {("GOOD", "CO1"), ("GOOD", "CO2")}
    nx_warnings = [r.message for r in caplog.records
                   if r.levelno == logging.WARNING and "ZERO" in r.message and "N-X" in r.message]
    assert len(nx_warnings) == 1


def _nx_model(lf_nx, sensitivity):
    import helpers as N
    from milp.milp_builder import NxMilpInputs, build_n0_milp_model
    ae_list = [N._make_ae_mb_nx("B1", patl_ka=1.0), N._make_ae_mb_nx("B2", patl_ka=1.0)]
    pst_inputs = N._make_pst_inputs(branch="B1")
    pst_inputs.sensitivity_pst_n0_pruned[("B2", "PST1")] = 5.0
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx=sensitivity, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )
    return build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 500.0}, "B2": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )


GOOD_SENS = {("B1", "PST1"): -10.0, ("B2", "PST1"): -10.0}


def test_a_pair_with_a_nan_current_is_skipped_with_a_warning_counting_pairs_per_contingency(caplog):
    lf_nx = {"CO1": {"B1": {1: 900.0}, "B2": {1: float("nan")}}}
    with caplog.at_level(logging.WARNING):
        model = _nx_model(lf_nx, {"CO1": GOOD_SENS})
    assert set(model.nx_branch_contingency_pairs) == {("B1", "CO1")}
    assert any("CO1" in r.message and "1 pair" in r.message for r in caplog.records
               if r.levelno == logging.WARNING)


def test_a_pair_without_any_current_for_the_branch_is_skipped_with_a_warning(caplog):
    lf_nx = {"CO1": {"B1": {1: 900.0}}}          # B2 has no entry
    with caplog.at_level(logging.WARNING):
        model = _nx_model(lf_nx, {"CO1": GOOD_SENS})
    assert set(model.nx_branch_contingency_pairs) == {("B1", "CO1")}
    assert any("CO1" in r.message and "1 pair" in r.message for r in caplog.records
               if r.levelno == logging.WARNING)


def test_a_pair_with_a_nan_sensitivity_is_skipped_with_a_warning(caplog):
    lf_nx = {"CO1": {"B1": {1: 900.0}, "B2": {1: 900.0}}}
    sens = {"CO1": {("B1", "PST1"): -10.0, ("B2", "PST1"): float("nan")}}
    with caplog.at_level(logging.WARNING):
        model = _nx_model(lf_nx, sens)
    assert set(model.nx_branch_contingency_pairs) == {("B1", "CO1")}
    assert any("CO1" in r.message and "sensitivit" in r.message for r in caplog.records
               if r.levelno == logging.WARNING)

# ===========================================================================
# Model equality: every constraint and the objective equal the stored fingerprints
# ===========================================================================

def test_built_models_equal_the_stored_fingerprints(tmp_path):
    """The synthetic curative case and every model of the mock fixture run have exactly the
    constraints, coefficients and objective recorded in tests/fixtures/milp_model_fingerprints.json
    (generated in a subprocess with PYTHONHASHSEED=0 for bit-repeatable float sums)."""
    import json
    import os
    import subprocess
    tests_dir = Path(__file__).resolve().parent
    repo = tests_dir.parent
    out = tmp_path / "fingerprints.json"
    script = (
        "import sys; sys.path[:0] = [r'%s', r'%s', r'%s']; import helpers; "
        "helpers.write_milp_model_fingerprints(r'%s')" % (tests_dir, repo / "src" / "rao", repo, out)
    )
    subprocess.run([sys.executable, "-c", script], check=True, cwd=repo, capture_output=True,
                   env={**os.environ, "PYTHONHASHSEED": "0"})
    expected = json.loads((tests_dir / "fixtures" / "milp_model_fingerprints.json").read_text())
    actual = json.loads(out.read_text())
    assert actual["synthetic"] == expected["synthetic"]
    assert len(actual["fixture_run"]) == len(expected["fixture_run"])
    for index, (model_actual, model_expected) in enumerate(zip(actual["fixture_run"], expected["fixture_run"])):
        assert model_actual == model_expected, f"fixture run model {index}"
