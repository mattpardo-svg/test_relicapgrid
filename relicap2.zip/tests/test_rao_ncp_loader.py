"""tests/test_rao_ncp_loader.py — unit tests for ncp_loader.py: timestamp generation, country
name helpers, build_ncp_files on a small synthetic Instance/ tree, and the input/ zip
handling: zip-entry classification, extraction with collision detection, and post-extraction
validation (duplicate or missing required profile).
"""
import sys
import zipfile
from pathlib import Path

import pytest

from pre_milp.ncp_loader import build_timestamp_list, _country_from_display, build_ncp_files


# ---------------------------------------------------------------------------
# build_timestamp_list
# ---------------------------------------------------------------------------

class TestBuildTimestampList:
    def test_basic_four_hours(self):
        assert build_timestamp_list("1030Z", 4) == ["1030Z", "1130Z", "1230Z", "1330Z"]

    def test_single_timestamp(self):
        assert build_timestamp_list("1030Z", 1) == ["1030Z"]

    def test_midnight_wrap(self):
        result = build_timestamp_list("2330Z", 3)
        assert result == ["2330Z", "0030Z", "0130Z"]

    def test_full_day(self):
        result = build_timestamp_list("0000Z", 24)
        assert len(result) == 24
        assert result[0]  == "0000Z"
        assert result[23] == "2300Z"

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="HHMMZ"):
            build_timestamp_list("10:30Z", 4)

    def test_invalid_hour_raises(self):
        with pytest.raises(ValueError):
            build_timestamp_list("9999Z", 4)

    def test_zero_timestamps_raises(self):
        with pytest.raises(ValueError, match="1–24"):
            build_timestamp_list("1030Z", 0)

    def test_too_many_timestamps_raises(self):
        with pytest.raises(ValueError, match="1–24"):
            build_timestamp_list("1030Z", 25)

    def test_consecutive_hours(self):
        result = build_timestamp_list("0800Z", 5)
        assert result == ["0800Z", "0900Z", "1000Z", "1100Z", "1200Z"]


# ---------------------------------------------------------------------------
# _country_from_display
# ---------------------------------------------------------------------------

class TestCountryFromDisplay:
    def test_strips_tso_prefix(self):
        assert _country_from_display("TSO-Belgovia") == "Belgovia"

    def test_bare_name_unchanged(self):
        assert _country_from_display("Belgovia") == "Belgovia"

    def test_all_known_tsos(self):
        tsos = [
            "TSO-Belgovia", "TSO-Britheim", "TSO-Espheim",
            "TSO-Galia", "TSO-Nordheim", "TSO-Portheim", "TSO-Svedala",
        ]
        countries = [_country_from_display(t) for t in tsos]
        assert "TSO-Belgovia" not in countries
        assert "Belgovia" in countries


# ---------------------------------------------------------------------------
# build_ncp_files — on a synthetic Instance/ tree with the ReliCapGrid layout: the real
# Organisation profile (7 TSOs), NCP files for Belgovia (all five profiles), Espheim and
# Svedala (AE, CO, RA, SIS) and Galia (AE, CO, RA), and Grid-only folders for the TSOs
# without NCP data (Britheim, Nordheim, Portheim)
# ---------------------------------------------------------------------------

_NCP_PROFILES_PER_COUNTRY = {
    "Belgovia": ("AE", "CO", "RA", "SHS", "SIS"),
    "Espheim": ("AE", "CO", "RA", "SIS"),
    "Galia": ("AE", "CO", "RA"),
    "Svedala": ("AE", "CO", "RA", "SIS"),
}
_GRID_ONLY_COUNTRIES = ("Britheim", "Nordheim", "Portheim")


@pytest.fixture
def DATA_ROOT(tmp_path):
    root = tmp_path / "Instance"
    org_dir = root / "commonData" / "NetworkCode" / "cimxml"
    org_dir.mkdir(parents=True)
    with zipfile.ZipFile(Path(__file__).resolve().parent / "fixtures" / "NCP_generic.zip") as zf:
        org_name = next(n for n in zf.namelist() if n.endswith("Org-NineRealms_CD.xml"))
        (org_dir / "Org-NineRealms_CD.xml").write_bytes(zf.read(org_name))
    for country, profiles in _NCP_PROFILES_PER_COUNTRY.items():
        cimxml = root / country / "NetworkCode" / "cimxml"
        cimxml.mkdir(parents=True)
        for profile in profiles:
            (cimxml / f"{country}_{profile}.xml").write_text("<rdf:RDF/>")
        (root / country / "Grid" / "cimxml").mkdir(parents=True)
    for country in _GRID_ONLY_COUNTRIES:
        (root / country / "Grid" / "cimxml").mkdir(parents=True)
    return root


class TestBuildNcpFilesLive:
    @pytest.fixture
    def tso_name_map(self, DATA_ROOT):
        from pre_milp.tso_name_resolver import build_tso_name_map
        org_cd = DATA_ROOT / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        return build_tso_name_map(org_cd)

    def test_returns_four_tsos(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        assert len(ncp_files) == 4

    def test_known_tsos_present(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        assert "TSO-Belgovia" in ncp_files
        assert "TSO-Espheim"  in ncp_files
        assert "TSO-Galia"    in ncp_files
        assert "TSO-Svedala"  in ncp_files

    def test_cgm_only_tsos_excluded(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        assert "TSO-Britheim" not in ncp_files
        assert "TSO-Nordheim" not in ncp_files
        assert "TSO-Portheim" not in ncp_files

    def test_belgovia_has_all_five_profiles(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        assert set(ncp_files["TSO-Belgovia"].keys()) == {"AE", "CO", "RA", "SHS", "SIS"}

    def test_required_profiles_present_for_all(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        for tso, profiles in ncp_files.items():
            for req in ("AE", "CO", "RA"):
                assert req in profiles, f"{tso} missing required profile {req}"

    def test_all_paths_exist(self, tso_name_map, DATA_ROOT):
        ncp_files = build_ncp_files(DATA_ROOT, tso_name_map)
        for tso, profiles in ncp_files.items():
            for profile, path in profiles.items():
                assert path.exists(), f"{tso} {profile} path does not exist: {path}"


# ---------------------------------------------------------------------------
# input/ folder — zip-entry classification, cell by cell
# ---------------------------------------------------------------------------

class TestClassifyNcpZipEntry:
    def test_recognized_profile_for_known_tso(self):
        from pre_milp import ncp_loader
        assert ncp_loader._classify_ncp_zip_entry("Belgovia_RA.xml", {"Belgovia"}) == ("recognized", "Belgovia", "RA")

    def test_organisation_file(self):
        from pre_milp import ncp_loader
        assert ncp_loader._classify_ncp_zip_entry("Org-NineRealms_CD.xml", {"Belgovia"}) == ("organisation", None, None)

    def test_object_registry_file_is_known_irrelevant(self):
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry("Org-NineRealms_CD_OR.xml", {"Belgovia"})
        assert category == "known_irrelevant"

    def test_ssi_suffix_is_known_irrelevant(self):
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry("Espheim_SSI.xml", {"Espheim"})
        assert category == "known_irrelevant"

    def test_cross_tso_hyphenated_export_is_known_irrelevant(self):
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry(
            "Svedala-Belgovia_CO.xml", {"Svedala", "Belgovia"},
        )
        assert category == "known_irrelevant"

    def test_unknown_tso_no_hyphen_is_unrecognized(self):
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry("Wakanda_CO.xml", {"Belgovia"})
        assert category == "unrecognized"

    def test_known_tso_with_unrecognized_profile_suffix_is_known_irrelevant(self):
        """A known TSO's file of a profile that is not parsed (ER, PS, RAS, ...) is
        known_irrelevant; unrecognized is for names that do not start with a TSO name."""
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry("Belgovia_XYZ.xml", {"Belgovia"})
        assert category == "known_irrelevant"

    def test_multi_underscore_suffix_from_known_tso_is_known_irrelevant(self):
        """Confirmed real filenames like 'Svedala_RAS_Jotunheim_agreed.xml'
        have more than one underscore in their own suffix — rpartition on
        the last underscore alone would misread the country as
        'Svedala_RAS_Jotunheim' (matching no real TSO) and wrongly report
        this as unrecognized. Matched by TSO-name prefix instead."""
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry(
            "Svedala_RAS_Jotunheim_agreed.xml", {"Svedala"},
        )
        assert category == "known_irrelevant"

    def test_non_xml_file_is_unrecognized(self):
        from pre_milp import ncp_loader
        category, _, _ = ncp_loader._classify_ncp_zip_entry("Belgovia_RA.txt", {"Belgovia"})
        assert category == "unrecognized"


class TestExtractNcpZipCollisionDetection:
    def test_same_basename_different_path_raises_before_extraction(self, tmp_path):
        """extractall() silently overwrites an entry with the same basename, so duplicates
        are detected on the zip's entry list before extraction."""
        from pre_milp import ncp_loader

        zip_path = tmp_path / "colliding.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("folder1/Belgovia_RA.xml", "CONTENT_A")
            zf.writestr("folder2/Belgovia_RA.xml", "CONTENT_B")

        with pytest.raises(ValueError, match="same filename"):
            ncp_loader.extract_ncp_zip(zip_path, tmp_path / "extracted")

    def test_missing_organisation_file_raises(self, tmp_path):
        from pre_milp import ncp_loader

        zip_path = tmp_path / "no_org.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("Belgovia_RA.xml", "content")

        with pytest.raises(FileNotFoundError, match="Org-NineRealms_CD.xml"):
            ncp_loader.extract_ncp_zip(zip_path, tmp_path / "extracted")

    def test_missing_zip_raises(self, tmp_path):
        from pre_milp import ncp_loader
        with pytest.raises(FileNotFoundError):
            ncp_loader.extract_ncp_zip(tmp_path / "does_not_exist.zip", tmp_path / "extracted")


class TestClassifyExtractedNcpFilesValidation:
    def test_missing_required_profile_raises(self, tmp_path):
        from pre_milp import ncp_loader

        extract_dir = tmp_path / "extracted"
        extract_dir.mkdir()
        (extract_dir / "Belgovia_AE.xml").write_text("content")
        # RA and CO deliberately absent

        with pytest.raises(ValueError, match="missing required profile"):
            ncp_loader.classify_extracted_ncp_files(extract_dir, {"TSO-Belgovia"})

    def test_missing_optional_profile_is_not_an_error(self, tmp_path):
        from pre_milp import ncp_loader

        extract_dir = tmp_path / "extracted"
        extract_dir.mkdir()
        for profile in ("AE", "CO", "RA"):
            (extract_dir / f"Belgovia_{profile}.xml").write_text("content")
        # SHS and SIS deliberately absent — optional, must not raise

        result = ncp_loader.classify_extracted_ncp_files(extract_dir, {"TSO-Belgovia"})
        assert set(result["TSO-Belgovia"].keys()) == {"AE", "CO", "RA"}

    def test_unrecognized_file_does_not_block_valid_tsos(self, tmp_path, caplog):
        from pre_milp import ncp_loader

        extract_dir = tmp_path / "extracted"
        extract_dir.mkdir()
        for profile in ("AE", "CO", "RA"):
            (extract_dir / f"Belgovia_{profile}.xml").write_text("content")
        (extract_dir / "Totally_Unexpected_File.xml").write_text("content")

        result = ncp_loader.classify_extracted_ncp_files(extract_dir, {"TSO-Belgovia"})
        assert "TSO-Belgovia" in result
        assert "did not match the expected" in caplog.text


# ---------------------------------------------------------------------------
# run_pipeline._find_unique_zip_by_prefix (input/ folder)
# ---------------------------------------------------------------------------

class TestFindUniqueZipByPrefix:
    def test_zero_matches_raises_file_not_found(self, tmp_path):
        import run_pipeline as rp
        with pytest.raises(FileNotFoundError):
            rp._find_unique_zip_by_prefix(tmp_path, "cgm")

    def test_missing_folder_raises_file_not_found(self, tmp_path):
        import run_pipeline as rp
        with pytest.raises(FileNotFoundError):
            rp._find_unique_zip_by_prefix(tmp_path / "does_not_exist", "cgm")

    def test_one_match_case_insensitive_prefix(self, tmp_path):
        import run_pipeline as rp
        (tmp_path / "CGM_XYZ.zip").write_bytes(b"")
        result = rp._find_unique_zip_by_prefix(tmp_path, "cgm")
        assert result.name == "CGM_XYZ.zip"

    def test_multiple_matches_raises_value_error(self, tmp_path):
        import run_pipeline as rp
        (tmp_path / "cgm_a.zip").write_bytes(b"")
        (tmp_path / "CGM_b.zip").write_bytes(b"")
        with pytest.raises(ValueError):
            rp._find_unique_zip_by_prefix(tmp_path, "cgm")

    def test_non_zip_files_are_ignored(self, tmp_path):
        import run_pipeline as rp
        (tmp_path / "cgm_notes.txt").write_bytes(b"")
        (tmp_path / "cgm.zip").write_bytes(b"")
        result = rp._find_unique_zip_by_prefix(tmp_path, "cgm")
        assert result.name == "cgm.zip"
