"""tests/test_rao_glsk_resolver.py - unit tests for glsk_resolver.py.
"""

import sys

from pathlib import Path
from data_model import RAKind, RDUnit

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


SIS_HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
"""


SIS_FOOTER = "</rdf:RDF>\n"


def _write_sis(tmp_path: Path, body: str) -> Path:
    path = tmp_path / "Test_SIS.xml"
    path.write_text(SIS_HEADER + body + SIS_FOOTER)
    return path


def _make_rd_unit(mrid: str, gu_mrid: str, available: bool = True, kind=RAKind.PREVENTIVE) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=available, kind=kind, initial_p=0.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


# ---------------------------------------------------------------------------
# Full chain resolution (synthetic, matching real SIS structure exactly)
# ---------------------------------------------------------------------------

def test_resolve_glsk_full_chain_single_generating_unit(tmp_path):
    """Given a full PowerBidSchedule -> PowerShiftKeyDistribution ->
    PowerShiftKeySchedule -> ParticipationFactorTimePoint chain for one RD
    RA with one generating unit, When resolving GLSK, Then the participation
    factor is correctly resolved and normalised to 1.0 (single valid unit)."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs1">
      <cim:IdentifiedObject.mRID>pbs1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd1">
      <cim:IdentifiedObject.mRID>pskd1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs1"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psks1">
      <cim:IdentifiedObject.mRID>psks1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU1"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pft1">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.7</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [_make_rd_unit("RA1", "GU1")]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU1"}, timestamp="1030Z",
    )

    assert result == {"RA1": {"GU1": 1.0}}


def test_resolve_glsk_full_chain_curative_ra(tmp_path):
    """The full chain for a CURATIVE RD RA resolves as for a preventive one."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs1">
      <cim:IdentifiedObject.mRID>pbs1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd1">
      <cim:IdentifiedObject.mRID>pskd1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs1"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psks1">
      <cim:IdentifiedObject.mRID>psks1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU1"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pft1">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>1.0</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [_make_rd_unit("RA1", "GU1", kind=RAKind.CURATIVE)]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU1"}, timestamp="1030Z",
    )

    assert result == {"RA1": {"GU1": 1.0}}


def test_resolve_glsk_mixed_preventive_and_curative_both_resolve(tmp_path):
    """One preventive and one curative RA, each with its own SIS chain: both resolve,
    independently."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs_prev">
      <cim:IdentifiedObject.mRID>pbs_prev</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA_PREV"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd_prev">
      <cim:IdentifiedObject.mRID>pskd_prev</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs_prev"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psks_prev"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psks_prev">
      <cim:IdentifiedObject.mRID>psks_prev</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU_PREV"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pft_prev">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>1.0</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psks_prev"/>
    </nc:ParticipationFactorTimePoint>
    <nc:PowerBidSchedule rdf:ID="_pbs_cur">
      <cim:IdentifiedObject.mRID>pbs_cur</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA_CUR"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd_cur">
      <cim:IdentifiedObject.mRID>pskd_cur</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs_cur"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psks_cur"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psks_cur">
      <cim:IdentifiedObject.mRID>psks_cur</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU_CUR"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pft_cur">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>1.0</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psks_cur"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [
        _make_rd_unit("RA_PREV", "GU_PREV", kind=RAKind.PREVENTIVE),
        _make_rd_unit("RA_CUR", "GU_CUR", kind=RAKind.CURATIVE),
    ]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU_PREV", "GU_CUR"}, timestamp="1030Z",
    )

    assert result == {"RA_PREV": {"GU_PREV": 1.0}, "RA_CUR": {"GU_CUR": 1.0}}


def test_resolve_glsk_normalises_across_two_units(tmp_path):
    """Given two generating units with unequal raw participation factors
    (0.3 and 0.6) both valid in the network, When resolving GLSK, Then the
    factors are normalised so they sum to 1.0, preserving relative shares."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs1">
      <cim:IdentifiedObject.mRID>pbs1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd1">
      <cim:IdentifiedObject.mRID>pskd1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs1"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psksA"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psksB"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psksA">
      <cim:IdentifiedObject.mRID>psksA</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GUA"/>
    </nc:PowerShiftKeySchedule>
    <nc:PowerShiftKeySchedule rdf:ID="_psksB">
      <cim:IdentifiedObject.mRID>psksB</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GUB"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pftA">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.3</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psksA"/>
    </nc:ParticipationFactorTimePoint>
    <nc:ParticipationFactorTimePoint rdf:ID="_pftB">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.6</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psksB"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [_make_rd_unit("RA1", "GUA")]  # only need RA1 available+preventive once

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GUA", "GUB"}, timestamp="1030Z",
    )

    assert abs(result["RA1"]["GUA"] - 1/3) < 1e-9
    assert abs(result["RA1"]["GUB"] - 2/3) < 1e-9
    assert abs(sum(result["RA1"].values()) - 1.0) < 1e-9


def test_resolve_glsk_removes_invalid_unit_and_redistributes(tmp_path):
    """Given a generating unit absent from network.get_generators().index,
    When resolving GLSK, Then it is removed and the remaining valid unit's
    factor is redistributed to 1.0."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs1">
      <cim:IdentifiedObject.mRID>pbs1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd1">
      <cim:IdentifiedObject.mRID>pskd1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs1"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psksA"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psksB"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psksA">
      <cim:IdentifiedObject.mRID>psksA</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU_VALID"/>
    </nc:PowerShiftKeySchedule>
    <nc:PowerShiftKeySchedule rdf:ID="_psksB">
      <cim:IdentifiedObject.mRID>psksB</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU_MISSING_FROM_NETWORK"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pftA">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.4</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psksA"/>
    </nc:ParticipationFactorTimePoint>
    <nc:ParticipationFactorTimePoint rdf:ID="_pftB">
      <nc:ParticipationFactorTimePoint.atTime>2022-06-15T10:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.6</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psksB"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [_make_rd_unit("RA1", "GU_VALID")]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU_VALID"},  # GU_MISSING_FROM_NETWORK deliberately excluded
        timestamp="1030Z",
    )

    assert result == {"RA1": {"GU_VALID": 1.0}}


def test_resolve_glsk_wrong_timestamp_yields_empty():
    """Given a ParticipationFactorTimePoint whose atTime doesn't match the
    requested timestamp, When resolving GLSK, Then the RA's GLSK is empty
    (not a crash, not a stale/wrong-timestamp value)."""
    import tempfile
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs1">
      <cim:IdentifiedObject.mRID>pbs1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_pskd1">
      <cim:IdentifiedObject.mRID>pskd1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_pbs1"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_psks1">
      <cim:IdentifiedObject.mRID>psks1</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_GU1"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_pft1">
      <nc:ParticipationFactorTimePoint.atTime>2024-02-22T17:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.5</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_psks1"/>
    </nc:ParticipationFactorTimePoint>
    """
    with tempfile.TemporaryDirectory() as d:
        sis_path = _write_sis(Path(d), body)
        rd_list = [_make_rd_unit("RA1", "GU1")]

        result = glsk_module.resolve_glsk(
            sis_path, rd_list, tso="TestTSO",
            valid_generator_mrids={"GU1"}, timestamp="1030Z",  # doesn't match 1730Z in the data
        )

    assert result == {"RA1": {}}


def test_resolve_glsk_ra_with_no_linkage_at_all_yields_empty(tmp_path):
    """Given an available preventive RD RA that has no PowerBidSchedule
    linked to it at all (present in rd_list but absent from the SIS
    structure entirely), When resolving GLSK, Then the RA key is present
    with an empty dict — never silently missing, never a crash."""
    from pre_milp import glsk_resolver as glsk_module

    body = """
    <nc:PowerBidSchedule rdf:ID="_pbs_unrelated">
      <cim:IdentifiedObject.mRID>pbs_unrelated</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_SOME_OTHER_RA"/>
    </nc:PowerBidSchedule>
    """
    sis_path = _write_sis(tmp_path, body)
    rd_list = [_make_rd_unit("RA_NO_LINKAGE", "GU1")]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU1"}, timestamp="1030Z",
    )

    assert result == {"RA_NO_LINKAGE": {}}


def test_resolve_glsk_no_sis_file_yields_empty_for_all_ras():
    """Given sis_path is None (TSO has no SIS file at all, e.g. Galia),
    When resolving GLSK, Then every preventive RD RA gets an empty dict,
    not an exception."""
    from pre_milp import glsk_resolver as glsk_module

    rd_list = [_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA2", "GU2")]

    result = glsk_module.resolve_glsk(
        None, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU1", "GU2"}, timestamp="1030Z",
    )

    assert result == {"RA1": {}, "RA2": {}}


def test_resolve_glsk_filters_unavailable_but_includes_curative_units():
    """An unavailable unit is excluded; an available curative unit is included
    (_add_curative_rd_block's in-operation check reads this GLSK)."""
    from pre_milp import glsk_resolver as glsk_module

    rd_list = [
        _make_rd_unit("RA_PREVENTIVE_AVAILABLE", "GU1", available=True, kind=RAKind.PREVENTIVE),
        _make_rd_unit("RA_UNAVAILABLE", "GU2", available=False, kind=RAKind.PREVENTIVE),
        _make_rd_unit("RA_CURATIVE", "GU3", available=True, kind=RAKind.CURATIVE),
        _make_rd_unit("RA_CURATIVE_UNAVAILABLE", "GU4", available=False, kind=RAKind.CURATIVE),
    ]

    result = glsk_module.resolve_glsk(
        None, rd_list, tso="TestTSO",
        valid_generator_mrids={"GU1", "GU2", "GU3", "GU4"}, timestamp="1030Z",
    )

    assert result == {"RA_PREVENTIVE_AVAILABLE": {}, "RA_CURATIVE": {}}


# ---------------------------------------------------------------------------
# Real-data shape: empty GLSK
# ---------------------------------------------------------------------------

def test_resolve_glsk_real_belgovia_shape_confirmed_empty(tmp_path):
    """A SIS shaped like the real Belgovia_SIS.xml (PowerShiftKeySchedule linked to an
    UNRELATED RA) gives an empty GLSK for the real RD RA."""
    from pre_milp import glsk_resolver as glsk_module

    # Shaped after the real file: PowerShiftKeySchedule content exists, but
    # is linked (via PowerBidSchedule.PowerRemedialAction) to a DIFFERENT
    # RA mRID than the real Belgovia RD RA.
    body = """
    <nc:PowerBidSchedule rdf:ID="_6c0ba4c5-5ac0-43f8-87d9-ec2fb41a3dec">
      <cim:IdentifiedObject.mRID>6c0ba4c5-5ac0-43f8-87d9-ec2fb41a3dec</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_fa73cfee-ff54-43cd-816b-51394cd76f0f"/>
    </nc:PowerBidSchedule>
    <nc:PowerShiftKeyDistribution rdf:ID="_7ab20445-576c-4162-aad5-d097d894a8e0">
      <cim:IdentifiedObject.mRID>7ab20445-576c-4162-aad5-d097d894a8e0</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_6c0ba4c5-5ac0-43f8-87d9-ec2fb41a3dec"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_3b5748de-39f2-45d7-9a66-65819c667e91"/>
    </nc:PowerShiftKeyDistribution>
    <nc:PowerShiftKeySchedule rdf:ID="_3b5748de-39f2-45d7-9a66-65819c667e91">
      <cim:IdentifiedObject.mRID>3b5748de-39f2-45d7-9a66-65819c667e91</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_413bbc8a-683c-7e07-4fb9-aa6ec83278e0"/>
    </nc:PowerShiftKeySchedule>
    <nc:ParticipationFactorTimePoint rdf:ID="_06dea5a7-512e-48da-a2fc-5e0ec83a5b8e">
      <nc:ParticipationFactorTimePoint.atTime>2024-02-22T17:30:00Z</nc:ParticipationFactorTimePoint.atTime>
      <nc:ParticipationFactorTimePoint.participationFactor>0.5</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_3b5748de-39f2-45d7-9a66-65819c667e91"/>
    </nc:ParticipationFactorTimePoint>
    """
    sis_path = _write_sis(tmp_path, body)

    # The REAL RD RA mRID and its 2 real generating units, per Belgovia_RA.xml
    rd_list = [
        _make_rd_unit("d874f8e3-7272-44b8-95ba-18f10449f036", "3a3b27be-b18b-4385-b557-6735d733baf0"),
        _make_rd_unit("d874f8e3-7272-44b8-95ba-18f10449f036", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"),
    ]

    result = glsk_module.resolve_glsk(
        sis_path, rd_list, tso="Belgovia",
        valid_generator_mrids={"3a3b27be-b18b-4385-b557-6735d733baf0", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"},
        timestamp="1030Z",
    )

    assert result == {"d874f8e3-7272-44b8-95ba-18f10449f036": {}}
