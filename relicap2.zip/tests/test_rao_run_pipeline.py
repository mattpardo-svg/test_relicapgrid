"""tests/test_rao_run_pipeline.py - fast tests of run_pipeline.py (they do not run main()).

Sections: config keys, config range checks, the result model selector, the RD workflow gate.
"""

import ast
import shutil
import subprocess
import sys
import pytest
import yaml
import logging
import run_pipeline

from pathlib import Path
from data_model import BidDirection, PowerBid, RAKind, RDUnit
from pre_milp.workflow_gates import rd_inputs_required

REPO_ROOT = Path(__file__).resolve().parents[1]


SRC = REPO_ROOT / "src" / "rao"


CONFIG_DIR = SRC / "config"


def _keys_read_by_code() -> set[tuple]:
    """Every key path passed to _cfg(...) in run_pipeline.py (the only reader of rao_config.yaml)."""
    tree = ast.parse((SRC / "run_pipeline.py").read_text(encoding="utf-8"))
    keys = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "_cfg":
            assert all(isinstance(a, ast.Constant) for a in node.args), "_cfg keys must be literals"
            if node.args:
                keys.add(tuple(a.value for a in node.args))
    return keys


def _load(name: str) -> dict:
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding="utf-8"))


def _exists(config: dict, keys: tuple) -> bool:
    for key in keys:
        if not isinstance(config, dict) or key not in config:
            return False
        config = config[key]
    return True


def test_the_scan_finds_the_keys_and_no_other_reader_bypasses_it():
    keys = _keys_read_by_code()
    assert len(keys) >= 30
    assert ("thresholds", "max_change_ra") in keys and ("logging_options", "debug_log_mode") in keys
    assert '_rao_config["' not in (SRC / "run_pipeline.py").read_text(encoding="utf-8"), \
        "read config through _cfg(...) so the scan sees the key"
    others = [p.name for p in SRC.rglob("*.py") if p.name != "run_pipeline.py" and "import yaml" in p.read_text(encoding="utf-8")]
    assert not others, f"{others} read YAML config outside run_pipeline.py: extend the scan"


@pytest.mark.parametrize("name", ["rao_config.default.yaml", "rao_config.yaml"])
def test_every_key_read_by_the_code_exists_in_the_file(name):
    config = _load(name)
    missing = sorted(k for k in _keys_read_by_code() if not _exists(config, k))
    assert not missing, f"{name} lacks keys the code reads: {missing}"


def _key_tree(config):
    return {key: _key_tree(value) for key, value in config.items()} if isinstance(config, dict) else None


def test_default_and_active_config_have_the_same_keys():
    assert _key_tree(_load("rao_config.default.yaml")) == _key_tree(_load("rao_config.yaml"))


@pytest.mark.parametrize("section, expected", [
    ("curative_ra", {"pst_group_kind_default": "blockedGroup", "pst_group_kind_per_tso": {}}),
    ("ra_limits", {"max_taps_per_tso": 6, "max_taps_per_tso_overrides": {}}),
    ("performance", {"lf_thread_count": 1, "solver_time_limit_seconds": None, "solver_mip_rel_gap": None}),
    ("outputs", {"write_nx_sensitivity_csvs": True}),
])
def test_the_config_loader_returns_the_documented_defaults(section, expected):
    from run_pipeline import _config_value

    config = _load("rao_config.default.yaml")
    for key, value in expected.items():
        assert _config_value(config, (section, key), CONFIG_DIR / "rao_config.default.yaml") == value


def test_a_missing_key_names_the_key_and_the_file():
    from run_pipeline import ConfigKeyError, _config_value

    path = Path("/x/rao_config.yaml")
    with pytest.raises(ConfigKeyError) as excinfo:
        _config_value({"thresholds": {"a": 1}}, ("thresholds", "max_change_ra"), path)
    message = str(excinfo.value)
    assert "thresholds.max_change_ra" in message and "rao_config.yaml" in message
    assert "rao_config.default.yaml" in message
    assert isinstance(excinfo.value, KeyError)
    with pytest.raises(ConfigKeyError):
        _config_value({}, ("logging_options", "debug_log_mode"), path)
    assert _config_value({"a": {"b": 3}}, ("a", "b"), path) == 3


def test_the_pipeline_module_loads_with_the_default_file_alone(tmp_path):
    """Copy the sources, replace the active config by the default one, import run_pipeline."""
    shutil.copytree(REPO_ROOT / "src", tmp_path / "src",
                    ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(REPO_ROOT / "pytest.ini", tmp_path / "pytest.ini")
    config = tmp_path / "src" / "rao" / "config"
    shutil.copy(config / "rao_config.default.yaml", config / "rao_config.yaml")
    code = (
        "import sys; sys.path[:0] = ['.', 'pre_milp']; import run_pipeline as r; "
        "print(r.MAX_CHANGE_RA, r.MAX_CHANGE_OVERLOAD, r.DEBUG_LOG_MODE)"
    )
    result = subprocess.run(
        [sys.executable, "-I", "-B", "-c", code], cwd=tmp_path / "src" / "rao",
        capture_output=True, text=True, timeout=300,
    )
    assert result.returncode == 0, result.stderr[-1500:]
    assert result.stdout.split() == ["1.0", "1.0", "False"]


# ===========================================================================
# Config range checks and unknown TSO names
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


# ---------------------------------------------------------------------------
# max_taps_per_tso_overrides: range checks and unknown TSO names
# ---------------------------------------------------------------------------

def _default_config():
    import yaml
    return yaml.safe_load((REPO_SRC / "config" / "rao_config.default.yaml").read_text(encoding="utf-8"))


def test_the_shipped_default_config_passes_the_range_checks():
    import run_pipeline
    run_pipeline.validate_config_ranges(_default_config(), Path("/x/rao_config.yaml"))


@pytest.mark.parametrize("section, key, bad", [
    ("thresholds", "min_loading_threshold_pct", -1.0),
    ("thresholds", "min_loading_threshold_pct_nx", -0.1),
    ("thresholds", "sensitivity_threshold_pct_pst", -5),
    ("thresholds", "sensitivity_threshold_pct_rd", -5),
    ("thresholds", "sensitivity_threshold_pct_pst_nx", -5),
    ("thresholds", "sensitivity_threshold_pct_rd_nx", -5),
    ("thresholds", "max_change_ra_sum_threshold", -1),
    ("thresholds", "max_change_ra", -1),
    ("thresholds", "max_change_overload", -1),
    ("iteration_caps", "max_linearisation_iterations", 0),
    ("iteration_caps", "max_completeness_iterations", 0),
    ("iteration_caps", "incremental_ac_fallback_max_steps", 0),
    ("iteration_caps", "max_linearisation_iterations", 2.5),
    ("thresholds", "max_change_ra", "high"),
    ("performance", "lf_thread_count", 0),
    ("performance", "lf_thread_count", 1.5),
    ("performance", "solver_time_limit_seconds", 0),
    ("performance", "solver_time_limit_seconds", -1.0),
    ("performance", "solver_mip_rel_gap", -0.1),
    ("outputs", "write_nx_sensitivity_csvs", "yes"),
])
def test_an_out_of_range_config_value_raises_a_clear_error_naming_key_value_and_file(section, key, bad):
    import run_pipeline
    config = _default_config()
    config[section][key] = bad
    with pytest.raises(ValueError) as excinfo:
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    message = str(excinfo.value)
    assert f"{section}.{key}" in message and repr(bad) in message and "rao_config.yaml" in message


def test_set_solver_limits_and_a_thread_count_above_one_are_accepted():
    import run_pipeline
    config = _default_config()
    config["performance"].update(lf_thread_count=4, solver_time_limit_seconds=30, solver_mip_rel_gap=0.0)
    config["outputs"]["write_nx_sensitivity_csvs"] = False
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


def test_a_threshold_of_exactly_zero_and_an_iteration_cap_of_one_are_accepted():
    import run_pipeline
    config = _default_config()
    config["thresholds"]["max_change_ra"] = 0
    config["iteration_caps"]["max_completeness_iterations"] = 1
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


def test_unknown_tso_names_in_the_tap_limit_overrides_are_warned_about_one_by_one(caplog):
    import run_pipeline
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_unknown_tso_names(
            "max_taps_per_tso_overrides", ["TSO-A", "TSO-TYPO", "TSO-Z"], {"TSO-A", "TSO-B"},
        )
    warnings = [r.message for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 2
    assert any("TSO-TYPO" in w and "max_taps_per_tso_overrides" in w and "TSO-A" in w for w in warnings)
    assert any("TSO-Z" in w for w in warnings)


def test_known_tso_names_in_the_overrides_give_no_warning(caplog):
    import run_pipeline
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_unknown_tso_names("max_taps_per_tso_overrides", ["TSO-A"], {"TSO-A", "TSO-B"})
    assert not [r for r in caplog.records if r.levelno == logging.WARNING]


# ---------------------------------------------------------------------------
# Pipeline-level wiring (real run on the mock inputs)
# ---------------------------------------------------------------------------

def test_a_bad_config_value_stops_the_import_of_the_pipeline(tmp_path):
    import shutil
    import subprocess
    root = Path(__file__).resolve().parents[1]
    shutil.copytree(root / "src", tmp_path / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(root / "pytest.ini", tmp_path / "pytest.ini")
    config_dir = tmp_path / "src" / "rao" / "config"
    text = (config_dir / "rao_config.default.yaml").read_text(encoding="utf-8")
    assert "max_change_ra: 1.0" in text
    (config_dir / "rao_config.yaml").write_text(text.replace("max_change_ra: 1.0", "max_change_ra: -1.0"),
                                                encoding="utf-8")
    result = subprocess.run(
        [sys.executable, "-I", "-B", "-c", "import sys; sys.path[:0] = ['.', 'pre_milp']; import run_pipeline"],
        cwd=tmp_path / "src" / "rao", capture_output=True, text=True, timeout=300,
    )
    assert result.returncode != 0
    assert "thresholds.max_change_ra" in result.stderr and "must be a number >= 0" in result.stderr



# ===========================================================================
# RD workflow gate
# ===========================================================================

def _unit(kind, available=True, mrid="RD1"):
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=available,
        kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )


# ---- 1. gate predicate -----------------------------------------------------

def test_gate_preventive_rd_opens_with_and_without_nx():
    for nx in (True, False):
        assert rd_inputs_required([_unit(RAKind.PREVENTIVE)], enable_nx_analysis=nx)


def test_gate_curative_only_rd_opens_only_with_nx():
    """Only a preventive unit opening the gate would leave curative-only RD without inputs."""
    assert rd_inputs_required([_unit(RAKind.CURATIVE)], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.CURATIVE)], enable_nx_analysis=False)


def test_gate_stays_closed_without_available_rd():
    assert not rd_inputs_required([], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.CURATIVE, available=False)], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.PREVENTIVE, available=False)], enable_nx_analysis=False)
