"""tests/test_rao_sensitivity_checks.py - unit tests for sensitivity_checks.py.

Sections: the guard rules and where the guard is called, reuse of the last valid sensitivities, and the guard tolerance.
"""

import pandas as pd
import sys
import pytest

from pre_milp import sensitivity_checks as sv, lf_parameters
from pathlib import Path
from data_model import AcVerificationStatus
from milp import ac_convergence_loop as acl
from helpers import Scenario

# ===========================================================================
# Guard rules
# ===========================================================================

SIDES = {"L1": 1, "L2": 2}


def _lf(**per_branch_currents):
    return {name: {1: value, 2: value} for name, value in per_branch_currents.items()}


# ---------------------------------------------------------------------------
# unit level: N-X
# ---------------------------------------------------------------------------

def test_a_matching_contingency_is_valid():
    lf = {"C1": _lf(L1=100.0, L2=50.0)}
    assert sv.find_invalid_nx_contingencies({"C1": {"L1": 100.0 + 1e-6, "L2": 50.0}}, set(), lf, SIDES) == {}


def test_a_zero_reference_with_a_non_zero_load_flow_is_invalid():
    lf = {"C1": _lf(L1=88.9, L2=50.0)}
    invalid = sv.find_invalid_nx_contingencies({"C1": {"L1": 0.0, "L2": 50.0}}, set(), lf, SIDES)
    assert list(invalid) == ["C1"] and "zero reference" in invalid["C1"]


def test_a_missing_reference_is_invalid():
    lf = {"C1": _lf(L1=100.0, L2=50.0)}
    invalid = sv.find_invalid_nx_contingencies({"C1": {"L2": 50.0}}, set(), lf, SIDES)
    assert list(invalid) == ["C1"] and "no reference" in invalid["C1"]


def test_a_branch_disconnected_by_the_contingency_has_no_reference_and_is_valid():
    lf = {"C1": _lf(L1=0.0, L2=50.0)}
    assert sv.find_invalid_nx_contingencies({"C1": {"L2": 50.0}}, set(), lf, SIDES) == {}


def test_a_contingency_without_any_reference_is_invalid():
    lf = {"C1": _lf(L1=100.0, L2=50.0)}
    assert list(sv.find_invalid_nx_contingencies({"C1": {}}, set(), lf, SIDES)) == ["C1"]


def test_a_deviation_beyond_the_tolerance_is_invalid_and_one_within_it_is_not():
    lf = {"C1": _lf(L1=100.0, L2=50.0)}
    inside = 100.0 * (1.0 + sv.NX_RELATIVE_TOLERANCE * 0.9)
    outside = 100.0 * (1.0 + sv.NX_RELATIVE_TOLERANCE * 1.1)
    assert sv.find_invalid_nx_contingencies({"C1": {"L1": inside, "L2": 50.0}}, set(), lf, SIDES) == {}
    assert list(sv.find_invalid_nx_contingencies({"C1": {"L1": outside, "L2": 50.0}}, set(), lf, SIDES)) == ["C1"]


def test_all_zero_sensitivities_with_a_non_zero_load_flow_current_are_invalid_even_if_the_reference_matches():
    lf = {"C1": _lf(L1=100.0, L2=50.0)}
    invalid = sv.find_invalid_nx_contingencies({"C1": {"L1": 100.0, "L2": 50.0}}, {"C1"}, lf, SIDES)
    assert list(invalid) == ["C1"] and "all sensitivities" in invalid["C1"]


def test_all_zero_sensitivities_with_an_unloaded_contingency_are_valid():
    lf = {"C1": _lf(L1=0.0, L2=0.5)}
    assert sv.find_invalid_nx_contingencies({"C1": {"L1": 0.0, "L2": 0.5}}, {"C1"}, lf, SIDES) == {}


def test_only_the_bad_contingency_is_reported():
    lf = {"C1": _lf(L1=100.0, L2=50.0), "C2": _lf(L1=100.0, L2=50.0)}
    reference = {"C1": {"L1": 100.0, "L2": 50.0}, "C2": {"L1": 0.0, "L2": 0.0}}
    assert list(sv.find_invalid_nx_contingencies(reference, set(), lf, SIDES)) == ["C2"]


# ---------------------------------------------------------------------------
# unit level: N-0 and the log
# ---------------------------------------------------------------------------

def test_n0_reference_agreeing_with_the_load_flow_is_valid_and_a_one_percent_deviation_is_not():
    lf = _lf(L1=100.0, L2=50.0)
    assert sv.find_invalid_n0_branches({"L1": 100.0 + 1e-9, "L2": 50.0}, lf, SIDES) == {}
    assert list(sv.find_invalid_n0_branches({"L1": 101.0, "L2": 50.0}, lf, SIDES)) == ["L1"]


def test_n0_zero_reference_is_invalid():
    assert list(sv.find_invalid_n0_branches({"L1": 0.0}, _lf(L1=100.0), SIDES)) == ["L1"]


def test_the_warning_lists_every_invalid_contingency(caplog):
    with caplog.at_level("WARNING"):
        sv.log_invalid("N-X", {"CO_A": "r1", "CO_B": "r2"}, "initial state")
    messages = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
    assert len(messages) == 1 and "CO_A" in messages[0] and "CO_B" in messages[0] and "initial state" in messages[0]


def test_nothing_is_logged_when_everything_is_valid(caplog):
    with caplog.at_level("WARNING"):
        sv.log_invalid("N-X", {}, "initial state")
    assert not caplog.records


# ---------------------------------------------------------------------------
# the four compute functions fill guard_out (fake pypowsybl)
# ---------------------------------------------------------------------------

def _install_with_references(monkeypatch, reference_value, sensitivity_value=1.0):
    from helpers import _Result, _install
    fake = _install(monkeypatch)
    reference = lambda: pd.DataFrame([[reference_value]], index=["reference_values"], columns=["b1"])
    fake.matrices["psdf_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    fake.matrices["ptdf_rd_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["g1"], columns=["b1"])
    fake.matrices[("nx_side1", "c1")] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    monkeypatch.setattr(
        _Result, "get_reference_matrix",
        lambda self, matrix_id, contingency_id=None: reference(), raising=True,
    )
    return fake


def _guarded_calls(monkeypatch, reference_value, sensitivity_value=1.0):
    """{function name: guard_out} for the four compute functions; lf current 100 A everywhere"""
    from pre_milp import n0_sensitivity, nx_sensitivity
    from helpers import _ae_lf_params as _ae, _co, _pst_lf_params as _pst, _rd_lf_params as _rd
    fake = _install_with_references(monkeypatch, reference_value, sensitivity_value)
    aes, lf_initial, lf_nx = [_ae("b1")], {"b1": {1: 100.0}}, {"c1": {"b1": {1: 100.0}}}
    guards = {name: {"stale": "marker"} for name in ("pst_n0", "rd_n0", "pst_nx", "rd_nx")}
    n0_sensitivity.compute_sensitivity_pst_n0(
        None, [_pst("p1")], aes, "1030Z", lf_initial=lf_initial, guard_out=guards["pst_n0"])
    n0_sensitivity.compute_sensitivity_rd_n0(
        None, [_rd("r1", "g1")], aes, "1030Z", lf_initial=lf_initial, guard_out=guards["rd_n0"])
    nx_sensitivity.compute_sensitivity_pst_nx(
        None, [_co("c1")], [_pst("p1")], aes, "1030Z", lf_nx=lf_nx, lf_initial=lf_initial, guard_out=guards["pst_nx"])
    fake.matrices[("nx_side1", "c1")] = pd.DataFrame([[sensitivity_value]], index=["g1"], columns=["b1"])
    nx_sensitivity.compute_sensitivity_rd_nx(
        None, [_co("c1")], [_rd("r1", "g1")], aes, "1030Z", lf_nx=lf_nx, lf_initial=lf_initial, guard_out=guards["rd_nx"])
    return guards


def test_every_compute_function_reports_nothing_when_the_reference_matches_the_load_flow(monkeypatch):
    assert _guarded_calls(monkeypatch, 100.0) == {name: {} for name in ("pst_n0", "rd_n0", "pst_nx", "rd_nx")}


def test_every_compute_function_reports_a_zero_reference(monkeypatch):
    guards = _guarded_calls(monkeypatch, 0.0)
    assert list(guards["pst_n0"]) == ["b1"] and list(guards["rd_n0"]) == ["b1"]
    assert list(guards["pst_nx"]) == ["c1"] and list(guards["rd_nx"]) == ["c1"]


def test_the_n_x_functions_report_all_zero_sensitivities_although_the_reference_matches(monkeypatch):
    guards = _guarded_calls(monkeypatch, 100.0, sensitivity_value=0.0)
    assert list(guards["pst_nx"]) == ["c1"] and list(guards["rd_nx"]) == ["c1"]
    assert guards["pst_n0"] == {} and guards["rd_n0"] == {}


def test_the_n_0_functions_report_nothing_without_a_load_flow_to_compare_with(monkeypatch):
    from pre_milp import n0_sensitivity
    from helpers import _ae_lf_params as _ae, _pst_lf_params as _pst
    _install_with_references(monkeypatch, 0.0)
    guard = {}
    n0_sensitivity.compute_sensitivity_pst_n0(None, [_pst("p1")], [_ae("b1")], "1030Z", guard_out=guard)
    assert guard == {}


# ===========================================================================
# Reuse of the last valid sensitivities
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


RULE = "zero reference current while the load flow current is 1100.0 A"


RUN_ON = {
    "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
    "max_change_overload": 0.0, "max_linearisation_iterations": 5,
}


def _tag(build_number):
    return 1.0 + 0.01 * build_number


def _nx_scenario(monkeypatch, invalid_builds=(), state_edit=None):
    """invalid_builds: build numbers whose N-X refresh the guard declares invalid for CO1"""
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides=dict(RUN_ON))
    state = scenario.new_state()
    if state_edit:
        state_edit(state)

    def compute(network, lf_nx):
        n = len(scenario.builds) + 1               # the refresh before build n
        invalid = n in invalid_builds
        factor = 0.0 if invalid else _tag(n)
        state.invalid_sensitivity_nx = {"CO1": RULE} if invalid else {}
        return (
            {"CO1": {k: v * factor for k, v in scenario.sens_pst_nx["CO1"].items()}},
            {"CO1": {k: v * factor for k, v in scenario.sens_rd_nx["CO1"].items()}},
        )

    original_hooks = scenario.hooks
    scenario.hooks = lambda: acl.NxLoopHooks(
        compute_lf_nx=original_hooks().compute_lf_nx, compute_sensitivities_nx=compute,
        find_new_pairs=lambda model, lf_nx: 0,
    )
    return scenario, state


def _built_nx(scenario, build_number):
    nx = scenario.builds[build_number - 1]["kwargs"]["nx_inputs"]
    return nx.sensitivity_pst_nx["CO1"], nx.sensitivity_rd_nx["CO1"]


def _expected(scenario, build_number):
    factor = _tag(build_number)
    return (
        {k: v * factor for k, v in scenario.sens_pst_nx["CO1"].items()},
        {k: v * factor for k, v in scenario.sens_rd_nx["CO1"].items()},
    )


# ============================================================ N-X: reuse
class TestNxReuse:
    def test_an_invalid_set_never_reaches_the_builder_the_stale_one_does(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(3,))
        scenario.run(state=state)
        assert len(scenario.builds) >= 4
        for n in range(2, len(scenario.builds) + 1):
            pst, rd = _built_nx(scenario, n)
            assert all(v != 0.0 for v in pst.values()) and all(v != 0.0 for v in rd.values()), f"build {n}"

    def test_invalid_at_solve_3_only_reuses_the_set_of_solve_2_and_solve_4_is_fresh_again(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(3,))
        scenario.run(state=state)
        assert _built_nx(scenario, 2) == _expected(scenario, 2)
        assert _built_nx(scenario, 3) == _expected(scenario, 2)       # stale: the one from solve 2
        assert _built_nx(scenario, 4) == _expected(scenario, 4)       # fresh again

    def test_consecutive_invalid_solves_keep_reusing_the_last_valid_set(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(3, 4, 5))
        scenario.run(state=state)
        assert len(scenario.builds) == 5
        for n in (3, 4, 5):
            assert _built_nx(scenario, n) == _expected(scenario, 2)

    def test_the_last_valid_set_is_the_latest_valid_one_not_the_one_reused_in_between(self, monkeypatch):
        # valid 2, invalid 3 (reuses 2), valid 4, invalid 5 -> must reuse 4, not 2 or 3
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(3, 5))
        scenario.run(state=state)
        assert _built_nx(scenario, 3) == _expected(scenario, 2)
        assert _built_nx(scenario, 4) == _expected(scenario, 4)
        assert _built_nx(scenario, 5) == _expected(scenario, 4)

    def test_the_initial_set_is_the_last_valid_one_before_any_refresh(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,))
        scenario.run(state=state)
        assert _built_nx(scenario, 2) == (scenario.sens_pst_nx["CO1"], scenario.sens_rd_nx["CO1"])

    def test_the_source_and_the_counts_are_recorded_per_solve(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(3, 4))
        scenario.run(state=state)
        counts = [row["stale_reused_sensitivity_contingencies"] for row in state.solve_history]
        assert counts[:5] == [0, 0, 1, 1, 0]
        assert [row["stale_reused_sensitivity_branches_n0"] for row in state.solve_history] == [0] * len(counts)
        assert state.sensitivity_source_nx == {"CO1": "fresh"}
        assert state.sensitivity_source_nx_ever == {"CO1": "stale_reused"}

    def test_a_healthy_run_records_fresh_only(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=())
        scenario.run(state=state)
        assert state.sensitivity_source_nx_ever.get("CO1", "fresh") == "fresh"
        assert all(row["stale_reused_sensitivity_contingencies"] == 0 for row in state.solve_history)


# ============================================================ N-X: stop
class TestNxStop:
    def test_no_earlier_valid_set_ends_the_loop_with_sensitivity_invalid_before_any_build(self, monkeypatch, caplog):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,), state_edit=lambda s: s.last_valid_sensitivity_nx.clear())
        with caplog.at_level("ERROR"):
            _, (_, model, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON
        assert AcVerificationStatus.from_termination_reason(reason) is AcVerificationStatus["SENSITIVITY_INVALID"]
        assert len(scenario.builds) == 1, "the build with the invalid set must not happen"
        assert model is not None, "the last applied model is still reported"
        assert "CO1" in state.sensitivity_failure and RULE in state.sensitivity_failure
        assert any("CO1" in r.getMessage() and RULE in r.getMessage() for r in caplog.records if r.levelname == "ERROR")

    def test_a_stored_set_whose_keys_no_longer_match_the_model_also_stops(self, monkeypatch):
        def break_keys(state):
            state.last_valid_sensitivity_nx["CO1"]["pst"][("B1", "PST_NOT_IN_THE_MODEL")] = -1.0
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,), state_edit=break_keys)
        _, (_, _, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON and len(scenario.builds) == 1
        assert "no longer match" in state.sensitivity_failure and "PST_NOT_IN_THE_MODEL" in state.sensitivity_failure

    def test_a_stored_set_with_an_unmonitored_branch_also_stops(self, monkeypatch):
        def break_keys(state):
            state.last_valid_sensitivity_nx["CO1"]["rd"][("B_NOT_MONITORED", "GU1")] = -1.0
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,), state_edit=break_keys)
        _, (_, _, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON and "B_NOT_MONITORED" in state.sensitivity_failure

    def test_a_stored_set_of_a_contingency_without_a_load_flow_also_stops(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,))
        original = scenario.hooks().compute_lf_nx
        scenario_hooks = scenario.hooks
        scenario.hooks = lambda: acl.NxLoopHooks(
            compute_lf_nx=lambda network: {"OTHER": scenario.grid.nx_lf()["CO1"]},
            compute_sensitivities_nx=scenario_hooks().compute_sensitivities_nx,
            find_new_pairs=lambda m, l: 0,
        )
        _, (_, _, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON and "load flow" in state.sensitivity_failure

    def test_the_completeness_loop_does_not_continue_after_the_stop(self, monkeypatch):
        scenario, state = _nx_scenario(monkeypatch, invalid_builds=(2,), state_edit=lambda s: s.last_valid_sensitivity_nx.clear())
        hooks = scenario.hooks()
        scenario.hooks = lambda: acl.NxLoopHooks(
            compute_lf_nx=hooks.compute_lf_nx, compute_sensitivities_nx=hooks.compute_sensitivities_nx,
            find_new_pairs=lambda model, lf_nx: 3,       # would ask for another completeness iteration
        )
        kwargs = scenario.loop_kwargs()
        _, _, _, reason, log_rows = acl.run_nested_rao_loop(
            max_completeness_iterations=3, state=state, nx_hooks=scenario.hooks(), **kwargs,
        )
        assert reason == acl.SENSITIVITY_INVALID_REASON
        assert len(scenario.builds) == 1 and len(log_rows) == 1


# ============================================================ N-0
def _n0_scenario(monkeypatch, invalid_builds=(), state_edit=None, kind="both"):
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides=dict(RUN_ON))
    state = scenario.new_state()
    if state_edit:
        state_edit(state)

    def make(base):
        def compute(**kwargs):
            n = len(scenario.builds) + 1
            invalid = n in invalid_builds
            guard = kwargs.get("guard_out")
            if guard is not None:
                guard.clear()
                if invalid:
                    guard["B1"] = RULE
            factor = _tag(n)
            return {k: (0.0 if (invalid and k[0] == "B1") else v * factor) for k, v in base.items()}
        return compute

    monkeypatch.setattr(acl, "compute_sensitivity_pst_n0", make(scenario.sens_pst_n0))
    monkeypatch.setattr(acl, "compute_sensitivity_rd_n0", make(scenario.sens_rd_n0))
    return scenario, state


def _built_n0(scenario, build_number):
    kwargs = scenario.builds[build_number - 1]["kwargs"]
    return kwargs["pst_inputs"].sensitivity_pst_n0_pruned, kwargs["rd_inputs"].sensitivity_rd_n0_pruned


class TestN0:
    def test_an_invalid_branch_gets_the_last_valid_pst_and_rd_sensitivities_and_the_others_stay_fresh(self, monkeypatch):
        scenario, state = _n0_scenario(monkeypatch, invalid_builds=(3,))
        scenario.run(state=state)
        pst2, rd2 = _built_n0(scenario, 2)
        pst3, rd3 = _built_n0(scenario, 3)
        assert pst3[("B1", "PST1")] == pst2[("B1", "PST1")] != 0.0
        assert rd3[("B1", "GU1")] == rd2[("B1", "GU1")] != 0.0
        assert pst3[("B2", "PST1")] == scenario.sens_pst_n0[("B2", "PST1")] * _tag(3)
        assert rd3[("B2", "GU2")] == scenario.sens_rd_n0[("B2", "GU2")] * _tag(3)
        pst4, _ = _built_n0(scenario, 4)
        assert pst4[("B1", "PST1")] == scenario.sens_pst_n0[("B1", "PST1")] * _tag(4)

    def test_consecutive_invalid_solves_and_an_intermediate_valid_one(self, monkeypatch):
        scenario, state = _n0_scenario(monkeypatch, invalid_builds=(3, 5))
        scenario.run(state=state)
        value = lambda n: _built_n0(scenario, n)[0][("B1", "PST1")]
        assert value(3) == value(2) and value(5) == value(4) != value(2)

    def test_counts_per_solve(self, monkeypatch):
        scenario, state = _n0_scenario(monkeypatch, invalid_builds=(3, 4))
        scenario.run(state=state)
        assert [row["stale_reused_sensitivity_branches_n0"] for row in state.solve_history][:5] == [0, 0, 1, 1, 0]
        assert [row["invalid_sensitivity_branches_n0"] for row in state.solve_history][:5] == [0, 0, 1, 1, 0]

    def test_no_earlier_valid_set_for_the_branch_stops_the_loop(self, monkeypatch, caplog):
        scenario, state = _n0_scenario(
            monkeypatch, invalid_builds=(2,), state_edit=lambda s: s.last_valid_sensitivity_n0_pst.clear(),
        )
        with caplog.at_level("ERROR"):
            _, (_, _, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON and len(scenario.builds) == 1
        assert "B1" in state.sensitivity_failure and RULE in state.sensitivity_failure
        assert any("B1" in r.getMessage() for r in caplog.records if r.levelname == "ERROR")

    def test_a_stored_branch_set_with_a_pst_that_is_no_longer_available_stops(self, monkeypatch):
        def break_keys(state):
            state.last_valid_sensitivity_n0_pst["B1"][("B1", "PST_GONE")] = -1.0
        scenario, state = _n0_scenario(monkeypatch, invalid_builds=(2,), state_edit=break_keys)
        _, (_, _, _, reason) = scenario.run(state=state)
        assert reason == acl.SENSITIVITY_INVALID_REASON and "PST_GONE" in state.sensitivity_failure


# ===========================================================================
# Guard tolerance
# ===========================================================================

# ------------------------------------------------------------------ guard tolerance
def _lf_contingency_propagation(**currents):
    return {branch: {1: current} for branch, current in currents.items()}


def test_a_deviation_just_above_the_nx_tolerance_is_flagged_and_just_below_is_not():
    lf = {"C1": _lf_contingency_propagation(L1=100.0, L2=50.0)}
    sides = {"L1": 1, "L2": 1}
    below = 100.0 * (1.0 + sv.NX_RELATIVE_TOLERANCE * 0.99)
    above = 100.0 * (1.0 + sv.NX_RELATIVE_TOLERANCE * 1.01)
    assert sv.find_invalid_nx_contingencies({"C1": {"L1": below, "L2": 50.0}}, set(), lf, sides) == {}
    assert list(sv.find_invalid_nx_contingencies({"C1": {"L1": above, "L2": 50.0}}, set(), lf, sides)) == ["C1"]


def test_the_nx_tolerance_is_one_percent():
    assert sv.NX_RELATIVE_TOLERANCE == 1e-2


def test_the_propagation_deviation_of_the_mock_case_is_flagged():
    """36 % (the largest mock deviation of the propagated security analysis) is far outside the tolerance"""
    lf = {"C1": _lf_contingency_propagation(L1=509.0)}
    reference = {"C1": {"L1": 692.5}}
    assert list(sv.find_invalid_nx_contingencies(reference, set(), lf, {"L1": 1})) == ["C1"]
