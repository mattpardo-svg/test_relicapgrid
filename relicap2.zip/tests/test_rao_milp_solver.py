"""tests/test_rao_milp_solver.py - tests for milp_solver.py.
"""

import sys
import types
import pytest

from pathlib import Path
from data_model import PST, RAKind, AEType
from milp.milp_solver import solve_n0_milp_model

class DummySolverResult:
    def __init__(self, termination_condition):
        self.solver = types.SimpleNamespace(termination_condition=termination_condition)


class DummySolver:
    def __init__(self, result):
        self._result = result

    def solve(self, model, tee=False, load_solutions=True):
        return self._result


@pytest.fixture(autouse=True)
def fake_pyomo(monkeypatch):
    fake_env = types.SimpleNamespace()
    fake_env.SolverFactory = lambda name, solver_io=None: DummySolver(DummySolverResult("optimal"))
    fake_env.value = lambda expr: expr
    monkeypatch.setitem(sys.modules, "pyomo", types.ModuleType("pyomo"))
    monkeypatch.setitem(sys.modules, "pyomo.environ", fake_env)
    return fake_env


class DummyModel:
    def __init__(self):
        self.tap_change_upward = {"p1": 2.0, "p2": 0.0}
        self.tap_change_downward = {"p1": 1.0, "p2": 0.0}
        self.overload_slack_n0 = {"b1": 0.0}
        self.branch_ids = ["b1"]
        self.secured_branch_ids = ["b1"]
        self.objective = 42.0
        self.solutions = types.SimpleNamespace(load_from=lambda results: None)


def test_solve_n0_milp_model_returns_pst_and_overload_results(tmp_path):
    model = DummyModel()
    pst_list = [
        PST("p1", "PST 1", "TSO", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, None),
    ]

    pst_results, overload_results = solve_n0_milp_model(
        milp_model=model,
        pst_list=pst_list,
        timestamp="1030Z",
        penalty_reference_pst_pra=100.0,
    )

    assert pst_results["p1"]["tap_change_result"] == 1.0
    assert pst_results["p1"]["current_tap_position"] == 0
    assert pst_results["p1"]["result_tap_position"] == 1.0
    assert pst_results["p1"]["penalty_cost_eur"] == 100.0
    assert overload_results["b1"] == 0.0


def test_solve_n0_milp_model_applies_tso_override_penalty_reference(tmp_path):
    model = DummyModel()
    pst_list = [
        PST("p1", "PST 1", "TSO-1", True, RAKind.PREVENTIVE, 2.0, -10, 10, 0, -10, 10, None),
        PST("p2", "PST 2", "TSO-2", True, RAKind.PREVENTIVE, 1.5, -10, 10, 0, -10, 10, None),
    ]

    pst_results, _ = solve_n0_milp_model(
        milp_model=model,
        pst_list=pst_list,
        timestamp="1030Z",
        penalty_reference_pst_pra=100.0,
        penalty_reference_pst_pra_per_tso={"TSO-1": 150.0},
    )

    assert pst_results["p1"]["penalty_reference_pst_pra"] == 150.0
    assert pst_results["p1"]["effective_penalty_cost_per_tap_eur"] == 300.0
    assert pst_results["p1"]["penalty_cost_eur"] == 300.0
    assert pst_results["p2"]["penalty_reference_pst_pra"] == 100.0
    assert pst_results["p2"]["effective_penalty_cost_per_tap_eur"] == 150.0




class TestRealSolve:
    """Real Pyomo and HiGHS: this class-level fixture of the same name replaces the module's
    autouse fake_pyomo for the tests of this class."""

    @pytest.fixture(autouse=True)
    def fake_pyomo(self):
        yield None

    def test_a_real_model_is_solved_and_its_tap_change_extracted(self):
        from data_model import AssessedElement
        from milp.milp_builder import PstMilpInputs, build_n0_milp_model
        ae = AssessedElement(
            mrid="AE1", name="AE1", tso="TSO", ae_type=AEType.SECURED, branch_mrid="B1",
            secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
            patl_ka={"1030Z": 1.0}, branch_side=1,
        )
        pst = PST("p1", "PST 1", "TSO", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, None)
        pst_inputs = PstMilpInputs(
            pst_list=[pst], pst_tap_bounds={"p1": (-10, 10)}, pst_group_equality_pairs=[],
            sensitivity_pst_n0_pruned={("B1", "p1"): -50.0}, pst_degrees_per_tap={"p1": 1.0},
            penalty_reference_pst_pra=1.0,
        )
        # 1120 A against 1000 A; -50 A per tap -> 3 taps up remove the overload at the lowest cost
        model = build_n0_milp_model([ae], "1030Z", {"B1": {1: 1120.0}}, 1000.0, pst_inputs=pst_inputs)
        pst_results, overload = solve_n0_milp_model(model, [pst], "1030Z", 1.0)
        assert pst_results["p1"]["tap_change_result"] == 3.0
        assert overload["B1"] == pytest.approx(0.0, abs=1e-6)
