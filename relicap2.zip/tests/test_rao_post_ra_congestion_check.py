"""Tests for post_ra_congestion_check.py: extracting the solution, applying and restoring it
on a real network, and finding new congested pairs.
"""

import pyomo.environ as pyo
import pytest

from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind
from milp import post_ra_congestion_check as cl

def _make_ae(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED):
    return AssessedElement(
        mrid=mrid, name="a", tso="TSO", ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


# ---------------------------------------------------------------------------
# extract_rd_target_p_solution
# ---------------------------------------------------------------------------

class TestExtractSolutions:
    def test_extract_rd_target_p_solution_adds_net_injection_to_target_p(self):
        model = pyo.ConcreteModel()
        model.gu_ids = pyo.Set(initialize=["GU1"])
        model.rd_net_injection_g = pyo.Expression(model.gu_ids, rule=lambda m, g: 7.5)

        generator_data = {"GU1": {"target_p": 50.0}}
        result = cl.extract_rd_target_p_solution(model, generator_data)

        assert result == {"GU1": 57.5}

    def test_extract_rd_target_p_solution_empty_without_preventive_rd_block(self):
        model = pyo.ConcreteModel()
        assert cl.extract_rd_target_p_solution(model, {}) == {}


# ---------------------------------------------------------------------------
# apply/restore — against a REAL pypowsybl synthetic network
# ---------------------------------------------------------------------------

class TestApplyRestoreRealNetwork:
    def test_apply_and_restore_pst_tap_and_generator_target_p(self):
        pp = pytest.importorskip("pypowsybl")
        network = pp.network.create_four_substations_node_breaker_network()

        original_tap = int(network.get_phase_tap_changers().loc["TWT", "tap"])
        gu_mrid = network.get_generators().index[0]
        original_target_p = float(network.get_generators().loc[gu_mrid, "target_p"])

        previous_taps, previous_target_p = cl.apply_preventive_solution_to_network(
            network,
            pst_tap_solution={"TWT": original_tap + 2},
            rd_target_p_solution={gu_mrid: original_target_p + 15.0},
        )

        assert int(network.get_phase_tap_changers().loc["TWT", "tap"]) == original_tap + 2
        assert float(network.get_generators().loc[gu_mrid, "target_p"]) == pytest.approx(original_target_p + 15.0)
        assert previous_taps == {"TWT": original_tap}
        assert previous_target_p[gu_mrid] == pytest.approx(original_target_p)

        cl.restore_network_state(network, previous_taps, previous_target_p)

        assert int(network.get_phase_tap_changers().loc["TWT", "tap"]) == original_tap
        assert float(network.get_generators().loc[gu_mrid, "target_p"]) == pytest.approx(original_target_p)

    def test_unknown_pst_mrid_skipped_not_crash(self):
        pp = pytest.importorskip("pypowsybl")
        network = pp.network.create_four_substations_node_breaker_network()

        previous_taps, _ = cl.apply_preventive_solution_to_network(
            network, pst_tap_solution={"NOT_A_REAL_PST": 5}, rd_target_p_solution={},
        )
        assert previous_taps == {}


# ---------------------------------------------------------------------------
# find_new_congested_pairs — the outage approximation's decision
# ---------------------------------------------------------------------------

def _lf_nx(current_a, branch="b1", co="co-1", side=1):
    return {co: {branch: {side: current_a}}}


class TestFindNewCongestedPairs:
    def test_detects_new_patl_congestion_not_already_constrained(self):
        new_patl, new_tatl, new_scanned = cl.find_new_congested_pairs(
            _lf_nx(1100.0), [_make_ae("ae-1", "b1", patl_ka=1.0)], "1030Z", set(), set(),
        )
        assert new_patl == {("b1", "co-1")} and new_tatl == set() and new_scanned == set()

    def test_does_not_report_an_already_constrained_pair_as_new(self):
        new_patl, _, _ = cl.find_new_congested_pairs(
            _lf_nx(1100.0), [_make_ae("ae-1", "b1", patl_ka=1.0)], "1030Z", {("b1", "co-1")}, set(),
        )
        assert new_patl == set()

    def test_no_congestion_below_patl(self):
        assert cl.find_new_congested_pairs(
            _lf_nx(500.0), [_make_ae("ae-1", "b1", patl_ka=1.0)], "1030Z", set(), set(),
        ) == (set(), set(), set())

    def test_detects_new_tatl_congestion_only(self):
        tatl_data = {"b1": {"tatl_limit_ampere": 900.0, "tatl_duration_seconds": 1200, "side": 1}}
        new_patl, new_tatl, _ = cl.find_new_congested_pairs(
            _lf_nx(950.0), [_make_ae("ae-1", "b1", patl_ka=2.0)], "1030Z", set(), set(), tatl_data=tatl_data,
        )
        assert new_patl == set() and new_tatl == {("b1", "co-1")}

    def test_a_tatl_pair_already_constrained_is_not_new(self):
        tatl_data = {"b1": {"tatl_limit_ampere": 900.0, "tatl_duration_seconds": 1200, "side": 1}}
        _, new_tatl, _ = cl.find_new_congested_pairs(
            _lf_nx(950.0), [_make_ae("ae-1", "b1", patl_ka=2.0)], "1030Z", set(), {("b1", "co-1")}, tatl_data=tatl_data,
        )
        assert new_tatl == set()

    def test_the_current_of_the_monitored_side_is_compared(self):
        ae = [_make_ae("ae-1", "b1", branch_side=2, patl_ka=1.0)]
        lf_nx = {"co-1": {"b1": {1: 1500.0, 2: 800.0}}}
        assert cl.find_new_congested_pairs(lf_nx, ae, "1030Z", set(), set())[0] == set()

    def test_a_scanned_branch_is_not_counted_as_patl_congestion(self):
        """Its raw patl_ka is not its limit: 1200 A over patl_ka 1000 A must not be a PATL pair."""
        scanned = _make_ae("ae-s", "b-scanned", patl_ka=1.0, ae_type=AEType.SCANNED)
        new_patl, _, _ = cl.find_new_congested_pairs(_lf_nx(1200.0, "b-scanned"), [scanned], "1030Z", set(), set())
        assert new_patl == set()

    def test_a_secured_branch_under_the_same_overload_is_counted(self):
        secured = _make_ae("ae-1", "b-secured", patl_ka=1.0, ae_type=AEType.SECURED)
        new_patl, _, _ = cl.find_new_congested_pairs(_lf_nx(1200.0, "b-secured"), [secured], "1030Z", set(), set())
        assert new_patl == {("b-secured", "co-1")}

    def test_a_scanned_branch_under_its_effective_limit_is_not_new_scanned_congestion(self):
        scanned = _make_ae("ae-s", "b-scanned", patl_ka=1.0, ae_type=AEType.SCANNED)
        lf_initial = {"b-scanned": {1: 1400.0}}      # effective limit = max(1000, 1400) = 1400 A
        _, _, new_scanned = cl.find_new_congested_pairs(
            _lf_nx(1200.0, "b-scanned"), [scanned], "1030Z", set(), set(), lf_initial=lf_initial,
        )
        assert new_scanned == set()

    def test_a_scanned_branch_over_its_effective_limit_is_new_scanned_congestion(self):
        scanned = _make_ae("ae-s", "b-scanned", patl_ka=1.0, ae_type=AEType.SCANNED)
        lf_initial = {"b-scanned": {1: 1050.0}}      # effective limit = 1050 A
        _, _, new_scanned = cl.find_new_congested_pairs(
            _lf_nx(1200.0, "b-scanned"), [scanned], "1030Z", set(), set(), lf_initial=lf_initial,
        )
        assert new_scanned == {("b-scanned", "co-1")}

    def test_an_already_constrained_scanned_pair_is_not_new(self):
        scanned = _make_ae("ae-s", "b-scanned", patl_ka=1.0, ae_type=AEType.SCANNED)
        _, _, new_scanned = cl.find_new_congested_pairs(
            _lf_nx(1200.0, "b-scanned"), [scanned], "1030Z", set(), set(),
            current_scanned_pairs={("b-scanned", "co-1")}, lf_initial={"b-scanned": {1: 1050.0}},
        )
        assert new_scanned == set()
