"""tests/test_rao_cra_preprocessing.py - tests for cra_preprocessing.py (curative PST availability and curative PST groups) and for the PST tap bounds and group pairs (pst_bounds.py, pst_groups.py).

Sections: curative PST groups, curative tap bounds fallback, preventive tap bounds and group pairs, curative PST availability.
"""

import logging
import sys
import pytest
import pyomo.environ as pyo

from pathlib import Path
from data_model import (
    AcVerificationStatus,
    Contingency,
    ContingencyType,
    RAKind,
    PST,
    AEType,
    AssessedElement,
    BidDirection,
    PowerBid,
    RDUnit,
)
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
from post_milp.n0_results_export import (
    extract_curative_pst_group_results,
    write_curative_pst_group_results_csv,
)
from pre_milp.cra_preprocessing import (
    compute_pst_cra_availability,
    build_curative_pst_group_constraints,
    validate_pst_group_kind,
    write_pst_cra_availability_csv,
)
from helpers import (
    _make_ae,
    _make_pst,
    GROUP,
    PENALTY_REFERENCE,
    TATL,
    _bounds,
    _contingency,
    _group_pst,
    _solve_group_model,
    _three_psts,
)
from pre_milp.pst_bounds import build_curative_tap_bounds_with_fallback, build_pst_tap_bounds
from pre_milp.pst_groups import build_pst_group_equality_pairs

# ---- outage-element exclusion in compute_pst_cra_availability --------------

def test_pst_that_is_an_outage_element_is_not_a_curative_ra_in_that_contingency():
    """A tripped PST is not available as a curative RA for its own outage."""
    psts = [_group_pst("P1", group_id=None, contingencies=("CO1", "CO2")),
            _group_pst("P2", group_id=None, contingencies=("CO1", "CO2"))]
    contingencies = [_contingency("CO1", tripped=["P1"]), _contingency("CO2")]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    assert ("P1", "B1", "CO1") not in availability       # tripped in CO1
    assert availability[("P1", "B1", "CO2")]["available"]  # fine in CO2
    assert availability[("P2", "B1", "CO1")]["available"]  # other PST unaffected


def test_availability_is_unchanged_without_contingencies_argument():
    psts = [_group_pst("P1", group_id=None)]
    assert compute_pst_cra_availability(psts, TATL) == compute_pst_cra_availability(psts, TATL, contingencies=[])


# ---- group builder ----------------------------------------------------------


def test_group_builder_makes_all_unique_pairs_for_the_contingency():
    psts = _three_psts()
    availability = compute_pst_cra_availability(psts, TATL, contingencies=[_contingency("CO1")])
    filtered, triples = build_curative_pst_group_constraints(
        psts, availability, _bounds(), [_contingency("CO1")], "blockedGroup",
    )
    assert filtered == availability
    assert triples == [("G1", "G2", "CO1"), ("G1", "G3", "CO1"), ("G2", "G3", "CO1")]


def test_psts_without_group_id_get_no_pairs_and_availability_is_untouched():
    psts = [_group_pst(m, group_id=None) for m in ("A", "B")]
    availability = compute_pst_cra_availability(psts, TATL)
    filtered, triples = build_curative_pst_group_constraints(
        psts, availability, _bounds(mrids=("A", "B")), [_contingency("CO1")], "blockedGroup",
    )
    assert triples == [] and filtered == availability


def test_no_common_delta_excludes_the_whole_group_and_logs(caplog):
    """G1 may only move -10..-5, G2 only +5..+10: no common rectified delta."""
    psts = _three_psts()
    availability = compute_pst_cra_availability(psts, TATL, contingencies=[_contingency("CO1")])
    bounds = {"G1": (-10, -5), "G2": (5, 10), "G3": (-10, 10)}
    with caplog.at_level(logging.WARNING):
        filtered, triples = build_curative_pst_group_constraints(
            psts, availability, bounds, [_contingency("CO1")], "blockedGroup",
        )
    assert triples == []
    assert not any(co == "CO1" for (_p, _x, co) in filtered)
    assert any("no common" in r.getMessage().lower() and GROUP in r.getMessage() for r in caplog.records)


def test_common_delta_is_judged_on_headroom_from_the_current_tap():
    """Absolute bounds -10..10 but G1 sits at tap 8 (headroom -18..+2) and G2 at
    tap -8 (headroom -2..+18): common delta -2..+2 exists. G3 at tap 10 with
    bounds 10..10 adds headroom 0..0: still common (0)."""
    psts = [_group_pst("G1", r0=8), _group_pst("G2", r0=-8), _group_pst("G3", r0=10)]
    availability = compute_pst_cra_availability(psts, TATL)
    bounds = {"G1": (-10, 10), "G2": (-10, 10), "G3": (10, 10)}
    _filtered, triples = build_curative_pst_group_constraints(psts, availability, bounds, [], "blockedGroup")
    assert len(triples) == 3
    bounds["G3"] = (9, 9)  # headroom -1..-1, inside G1 (-10..2) and G2 (-2..10): common delta -1
    _f, triples2 = build_curative_pst_group_constraints(psts, availability, bounds, [], "blockedGroup")
    assert len(triples2) == 3
    bounds["G3"] = (-10, -9)  # headroom -20..-19 vs G2 -2..18: none
    filtered3, triples3 = build_curative_pst_group_constraints(psts, availability, bounds, [], "blockedGroup")
    assert triples3 == [] and not filtered3


def test_outage_member_reduced_group_keeps_remaining_psts_as_a_group():
    psts = _three_psts()
    contingencies = [_contingency("CO1", tripped=["G3"])]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    filtered, triples = build_curative_pst_group_constraints(
        psts, availability, _bounds(), contingencies, "reducedGroup",
    )
    assert triples == [("G1", "G2", "CO1")]
    assert {p for (p, _x, co) in filtered if co == "CO1"} == {"G1", "G2"}


def test_outage_member_blocked_group_makes_all_three_unavailable():
    psts = _three_psts()
    contingencies = [_contingency("CO1", tripped=["G3"])]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    filtered, triples = build_curative_pst_group_constraints(
        psts, availability, _bounds(), contingencies, "blockedGroup",
    )
    assert triples == []
    assert not any(co == "CO1" for (_p, _x, co) in filtered)


def test_blocked_group_only_blocks_the_contingency_with_the_outage():
    psts = _three_psts(contingencies=("CO1", "CO2"))
    contingencies = [_contingency("CO1", tripped=["G3"]), _contingency("CO2")]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    filtered, triples = build_curative_pst_group_constraints(
        psts, availability, _bounds(), contingencies, "blockedGroup",
    )
    assert {co for (_p, _x, co) in filtered} == {"CO2"}
    assert {co for (_a, _b, co) in triples} == {"CO2"} and len(triples) == 3


def _two_tso_groups():
    """Group GA (TSO_A: A1-A3) and group GB (TSO_B: B1-B3); CO1 trips A3 and B3."""
    psts = []
    for tso, group_id, prefix in (("TSO_A", "GA", "A"), ("TSO_B", "GB", "B")):
        for i in (1, 2, 3):
            pst = _group_pst(f"{prefix}{i}", group_id=group_id)
            pst.tso = tso
            psts.append(pst)
    return psts


def _two_tso_run(per_tso, default="blockedGroup"):
    psts = _two_tso_groups()
    contingencies = [_contingency("CO1", tripped=["A3", "B3"])]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    bounds = _bounds(mrids=[p.mrid for p in psts])
    return build_curative_pst_group_constraints(psts, availability, bounds, contingencies, default, per_tso)


def test_two_tsos_with_different_group_kinds_in_one_run():
    """Per-TSO PSTGroupKind: TSO_A keeps the default (blocked), TSO_B is overridden to reduced."""
    filtered, triples = _two_tso_run({"TSO_B": "reducedGroup"})
    assert not any(p.startswith("A") for (p, _x, _co) in filtered)          # group GA blocked entirely
    assert {p for (p, _x, _co) in filtered} == {"B1", "B2"}                 # GB: tripped B3 gone, rest kept
    assert triples == [("B1", "B2", "CO1")]                                 # GB's remaining two still equal


def test_per_tso_override_can_also_block_while_default_is_reduced():
    filtered, triples = _two_tso_run({"TSO_B": "blockedGroup"}, default="reducedGroup")
    assert not any(p.startswith("B") for (p, _x, _co) in filtered)
    assert triples == [("A1", "A2", "CO1")]


def test_without_override_map_the_default_applies_to_every_tso():
    _filtered, triples = _two_tso_run(None)
    assert triples == []                                                    # both groups blocked
    _filtered, triples = _two_tso_run({}, default="reducedGroup")
    assert triples == [("A1", "A2", "CO1"), ("B1", "B2", "CO1")]


def test_invalid_per_tso_kind_is_rejected():
    with pytest.raises(ValueError):
        _two_tso_run({"TSO_B": "nonsense"})


def test_group_kind_value_is_validated():
    assert validate_pst_group_kind("reducedGroup") == "reducedGroup"
    assert validate_pst_group_kind("blockedGroup") == "blockedGroup"
    with pytest.raises(ValueError):
        validate_pst_group_kind("somethingElse")


# ---- MILP: the equality constraint ------------------------------------------


def _delta(model, m):
    return (pyo.value(model.curative_tap_change_upward[m, "CO1"])
            - pyo.value(model.curative_tap_change_downward[m, "CO1"]))


def test_group_members_get_the_same_curative_delta_tap():
    """Only G1 can relieve the 50 A overload (-10 A/tap). Without the group
    constraint G1 moves alone (cost 5 taps x 10 = 50); with it all three move
    the same 5 taps (cost 150)."""
    model, triples = _solve_group_model({"G1": -10.0, "G2": 0.0, "G3": 0.0})
    assert len(triples) == 3
    assert _delta(model, "G1") == pytest.approx(5.0, abs=1e-6)
    assert _delta(model, "G2") == pytest.approx(5.0, abs=1e-6)
    assert _delta(model, "G3") == pytest.approx(5.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(150.0, abs=1e-6)


def test_group_constraint_has_one_row_per_pair_and_contingency():
    model, _ = _solve_group_model({"G1": -10.0, "G2": 0.0, "G3": 0.0})
    assert len(model.curative_pst_group_equality) == 3


def test_excluded_group_cannot_relieve_the_overload():
    bounds = {"G1": (-10, -5), "G2": (5, 10), "G3": (-10, 10)}
    model, triples = _solve_group_model({"G1": -10.0, "G2": 0.0, "G3": 0.0}, bounds=bounds)
    assert triples == []
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_reduced_group_remaining_two_move_equally_in_the_model():
    model, triples = _solve_group_model(
        {"G1": -10.0, "G2": 0.0, "G3": -10.0}, group_kind="reducedGroup", tripped=["G3"],
    )
    assert triples == [("G1", "G2", "CO1")]
    assert _delta(model, "G1") == pytest.approx(_delta(model, "G2"), abs=1e-6)
    assert _delta(model, "G1") == pytest.approx(5.0, abs=1e-6)
    assert ("G3", "CO1") not in list(model.curative_pst_contingency_pairs)


def test_blocked_group_all_three_unavailable_in_the_model():
    model, _ = _solve_group_model({"G1": -10.0, "G2": -10.0, "G3": -10.0}, tripped=["G3"])
    assert not hasattr(model, "curative_pst_contingency_pairs")
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


# ---- RAO result log ---------------------------------------------------------

def test_group_tap_change_is_reported_per_group_and_contingency(tmp_path):
    model, triples = _solve_group_model({"G1": -10.0, "G2": 0.0, "G3": 0.0})
    psts = _three_psts()
    results = extract_curative_pst_group_results(model, triples, psts)
    row = results[(GROUP, "CO1")]
    assert row["pst_mrids"] == ["G1", "G2", "G3"]
    assert row["group_delta_tap"] == pytest.approx(5.0, abs=1e-6)
    out = tmp_path / "results_curative_pst_groups.csv"
    write_curative_pst_group_results_csv(results, out, "1030Z", AcVerificationStatus.NOT_APPLICABLE, "n/a")
    lines = out.read_text(encoding="utf-8").strip().splitlines()
    assert lines[0].split(",")[:4] == ["group_id", "contingency_mrid", "pst_mrids", "group_delta_tap"]
    assert len(lines) == 2


def test_group_results_header_only_when_no_groups(tmp_path):
    out = tmp_path / "results_curative_pst_groups.csv"
    assert extract_curative_pst_group_results(object(), [], []) == {}
    write_curative_pst_group_results_csv({}, out, "1030Z", AcVerificationStatus.NOT_APPLICABLE, "n/a")
    assert len(out.read_text(encoding="utf-8").strip().splitlines()) == 1


# ===========================================================================
# Curative tap bounds fallback
# ===========================================================================

def _pst(kind, lo, hi, mrid="T1"):
    pst = _make_pst(mrid, kind)
    pst.operating_tap_min, pst.operating_tap_max = lo, hi
    return pst


def test_curative_pst_uses_its_own_range_not_the_preventive_ones():
    preventive = _pst(RAKind.PREVENTIVE, -20, 20)
    curative = _pst(RAKind.CURATIVE, -5, 5)
    for pst_list in ([preventive, curative], [curative, preventive]):
        bounds = build_curative_tap_bounds_with_fallback(
            [p for p in pst_list if p.kind == RAKind.CURATIVE], {},
        )
        assert bounds == {"T1": (-5, 5)}


def test_explicit_range_constraint_wins_over_fallback():
    curative = _pst(RAKind.CURATIVE, -5, 5)
    assert build_curative_tap_bounds_with_fallback([curative], {"T1": (-3, 4)}) == {"T1": (-3, 4)}


def test_fallback_count_is_logged_once(caplog):
    psts = [_pst(RAKind.CURATIVE, -5, 5, "A"), _pst(RAKind.CURATIVE, -6, 6, "B"), _pst(RAKind.CURATIVE, -7, 7, "C")]
    with caplog.at_level(logging.INFO):
        build_curative_tap_bounds_with_fallback(psts, {"C": (-1, 1)})
    msgs = [r.getMessage() for r in caplog.records if "fallback" in r.getMessage()]
    assert len(msgs) == 1
    assert "2 of 3" in msgs[0]


# ===========================================================================
# Preventive PST tap bounds and group pairs, curative PST availability
# ===========================================================================

class TestBuildPstTapBounds:
    def test_hardware_and_operating_limits_applied(self):
        pst = PST(
            mrid="pst-1",
            name="PST 1",
            tso="TSO-Belgovia",
            available=True,
            kind=RAKind.PREVENTIVE,
            penalty_factor=0.5,
            low_step=-17,
            high_step=17,
            r0=0,
            operating_tap_min=-10,
            operating_tap_max=10,
            group_id=None,
        )
        bounds = build_pst_tap_bounds([pst])
        assert bounds["pst-1"] == (-10, 10)

    def test_relative_limits_applied(self):
        pst = PST(
            mrid="pst-2",
            name="PST 2",
            tso="TSO-Belgovia",
            available=True,
            kind=RAKind.PREVENTIVE,
            penalty_factor=0.5,
            low_step=-20,
            high_step=20,
            r0=5,
            operating_tap_min=-20,
            operating_tap_max=20,
            group_id=None,
        )
        pst.low_step_relative = -3
        pst.high_step_relative = 4

        bounds = build_pst_tap_bounds([pst])
        assert bounds["pst-2"] == (2, 9)

    def test_effective_bounds_clamped_to_hardware_limits(self):
        pst = PST(
            mrid="pst-3",
            name="PST 3",
            tso="TSO-Belgovia",
            available=True,
            kind=RAKind.PREVENTIVE,
            penalty_factor=0.5,
            low_step=-5,
            high_step=5,
            r0=0,
            operating_tap_min=-10,
            operating_tap_max=10,
            group_id=None,
        )
        pst.low_step_relative = -20
        pst.high_step_relative = 20

        bounds = build_pst_tap_bounds([pst])
        assert bounds["pst-3"] == (-5, 5)

    def test_warning_when_current_outside_effective_bounds(self, caplog):
        pst = PST(
            mrid="pst-4",
            name="PST 4",
            tso="TSO-Belgovia",
            available=True,
            kind=RAKind.PREVENTIVE,
            penalty_factor=0.5,
            low_step=-10,
            high_step=10,
            r0=15,
            operating_tap_min=-10,
            operating_tap_max=10,
            group_id=None,
        )

        caplog.set_level("WARNING")
        bounds = build_pst_tap_bounds([pst])
        assert bounds["pst-4"] == (-10, 10)
        assert "current tap 15 outside effective bounds" in caplog.text


class TestBuildPstGroupEqualityPairs:
    def test_empty_when_no_groups(self):
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, None),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, None),
        ]
        pairs = build_pst_group_equality_pairs(pst_list, {pst.mrid: (-10, 10) for pst in pst_list})
        assert pairs == []

    def test_valid_group_builds_pairs(self):
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
        ]
        pairs = build_pst_group_equality_pairs(pst_list, {"pst-1": (-10, 10), "pst-2": (-10, 10)})
        assert pairs == [("pst-1", "pst-2")]

    def test_excludes_group_when_unavailable(self, caplog):
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", False, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
        ]
        caplog.set_level("WARNING")
        pairs = build_pst_group_equality_pairs(pst_list, {"pst-1": (-10, 10), "pst-2": (-10, 10)})
        assert pairs == []
        assert "excluded because unavailable PSTs present" in caplog.text

    def test_excludes_group_when_bounds_empty(self, caplog):
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, -5, "group-1"),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, 5, 10, "group-1"),
        ]
        caplog.set_level("WARNING")
        pairs = build_pst_group_equality_pairs(pst_list, {"pst-1": (-10, -5), "pst-2": (5, 10)})
        assert pairs == []
        assert "effective group range" in caplog.text

    def test_excludes_group_when_member_missing_from_pst_tap_bounds(self, caplog):
        """A group member excluded by build_pst_tap_bounds (empty effective range) excludes
        the group too; its hardware limits are not used as a fallback."""
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
        ]
        # pst-2 absent from pst_tap_bounds, as if build_pst_tap_bounds excluded it
        caplog.set_level("WARNING")
        pairs = build_pst_group_equality_pairs(pst_list, {"pst-1": (-10, 10)})
        assert pairs == []
        assert "no valid tap bounds" in caplog.text
        assert "pst-2" in caplog.text

    def test_builds_all_unique_pairs_for_group(self):
        pst_list = [
            PST("pst-1", "PST 1", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
            PST("pst-2", "PST 2", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
            PST("pst-3", "PST 3", "TSO-Belgovia", True, RAKind.PREVENTIVE, 1.0, -10, 10, 0, -10, 10, "group-1"),
        ]
        pairs = build_pst_group_equality_pairs(pst_list, {
            "pst-1": (-10, 10),
            "pst-2": (-10, 10),
            "pst-3": (-10, 10),
        })
        assert pairs == [
            ("pst-1", "pst-2"),
            ("pst-1", "pst-3"),
            ("pst-2", "pst-3"),
        ]


def _make_curative_pst(
    mrid="pst1", reaction_time_minutes=3.0, time_per_stage_minutes=2.0,
    linked_contingency_mrids=None, available=True,
):
    return PST(
        mrid=mrid, name="p", tso="T", available=available, kind=RAKind.CURATIVE,
        penalty_factor=0.0, low_step=-10, high_step=10, r0=0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
        reaction_time_minutes=reaction_time_minutes,
        time_per_stage_minutes=time_per_stage_minutes,
        linked_contingency_mrids=["co1"] if linked_contingency_mrids is None else linked_contingency_mrids,
    )


class TestComputePstCraAvailability:
    def test_acceptance_criteria_example_from_spec(self):
        """time_per_stage 2 min, TATL 300 s (5 min), reaction 3 min ->
        max_curative_taps = floor((5 - 3) / 2) = 1, available."""
        pst = _make_curative_pst(reaction_time_minutes=3.0, time_per_stage_minutes=2.0)
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result[("pst1", "xne1", "co1")] == {"max_curative_taps": 1, "available": True}

    def test_max_curative_taps_zero_or_negative_is_not_available(self):
        """Given not enough time even for one stage (reaction time alone
        exceeds the TATL window), When availability is computed, Then
        max_curative_taps <= 0 AND available == False."""
        pst = _make_curative_pst(reaction_time_minutes=10.0, time_per_stage_minutes=2.0)
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}  # 5 min

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result[("pst1", "xne1", "co1")]["available"] is False
        assert result[("pst1", "xne1", "co1")]["max_curative_taps"] <= 0

    def test_missing_timing_data_skips_pst_entirely(self):
        """A curative PST without reaction_time_minutes contributes no entries (no
        defaulted 0-tap result)."""
        pst = _make_curative_pst(reaction_time_minutes=None, time_per_stage_minutes=2.0)
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result == {}

    def test_pst_with_no_linked_contingency_contributes_nothing(self):
        pst = _make_curative_pst(linked_contingency_mrids=[])
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result == {}

    def test_preventive_pst_contributes_nothing(self):
        """Only curative PSTs are considered — a preventive PST (even one
        with linked_contingency_mrids somehow set) contributes nothing."""
        pst = PST(
            mrid="pst1", name="p", tso="T", available=True, kind=RAKind.PREVENTIVE,
            penalty_factor=0.0, low_step=-10, high_step=10, r0=0,
            operating_tap_min=-10, operating_tap_max=10, group_id=None,
            reaction_time_minutes=3.0, time_per_stage_minutes=2.0,
            linked_contingency_mrids=["co1"],
        )
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result == {}

    def test_unavailable_curative_pst_contributes_nothing(self):
        pst = _make_curative_pst(available=False)
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert result == {}

    def test_one_pst_linked_to_multiple_contingencies_gets_entry_per_contingency(self):
        pst = _make_curative_pst(linked_contingency_mrids=["co1", "co2"])
        tatl_data = {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}}

        result = compute_pst_cra_availability([pst], tatl_data)

        assert set(result.keys()) == {("pst1", "xne1", "co1"), ("pst1", "xne1", "co2")}

    def test_one_pst_gets_entry_per_tatl_bearing_xne(self):
        pst = _make_curative_pst()
        tatl_data = {
            "xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1},
            "xne2": {"tatl_limit_ampere": 900.0, "tatl_duration_seconds": 600, "side": 2},
        }

        result = compute_pst_cra_availability([pst], tatl_data)

        assert set(result.keys()) == {("pst1", "xne1", "co1"), ("pst1", "xne2", "co1")}
        # xne2 has a longer TATL window -> floor((10-3)/2) = 3
        assert result[("pst1", "xne2", "co1")]["max_curative_taps"] == 3

    def test_empty_tatl_data_contributes_nothing(self):
        pst = _make_curative_pst()
        result = compute_pst_cra_availability([pst], {})
        assert result == {}

    def test_no_curative_psts_at_all_returns_empty(self):
        result = compute_pst_cra_availability([], {"xne1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 300, "side": 1}})
        assert result == {}


# ---------------------------------------------------------------------------
# write_pst_cra_availability_csv
# ---------------------------------------------------------------------------

class TestWritePstCraAvailabilityCsv:
    def test_writes_header_and_rows(self, tmp_path):
        pst_cra_availability = {("pst1", "xne1", "co1"): {"max_curative_taps": 1, "available": True}}
        output_path = tmp_path / "pst_cra_availability.csv"
        write_pst_cra_availability_csv(pst_cra_availability, output_path)
        content = output_path.read_text(encoding="utf-8")
        lines = content.splitlines()
        assert lines[0] == "pst_mrid,branch_mrid,contingency_mrid,max_curative_taps,available"
        assert "pst1,xne1,co1,1,True" in lines[1]

    def test_empty_input_still_writes_header_only(self, tmp_path):
        output_path = tmp_path / "pst_cra_availability.csv"
        write_pst_cra_availability_csv({}, output_path)
        content = output_path.read_text(encoding="utf-8")
        assert len(content.splitlines()) == 1
