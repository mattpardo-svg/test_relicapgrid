"""tests/test_rao_run_pipeline_end_to_end.py - tests that run run_pipeline.main() on the
fixtures (the ReliCapGrid case and the mock cases): real-dataset runs, the operating point of the loop, the
sensitivity guard in a full run, curative RD without preventive RD, the lf_nx baseline of
the export, the results summary identity, unknown TSO in the overrides.
"""

import csv
import importlib
import sys
import pytest
import pandas as pd
import shutil
import pyomo.environ as pyo

from pathlib import Path
from types import SimpleNamespace
from helpers import (
    _MOCK_NX_NCP_ZIP,
    run_pipeline_on_fixture_inputs,
    _bid_rd_cost as _bid,
    _unit,
    _make_ae,
    _make_pst,
    REFERENCE_PST,
    REFERENCE_RD,
    _all_terms_scenario,
    FIXTURE_CGM_ZIP,
    fixture_instance_root,
)
from pre_milp import sensitivity_checks as sv
from data_model import BidDirection, PowerBid, RAKind, RDUnit, AcVerificationStatus
from milp import ac_convergence_loop as acl
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from post_milp.n0_results_export import (
    extract_curative_rd_results,
    extract_rd_results,
    extract_results_summary,
    write_results_summary_csv,
)

def _find_repo_root(start: Path) -> Path:
    """Walk upward from `start` to the first directory containing src/rao/data_model.py (a
    fixed-location marker, as in run_pipeline._find_repo_root)."""
    candidate = start.resolve()
    for _ in range(8):
        if (candidate / "src" / "rao" / "data_model.py").is_file():
            return candidate
        if candidate.parent == candidate:
            break
        candidate = candidate.parent
    raise RuntimeError(
        f"Could not locate the repo root (a directory containing "
        f"src/rao/data_model.py) by walking up from {start} — "
        f"checked up to 8 parent directories. If the repo layout has "
        f"changed, this search depth may need increasing."
    )


REPO_ROOT = _find_repo_root(Path(__file__).parent)


SRC_ROOT = REPO_ROOT / "src" / "rao"


DATA_ROOT = fixture_instance_root()


@pytest.fixture
def run_pipeline_module(tmp_path, monkeypatch, real_input_folder):
    """Fresh import of run_pipeline with OUTPUT_DIR redirected to a tmp
    directory, so tests never write into (or depend on) the repo's real
    output/ directory."""
    # SRC_ROOT and REPO_ROOT on sys.path again, in case test ordering changed it
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))

    import run_pipeline as rp
    importlib.reload(rp)
    monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path)
    # main() reads only input/: real_input_folder (conftest.py) builds it from tests/fixtures
    monkeypatch.setattr(rp, "INPUT_DIR", real_input_folder)
    return rp


# ---------------------------------------------------------------------------
# Regression: ENABLE_NX_ANALYSIS=False (the default) is unaffected
# ---------------------------------------------------------------------------

class TestRdOnlyOutputWhenNxDisabled:
    def test_default_run_produces_identical_rd_only_output(self, run_pipeline_module, tmp_path):
        """With ENABLE_NX_ANALYSIS forced off, main() produces the RD-only preventive output:
        no N-X artifacts (no preventive PSTs, RD block empty via the GLSK guard, optimal).
        The flag is set explicitly, not read from the file's default."""
        run_pipeline_module.ENABLE_NX_ANALYSIS = False

        run_pipeline_module.main()

        assert (tmp_path / "results_preventive_rd.csv").exists()
        assert not (tmp_path / "sensitivity_pst_nx.csv").exists()
        assert not (tmp_path / "results_nx_loadings.csv").exists()
        assert not (tmp_path / "results_contingency_status.csv").exists()
        assert not (tmp_path / "results_completeness_iterations.csv").exists()


# ---------------------------------------------------------------------------
# ENABLE_NX_ANALYSIS=True produces real, non-trivial N-X artifacts
# ---------------------------------------------------------------------------

class TestNxAnalysisEnabled:
    def test_real_nx_artifacts_produced_and_non_trivial(self, run_pipeline_module, tmp_path):
        """With ENABLE_NX_ANALYSIS=True on the real dataset, the N-X output files exist with
        non-trivial content."""
        run_pipeline_module.ENABLE_NX_ANALYSIS = True
        run_pipeline_module.main()

        sensitivity_nx_path = tmp_path / "sensitivity_pst_nx.csv"
        loadings_path = tmp_path / "results_nx_loadings.csv"
        status_path = tmp_path / "results_contingency_status.csv"

        assert loadings_path.exists()
        loadings_rows = list(csv.DictReader(loadings_path.open()))
        assert len(loadings_rows) > 0, "results_nx_loadings.csv must have real rows against real data"

        assert status_path.exists()
        status_rows = list(csv.DictReader(status_path.open()))
        # 22 distinct contingency mRIDs: equipment validation covers 8 CoMo types (gen, load,
        # shuntCompensator, busbar, ... besides line/transformer); the count is specific to
        # this dataset's CO.xml
        assert len(status_rows) == 22, "expected all 22 must-study contingencies at 1030Z reported"

        # Belgovia CO3 (equipment_type 'gen', trips BO-G2) is applied, not skipped as "not
        # found in CGM"
        co3_row = next((r for r in status_rows if r["contingency_mrid"] == "37997e71-cb7d-4a8c-baa6-2a1594956da9"), None)
        assert co3_row is not None, "CO3 (gen/BO-G2) must be present in results_contingency_status.csv"
        assert co3_row["converged"] == "True"

        # Svedala busbar contingency (OutOfRangeContingency, two BusbarSections via
        # add_multiple_elements_contingency): pypowsybl's contingency API needs no
        # equipment-type-specific code
        busbar_row = next((r for r in status_rows if r["contingency_mrid"] == "e8e8300b-e3b1-41ba-81af-406f6e5b4a55"), None)
        assert busbar_row is not None, "Svedala busbar OutOfRangeContingency must be present"
        assert busbar_row["converged"] == "True"

        converged_count = sum(1 for r in status_rows if r["converged"] == "True")
        # every contingency converges (22/22) on this dataset: use_reactive_limits=False and
        # the contingency's own tripped equipment is not taken as a network split; a
        # non-converged one here is a real regression
        assert converged_count == len(status_rows), (
            f"expected ALL must-study contingencies to converge (got "
            f"{converged_count}/{len(status_rows)}) — confirmed the expected "
            f"outcome on this dataset now that reactive-limit enforcement is "
            f"disabled and the false-positive network-split detection is "
            f"fixed; if this regresses, investigate rather than relax this "
            f"assertion back to a range"
        )

    def test_no_optimise_guard_pst_and_rd_none_nx_present_solves(
        self, run_pipeline_module, tmp_path,
    ):
        """No available preventive PST, RD switched OFF (rd_inputs None) and
        ENABLE_NX_ANALYSIS=True: main() does not take the 'nothing to optimise' exit."""
        run_pipeline_module.ENABLE_RD_REMEDIAL_ACTIONS = False
        run_pipeline_module.ENABLE_NX_ANALYSIS = True

        # no "nothing to optimise": nx_inputs alone is enough to solve
        run_pipeline_module.main()

        assert (tmp_path / "results_nx_loadings.csv").exists()

    def test_still_raises_when_pst_rd_and_nx_all_absent(self, run_pipeline_module):
        """With PST, RD and N-X all absent the 'nothing to optimise' guard still applies
        (all three conditions)."""
        run_pipeline_module.ENABLE_PST_REMEDIAL_ACTIONS = False
        run_pipeline_module.ENABLE_RD_REMEDIAL_ACTIONS = False
        run_pipeline_module.ENABLE_NX_ANALYSIS = False

        with pytest.raises(ValueError, match="nothing to optimise"):
            run_pipeline_module.main()


# ---------------------------------------------------------------------------
# CRA correctly computes empty on this dataset — not skipped, not erroring
# ---------------------------------------------------------------------------

class TestCraCorrectlyComputesEmptyOnRealData:
    def test_curative_solves_optimal_with_confirmed_empty_cra(self, run_pipeline_module, tmp_path, caplog):
        """On the real dataset pst_cra_availability is empty (the curative PST lacks timing
        data) and there is no curative RD: with N-X on, the pipeline still solves to optimal
        with the PATL/TATL constraints active. The dataset facts are checked in the next test."""
        run_pipeline_module.ENABLE_NX_ANALYSIS = True

        run_pipeline_module.main()  # must not raise

        loadings_path = tmp_path / "results_nx_loadings.csv"
        assert loadings_path.exists()
        loadings_rows = list(csv.DictReader(loadings_path.open()))
        # PATL/TATL constraints present: rows with populated loading columns
        assert len(loadings_rows) > 0
        assert any(row["loading_pct_nx_initial"] not in ("", None) for row in loadings_rows)

    def test_pst_cra_availability_confirmed_empty_and_curative_rd_confirmed_absent(self):
        """The two dataset facts the previous test depends on, derived from the data here."""
        from pathlib import Path as P
        from pre_milp import cgmes_loader, tso_name_resolver, ncp_loader, ncp_parser
        from pre_milp.nx_security_analysis import compute_tatl_data
        from pre_milp.cra_preprocessing import compute_pst_cra_availability
        from data_model import RAKind

        org_cd_path = DATA_ROOT / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
        _, tap_changer_dict, generating_unit_dict = cgmes_loader.extract_equipment_dicts(network)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.build_ncp_files(DATA_ROOT, tso_name_map)
        timestamp_list = ncp_loader.build_timestamp_list("1030Z", 4)

        ae_flat_list, pst_list, rd_list = [], [], []
        cgm_static_patl = cgmes_loader.build_cgm_static_patl(network)
        branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)
        for tso, profiles in sorted(ncp_files.items()):
            country = tso.removeprefix("TSO-")
            eq_candidates = list((DATA_ROOT / country / "Grid" / "cimxml").glob("*_EQ_*.xml"))
            tap_changer_to_transformer = (
                ncp_parser.build_tap_changer_to_transformer_map(eq_candidates[0]) if eq_candidates else {}
            )
            current_limit_side = (
                ncp_parser.build_current_limit_side_map(eq_candidates[0]) if eq_candidates else {}
            )
            ae_flat_list.extend(ncp_parser.parse_assessed_elements(
                profiles["AE"], profiles.get("SHS"), tso, timestamp_list, cgm_static_patl,
                cgm_branch_mrids=set(branch_mrid_to_name.keys()), current_limit_side=current_limit_side,
            ))
            if "RA" in profiles:
                pst_list.extend(ncp_parser.parse_psts(
                    profiles["RA"], tso, tap_changer_dict, tap_changer_to_transformer,
                ))
                rds, _bids = ncp_parser.parse_rd_units(
                    profiles["RA"], profiles.get("SIS"), tso, timestamp_list, generating_unit_dict,
                )
                rd_list.extend(rds)

        tatl_data = compute_tatl_data(network, ae_flat_list, "1030Z")
        pst_cra_availability = compute_pst_cra_availability(pst_list, tatl_data)

        assert pst_cra_availability == {}
        assert all(rd.kind == RAKind.PREVENTIVE for rd in rd_list)


# ---------------------------------------------------------------------------
# Completeness loop on real data: it ends by convergence (no new congestion at the last
# check), not by running out of max_completeness_iterations. No exact iteration count is
# asserted (it depends on the dataset).
# ---------------------------------------------------------------------------

class TestCompletenessLoopRealDataConvergence:
    def test_completeness_loop_converges_on_real_data_not_just_exhausts_iterations(
        self, run_pipeline_module, tmp_path,
    ):
        """With N-X on the real dataset, results_completeness_iterations.csv has at least one
        row and its last row has new_constraints_added == 0 (converged, not exhausted)."""
        run_pipeline_module.ENABLE_NX_ANALYSIS = True
        run_pipeline_module.main()

        iterations_path = tmp_path / "results_completeness_iterations.csv"
        assert iterations_path.exists()

        rows = list(csv.DictReader(iterations_path.open()))
        assert len(rows) >= 1, "expected at least the initial iteration (iteration 0) to be logged"

        final_row = rows[-1]
        assert int(final_row["new_constraints_added"]) == 0, (
            f"Expected the completeness loop's final iteration to report "
            f"zero new constraints (genuine convergence), but got "
            f"{final_row['new_constraints_added']!r}. If this fails, either "
            f"the loop is exhausting max_completeness_iterations without "
            f"stabilizing (a real regression worth investigating), or a "
            f"genuine, legitimate dataset change has altered the "
            f"convergence behaviour and this assertion's expectation "
            f"itself needs revisiting — check which before assuming either."
        )


# ---------------------------------------------------------------------------
# End to end on a generator-produced NCP zip, the real CGM zip and an input/ folder
# ---------------------------------------------------------------------------

# _REAL_CGM_ZIP / _NCP_GENERIC_ZIP for TestRealEndToEndInputFolder. NCP_generic.zip is an
# unmodified generic submission (unlike the purpose-built NCP_pst_fallback_scenario.zip).
_REAL_CGM_ZIP = REPO_ROOT / "tests" / "fixtures" / "CGM_package.zip"


_NCP_GENERIC_ZIP = REPO_ROOT / "tests" / "fixtures" / "NCP_generic.zip"


class TestRealEndToEndInputFolder:
    def test_full_pipeline_runs_against_input_folder(self, tmp_path, monkeypatch):
        """A generator-produced NCP zip and the real CGM zip in an input/ folder, run through
        run_pipeline.main(): zip discovery, CGM loading, NCP extraction and classification,
        TSO resolution and EQ file lookup work together.
        """
        input_dir = tmp_path / "input"
        input_dir.mkdir()
        (input_dir / "cgm.zip").write_bytes(_REAL_CGM_ZIP.read_bytes())
        (input_dir / "ncp.zip").write_bytes(_NCP_GENERIC_ZIP.read_bytes())

        import importlib
        import run_pipeline as rp
        importlib.reload(rp)
        monkeypatch.setattr(rp, "INPUT_DIR", input_dir)
        monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path / "output")

        rp.main()  # must not raise

        assert (tmp_path / "output" / "lf_basecase.csv").exists()
        assert (tmp_path / "output" / "co_flat_list.csv").exists()


# ===========================================================================
# Operating point of the loop
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _rows(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _close(left: dict, right: dict, tolerance: float = 1e-6) -> bool:
    """Nested {key: {key: {side: amps}}} / {key: {side: amps}} comparison."""
    if isinstance(left, dict):
        return left.keys() <= right.keys() and all(_close(left[k], right[k], tolerance) for k in left)
    if float(left) != float(left) and float(right) != float(right):
        return True  # both NaN (out-of-service side)
    return abs(float(left) - float(right)) <= tolerance * max(1.0, abs(float(right)))


@pytest.fixture(scope="module")
def instrumented_run(tmp_path_factory):
    captured = SimpleNamespace(builds=[], models=[], network=None, state=None, nx_hooks=None, mismatches=[])

    def customize(rp, monkeypatch):
        acl = rp.ac_convergence_loop
        real_nested = acl.run_nested_rao_loop
        real_build = acl.build_n0_milp_model

        def spy_nested(**kwargs):
            captured.network = kwargs["network"]
            captured.state = kwargs["state"]
            captured.nx_hooks = kwargs["nx_hooks"]
            return real_nested(**kwargs)

        def spy_build(*args, **kwargs):
            network = captured.network
            record = {
                "r0": {p.mrid: p.r0 for p in kwargs["pst_inputs"].pst_list} if kwargs.get("pst_inputs") else {},
                "target_p": (
                    {gu: d["target_p"] for gu, d in kwargs["rd_inputs"].generator_data.items()}
                    if kwargs.get("rd_inputs") else {}
                ),
                "network_taps": acl._extract_phase_tap_positions(network),
                "network_target_p": acl._extract_generator_target_p(network),
                "lf_n0_matches": _close(kwargs["lf_initial"], acl.cgmes_loader.build_lf_initial(network)),
                "lf_initial": kwargs["lf_initial"],
                "lf_nx": kwargs["nx_inputs"].lf_nx if kwargs.get("nx_inputs") is not None else None,
            }
            if kwargs.get("nx_inputs") is not None and captured.nx_hooks is not None:
                fresh_lf_nx = captured.nx_hooks.compute_lf_nx(network)
                record["lf_nx_matches"] = _close(kwargs["nx_inputs"].lf_nx, fresh_lf_nx, 1e-5)
            captured.builds.append(record)
            model = real_build(*args, **kwargs)
            captured.models.append(model)
            return model

        monkeypatch.setattr(acl, "run_nested_rao_loop", spy_nested)
        monkeypatch.setattr(acl, "build_n0_milp_model", spy_build)

    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("instrumented_mock_run"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )
    captured.output_dir = run.output_dir
    return captured


def test_every_build_on_the_real_network_starts_from_the_applied_state(instrumented_run):
    builds = instrumented_run.builds
    assert len(builds) >= 2, "the mock case needs a second build for this to mean anything"
    for index, build in enumerate(builds, start=1):
        for mrid, r0 in build["r0"].items():
            assert float(build["network_taps"][mrid]) == r0, f"build {index}: PST {mrid} r0 != network tap"
        for gu, target_p in build["target_p"].items():
            assert build["network_target_p"][gu] == pytest.approx(target_p, abs=1e-9), (
                f"build {index}: GU {gu} target_p != network"
            )
        assert build["lf_n0_matches"], f"build {index}: N-0 load flow is not the one of the network"
        assert build["lf_nx_matches"], f"build {index}: N-X load flow is not a fresh one of the network"
    assert builds[-1]["network_taps"] != builds[0]["network_taps"], "nothing moved between the builds"


def test_final_network_equals_the_reported_final_values(instrumented_run):
    from milp import ac_convergence_loop as acl
    out = instrumented_run.output_dir
    network_taps = acl._extract_phase_tap_positions(instrumented_run.network)
    network_target_p = acl._extract_generator_target_p(instrumented_run.network)
    for row in _rows(out / "results_pst.csv"):
        if row["result_tap_position"] != "":
            assert float(row["result_tap_position"]) == pytest.approx(network_taps[row["pst_mrid"]], abs=1e-9)
    for row in _rows(out / "results_generating_units.csv"):
        assert float(row["result_production_mw"]) == pytest.approx(network_target_p[row["gu_mrid"]], abs=1e-6)

    # the last lf_post_n0 record is a load flow on exactly the final state
    from pre_milp import cgmes_loader
    final_lf = cgmes_loader.build_lf_initial(instrumented_run.network)
    last_iteration = max(int(r["ac_iteration"]) for r in _rows(out / "lf_post_n0.csv"))
    for row in _rows(out / "lf_post_n0.csv"):
        if int(row["ac_iteration"]) == last_iteration and row["i_ka_after"] != "":
            amps = float(row["i_ka_after"]) * 1000.0  # the file reports the monitored side
            assert any(
                amps == pytest.approx(v, rel=1e-6, abs=1e-6) for v in final_lf[row["branch_mrid"]].values()
            ), f"{row['branch_mrid']}: lf_post after-current is not a load flow of the final state"


def test_every_file_agrees_with_original_plus_cumulative_change(instrumented_run):
    out = instrumented_run.output_dir
    state = instrumented_run.state
    for row in _rows(out / "results_pst.csv"):
        original, change, final = (float(row[k]) for k in ("original_tap_position", "tap_change_result", "result_tap_position"))
        assert final == original + change
        assert original == state.original_tap_by_pst[row["pst_mrid"]]
        assert final == state.current_tap_by_pst[row["pst_mrid"]]
    for row in _rows(out / "results_generating_units.csv"):
        original, change, final = (float(row[k]) for k in ("initial_production_mw", "rd_volume_net_mw", "result_production_mw"))
        assert final == pytest.approx(original + change, abs=1e-6)
        assert original == pytest.approx(state.original_target_p_by_gu[row["gu_mrid"]], abs=1e-9)
        assert final == pytest.approx(state.current_target_p_by_gu[row["gu_mrid"]], abs=1e-6)
    # bid volumes (signed: UP bids positive) are the accumulated applied volumes
    for row in _rows(out / "results_preventive_rd.csv"):
        assert float(row["rd_volume_net_mw"]) == pytest.approx(
            state.cumulative_signed_volume_mw.get(row["bid_mrid"], 0.0), abs=1e-6,
        )
    # history: the applied deltas add up to the cumulative taps
    summary_rows = _rows(out / "results_summary.csv")
    assert summary_rows


def test_cumulative_tap_change_per_tso_stays_within_the_limit(instrumented_run):
    out = instrumented_run.output_dir
    limits = {r["tso"]: float(r["max_taps_per_tso"]) for r in _rows(out / "results_tso_tap_limits.csv")}
    used: dict[str, float] = {}
    for row in _rows(out / "results_pst.csv"):
        if row["tso"] in limits:
            used[row["tso"]] = used.get(row["tso"], 0.0) + abs(float(row["tap_change_result"]))
    assert limits and used
    for tso, total in used.items():
        assert total <= limits[tso] + 1e-6, f"{tso}: |final - original| summed over its PSTs = {total} > limit {limits[tso]}"
    for row in _rows(out / "results_tso_tap_limits.csv"):
        assert float(row["tap_total"]) == pytest.approx(used.get(row["tso"], 0.0), abs=1e-6)


def test_summary_identity_and_cumulative_costs(instrumented_run):
    out = instrumented_run.output_dir
    summary = {r["metric"] if "metric" in r else list(r.values())[0]: r for r in _rows(out / "results_summary.csv")}
    values = _summary_values(out)
    assert abs(values["objective_residual_eur"]) < 1e-6
    assert values["sum_pst_penalty_cost_eur"] == pytest.approx(
        sum(float(r["penalty_cost_eur"]) for r in _rows(out / "results_pst.csv")), abs=1e-6,
    )
    assert values["sum_rd_cost_eur"] == pytest.approx(
        sum(float(r["rd_cost_eur"]) for r in _rows(out / "results_preventive_rd.csv")), abs=1e-6,
    )
    assert not any(key.startswith("cumulative_") for key in values), "the cumulative_* summary rows were dropped"
    assert summary


def _summary_values(out: Path) -> dict[str, float]:
    rows = _rows(out / "results_summary.csv")
    key_column, value_column = list(rows[0].keys())[:2]
    values = {}
    for row in rows:
        try:
            values[row[key_column]] = float(row[value_column])
        except ValueError:
            pass
    return values


def test_result_file_schemas(instrumented_run):
    from output_file_registry import OUTPUT_FILE_REGISTRY
    out = instrumented_run.output_dir

    def header(name: str) -> list[str]:
        with open(out / name, newline="", encoding="utf-8") as f:
            return next(csv.reader(f))

    pst_header = header("results_pst.csv")
    assert "original_tap_position" in pst_header and "current_tap_position" not in pst_header
    assert pst_header[-2:] == ["last_solve_start_tap_position", "last_solve_tap_change"]
    assert "last_solve_rd_volume_net_mw" in header("results_preventive_rd.csv")
    assert header("results_nx_loadings.csv")[-2:] == [
        "loading_pct_nx_post_pra_model", "loading_pct_nx_post_pra_model_diff_pct",
    ]
    history = _rows(out / "results_iteration_history.csv")
    assert history and {"completeness_iteration", "linearisation_iteration", "seconds_load_flow",
                        "seconds_nx_load_flow", "seconds_nx_sensitivity", "seconds_build_and_solve"} <= set(history[0])
    assert [int(r["solve_index"]) for r in history] == list(range(1, len(history) + 1))
    assert "results_iteration_history.csv" in OUTPUT_FILE_REGISTRY
    assert (out / "results_completeness_iterations.csv").exists()
    # the post-PRA N-X loadings are real AC results; the model prediction and the difference sit beside them
    for row in _rows(out / "results_nx_loadings.csv")[:50]:
        if row["loading_pct_nx_post_pra"] != "":
            assert float(row["loading_pct_nx_post_pra_model_diff_pct"]) == pytest.approx(
                float(row["loading_pct_nx_post_pra"]) - float(row["loading_pct_nx_post_pra_model"]), abs=1e-9,
            )
    log_text = (out / "run_log.txt").read_text(encoding="utf-8")
    assert "[RUNTIME]" in log_text, "per-iteration runtimes are logged in run_log.txt"


def test_criterion_4_is_taken_from_the_ac_state_and_the_loop_no_longer_stops_on_zero_slack(instrumented_run):
    out = instrumented_run.output_dir
    history = _rows(out / "results_iteration_history.csv")
    assert {"overload_change_ampere", "criterion_1_met", "criterion_3_met", "criterion_4_met",
            "converged_by", "cycle_match_iteration", "max_abs_tap_change", "max_abs_rd_change_mw"} <= set(history[0])
    first, second = history[0], history[1]
    # iteration 1 is evaluable against the initial AC state and does not fire on the mock case
    assert float(first["overload_change_ampere"]) > 1.0 and first["criterion_4_met"] == "False"
    # redispatch keeps moving in iteration 2 with model slack 0 in both solves (about 99 MW
    # with the pipeline's sensitivity parameters)
    assert float(second["total_overload"]) == 0.0 and float(first["total_overload"]) == 0.0
    assert float(second["sum_abs_rd_change_mw"]) > 50.0
    assert second["converged"] == "False" and second["criterion_4_met"] == "False"
    for row in history:
        assert (row["criterion_4_met"] == "True") == (float(row["overload_change_ampere"]) < 1.0)


def test_the_curative_effect_used_by_criterion_4_equals_the_curative_part_of_the_nx_export(instrumented_run):
    out = instrumented_run.output_dir
    model = instrumented_run.models[-1]
    checked = nonzero = 0
    for row in _rows(out / "results_nx_loadings.csv"):
        pair = (row["branch_mrid"], row["contingency_mrid"])
        if pair not in model.nx_branch_contingency_pairs or row["loading_pct_nx_post_pra_cra"] == "":
            continue
        patl_ampere = float(row["patl_ka"]) * 1000.0
        exported_effect = (
            float(row["loading_pct_nx_post_pra_cra"]) - float(row["loading_pct_nx_post_pra"])
        ) / 100.0 * patl_ampere
        assert model.nx_curative_effect_ampere(*pair) == pytest.approx(exported_effect, abs=1e-6)
        checked += 1
        nonzero += abs(exported_effect) > 1e-6
    assert checked > 100 and nonzero > 0, "the check must cover pairs with a real curative effect"


def test_criterion_4_equals_an_independent_recomputation_from_the_ac_states(instrumented_run):
    """Per solve s: sum over the model's monitored elements of |overload(state s) - overload(state s-1)|
    with overload = max(0, I_AC (+ curative effect of the solve) - limit); state s-1 is the input of
    solve s, state s the input of build s+1."""
    from data_model import select_by_side
    history = _rows(instrumented_run.output_dir / "results_iteration_history.csv")
    builds, models = instrumented_run.builds, instrumented_run.models
    assert len(builds) == len(models) >= 3

    def overload_sum(model, build, curative_model):
        total = {}
        for branch, (side, limit) in model.overload_monitoring["n0"].items():
            total[("n0", branch)] = max(0.0, select_by_side(build["lf_initial"][branch], side, branch) - limit)
        for kind in ("nx_patl", "nx_tatl"):
            for (branch, contingency), (side, limit) in model.overload_monitoring[kind].items():
                current = select_by_side(build["lf_nx"][contingency][branch], side, branch)
                if curative_model is not None:
                    current += curative_model.nx_curative_effect_ampere(branch, contingency)
                total[(kind, branch, contingency)] = max(0.0, current - limit)
        return total

    for solve in range(1, len(builds)):          # solves with a following build = a known state s
        model = models[solve - 1]
        now = overload_sum(model, builds[solve], model)
        before = overload_sum(model, builds[solve - 1], models[solve - 2] if solve >= 2 else None)
        expected = sum(abs(now[k] - before[k]) for k in now)
        assert float(history[solve - 1]["overload_change_ampere"]) == pytest.approx(expected, rel=1e-6, abs=1e-6), (
            f"solve {solve}"
        )


def test_the_state_keeps_the_curative_effect_of_the_last_applied_solve(instrumented_run):
    state, model = instrumented_run.state, instrumented_run.models[-1]
    assert state.last_curative_effect_ampere
    for (branch, contingency), effect in state.last_curative_effect_ampere.items():
        assert effect == pytest.approx(model.nx_curative_effect_ampere(branch, contingency), abs=1e-9)
    assert any(abs(v) > 1e-6 for v in state.last_curative_effect_ampere.values())


def test_the_sensitivity_guard_flags_nothing_on_a_healthy_run(instrumented_run):
    out = instrumented_run.output_dir
    status = _rows(out / "results_contingency_status.csv")
    assert status and all(row["sensitivity_valid"] == "True" for row in status)
    history = _rows(out / "results_iteration_history.csv")
    assert all(row["invalid_sensitivity_contingencies"] == "0" and row["invalid_sensitivity_branches_n0"] == "0"
               for row in history)
    assert "SENSITIVITY GUARD" not in (out / "run_log.txt").read_text(encoding="utf-8")


# ===========================================================================
# Sensitivity guard in a full run
# ===========================================================================

SIDES = {"L1": 1, "L2": 2}


# ---------------------------------------------------------------------------
# the four compute functions fill guard_out (fake pypowsybl)
# ---------------------------------------------------------------------------

def _install_with_references(monkeypatch, reference_value, sensitivity_value=1.0):
    from helpers import _Result, _install
    fake = _install(monkeypatch)
    reference = lambda: pd.DataFrame([[reference_value]], index=["reference_values"], columns=["b1"])
    fake.matrices["psdf_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    fake.matrices["ptdf_rd_n0_side1"] = pd.DataFrame([[sensitivity_value]], index=["g1"], columns=["b1"])
    fake.matrices[("nx_side1", "c1")] = pd.DataFrame([[sensitivity_value]], index=["p1"], columns=["b1"])
    monkeypatch.setattr(
        _Result, "get_reference_matrix",
        lambda self, matrix_id, contingency_id=None: reference(), raising=True,
    )
    return fake


# ---------------------------------------------------------------------------
# end to end on the mock case: a failing analysis for one contingency
# ---------------------------------------------------------------------------
# Every mode fails only AFTER the first MILP was built (the initial computation is healthy, so there is
# a valid set to reuse; a failure at the initial computation stops the run, see the last test):
# mode "refresh_only":      reference current and sensitivities of one contingency are zero
# mode "refresh_sens_only": only the sensitivities are zero (the reference still matches the load flow)
# mode "refresh_pst_only" / "refresh_rd_only": only the sensitivities of that analysis are zero

@pytest.fixture(scope="module", params=["refresh_only", "refresh_sens_only", "refresh_pst_only", "refresh_rd_only"])
def failing_run(request, tmp_path_factory):
    mode = request.param
    seen = {"target": None, "events": [], "active": False, "built": []}
    sens_only_modes = ("refresh_sens_only", "refresh_pst_only", "refresh_rd_only")

    def customize(rp, monkeypatch):
        import logging
        from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
        real_run = AcSensitivityAnalysis.run

        class Failed:
            analysis = "n0"

            def __init__(self, real):
                self.real = real

            def get_reference_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_reference_matrix(matrix_id, contingency_id)
                if contingency_id is None or matrix is None:
                    return matrix
                if seen["target"] is None and float(matrix.abs().max().max()) > 50.0:
                    seen["target"] = contingency_id
                zero = seen["active"] and mode not in sens_only_modes and contingency_id == seen["target"]
                return matrix * 0.0 if zero else matrix

            def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_sensitivity_matrix(matrix_id, contingency_id)
                restricted = {"refresh_pst_only": "pst", "refresh_rd_only": "rd"}.get(mode)
                # one N-X analysis holds both kinds: its matrix ids say which (nx_pst_*, nx_rd_*)
                kind = ("pst" if str(matrix_id).startswith("nx_pst") else
                        "rd" if str(matrix_id).startswith("nx_rd") else self.analysis)
                if seen["active"] and contingency_id is not None and matrix is not None \
                        and contingency_id == seen["target"] and restricted in (None, kind):
                    return matrix * 0.0
                return matrix

            def __getattr__(self, name):
                return getattr(self.real, name)

        def run(self, network, parameters=None, *args, **kwargs):
            import inspect
            names = [frame.function for frame in inspect.stack()[1:6]]
            analysis = "pst" if "compute_sensitivity_pst_nx" in names else "rd" if "compute_sensitivity_rd_nx" in names else "n0"
            failed = Failed(real_run(self, network, parameters, *args, **kwargs))
            failed.analysis = analysis
            return failed

        monkeypatch.setattr(AcSensitivityAnalysis, "run", run)

        warnings_seen = []

        class Collect(logging.Handler):
            def emit(self, record):
                if record.levelno == logging.WARNING and "SENSITIVITY GUARD" in record.getMessage():
                    warnings_seen.append(record.getMessage())

        seen["collector"] = Collect()
        logging.getLogger().addHandler(seen["collector"])
        acl = rp.ac_convergence_loop
        real_build = acl.build_n0_milp_model

        def spy_build(*args, **kwargs):
            seen["events"].append(("build", len(warnings_seen)))
            seen["active"] = True      # from the first build on, every analysis of the target fails
            nx = kwargs.get("nx_inputs")
            seen["built"].append((
                dict(nx.sensitivity_pst_nx.get(seen["target"], {})), dict(nx.sensitivity_rd_nx.get(seen["target"], {})),
            ))
            return real_build(*args, **kwargs)

        monkeypatch.setattr(acl, "build_n0_milp_model", spy_build)
        # the target contingency must be known before the first build in every mode
    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp(f"guard_{mode}"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )
    import logging
    logging.getLogger().removeHandler(seen["collector"])
    return SimpleNamespace(run=run, mode=mode, target=seen["target"], out=run.output_dir, events=seen["events"], built=seen["built"])


def _rows_sensitivity_guard(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def test_the_failing_contingency_is_logged_as_a_warning_in_run_log(failing_run):
    lines = (failing_run.out / "run_log.txt").read_text(encoding="utf-8").splitlines()
    guard = [line for line in lines if "SENSITIVITY GUARD" in line]
    assert guard and all("WARNING" in line for line in guard)
    assert any(failing_run.target in line for line in guard)
    assert any("refresh" in line for line in guard)
    assert not any("initial state" in line for line in guard)


def test_only_the_failing_contingency_is_marked_invalid_in_the_status_csv(failing_run):
    rows = _rows_sensitivity_guard(failing_run.out / "results_contingency_status.csv")
    assert "sensitivity_valid" in rows[0] and "sensitivity_source" in rows[0]
    invalid = [row["contingency_mrid"] for row in rows if row["sensitivity_valid"] == "False"]
    assert invalid == [failing_run.target]
    stale = [row["contingency_mrid"] for row in rows if row["sensitivity_source"] == "stale_reused"]
    assert stale == [failing_run.target]
    assert {row["sensitivity_source"] for row in rows} == {"fresh", "stale_reused"}


def test_every_solve_counts_the_contingencies_its_sensitivities_were_invalid_for(failing_run):
    history = _rows_sensitivity_guard(failing_run.out / "results_iteration_history.csv")
    assert "invalid_sensitivity_contingencies" in history[0]
    # solve 1 was built from the healthy initial sensitivities; every later one reuses the target's
    expected = [0] + [1] * (len(history) - 1)
    assert [int(row["invalid_sensitivity_contingencies"]) for row in history] == expected
    assert [int(row["stale_reused_sensitivity_contingencies"]) for row in history] == expected
    assert all(int(row["invalid_sensitivity_branches_n0"]) == 0 for row in history)
    assert all(int(row["stale_reused_sensitivity_branches_n0"]) == 0 for row in history)


def test_the_summary_holds_the_maximum_number_of_stale_reused_contingencies(failing_run):
    summary = {row["metric"]: row["value"] for row in _rows_sensitivity_guard(failing_run.out / "results_summary.csv")}
    assert summary["max_stale_reused_sensitivity_contingencies"] == "1"


def test_the_builder_receives_the_valid_initial_set_of_the_failing_contingency_in_every_later_solve(failing_run):
    """e2e spy on the builder inputs: never the zero (invalid) set, always the last valid one"""
    built = failing_run.built
    assert len(built) >= 2
    initial_pst, initial_rd = built[0]
    assert any(v != 0.0 for v in initial_pst.values()) or any(v != 0.0 for v in initial_rd.values())
    for pst, rd in built[1:]:
        assert pst == initial_pst and rd == initial_rd


def test_the_warning_precedes_every_build_that_used_the_invalid_sensitivities(failing_run):
    """never silent: by the time a MILP is built from reused sensitivities the WARNING is out"""
    builds = [count for kind, count in failing_run.events if kind == "build"]
    assert len(builds) >= 2
    assert builds[0] == 0 and builds[1] >= 1 and all(b > a for a, b in zip(builds[1:], builds[2:]))


def test_invalid_sensitivities_at_the_initial_computation_stop_the_run_with_a_clear_error(tmp_path):
    """no earlier valid set exists: SensitivityGuardError, the outputs say why, the rule and the contingency are named"""
    from pre_milp.sensitivity_checks import SensitivityGuardError
    seen = {"target": None}

    def customize(rp, monkeypatch):
        from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
        real_run = AcSensitivityAnalysis.run

        class Failed:
            def __init__(self, real):
                self.real = real

            def get_reference_matrix(self, matrix_id, contingency_id=None):
                matrix = self.real.get_reference_matrix(matrix_id, contingency_id)
                if contingency_id is None or matrix is None:
                    return matrix
                if seen["target"] is None and float(matrix.abs().max().max()) > 50.0:
                    seen["target"] = contingency_id
                return matrix * 0.0 if contingency_id == seen["target"] else matrix

            def __getattr__(self, name):
                return getattr(self.real, name)

        monkeypatch.setattr(
            AcSensitivityAnalysis, "run", lambda self, *a, **k: Failed(real_run(self, *a, **k)),
        )

    with pytest.raises(SensitivityGuardError) as error:
        run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=customize)
    out = tmp_path / "output"
    assert seen["target"] in str(error.value) and "zero reference current" in str(error.value)
    summary = {row["metric"]: row["value"] for row in _rows_sensitivity_guard(out / "results_summary.csv")}
    assert summary["ac_verification_status"] == "SENSITIVITY_INVALID"
    assert seen["target"] in summary["sensitivity_guard_error"]
    log_lines = (out / "run_log.txt").read_text(encoding="utf-8")
    assert any("ERROR" in line and seen["target"] in line for line in log_lines.splitlines() if "SENSITIVITY GUARD" in line)
    status = _rows_sensitivity_guard(out / "results_contingency_status.csv")
    assert [row["contingency_mrid"] for row in status if row["sensitivity_valid"] == "False"] == [seen["target"]]


# ---------------------------------------------------------------------------
# loop level (FakeGrid harness): the N-0 refresh at the applied state
# ---------------------------------------------------------------------------


# ===========================================================================
# Curative RD without preventive RD
# ===========================================================================

REPO_ROOT_curative_rd_without_preventive_rd = Path(__file__).resolve().parent.parent


# ---- 3. pipeline level -------------------------------------------------------

FIXTURES = REPO_ROOT_curative_rd_without_preventive_rd / "tests" / "fixtures"


requires_fixtures = pytest.mark.skipif(
    not ((FIXTURES / "CGM_package.zip").is_file() and (FIXTURES / "NCP_pst_fallback_scenario.zip").is_file()),
    reason="CGM_package.zip / NCP_pst_fallback_scenario.zip not in tests/fixtures",
)


@requires_fixtures
def test_pipeline_runs_with_curative_only_rd_and_uses_curative_bids(tmp_path, monkeypatch):
    input_dir, output_dir = tmp_path / "input", tmp_path / "output"
    input_dir.mkdir()
    shutil.copy(FIXTURES / "CGM_package.zip", input_dir / "cgm.zip")
    shutil.copy(FIXTURES / "NCP_pst_fallback_scenario.zip", input_dir / "ncp.zip")

    rp = importlib.import_module("run_pipeline")
    monkeypatch.setattr(rp, "INPUT_DIR", input_dir)
    monkeypatch.setattr(rp, "OUTPUT_DIR", output_dir)
    monkeypatch.setattr(rp, "ENABLE_NX_ANALYSIS", True)
    monkeypatch.setattr(rp, "ENABLE_PST_REMEDIAL_ACTIONS", True)
    monkeypatch.setattr(rp, "ENABLE_RD_REMEDIAL_ACTIONS", True)

    original_parse_rd_units = rp.ncp_parser.parse_rd_units

    def curative_only(*args, **kwargs):
        units, bids = original_parse_rd_units(*args, **kwargs)
        units = [u for u in units if u.kind == RAKind.CURATIVE]
        keep = {str(u.mrid) for u in units}
        return units, [b for b in bids if str(b.ra_mrid) in keep]

    monkeypatch.setattr(rp.ncp_parser, "parse_rd_units", curative_only)
    rp.main()

    # preventive RD results are header-only, the run still produced N-X output
    with open(output_dir / "results_preventive_rd.csv", newline="") as f:
        assert len(list(csv.reader(f))) == 1
    assert (output_dir / "results_nx_loadings.csv").is_file()
    # the curative-only RD run also writes the curative RD results file
    with open(output_dir / "results_curative_rd.csv", newline="") as f:
        curative_rd_rows = list(csv.DictReader(f))
    assert curative_rd_rows == [] or "curative_cost_eur" in curative_rd_rows[0]
    # curative RD sensitivities existed and the GLSK of the curative units resolved
    with open(output_dir / "glsk_resolved.csv", newline="") as f:
        assert len(list(csv.reader(f))) > 1


# ===========================================================================
# lf_nx baseline handed to the export
# ===========================================================================

REPO_ROOT_completeness_loop = Path(__file__).resolve().parents[1]


@pytest.fixture
def run_pipeline_module_completeness_loop(tmp_path, monkeypatch, real_input_folder):
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))
    if str(REPO_ROOT_completeness_loop) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT_completeness_loop))
    import run_pipeline as rp
    importlib.reload(rp)
    monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path)
    # main() reads only input/: real_input_folder (conftest.py) builds it from tests/fixtures
    monkeypatch.setattr(rp, "INPUT_DIR", real_input_folder)
    return rp


class TestLfNxInitialStaysFixedAtPreRaBaseline:
    def test_export_receives_the_static_pre_ra_lf_nx_not_the_refreshed_one(self, run_pipeline_module_completeness_loop, monkeypatch):
        """The N-X loadings export keeps the ORIGINAL pre-RA N-X load flow as its
        'initial' reference, and gets the refreshed load flow of the final applied
        state separately (lf_nx_final). Guards against passing the refreshed one as
        the initial reference (the near-miss recorded in this file's docstring)."""
        captured = {}
        acl = run_pipeline_module_completeness_loop.ac_convergence_loop
        original_nested = acl.run_nested_rao_loop

        def spy_nested(**kwargs):
            captured["pre_loop_lf_nx"] = kwargs["nx_inputs"].lf_nx
            captured["state"] = kwargs["state"]
            return original_nested(**kwargs)

        monkeypatch.setattr(acl, "run_nested_rao_loop", spy_nested)
        original_export = run_pipeline_module_completeness_loop.nx_results_export.export_nx_loadings_csv

        def spy_export(*args, **kwargs):
            captured["initial"] = kwargs.get("lf_nx_initial")
            captured["final"] = kwargs.get("lf_nx_final")
            return original_export(*args, **kwargs)

        monkeypatch.setattr(run_pipeline_module_completeness_loop.nx_results_export, "export_nx_loadings_csv", spy_export)

        run_pipeline_module_completeness_loop.ENABLE_PST_REMEDIAL_ACTIONS = True
        run_pipeline_module_completeness_loop.ENABLE_RD_REMEDIAL_ACTIONS = True
        run_pipeline_module_completeness_loop.ENABLE_NX_ANALYSIS = True
        run_pipeline_module_completeness_loop.main()

        assert "pre_loop_lf_nx" in captured, "run_nested_rao_loop was never called — test setup issue"
        assert "initial" in captured, "export_nx_loadings_csv was never called — test setup issue"
        assert captured["initial"] is captured["pre_loop_lf_nx"], (
            "the export's 'initial' N-X load flow is not the pre-RA one"
        )
        assert captured["initial"] == captured["state"].original_lf_nx
        assert captured["final"] is captured["state"].current_lf_nx
        assert captured["final"] is not captured["initial"]


# ===========================================================================
# Results summary identity
# ===========================================================================

REPO_ROOT_results_summary = Path(__file__).resolve().parents[1]


@requires_fixtures
def test_identity_holds_on_the_mock_n_x_pipeline_run(tmp_path, monkeypatch):
    input_dir, output_dir = tmp_path / "input", tmp_path / "output"
    input_dir.mkdir()
    shutil.copy(FIXTURES / "CGM_package.zip", input_dir / "cgm.zip")
    shutil.copy(FIXTURES / "NCP_pst_fallback_scenario.zip", input_dir / "ncp.zip")
    rp = importlib.import_module("run_pipeline")
    monkeypatch.setattr(rp, "INPUT_DIR", input_dir)
    monkeypatch.setattr(rp, "OUTPUT_DIR", output_dir)
    monkeypatch.setattr(rp, "ENABLE_NX_ANALYSIS", True)
    monkeypatch.setattr(rp, "ENABLE_PST_REMEDIAL_ACTIONS", True)
    monkeypatch.setattr(rp, "ENABLE_RD_REMEDIAL_ACTIONS", True)
    rp.main()

    with open(output_dir / "results_summary.csv", newline="") as f:
        summary = {metric: value for metric, value in list(csv.reader(f))[1:]}
    assert abs(float(summary["objective_residual_eur"])) < 1e-6
    assert float(summary["sum_curative_rd_cost_eur"]) > 0.0
    assert summary["ac_verification_status"]


# ===========================================================================
# Unknown TSO in the tap limit overrides
# ===========================================================================

def test_pipeline_run_warns_about_an_unknown_tso_in_the_overrides_and_writes_the_reporting_columns(tmp_path):
    import csv
    from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "MAX_TAPS_PER_TSO_OVERRIDES", {"TSO-Nowhere": 3})

    run = run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
                                         customize_pipeline=customize)
    out = run.output_dir if hasattr(run, "output_dir") else tmp_path / "output"
    log_text = (out / "run_log.txt").read_text(encoding="utf-8", errors="ignore")
    assert "max_taps_per_tso_overrides" in log_text and "TSO-Nowhere" in log_text
    summary = {r[0]: r[1] for r in csv.reader(open(out / "results_summary.csv", newline=""))}
    assert summary["completeness_iteration_limit_reached"] in ("True", "False")
    header = next(csv.reader(open(out / "results_iteration_history.csv", newline="")))
    assert "nx_contingencies_lost_at_refresh" in header

# ===========================================================================
# Solver time limit and the N-X sensitivity CSV switch
# ===========================================================================

@pytest.fixture(scope="module")
def time_limited_run_without_nx_csvs(tmp_path_factory):
    """The mock N-X run with a 1 µs HiGHS time limit and write_nx_sensitivity_csvs false."""
    from milp import milp_solver

    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "SOLVER_TIME_LIMIT_SECONDS", 1e-6)
        monkeypatch.setattr(rp, "WRITE_NX_SENSITIVITY_CSVS", False)
        monkeypatch.setattr(milp_solver, "SOLVER_TIME_LIMIT_SECONDS", milp_solver.SOLVER_TIME_LIMIT_SECONDS)

    return run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("time_limited"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )


def _summary_metrics(output_dir):
    with open(output_dir / "results_summary.csv", newline="") as f:
        return {row["metric"]: row["value"] for row in csv.DictReader(f)}


def test_a_solve_stopped_at_the_time_limit_ends_the_run_as_solver_non_optimal(time_limited_run_without_nx_csvs):
    metrics = _summary_metrics(time_limited_run_without_nx_csvs.output_dir)
    assert metrics["ac_verification_status"] == AcVerificationStatus.SOLVER_NON_OPTIMAL.value


def test_without_a_time_limit_the_run_is_not_stopped_by_the_solver(mock_nx_pipeline_run):
    metrics = _summary_metrics(mock_nx_pipeline_run.output_dir)
    assert metrics["ac_verification_status"] == AcVerificationStatus.CONVERGED.value


def test_the_nx_sensitivity_csvs_are_not_written_when_switched_off(time_limited_run_without_nx_csvs):
    output_dir = time_limited_run_without_nx_csvs.output_dir
    assert not (output_dir / "sensitivity_pst_nx.csv").exists()
    assert not (output_dir / "sensitivity_rd_nx.csv").exists()
    assert (output_dir / "lf_nx_initial.csv").exists()


def test_the_nx_sensitivity_csvs_are_written_by_default(mock_nx_pipeline_run):
    assert (mock_nx_pipeline_run.output_dir / "sensitivity_pst_nx.csv").exists()
    assert (mock_nx_pipeline_run.output_dir / "sensitivity_rd_nx.csv").exists()
