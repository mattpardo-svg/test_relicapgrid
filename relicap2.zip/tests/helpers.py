"""Shared builders and helpers for the test files (code only; fixtures stay in conftest.py).

Moved here from the test files that used to import them from each other.
"""
import sys
from pathlib import Path

REPO_ROOT_FOR_PATHS = Path(__file__).resolve().parents[1]
for _p in (REPO_ROOT_FOR_PATHS / "src" / "rao", REPO_ROOT_FOR_PATHS / "src" / "rao" / "pre_milp", REPO_ROOT_FOR_PATHS):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from data_model import AEType, AssessedElement, PST, RAKind  # noqa: E402  # noqa: E402
from data_model import (  # noqa: E402
    AEType, AssessedElement, BidDirection, PowerBid, PST, RAKind, RDUnit,
)  # noqa: E402
from milp.milp_builder import NxMilpInputs  # noqa: E402  # noqa: E402
from milp.operating_point_state import OperatingPointState  # noqa: E402  # noqa: E402
from milp import ac_convergence_loop as acl  # noqa: E402  # noqa: E402
import copy  # noqa: E402
from data_model import BidDirection, PowerBid, RAKind, RDUnit  # noqa: E402  # noqa: E402
from milp.milp_builder import NxMilpInputs, RdMilpInputs, build_n0_milp_model  # noqa: E402  # noqa: E402
import pyomo.environ as pyo  # noqa: E402  # noqa: E402
from data_model import AcVerificationStatus, Contingency, ContingencyType, RAKind  # noqa: E402  # noqa: E402
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model  # noqa: E402  # noqa: E402
from pre_milp.cra_preprocessing import compute_pst_cra_availability  # noqa: E402  # noqa: E402
from pre_milp.cra_preprocessing import (  # noqa: E402
    build_curative_pst_group_constraints,
    validate_pst_group_kind,
)  # noqa: E402
from data_model import AcVerificationStatus, AEType, AssessedElement, BidDirection, PST, PowerBid, RAKind, RDUnit  # noqa: E402  # noqa: E402
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind  # noqa: E402  # noqa: E402
from data_model import (  # noqa: E402
    AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit,
)  # noqa: E402
import pandas as pd  # noqa: E402
import sys  # noqa: E402
from types import SimpleNamespace  # noqa: E402
import types  # noqa: E402
from data_model import AEType, AssessedElement, BidDirection, PST, PowerBid, RAKind, RDUnit  # noqa: E402  # noqa: E402
from milp.milp_builder import (  # noqa: E402
    NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model,
)  # noqa: E402
from pathlib import Path  # noqa: E402
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model  # noqa: E402  # noqa: E402
from data_model import AcVerificationStatus, BidDirection, RAKind  # noqa: E402  # noqa: E402
import pyomo.environ as pyo  # noqa: E402
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit  # noqa: E402
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RDUnit  # noqa: E402  # noqa: E402
import logging  # noqa: E402  # noqa: E402
from types import SimpleNamespace  # noqa: E402  # noqa: E402
import shutil  # noqa: E402  # noqa: E402
import importlib  # noqa: E402  # noqa: E402
import pytest  # noqa: E402

# ---- builders for the pst kind separation tests ----
def _make_ae(branch_mrid: str, patl_ka: float = 1.0, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=1,
    )


def _make_pst(mrid: str, kind: RAKind, penalty_factor: float = 1.0, r0: int = 0,
              tso: str = "TestTSO", group_id=None) -> PST:
    return PST(
        mrid=mrid, name=f"{mrid}-{kind.value}", tso=tso, available=True, kind=kind,
        penalty_factor=penalty_factor, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=group_id,
    )


# ---- builders for the operating point state tests ----
TIMESTAMP = "1030Z"


PST_A_PER_TAP_N0 = -50.0


GU_A_PER_MW_N0 = -5.0


PST_A_PER_TAP_NX = -40.0


GU_A_PER_MW_NX = -2.0


BASE_N0 = {"B1": 1250.0, "B2": 500.0}


BASE_NX = {"CO1": {"B1": 1250.0, "B2": 1100.0}}


class FakeGrid:
    """The 'network': taps and target_p, linear currents, a counted load flow."""

    def __init__(self, physics_scale: float = 1.0):
        self.taps = {"PST1": 0}
        self.target_p = {"GU1": 50.0, "GU2": 50.0}
        self.original_taps = dict(self.taps)
        self.original_target_p = dict(self.target_p)
        self.physics_scale = physics_scale
        self.load_flow_calls = 0
        self.fail_load_flow_on_calls: set[int] = set()
        self.applied_history: list[tuple[dict, dict]] = []

    def _delta(self, per_tap: float, per_mw: float) -> float:
        d_taps = self.taps["PST1"] - self.original_taps["PST1"]
        d_mw = self.target_p["GU1"] - self.original_target_p["GU1"]
        return self.physics_scale * (per_tap * d_taps + per_mw * d_mw)

    def n0_lf(self) -> dict:
        d = self._delta(PST_A_PER_TAP_N0, GU_A_PER_MW_N0)
        return {"B1": {1: BASE_N0["B1"] + d}, "B2": {1: BASE_N0["B2"]}}

    def nx_lf(self) -> dict:
        d_b1 = self._delta(PST_A_PER_TAP_N0, GU_A_PER_MW_N0)
        d_b2 = self._delta(PST_A_PER_TAP_NX, GU_A_PER_MW_NX)
        return {"CO1": {"B1": {1: BASE_NX["CO1"]["B1"] + d_b1}, "B2": {1: BASE_NX["CO1"]["B2"] + d_b2}}}


def _ae(branch: str) -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch}", name=branch, tso="T", ae_type=AEType.SECURED, branch_mrid=branch,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={TIMESTAMP: 1.0}, branch_side=1,
    )


def _pst() -> PST:
    return PST(
        mrid="PST1", name="PST1", tso="T", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _rd(index: int = 1) -> RDUnit:
    return RDUnit(
        mrid=f"RD{index}", name=f"RD{index}", tso="T", gu_mrid=f"GU{index}", gu_name=f"GU{index}", available=True,
        kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=200.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=1.0,
    )


def _bid(available_mw: float, index: int = 1) -> PowerBid:
    # RD balancing forces sum(net injection) = 0: GU1 goes UP, GU2 compensates DOWN
    return PowerBid(
        mrid=f"BID{index}", ra_mrid=f"RD{index}", direction=BidDirection.UP if index == 1 else BidDirection.DOWN,
        available_mw={TIMESTAMP: available_mw},
        price_eur_mw=10.0, penalty_factor=1.0, lead_time_h=0.0, activation_cost_eur=None,
        min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


class Scenario:
    """Wires a FakeGrid into the loop and records every MILP build."""

    def __init__(self, monkeypatch, physics_scale=1.0, with_nx=False, bid_available_mw=100.0,
                 tap_bounds=(-3, 3), loop_overrides=None):
        self.grid = FakeGrid(physics_scale)
        self.with_nx = with_nx
        self.builds: list[dict] = []
        self.load_flow_states: list[tuple[dict, float]] = []
        self.pst_list = [_pst()]
        self.rd_list = [_rd(1), _rd(2)]
        self.bid_list = [_bid(bid_available_mw, 1), _bid(1000.0, 2)]
        self.ae_list = [_ae("B1"), _ae("B2")]
        self.tap_bounds = tap_bounds
        self.loop_overrides = loop_overrides or {}
        self.sens_pst_n0 = {("B1", "PST1"): PST_A_PER_TAP_N0, ("B2", "PST1"): 0.0}
        self.sens_rd_n0 = {("B1", "GU1"): GU_A_PER_MW_N0, ("B2", "GU1"): 0.0, ("B1", "GU2"): 0.0, ("B2", "GU2"): 0.0}
        self.sens_pst_nx = {"CO1": {("B1", "PST1"): PST_A_PER_TAP_N0, ("B2", "PST1"): PST_A_PER_TAP_NX}}
        self.sens_rd_nx = {"CO1": {("B1", "GU1"): GU_A_PER_MW_N0, ("B2", "GU1"): GU_A_PER_MW_NX}}
        self._install(monkeypatch)

    # ---- fake network-touching functions
    def _install(self, monkeypatch):
        grid = self.grid

        def apply_pst(network, pst_results):
            for mrid, row in pst_results.items():
                grid.taps[mrid] = int(round(float(row["result_tap_position"])))

        def apply_preventive(network, pst_tap_solution, rd_target_p_solution):
            previous = dict(grid.target_p)
            for gu, value in (rd_target_p_solution or {}).items():
                grid.target_p[gu] = float(value)
            return {}, previous

        def run_ac(network, use_reactive_limits=False, extra_lf_params=None):
            grid.load_flow_calls += 1
            if grid.load_flow_calls in grid.fail_load_flow_on_calls:
                return False, "FAILED", None
            return True, "CONVERGED", None

        def revert_incrementally(network, **kwargs):
            grid.taps.update({k: int(v) for k, v in kwargs["revert_tap_positions"].items()})
            grid.target_p.update(kwargs["revert_target_p"])
            return False, "FAILED", 0

        real_build = acl.build_n0_milp_model

        def spy_build(*args, **kwargs):
            # everything is copied AT BUILD TIME: later in-place mutation of the passed
            # objects (e.g. pst.r0) must not hide or fake a mismatch
            pst_inputs, rd_inputs, nx_inputs = kwargs.get("pst_inputs"), kwargs.get("rd_inputs"), kwargs.get("nx_inputs")
            self.builds.append({
                "kwargs": kwargs,
                "model_r0": {p.mrid: p.r0 for p in pst_inputs.pst_list} if pst_inputs else None,
                "model_target_p": (
                    {gu: d["target_p"] for gu, d in rd_inputs.generator_data.items()} if rd_inputs else None
                ),
                "model_n0_lf": copy.deepcopy(kwargs["lf_initial"]),
                "model_nx_lf": copy.deepcopy(nx_inputs.lf_nx) if nx_inputs else None,
                "grid_taps": dict(grid.taps), "grid_target_p": dict(grid.target_p),
                "grid_n0_lf": grid.n0_lf(), "grid_nx_lf": grid.nx_lf(),
            })
            return real_build(*args, **kwargs)

        monkeypatch.setattr(acl, "_apply_pst_results_to_network", apply_pst)
        monkeypatch.setattr(acl, "apply_preventive_solution_to_network", apply_preventive)
        monkeypatch.setattr(acl, "_run_ac_loadflow", run_ac)
        monkeypatch.setattr(acl, "_apply_changes_incrementally", revert_incrementally)
        monkeypatch.setattr(acl, "_extract_generator_target_p", lambda network: dict(grid.target_p))
        monkeypatch.setattr(acl, "_extract_phase_tap_positions", lambda network: dict(grid.taps))
        monkeypatch.setattr(acl, "_snapshot_bus_voltage_state", lambda network: {})
        monkeypatch.setattr(acl, "_restore_bus_voltage_state", lambda network, state: None)
        monkeypatch.setattr(acl, "compute_sensitivity_pst_n0", lambda **kwargs: dict(self.sens_pst_n0))
        monkeypatch.setattr(acl, "compute_sensitivity_rd_n0", lambda **kwargs: dict(self.sens_rd_n0))
        monkeypatch.setattr(acl.cgmes_loader, "build_lf_initial", lambda network: grid.n0_lf())
        monkeypatch.setattr(acl, "build_n0_milp_model", spy_build)

    # ---- inputs
    def nx_inputs(self):
        return NxMilpInputs(
            lf_nx=self.grid.nx_lf(), sensitivity_pst_nx=self.sens_pst_nx,
            sensitivity_rd_nx=self.sens_rd_nx, penalty_cost_overload_nx_patl=500.0,
        ) if self.with_nx else None

    def hooks(self):
        if not self.with_nx:
            return None
        return acl.NxLoopHooks(
            compute_lf_nx=lambda network: self.grid.nx_lf(),
            compute_sensitivities_nx=lambda network, lf_nx: (self.sens_pst_nx, self.sens_rd_nx),
            find_new_pairs=lambda model, lf_nx: 0,
        )

    def new_state(self):
        return OperatingPointState.at_original_network(
            pst_list=self.pst_list, generator_data=self.generator_data(),
            lf_n0=self.grid.n0_lf(), lf_nx=self.grid.nx_lf() if self.with_nx else None,
            sensitivity_pst_n0=self.sens_pst_n0, sensitivity_rd_n0=self.sens_rd_n0,
            sensitivity_pst_nx=self.sens_pst_nx if self.with_nx else None,
            sensitivity_rd_nx=self.sens_rd_nx if self.with_nx else None,
        )

    @staticmethod
    def generator_data():
        return {
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU2"},
        }

    def loop_kwargs(self):
        kwargs = dict(
            network=object(), pst_list=self.pst_list, rd_list=self.rd_list, ae_flat_list=self.ae_list,
            timestamp=TIMESTAMP, lf_initial=self.grid.n0_lf(),
            pst_tap_bounds={"PST1": self.tap_bounds},
            sensitivity_pst_n0=self.sens_pst_n0, sensitivity_rd_n0=self.sens_rd_n0,
            pst_group_equality_pairs=[], penalty_reference_pst_pra=10.0, penalty_reference_rd_pra=10.0,
            penalty_cost_overload_n0=1000.0, pst_degrees_per_tap={"PST1": 1.0},
            generator_data=self.generator_data(), bid_list=self.bid_list, glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU2": 1.0}},
            max_change_ra_sum_threshold=1.0, max_rd_mw_change_threshold=1.0, max_change_ra=1.0,
            max_change_overload=0.0, max_linearisation_iterations=10,
            nx_inputs=self.nx_inputs(),
        )
        kwargs.update(self.loop_overrides)
        return kwargs

    def run(self, state=None, **extra):
        state = state or self.new_state()
        kwargs = self.loop_kwargs()
        kwargs.update(extra)
        result = acl.run_post_rao_ac_verification_loop(state=state, nx_hooks=self.hooks(), **kwargs)
        return state, result


def export_status():
    from data_model import AcVerificationStatus
    return AcVerificationStatus.CONVERGED


# ---- builders for the curative rd cost tests ----
REFERENCE = 10.0


PENALTY_FACTOR = 1.0


BIDS = [
    ("BID_UP_A", BidDirection.UP, 20.0, 5.0, 8.0),
    ("BID_UP_B", BidDirection.UP, 30.0, 8.0, 5.0),
    ("BID_DOWN_A", BidDirection.DOWN, 50.0, 7.0, 3.0),
    ("BID_DOWN_B", BidDirection.DOWN, 40.0, 3.0, 7.0),
]


def _unit(mrid, gu):
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True,
        kind=RAKind.CURATIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1", "CO2"], linked_xne_mrids=[], penalty_factor=PENALTY_FACTOR,
    )


def _bid_rd_cost(mrid, ra, direction, price):
    return PowerBid(
        mrid=mrid, ra_mrid=ra, direction=direction, available_mw={"1030Z": 100.0},
        price_eur_mw=price, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def _solved_model(penalty_reference_rd_pra_per_tso=None):
    """Each bid has its own generating unit and its own overloaded branch
    (10 A per MW, PATL 1000 A): an UP bid reduces the loading with -10 A/MW,
    a DOWN bid with +10 A/MW (net injection is up - down)."""
    rd_list, bid_list, glsk, generator_data = [], [], {}, {}
    lf_nx = {"CO1": {}, "CO2": {}}
    sensitivity_rd_nx = {"CO1": {}, "CO2": {}}
    ae_list, lf_initial = [], {}
    for bid_mrid, direction, price, need_co1, need_co2 in BIDS:
        suffix = bid_mrid.removeprefix("BID_")
        ra, gu, branch = f"RD_{suffix}", f"GU_{suffix}", f"B_{suffix}"
        rd_list.append(_unit(ra, gu))
        bid_list.append(_bid_rd_cost(bid_mrid, ra, direction, price))
        glsk[ra] = {gu: 1.0}
        generator_data[gu] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
        ae_list.append(_make_ae(branch))
        lf_initial[branch] = {1: 500.0}
        sign = -10.0 if direction == BidDirection.UP else 10.0
        for co, need in (("CO1", need_co1), ("CO2", need_co2)):
            lf_nx[co][branch] = {1: 1000.0 + 10.0 * need}
            sensitivity_rd_nx[co][(branch, gu)] = sign
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE,
        penalty_reference_rd_pra_per_tso=penalty_reference_rd_pra_per_tso,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx={}, sensitivity_rd_nx=sensitivity_rd_nx,
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial=lf_initial,
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


# ---- builders for the curative pst groups tests ----
PENALTY_REFERENCE = 10.0


TATL = {"B1": {"tatl_duration_seconds": 1800, "tatl_limit_ampere": 1200.0, "side": 1}}


GROUP = "GSARA_GROUP"


def _group_pst(mrid, group_id=GROUP, contingencies=("CO1",), r0=0):
    pst = _make_pst(mrid, RAKind.CURATIVE, r0=r0, group_id=group_id)
    pst.reaction_time_minutes = 0.0
    pst.time_per_stage_minutes = 3.0  # (30 min - 0) / 3 = 10 taps
    pst.linked_contingency_mrids = list(contingencies)
    pst.linked_xne_mrids = []
    return pst


def _contingency(mrid, tripped=()):
    return Contingency(
        mrid=mrid, name=mrid, tso="TestTSO", contingency_type=ContingencyType.ORDINARY,
        must_study={"1030Z": True}, equipment_mrids=list(tripped), equipment_types=["transformer"] * len(tripped),
    )


def _three_psts(contingencies=("CO1",)):
    return [_group_pst(m, contingencies=contingencies) for m in ("G1", "G2", "G3")]


def _bounds(lo=-10, hi=10, mrids=("G1", "G2", "G3")):
    return {m: (lo, hi) for m in mrids}


def _solve_group_model(sens, group_kind="blockedGroup", tripped=(), bounds=None, loading=1050.0):
    psts = _three_psts()
    contingencies = [_contingency("CO1", tripped=tripped)]
    availability = compute_pst_cra_availability(psts, TATL, contingencies=contingencies)
    bounds = bounds or _bounds()
    filtered, triples = build_curative_pst_group_constraints(psts, availability, bounds, contingencies, group_kind)
    pst_inputs = PstMilpInputs(
        pst_list=psts, pst_tap_bounds={}, pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={m: 1.0 for m in ("G1", "G2", "G3")}, penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: loading}}},
        sensitivity_pst_nx={"CO1": {("B1", m): s for m, s in sens.items()}},
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=1000.0,
        pst_cra_availability=filtered, pst_tap_bounds_curative=bounds,
        curative_pst_group_triples=triples,
    )
    model = build_n0_milp_model(
        [_make_ae("B1")], "1030Z", lf_initial={"B1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, triples


# ---- builders for the milp builder results tests ----
def _make_ae_mb_results(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_rd_unit(mrid: str, gu_mrid: str, tso: str = "TestTSO") -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict, price_eur_mw: float = 0.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


# ---- builders for the nx filters and scanned elements tests ----
def _make_ae_nx_filters(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED):
    return AssessedElement(
        mrid=mrid, name="a", tso="TSO", ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


def _make_pst_nx_filters(mrid, r0=0):
    return PST(
        mrid=mrid, name=mrid, tso="TSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_contingency(mrid, equipment_mrids, must_study=True, timestamp="1030Z"):
    return Contingency(
        mrid=mrid, name=f"CO {mrid}", tso="TSO",
        contingency_type=ContingencyType.ORDINARY,
        must_study={timestamp: must_study},
        equipment_mrids=equipment_mrids,
    )


# ---- builders for the sensitivity lf parameters tests ----
class _LfParameters:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


class _Result:
    def __init__(self, matrices):
        self._matrices = matrices

    def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
        return self._matrices.get((matrix_id, contingency_id), self._matrices.get(matrix_id))

    def get_reference_matrix(self, matrix_id, contingency_id=None):
        return None


class _Analysis:
    def __init__(self, fake):
        self.fake = fake

    def add_single_element_contingency(self, *a):
        pass

    def add_multiple_elements_contingency(self, *a):
        pass

    def add_factor_matrix(self, **kwargs):
        pass

    def run(self, network, parameters=None, **kwargs):
        self.fake.sensitivity_parameters.append(parameters)
        return _Result(self.fake.matrices)


class _SecParameters:
    def __init__(self, load_flow_parameters=None, provider_parameters=None):
        self.load_flow_parameters = load_flow_parameters
        self.provider_parameters = provider_parameters


def _fake_pypowsybl(matrices):
    fake = types.ModuleType("pypowsybl")
    fake.matrices = matrices
    fake.sensitivity_parameters = []
    fake.loadflow_parameters = []
    fake.security_parameters = []

    sensitivity = types.ModuleType("pypowsybl.sensitivity")
    sensitivity.ContingencyContextType = SimpleNamespace(NONE="NONE", SPECIFIC="SPECIFIC", ALL="ALL")
    sensitivity.SensitivityFunctionType = SimpleNamespace(BRANCH_CURRENT_1="B1", BRANCH_CURRENT_2="B2")
    sensitivity.SensitivityVariableType = SimpleNamespace(
        TRANSFORMER_PHASE="TP", INJECTION_ACTIVE_POWER="IAP",
    )
    sensitivity.create_ac_analysis = lambda: _Analysis(fake)
    fake.sensitivity = sensitivity

    loadflow = types.ModuleType("pypowsybl.loadflow")
    loadflow.Parameters = _LfParameters

    def run_ac(network, parameters=None):
        fake.loadflow_parameters.append(parameters)
        return [SimpleNamespace(status=SimpleNamespace(name="CONVERGED"))]

    loadflow.run_ac = run_ac
    fake.loadflow = loadflow

    class _Security:
        def add_single_element_contingency(self, *a):
            pass

        def add_multiple_elements_contingency(self, *a):
            pass

        def add_monitored_elements(self, **kw):
            pass

        def run_ac(self, network, parameters=None):
            fake.security_parameters.append(parameters)
            raise _StopHere()

    security = types.ModuleType("pypowsybl.security")
    security.create_analysis = lambda: _Security()
    security.Parameters = _SecParameters
    fake.security = security
    return fake


class _StopHere(Exception):
    """the security analysis fake stops once it has seen its parameters"""


def _ae_lf_params(branch, side=1):
    return AssessedElement(
        mrid=f"ae-{branch}", name="a", tso="T", ae_type=AEType.SECURED, branch_mrid=branch,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": 1.0}, branch_side=side,
    )


def _pst_lf_params(mrid):
    return PST(
        mrid=mrid, name="p", tso="T", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
        low_step=-10, high_step=10, r0=0, operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _rd_lf_params(mrid, gu):
    return RDUnit(
        mrid=mrid, name="r", tso="T", gu_mrid=gu, gu_name="g", available=True, kind=RAKind.PREVENTIVE,
        initial_p=10.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _co(mrid):
    return Contingency(
        mrid=mrid, name="c", tso="T", contingency_type=ContingencyType.ORDINARY,
        must_study={"1030Z": True}, equipment_mrids=["eq"],
    )


def _install(monkeypatch):
    matrices = {
        "psdf_n0_side1": pd.DataFrame([[1.0]], index=["p1"], columns=["b1"]),
        "ptdf_rd_n0_side1": pd.DataFrame([[1.0]], index=["g1"], columns=["b1"]),
        ("nx_side1", "c1"): pd.DataFrame([[1.0]], index=["p1"], columns=["b1"]),
    }
    fake = _fake_pypowsybl(matrices)
    monkeypatch.setitem(sys.modules, "pypowsybl", fake)
    monkeypatch.setitem(sys.modules, "pypowsybl.sensitivity", fake.sensitivity)
    monkeypatch.setitem(sys.modules, "pypowsybl.loadflow", fake.loadflow)
    return fake


# ---- builders for the completeness loop tests ----
_NESTED_OVERRIDES = {
    "max_change_ra_sum_threshold": 1.0, "max_rd_mw_change_threshold": 1.0, "max_change_ra": 1.0,
    "max_change_overload": 1.0, "max_linearisation_iterations": 5,
}


def _run_nested(monkeypatch, new_pairs_by_check, max_completeness_iterations):
    """find_new_pairs returns the numbers in new_pairs_by_check, one per check (the last repeats)."""
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides=dict(_NESTED_OVERRIDES))
    state = scenario.new_state()
    calls = []

    def find_new_pairs(model, lf_nx):
        calls.append(len(calls))
        return new_pairs_by_check[min(len(calls) - 1, len(new_pairs_by_check) - 1)]

    base = scenario.hooks()
    hooks = acl.NxLoopHooks(
        compute_lf_nx=base.compute_lf_nx, compute_sensitivities_nx=base.compute_sensitivities_nx,
        find_new_pairs=find_new_pairs,
    )
    _, _, _, reason, log_rows = acl.run_nested_rao_loop(
        max_completeness_iterations=max_completeness_iterations, state=state, nx_hooks=hooks,
        **scenario.loop_kwargs(),
    )
    return scenario, state, reason, log_rows, calls


# ---- builders for the milp builder scanned elements tests ----
def _make_ae_mb_scanned(branch_mrid: str, ae_type: AEType, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}_{ae_type.value}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_mb_scanned(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


# ---- builders for the milp builder nx tests ----
def _make_ae_mb_nx(branch_mrid: str, side: int = 1, patl_ka: float = 1.0,
             ae_type=AEType.SECURED, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_mb_nx(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_pst_inputs(pst_mrid="PST1", r0=0, sensitivity_n0=5.0, degrees_per_tap=1.5, branch="BRANCH1"):
    return PstMilpInputs(
        pst_list=[_make_pst_mb_nx(pst_mrid, r0=r0)],
        pst_tap_bounds={pst_mrid: (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={(branch, pst_mrid): sensitivity_n0},
        pst_degrees_per_tap={pst_mrid: degrees_per_tap},
        penalty_reference_pst_pra=10.0,
    )


# ---- builders for the ncp parser tests ----
_RA_HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
"""


_RA_FOOTER = "</rdf:RDF>\n"


def _write_penalty_factor_ra(tmp_path: Path, body: str) -> Path:
    path = tmp_path / "Test_RA.xml"
    path.write_text(_RA_HEADER + body + _RA_FOOTER)
    return path


# ---- builders for the results summary tests ----
REFERENCE_PST = 10.0


REFERENCE_RD = 10.0


def _all_terms_scenario():
    """Every cost component non-zero: N-0 branch B1 overloaded (PST limited to 3
    taps, RD limited by a soft RA-count limit), N-X branch B2 overloaded under CO1
    (curative PST capped at 3 taps, curative RD 20 MW, rest stays as slack)."""
    preventive_pst = _make_pst("P1", RAKind.PREVENTIVE)
    curative_pst = _make_pst("CP", RAKind.CURATIVE)
    curative_pst.linked_contingency_mrids = ["CO1"]
    curative_pst.linked_xne_mrids = []
    pst_inputs = PstMilpInputs(
        pst_list=[preventive_pst, curative_pst],
        pst_tap_bounds={"P1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("B1", "P1"): -10.0},
        pst_degrees_per_tap={"P1": 1.0, "CP": 1.0},
        penalty_reference_pst_pra=REFERENCE_PST, max_taps_per_tso=3,
    )

    rd_list, bid_list, glsk, generator_data = [], [], {}, {}
    for ra, gu, kind, direction, price in (
        ("RD_UP", "GU_UP", RAKind.PREVENTIVE, BidDirection.UP, 1.0),
        ("RD_DN", "GU_DN", RAKind.PREVENTIVE, BidDirection.DOWN, 0.0),
        ("RD_C", "GU_C", RAKind.CURATIVE, BidDirection.UP, 2.0),
    ):
        unit = _unit(ra, gu)
        unit.kind = kind
        rd_list.append(unit)
        bid = _bid_rd_cost(f"BID_{ra}", ra, direction, price)
        bid.available_mw = {"1030Z": 20.0}
        bid_list.append(bid)
        glsk[ra] = {gu: 1.0}
        generator_data[gu] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned={("B1", "GU_UP"): -1.0},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE_RD,
        max_ra_count_per_timestamp_tso={"TestTSO": 1}, ra_limit_constraint_hard=False, ra_limit_penalty=7.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B2": {1: 1100.0}}},
        sensitivity_pst_nx={"CO1": {("B2", "CP"): -10.0}},
        sensitivity_rd_nx={"CO1": {("B2", "GU_C"): -1.0}},
        penalty_cost_overload_nx_patl=50.0,
        pst_cra_availability={("CP", "B2", "CO1"): {"max_curative_taps": 3, "available": True}},
        pst_tap_bounds_curative={"CP": (-10, 10)},
    )
    model = build_n0_milp_model(
        [_make_ae("B1"), _make_ae("B2")], "1030Z", lf_initial={"B1": {1: 1100.0}, "B2": {1: 500.0}},
        penalty_cost_overload_n0=30.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, pst_inputs, rd_inputs


# ---- builders for the nx security analysis tests ----
def _make_ae_nx_sec(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED):
    return AssessedElement(
        mrid=mrid, name="a", tso="TSO", ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


def _make_contingency_nx_sec(mrid, equipment_mrids, must_study=True, timestamp="1030Z"):
    return Contingency(
        mrid=mrid, name=f"CO {mrid}", tso="TSO",
        contingency_type=ContingencyType.ORDINARY,
        must_study={timestamp: must_study},
        equipment_mrids=equipment_mrids,
    )


class DummyContingencyContextType:
    NONE = "NONE"
    SPECIFIC = "SPECIFIC"
    ALL = "ALL"


class DummySensitivityFunctionType:
    BRANCH_CURRENT_1 = "BRANCH_CURRENT_1"
    BRANCH_CURRENT_2 = "BRANCH_CURRENT_2"


class DummySensitivityVariableType:
    TRANSFORMER_PHASE = "TRANSFORMER_PHASE"
    INJECTION_ACTIVE_POWER = "INJECTION_ACTIVE_POWER"


class DummySensitivityResult:
    def __init__(self, matrices: dict):
        # matrices: dict[(matrix_id, contingency_id), DataFrame]
        self._matrices = matrices

    def get_sensitivity_matrix(self, matrix_id, contingency_id=None):
        return self._matrices.get((matrix_id, contingency_id))


class DummySensitivityAnalysis:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.single_element_contingencies = []   # list of (element_id, contingency_id)
        self.multiple_element_contingencies = []  # list of (element_ids, contingency_id)
        self.add_factor_matrix_calls = []         # list of kwargs dicts

    def add_single_element_contingency(self, element_id, contingency_id):
        self.single_element_contingencies.append((element_id, contingency_id))

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        self.multiple_element_contingencies.append((list(element_ids), contingency_id))

    def add_factor_matrix(self, **kwargs):
        self.add_factor_matrix_calls.append(kwargs)

    def run(self, network, parameters=None):
        return DummySensitivityResult(self._matrices)


class DummySensitivityModule:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.ContingencyContextType = DummyContingencyContextType
        self.SensitivityFunctionType = DummySensitivityFunctionType
        self.SensitivityVariableType = DummySensitivityVariableType
        self.last_analysis = None

    def create_ac_analysis(self):
        self.last_analysis = DummySensitivityAnalysis(self._matrices)
        return self.last_analysis


class DummyPostContingencyResult:
    def __init__(self, status_name: str):
        self.status = type("Status", (), {"name": status_name})()


class DummySecurityAnalysisResult:
    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self.post_contingency_results = post_contingency_results
        self.branch_results = branch_results


class DummySecurityAnalysis:
    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results
        self.single_element_contingencies = []
        self.multiple_element_contingencies = []
        self.monitored_branch_ids = None

    def add_single_element_contingency(self, element_id, contingency_id):
        self.single_element_contingencies.append((element_id, contingency_id))

    def add_multiple_elements_contingency(self, element_ids, contingency_id):
        self.multiple_element_contingencies.append((list(element_ids), contingency_id))

    def add_monitored_elements(self, branch_ids):
        self.monitored_branch_ids = list(branch_ids)

    def run_ac(self, network, parameters=None):
        return DummySecurityAnalysisResult(self._post_contingency_results, self._branch_results)


class DummySecurityModule:
    class Parameters:
        def __init__(self, load_flow_parameters=None, provider_parameters=None):
            self.load_flow_parameters = load_flow_parameters
            self.provider_parameters = provider_parameters

    def __init__(self, post_contingency_results: dict, branch_results: pd.DataFrame):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results
        self.last_analysis = None

    def create_analysis(self):
        self.last_analysis = DummySecurityAnalysis(self._post_contingency_results, self._branch_results)
        return self.last_analysis


class DummyLoadflowModule:
    """Minimal stand-in for pypowsybl.loadflow, reached by attribute access (as the code
    under test uses it)."""
    class Parameters:
        """Spy: records the kwargs of its latest construction at class level, so tests can
        check that use_reactive_limits reaches the construction."""
        last_kwargs = None

        def __init__(self, **kwargs):
            DummyLoadflowModule.Parameters.last_kwargs = kwargs
            for key, value in kwargs.items():
                setattr(self, key, value)


class DummyPypowsyblModule:
    def __init__(self, sensitivity_matrices=None, post_contingency_results=None, branch_results=None):
        self.sensitivity = DummySensitivityModule(sensitivity_matrices or {})
        self.security = DummySecurityModule(post_contingency_results or {}, branch_results)
        self.loadflow = DummyLoadflowModule()


def _branch_results_df(rows: list[dict]) -> pd.DataFrame:
    """rows: list of dicts with keys contingency_id, branch_id, i1, i2."""
    if not rows:
        return pd.DataFrame(columns=["contingency_id", "branch_id", "i1", "i2"]).set_index(
            ["contingency_id", "branch_id"]
        )
    df = pd.DataFrame(rows)
    return df.set_index(["contingency_id", "branch_id"])


# ---- builders for the nx results export tests ----
def _make_ae_r39(branch_mrid, side=1, patl_ka=1.0, tso="TestTSO"):
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso=tso,
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=side,
    )


def _make_contingency_r39(mrid, name, equipment_mrids, must_study=True, timestamp="1030Z"):
    return Contingency(
        mrid=mrid, name=name, tso="TestTSO",
        contingency_type=ContingencyType.ORDINARY,
        must_study={timestamp: must_study},
        equipment_mrids=equipment_mrids,
    )


def _make_pst_inputs_r39(pst_mrid="PST1", sensitivity_n0=0.0, degrees_per_tap=1.0):
    return PstMilpInputs(
        pst_list=[PST(
            mrid=pst_mrid, name=pst_mrid, tso="T", available=True, kind=RAKind.PREVENTIVE,
            penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
            operating_tap_min=-10, operating_tap_max=10, group_id=None,
        )],
        pst_tap_bounds={pst_mrid: (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", pst_mrid): sensitivity_n0},
        pst_degrees_per_tap={pst_mrid: degrees_per_tap},
        penalty_reference_pst_pra=10.0,
    )


def _solve(model):
    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


# ---- running the pipeline on the fixtures ----
REPO_ROOT = Path(__file__).resolve().parents[1]


_FIXTURES = REPO_ROOT / "tests" / "fixtures"


_MOCK_NX_CGM_ZIP = _FIXTURES / "CGM_package.zip"


_MOCK_NX_NCP_ZIP = _FIXTURES / "NCP_pst_fallback_scenario.zip"


def run_pipeline_on_fixture_inputs(
    work_dir: Path, ncp_zip: Path, enable_nx_analysis: bool, prepare_output_dir=None,
    customize_pipeline=None,
) -> SimpleNamespace:
    """Run run_pipeline.main() once on CGM_package.zip + ncp_zip inside
    work_dir (input/ and output/ are created there). prepare_output_dir, if
    given, is called with the output directory BEFORE the run (used to
    pre-populate stale files). customize_pipeline, if given, is called with
    (run_pipeline module, monkeypatch) before the run. Returns the output directory and the
    instrumentation records."""
    input_dir, output_dir = work_dir / "input", work_dir / "output"
    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy(_MOCK_NX_CGM_ZIP, input_dir / "cgm.zip")
    shutil.copy(ncp_zip, input_dir / "ncp.zip")
    if prepare_output_dir is not None:
        prepare_output_dir(output_dir)

    rp = importlib.import_module("run_pipeline")
    records = SimpleNamespace(glsk_results_per_tso=[])
    monkeypatch = pytest.MonkeyPatch()
    # A real run (python run_pipeline.py) logs at INFO to run_log.txt; under
    # pytest the root logger usually sits at WARNING, so set it for this run.
    root_logger = logging.getLogger()
    previous_root_level = root_logger.level
    root_logger.setLevel(logging.INFO)
    try:
        monkeypatch.setattr(rp, "INPUT_DIR", input_dir)
        monkeypatch.setattr(rp, "OUTPUT_DIR", output_dir)
        monkeypatch.setattr(rp, "ENABLE_NX_ANALYSIS", enable_nx_analysis)
        monkeypatch.setattr(rp, "ENABLE_PST_REMEDIAL_ACTIONS", True)
        monkeypatch.setattr(rp, "ENABLE_RD_REMEDIAL_ACTIONS", True)

        original_resolve_glsk = rp.glsk_resolver.resolve_glsk

        def recording_resolve_glsk(*args, **kwargs):
            result = original_resolve_glsk(*args, **kwargs)
            records.glsk_results_per_tso.append(dict(result))
            return result

        monkeypatch.setattr(rp.glsk_resolver, "resolve_glsk", recording_resolve_glsk)
        if customize_pipeline is not None:
            customize_pipeline(rp, monkeypatch)
        rp.main()
    finally:
        monkeypatch.undo()
        root_logger.setLevel(previous_root_level)
        # main() attaches a FileHandler to the root logger; detach and close
        # it so the log file of this run is complete and no handler leaks.
        for handler in list(root_logger.handlers):
            if isinstance(handler, logging.FileHandler) and Path(handler.baseFilename).parent == output_dir:
                root_logger.removeHandler(handler)
                handler.close()
    return SimpleNamespace(output_dir=output_dir, records=records)

# ---- an Instance/-shaped tree built from the fixture zips ----
# NCP_generic.zip holds the NCP files of the ReliCapGrid instance and CGM_package.zip its
# EQ files (identical content, line endings aside), so the tests that read single NCP or EQ
# files work on this tree instead of a separate copy of the dataset.

FIXTURE_CGM_ZIP = _FIXTURES / "CGM_package.zip"
FIXTURE_NCP_GENERIC_ZIP = _FIXTURES / "NCP_generic.zip"
_RECOGNIZED_PROFILE_SUFFIXES = ("AE", "CO", "RA", "SHS", "SIS")
_INSTANCE_ROOT_CACHE: list = []


def _ncp_folder_for(file_name: str) -> str:
    """Instance/ folder of an NCP file: Org-* -> commonData, a cross-TSO export
    ("Svedala-Belgovia_CO.xml") -> its first TSO, otherwise the part before the profile."""
    if file_name.startswith("Org-"):
        return "commonData"
    prefix = file_name.rsplit("_", 1)[0]
    if prefix.startswith("DC-"):
        return prefix
    return prefix.split("-", 1)[0]


def _eq_folder_for(file_name: str) -> str:
    """Instance/ folder of an EQ file: "..._HVDC-Espheim-Svedala_EQ_1.xml" ->
    "DC-Espheim-Svedala", "20220615T2230Z__Belgovia_EQ_1.xml" -> "Belgovia"."""
    name = file_name.split("_EQ")[0].rsplit("_", 1)[-1]
    return "DC-" + name[len("HVDC-"):] if name.startswith("HVDC-") else name


def fixture_instance_root() -> Path:
    """Build (once per session, in a temp folder) an Instance/ tree:
    {TSO}/NetworkCode/cimxml/{TSO}_{PROFILE}.xml from NCP_generic.zip,
    commonData/NetworkCode/cimxml/Org-NineRealms_CD.xml, and
    {TSO}/Grid/cimxml/*_EQ_*.xml from CGM_package.zip."""
    if _INSTANCE_ROOT_CACHE:
        return _INSTANCE_ROOT_CACHE[0]
    import atexit
    import tempfile
    import zipfile

    base = Path(tempfile.mkdtemp(prefix="rao_instance_"))
    atexit.register(shutil.rmtree, base, True)
    root = base / "Instance"
    with zipfile.ZipFile(FIXTURE_NCP_GENERIC_ZIP) as zf:
        for name in zf.namelist():
            file_name = name.rsplit("/", 1)[-1]
            target = root / _ncp_folder_for(file_name) / "NetworkCode" / "cimxml" / file_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(name))
    with zipfile.ZipFile(FIXTURE_CGM_ZIP) as zf:
        for name in zf.namelist():
            file_name = name.rsplit("/", 1)[-1]
            if "_EQ_" not in file_name:
                continue
            target = root / _eq_folder_for(file_name) / "Grid" / "cimxml" / file_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(name))
    _INSTANCE_ROOT_CACHE.append(root)
    return root


def build_fixture_input_folder(input_dir: Path) -> Path:
    """An input/ folder for run_pipeline.main(): cgm.zip = CGM_package.zip, ncp.zip = the
    Org-NineRealms_CD.xml and every {TSO}_{AE,CO,RA,SHS,SIS}.xml of the fixture Instance/
    tree. Returns input_dir."""
    import zipfile

    root = fixture_instance_root()
    input_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy(FIXTURE_CGM_ZIP, input_dir / "cgm.zip")
    with zipfile.ZipFile(input_dir / "ncp.zip", "w") as zf:
        org_file = root / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        zf.write(org_file, arcname=org_file.name)
        for tso_dir in sorted(root.iterdir()):
            cimxml_dir = tso_dir / "NetworkCode" / "cimxml"
            if not cimxml_dir.is_dir():
                continue
            for suffix in _RECOGNIZED_PROFILE_SUFFIXES:
                candidate = cimxml_dir / f"{tso_dir.name}_{suffix}.xml"
                if candidate.exists():
                    zf.write(candidate, arcname=candidate.name)
    return input_dir

# ---- MILP model fingerprints (builder equality tests) ----
def milp_model_fingerprint(model) -> dict:
    """{constraint or objective name: sha256 of its exact algebra}: bounds, constant and every
    (variable name, coefficient) of generate_standard_repn, floats as repr, rows sorted by name."""
    import hashlib
    from pyomo.repn import generate_standard_repn

    def digest(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def algebra(expression) -> str:
        repn = generate_standard_repn(expression, compute_values=True, quadratic=False)
        terms = sorted((v.name, repr(float(c))) for v, c in zip(repn.linear_vars, repn.linear_coefs))
        return f"{float(repn.constant)!r}|{terms}"

    fingerprint = {}
    for constraint in model.component_data_objects(pyo.Constraint, active=True, sort=True):
        lower = None if constraint.lower is None else repr(float(pyo.value(constraint.lower)))
        upper = None if constraint.upper is None else repr(float(pyo.value(constraint.upper)))
        fingerprint[constraint.name] = digest(f"{lower}|{upper}|{algebra(constraint.body)}")
    for objective in model.component_data_objects(pyo.Objective, active=True, sort=True):
        fingerprint[objective.name] = digest(f"{objective.sense}|{algebra(objective.expr)}")
    return fingerprint


def synthetic_curative_milp_inputs(seed: int = 7) -> dict:
    """Deterministic build_n0_milp_model keyword arguments: 12 secured branches with a TATL,
    6 contingencies, 4 PSTs (preventive and curative), 6 preventive and 3 curative RD units with
    UP/DOWN bids; half of the N-X sensitivities are zero."""
    import random
    rnd = random.Random(seed)
    timestamp = "1030Z"
    branches = [f"B{i}" for i in range(12)]
    contingencies = [f"C{i}" for i in range(6)]
    ae_flat_list = [AssessedElement(
        mrid=f"AE{b}", name=b, tso=f"T{i % 2}", ae_type=AEType.SECURED, branch_mrid=b,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: 1.0}, branch_side=1 + (i % 2)) for i, b in enumerate(branches)]
    lf_initial = {b: {1: rnd.uniform(700, 1050), 2: rnd.uniform(700, 1050)} for b in branches}
    pst_ids = [f"P{i}" for i in range(4)]
    pst_list = []
    for i, p in enumerate(pst_ids):
        for kind in (RAKind.PREVENTIVE, RAKind.CURATIVE):
            pst_list.append(PST(
                mrid=p, name=f"{p}-{kind.value}", tso=f"T{i % 2}", available=True, kind=kind,
                penalty_factor=1.0, low_step=-10, high_step=10, r0=0, operating_tap_min=-10,
                operating_tap_max=10, group_id=None, reaction_time_minutes=1.0, time_per_stage_minutes=1.0,
                linked_contingency_mrids=list(contingencies)))
    units = [(f"G{i}", RAKind.PREVENTIVE) for i in range(6)] + [(f"GC{i}", RAKind.CURATIVE) for i in range(3)]
    rd_list = [RDUnit(
        mrid=f"R{g}", name=g, tso=f"T{i % 2}", gu_mrid=g, gu_name=g, available=True, kind=kind,
        initial_p=100.0, max_p=300.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=list(contingencies)) for i, (g, kind) in enumerate(units)]
    bid_list = [PowerBid(
        mrid=f"BID{g}{d.value}", ra_mrid=f"R{g}", direction=d, available_mw={timestamp: 50.0},
        price_eur_mw=rnd.uniform(5, 50), penalty_factor=1.0, lead_time_h=0.0, activation_cost_eur=None,
        min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None)
        for g, _ in units for d in (BidDirection.UP, BidDirection.DOWN)]
    gu_ids = [g for g, _ in units]

    def sensitivities(variables, scale):
        return {(b, v): (rnd.uniform(-scale, scale) if rnd.random() < 0.5 else 0.0)
                for b in branches for v in variables}

    pst_inputs = PstMilpInputs(
        pst_list=pst_list, pst_tap_bounds={p: (-10, 10) for p in pst_ids}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned=sensitivities(pst_ids, 20.0), pst_degrees_per_tap={p: 1.5 for p in pst_ids},
        penalty_reference_pst_pra=100.0,
    )
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk={f"R{g}": {g: 1.0} for g in gu_ids},
        sensitivity_rd_n0_pruned=sensitivities(gu_ids, 2.0),
        generator_data={g: {"target_p": 100.0, "max_p": 300.0, "min_p": 0.0} for g in gu_ids},
        penalty_reference_rd_pra=100.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={c: {b: {1: rnd.uniform(700, 1150), 2: rnd.uniform(700, 1150)} for b in branches} for c in contingencies},
        sensitivity_pst_nx={c: sensitivities(pst_ids, 20.0) for c in contingencies},
        sensitivity_rd_nx={c: sensitivities(gu_ids, 2.0) for c in contingencies},
        penalty_cost_overload_nx_patl=10000.0, penalty_cost_overload_nx_tatl=100000.0,
        tatl_data={b: {"tatl_limit_ampere": 1100.0, "tatl_duration_seconds": 600, "side": 1 + (i % 2)}
                   for i, b in enumerate(branches)},
        pst_cra_availability={(p, b, c): {"max_curative_taps": 3, "available": True}
                              for p in pst_ids for b in branches for c in contingencies},
        pst_tap_bounds_curative={p: (-10, 10) for p in pst_ids},
    )
    return dict(ae_flat_list=ae_flat_list, timestamp=timestamp, lf_initial=lf_initial,
                penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs, nx_inputs=nx_inputs)

def milp_model_fingerprint_by_family(model) -> dict:
    """{component name (constraint family or objective): sha256 over its rows' fingerprints}."""
    import hashlib
    families: dict[str, list[str]] = {}
    for row_name, row_hash in milp_model_fingerprint(model).items():
        families.setdefault(row_name.split("[")[0], []).append(f"{row_name}={row_hash}")
    return {name: hashlib.sha256("\n".join(rows).encode("utf-8")).hexdigest() for name, rows in sorted(families.items())}


def fixture_run_models(work_dir: Path) -> list:
    """The models build_n0_milp_model returned in the mock N-X fixture run, in build order."""
    models = []

    def keep_models(rp, monkeypatch):
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping_build(*args, **kwargs):
            model = build(*args, **kwargs)
            models.append(model)
            return model

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping_build)

    run_pipeline_on_fixture_inputs(work_dir, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=keep_models)
    return models

def write_milp_model_fingerprints(path: Path) -> None:
    """Fingerprints (by family) of the synthetic model and of every model of the mock fixture
    run, as JSON. Run with PYTHONHASHSEED=0: set iteration order changes float summation order
    in the last bits, so only a fixed hash seed gives bit-repeatable fingerprints."""
    import json
    import tempfile
    from milp.milp_builder import build_n0_milp_model
    out = {"synthetic": milp_model_fingerprint_by_family(build_n0_milp_model(**synthetic_curative_milp_inputs()))}
    with tempfile.TemporaryDirectory() as work_dir:
        out["fixture_run"] = [milp_model_fingerprint_by_family(m) for m in fixture_run_models(Path(work_dir))]
    Path(path).write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
