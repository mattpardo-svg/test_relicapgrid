"""tests/test_rao_lf_parameters.py - tests for lf_parameters.py and for the load-flow parameters every call site hands to pypowsybl.

Sections: parameters of the sensitivity and load-flow call sites, and contingency propagation off in every security analysis.
"""

import sys
import types
import pandas as pd
import pytest
import inspect

from pathlib import Path
from types import SimpleNamespace
from helpers import (
    _MOCK_NX_NCP_ZIP,
    run_pipeline_on_fixture_inputs,
    _Analysis,
    _LfParameters,
    _Result,
    _SecParameters,
    _StopHere,
    _ae_lf_params as _ae,
    _co,
    _fake_pypowsybl,
    _install,
    _pst_lf_params as _pst,
    _rd_lf_params as _rd,
)
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit
from pre_milp import lf_parameters, sensitivity_checks as sv

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


EXTRA = {"distributed_slack": False, "balance_type": "SOME_BALANCE", "voltage_init_mode": "SOME_INIT"}


def _call_all_sensitivities(monkeypatch, **lf_kwargs):
    """run the four sensitivity functions on the fake; returns the fake"""
    from pre_milp import n0_sensitivity, nx_sensitivity
    fake = _install(monkeypatch)
    aes = [_ae("b1")]
    n0_sensitivity.compute_sensitivity_pst_n0(None, [_pst("p1")], aes, "1030Z", **lf_kwargs)
    n0_sensitivity.compute_sensitivity_rd_n0(None, [_rd("r1", "g1")], aes, "1030Z", **lf_kwargs)
    lf_nx = {"c1": {"b1": {1: 100.0}}}
    nx_sensitivity.compute_sensitivity_pst_nx(
        None, [_co("c1")], [_pst("p1")], aes, "1030Z", lf_nx=lf_nx, lf_initial={"b1": {1: 50.0}}, **lf_kwargs,
    )
    fake.matrices[("nx_side1", "c1")] = pd.DataFrame([[1.0]], index=["g1"], columns=["b1"])
    nx_sensitivity.compute_sensitivity_rd_nx(
        None, [_co("c1")], [_rd("r1", "g1")], aes, "1030Z", lf_nx=lf_nx, lf_initial={"b1": {1: 50.0}}, **lf_kwargs,
    )
    return fake


# ---------------------------------------------------------------------------
# A: the single source
# ---------------------------------------------------------------------------

def test_the_builder_merges_use_reactive_limits_extras_and_overrides(monkeypatch):
    from pre_milp.lf_parameters import build_loadflow_parameters
    _install(monkeypatch)
    plain = build_loadflow_parameters(False, EXTRA)
    assert plain.kwargs == {"use_reactive_limits": False, **EXTRA}
    overridden = build_loadflow_parameters(True, EXTRA, voltage_init_mode="PREVIOUS_VALUES")
    assert overridden.kwargs == {"use_reactive_limits": True, **{**EXTRA, "voltage_init_mode": "PREVIOUS_VALUES"}}
    assert build_loadflow_parameters().kwargs == {"use_reactive_limits": False}


def test_all_four_sensitivity_functions_pass_the_load_flow_parameters_to_the_analysis(monkeypatch):
    fake = _call_all_sensitivities(monkeypatch, use_reactive_limits=True, extra_lf_params=EXTRA)
    assert len(fake.sensitivity_parameters) == 4
    for parameters in fake.sensitivity_parameters:
        assert parameters is not None
        assert parameters.kwargs == {"use_reactive_limits": True, **EXTRA}


@pytest.mark.parametrize("index", [0, 1, 2, 3], ids=["n0_pst", "n0_rd", "nx_pst", "nx_rd"])
def test_each_sensitivity_function_passes_its_own_parameters(monkeypatch, index):
    fake = _call_all_sensitivities(monkeypatch, use_reactive_limits=False, extra_lf_params=EXTRA)
    assert fake.sensitivity_parameters[index] is not None
    assert fake.sensitivity_parameters[index].kwargs == {"use_reactive_limits": False, **EXTRA}


def test_sensitivities_and_the_load_flows_they_belong_to_use_identical_parameters(monkeypatch):
    from pre_milp import cgmes_loader, nx_security_analysis
    from milp import post_ra_congestion_check
    fake = _call_all_sensitivities(monkeypatch, use_reactive_limits=True, extra_lf_params=EXTRA)
    cgmes_loader.run_initial_loadflow(None, use_reactive_limits=True, extra_lf_params=EXTRA)
    post_ra_congestion_check._run_ac_loadflow(None, use_reactive_limits=True, extra_lf_params=EXTRA)
    with pytest.raises(_StopHere):
        nx_security_analysis.compute_lf_nx(
            None, [_co("c1")], [_ae("b1")], "1030Z", use_reactive_limits=True, extra_lf_params=EXTRA,
        )
    load_flow_side = [p.kwargs for p in fake.loadflow_parameters] + [p.load_flow_parameters.kwargs for p in fake.security_parameters]
    assert len(load_flow_side) == 3
    sensitivity_side = [p.kwargs for p in fake.sensitivity_parameters]
    assert all(kwargs == load_flow_side[0] for kwargs in load_flow_side + sensitivity_side)


# ---------------------------------------------------------------------------
# A: wiring at every call site, end to end on the real mock case
# ---------------------------------------------------------------------------

SITES = [
    ("compute_sensitivity_pst_n0", "main"),
    ("compute_sensitivity_rd_n0", "main"),
    ("compute_sensitivities_nx", "main"),
    ("compute_sensitivity_pst_n0", "_refresh_n0_sensitivities"),
    ("compute_sensitivity_rd_n0", "_refresh_n0_sensitivities"),
    ("compute_sensitivities_nx", "_nx_sensitivities_at_current_state"),
]


@pytest.fixture(scope="module")
def sensitivity_calls(tmp_path_factory):
    import inspect
    calls = []   # (function name, caller function name, parameters passed to the analysis, keyword arguments of the call)

    def customize(rp, monkeypatch):
        import pypowsybl as pp
        from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
        current = []
        real_run = AcSensitivityAnalysis.run

        def spy_run(self, network, parameters=None, *args, **kwargs):
            current.append(parameters)
            return real_run(self, network, parameters, *args, **kwargs)

        monkeypatch.setattr(AcSensitivityAnalysis, "run", spy_run)

        def wrap(owner, name):
            real = getattr(owner, name)

            def spy(*args, **kwargs):
                caller = inspect.stack()[1].function
                current.clear()
                result = real(*args, **kwargs)
                calls.append((name, caller, list(current), dict(kwargs)))
                return result

            monkeypatch.setattr(owner, name, spy)

        acl = rp.ac_convergence_loop
        for name in ("compute_sensitivity_pst_n0", "compute_sensitivity_rd_n0"):
            wrap(rp.n0_sensitivity, name)          # pipeline: n0_sensitivity.<name>(...)
            wrap(acl, name)                        # loop refresh: imported name
        wrap(rp, "compute_sensitivities_nx")   # PST and RD N-X sensitivities: one analysis

    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("lf_parameter_sites"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        customize_pipeline=customize,
    )
    import run_pipeline as rp_module
    return SimpleNamespace(calls=calls, rp=rp_module, run=run)


def _parameters_dict(parameters):
    return {
        name: getattr(parameters, name)
        for name in (
            "use_reactive_limits", "distributed_slack", "balance_type", "voltage_init_mode",
            "component_mode", "transformer_voltage_control_on", "phase_shifter_regulation_on",
            "twt_split_shunt_admittance", "shunt_compensator_voltage_control_on", "read_slack_bus",
            "write_slack_bus", "hvdc_ac_emulation", "dc_power_factor",
        )
    }


def _expected(rp, **overrides):
    import pypowsybl as pp
    kwargs = {**rp.EXTRA_LF_PARAMS, **overrides}
    return _parameters_dict(pp.loadflow.Parameters(use_reactive_limits=rp.USE_REACTIVE_LIMITS, **kwargs))


@pytest.mark.parametrize("function,caller", SITES)
def test_every_call_site_passes_the_pipelines_load_flow_parameters(sensitivity_calls, function, caller):
    import pypowsybl as pp
    rp = sensitivity_calls.rp
    matching = [c for c in sensitivity_calls.calls if c[0] == function and c[1] == caller]
    assert matching, f"call site {function} from {caller} was never exercised"
    expected = _expected(
        rp, **({"voltage_init_mode": pp.loadflow.VoltageInitMode.PREVIOUS_VALUES}
               if caller == "_refresh_n0_sensitivities" else {}),
    )
    expected_extra = {**rp.EXTRA_LF_PARAMS}
    if caller == "_refresh_n0_sensitivities":
        expected_extra["voltage_init_mode"] = pp.loadflow.VoltageInitMode.PREVIOUS_VALUES
    for _, _, parameters_seen, call_kwargs in matching:
        assert len(parameters_seen) == 1
        assert parameters_seen[0] is not None, f"{function} from {caller} ran with pypowsybl's defaults"
        assert _parameters_dict(parameters_seen[0]) == expected
        # the call site itself hands the pipeline's settings down (not just defaults that happen to match)
        assert call_kwargs.get("use_reactive_limits") == rp.USE_REACTIVE_LIMITS
        assert call_kwargs.get("extra_lf_params") == expected_extra


def test_the_mock_case_exercises_every_call_site_at_least_once(sensitivity_calls):
    seen = {(c[0], c[1]) for c in sensitivity_calls.calls}
    assert set(SITES) <= seen


def test_the_loop_refresh_hands_the_extras_down_with_only_the_warm_start_overridden(monkeypatch):
    """the N-0 refresh inside the loop: same extras as every load flow, voltage init warm-started"""
    import pypowsybl as pp
    from milp import ac_convergence_loop as acl
    seen = {}

    def fake_compute(name):
        def compute(**kwargs):
            seen[name] = kwargs
            return {}
        return compute

    monkeypatch.setattr(acl, "compute_sensitivity_pst_n0", fake_compute("pst"))
    monkeypatch.setattr(acl, "compute_sensitivity_rd_n0", fake_compute("rd"))
    state = SimpleNamespace(current_lf_n0={}, sensitivity_pst_n0=None, sensitivity_rd_n0=None)
    acl._refresh_n0_sensitivities(
        state, object(), [_pst("p1")], [_rd("r1", "g1")], [_ae("b1")], "1030Z", 0.0, 0.0, True,
        extra_lf_params=EXTRA,
    )
    for name in ("pst", "rd"):
        assert seen[name]["use_reactive_limits"] is True
        assert seen[name]["extra_lf_params"] == {**EXTRA, "voltage_init_mode": pp.loadflow.VoltageInitMode.PREVIOUS_VALUES}


# ===========================================================================
# Contingency propagation
# ===========================================================================

# reference current of the sensitivity analysis vs lf_nx, relative to max(|lf_nx|, 1 A).
# Measured with propagation off: mock 1.7e-9 at the initial state; the permanent test asserts <= this.
REFERENCE_VS_LF_NX_TOLERANCE = 1e-4


def _propagation(parameters):
    return parameters.provider_parameters.get("contingencyPropagation")


# ------------------------------------------------------------------ the shared builder
def test_the_security_parameters_switch_propagation_off_and_carry_the_pipeline_load_flow_parameters():
    import pypowsybl as pp
    extra = {"distributed_slack": True, "voltage_init_mode": pp.loadflow.VoltageInitMode.UNIFORM_VALUES}
    parameters = lf_parameters.build_security_analysis_parameters(True, extra)
    assert isinstance(parameters, pp.security.Parameters)
    assert _propagation(parameters) == "false"
    expected = lf_parameters.build_loadflow_parameters(True, extra)
    assert repr(parameters.load_flow_parameters) == repr(expected)


def test_the_load_flow_parameters_builder_itself_is_unchanged_so_sensitivities_and_load_flows_are_not_touched():
    parameters = lf_parameters.build_loadflow_parameters(False, {"distributed_slack": True})
    assert not hasattr(parameters, "provider_parameters") or "contingencyPropagation" not in (parameters.provider_parameters or {})


# ------------------------------------------------------------------ every security analysis call
def test_compute_lf_nx_is_the_only_place_that_creates_a_security_analysis():
    """every site that needs lf_nx (initial, loop refresh, completeness check) goes through it"""
    offenders = []
    for path in sorted(REPO_SRC.rglob("*.py")):
        if path.name == "nx_security_analysis.py":
            continue
        text = path.read_text(encoding="utf-8")
        if "security.create_analysis(" in text or "create_security_analysis(" in text:
            offenders.append(path.name)
    assert offenders == []


@pytest.fixture(scope="module")
def pipeline_with_spies(tmp_path_factory):
    import pypowsybl as pp
    from pypowsybl.security.impl.security import SecurityAnalysis
    security_calls, references = [], []

    def customize(rp, monkeypatch):
        real_run_ac = SecurityAnalysis.run_ac

        def spy(self, network, parameters=None, *args, **kwargs):
            callers = [frame.function for frame in inspect.stack()[1:12]]
            security_calls.append({"parameters": parameters, "callers": callers})
            return real_run_ac(self, network, parameters, *args, **kwargs)

        monkeypatch.setattr(SecurityAnalysis, "run_ac", spy)
        real_sensitivities = rp.compute_sensitivities_nx

        def sensitivities_spy(*args, **kwargs):
            reference = {}
            result = real_sensitivities(*args, **{**kwargs, "pst_reference_out": reference})
            bound = inspect.signature(real_sensitivities).bind(*args, **kwargs)
            bound.apply_defaults()
            from milp.milp_builder import _get_monitored_branch_sides
            sides = _get_monitored_branch_sides(bound.arguments["ae_flat_list"])
            references.append((reference, bound.arguments["lf_nx"], sides))
            return result

        monkeypatch.setattr(rp, "compute_sensitivities_nx", sensitivities_spy)

    run = run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("propagation"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=customize,
    )
    return security_calls, references, run


def test_every_security_analysis_of_a_full_run_has_propagation_off(pipeline_with_spies):
    security_calls, _, _ = pipeline_with_spies
    assert len(security_calls) >= 2                     # the initial state and at least one refresh
    for call in security_calls:
        assert call["parameters"] is not None and _propagation(call["parameters"]) == "false", call["callers"][:4]


def test_the_initial_and_the_loop_refresh_sites_were_both_exercised(pipeline_with_spies):
    security_calls, _, _ = pipeline_with_spies
    callers = [set(call["callers"]) for call in security_calls]
    assert any("main" in c and "_nx_load_flow_at_current_state" not in c for c in callers)
    assert any("_nx_load_flow_at_current_state" in c for c in callers)


def _max_deviation(references):
    worst = 0.0
    for reference, lf_nx, sides in references:
        for contingency, branches in reference.items():
            for branch, value in branches.items():
                lf = lf_nx.get(contingency, {}).get(branch, {}).get(sides.get(branch, 1))
                if lf is None or lf != lf or value != value:
                    continue
                worst = max(worst, abs(value - lf) / max(abs(lf), sv.RELATIVE_FLOOR_AMPERE))
    return worst


def test_sensitivity_reference_equals_lf_nx_for_every_contingency_and_branch(pipeline_with_spies):
    """Both analyses model the same contingency (initial state and every refresh)."""
    _, references, _ = pipeline_with_spies
    assert len(references) >= 2
    assert len(references[0][0]) == 16                  # all mock must-study contingencies
    assert _max_deviation(references) <= REFERENCE_VS_LF_NX_TOLERANCE


def test_the_guard_tolerance_keeps_at_least_ten_times_margin_over_the_measured_deviation(pipeline_with_spies):
    _, references, _ = pipeline_with_spies
    assert _max_deviation(references) * 10 <= sv.NX_RELATIVE_TOLERANCE

# ===========================================================================
# lf_thread_count: OpenLoadFlow threadCount of the security and sensitivity analyses
# ===========================================================================

def test_thread_count_one_passes_nothing_and_keeps_the_load_flow_parameters(monkeypatch):
    import pypowsybl as pp
    monkeypatch.setattr(lf_parameters, "LF_THREAD_COUNT", 1)
    security = lf_parameters.build_security_analysis_parameters(False, {"distributed_slack": True})
    assert security.provider_parameters == {"contingencyPropagation": "false"}
    sensitivity = lf_parameters.build_sensitivity_parameters(False, {"distributed_slack": True})
    assert isinstance(sensitivity, pp.loadflow.Parameters)


def test_a_thread_count_above_one_reaches_both_analysis_parameters(monkeypatch):
    import pypowsybl as pp
    monkeypatch.setattr(lf_parameters, "LF_THREAD_COUNT", 3)
    security = lf_parameters.build_security_analysis_parameters(False, {"distributed_slack": True})
    assert security.provider_parameters == {"contingencyPropagation": "false", "threadCount": "3"}
    sensitivity = lf_parameters.build_sensitivity_parameters(False, {"distributed_slack": True})
    assert isinstance(sensitivity, pp.sensitivity.Parameters)
    assert sensitivity.provider_parameters == {"threadCount": "3"}
    assert sensitivity.load_flow_parameters.distributed_slack is True


def test_every_sensitivity_analysis_takes_the_sensitivity_parameters():
    """No sensitivity analysis runs on the bare load-flow parameters (the thread count would be lost)."""
    for name in ("n0_sensitivity.py", "nx_sensitivity.py"):
        text = (REPO_SRC / "pre_milp" / name).read_text(encoding="utf-8")
        assert "parameters=build_loadflow_parameters(" not in text, name
        assert "parameters=build_sensitivity_parameters(" in text, name


@pytest.fixture(scope="module")
def two_thread_run_calls(tmp_path_factory):
    from pypowsybl.security.impl.security import SecurityAnalysis
    from pypowsybl.sensitivity.impl.ac_sensitivity_analysis import AcSensitivityAnalysis
    seen = {"security": [], "sensitivity": []}

    def customize(rp, monkeypatch):
        real_security, real_sensitivity = SecurityAnalysis.run_ac, AcSensitivityAnalysis.run

        def security_spy(self, network, parameters=None, *args, **kwargs):
            seen["security"].append(parameters)
            return real_security(self, network, parameters, *args, **kwargs)

        def sensitivity_spy(self, network, parameters=None, *args, **kwargs):
            seen["sensitivity"].append(parameters)
            return real_sensitivity(self, network, parameters, *args, **kwargs)

        monkeypatch.setattr(SecurityAnalysis, "run_ac", security_spy)
        monkeypatch.setattr(AcSensitivityAnalysis, "run", sensitivity_spy)
        monkeypatch.setattr(rp, "LF_THREAD_COUNT", 2)
        monkeypatch.setattr(lf_parameters, "LF_THREAD_COUNT", lf_parameters.LF_THREAD_COUNT)

    run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("two_threads"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True, customize_pipeline=customize,
    )
    return seen


def test_lf_thread_count_reaches_every_security_and_sensitivity_analysis_of_a_run(two_thread_run_calls):
    assert two_thread_run_calls["security"] and two_thread_run_calls["sensitivity"]
    for parameters in two_thread_run_calls["security"] + two_thread_run_calls["sensitivity"]:
        assert parameters.provider_parameters.get("threadCount") == "2"
