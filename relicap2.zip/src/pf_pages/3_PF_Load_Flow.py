import streamlit as st
from typing import Any
from src.core.pf.loadflow_request import request_loadflow
from src.core.config import config

st.markdown("# Load Flow Computation")
st.sidebar.header("Load Flow Computation")


if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None and \
'pf_db_checked' in st.session_state and st.session_state.pf_db_checked:
    st.caption(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: {st.session_state.pf_db_checked}')
elif 'pf_current_model' in st.session_state:
    st.warning(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')
else:
    st.session_state.pf_current_model = config.get('paths', 'last_pf_model', '')
    st.error(f'Default Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')

def perform_lf() -> None:
    with st.spinner("Running Load Flow..."):
        if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None:
            result, lf_results, output = request_loadflow(st.session_state['pf_current_model'])
            st.session_state['pf_lf_result'] = result
            st.session_state['pf_lf_output'] = output
            if result:
                st.session_state['pf_lf_results'] = lf_results

def get_lf_results() -> Any:
    if 'pf_lf_results' in st.session_state and st.session_state['pf_lf_results'] is not None:
        return st.session_state['pf_lf_results']

def style_status(row):
    cloading = row.get("loading", row.get("loading", ""))
    if cloading > 100.:
        return ["background-color: #f8d7da"] * len(row)
    elif cloading > 80.:
        return ["background-color: #fff3cd"] * len(row)
    else:
        return ["background-color: #d4edda"] * len(row)

enabled = 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None
st.button("Perform Load Flow", type="primary", on_click=perform_lf, disabled=not enabled)

lf_result = None
if 'pf_lf_result' in st.session_state and st.session_state['pf_lf_result'] is not None:
    lf_result = st.session_state['pf_lf_result']

lf_attempted = 'pf_lf_result' in st.session_state

lf_has_results = False
if lf_result == True and 'pf_lf_results' in st.session_state and st.session_state['pf_lf_results'] is not None:
    lf_has_results = True

lf_has_output = False
if 'pf_lf_output' in st.session_state and st.session_state['pf_lf_output'] is not None:
    lf_has_output = True

# ---- Load Flow Summary ----
if lf_attempted or lf_has_results or lf_has_output:
    if lf_result is False:
        st.error("Load Flow failed.")
    with st.expander("Load Flow Log", expanded=False):
        if lf_has_output:
            st.text("\n".join(st.session_state['pf_lf_output']))

if lf_has_results:
    # ---- Branch Thermal Loading ----
    st.write("### Branch Thermal Loading")
    pd_res = get_lf_results().sort_values(by="loading", ascending=False, inplace=False)
    st.dataframe(pd_res.style.format(na_rep="-").apply(style_status, axis=1), width="stretch",
                 column_config={
                     "loading": st.column_config.NumberColumn(
                        "loading (%)",
                        help="Worst loading",
                        format="%.3f"
                     ),
                     "p1": st.column_config.NumberColumn(
                         "p1 (MW)",
                         help="Active Power in MW on side i",
                         format="%.4f"
                     ),
                     "q1": st.column_config.NumberColumn(
                         "q1 (Mvar)",
                         help="Reactive Power in MW on side i",
                         format="%.4f"
                     ),
                     "i1": st.column_config.NumberColumn(
                         "i1 (A)",
                         help="Current in A on side i",
                         format="%.4f"
                     ),
                     "inom1": st.column_config.NumberColumn(
                         "inom1 (A)",
                         help="Nominal Current in A on side i",
                         format="%.4f"
                     ),
                     "p2": st.column_config.NumberColumn(
                         "p2 (MW)",
                         help="Active Power in MW on side j",
                         format="%.4f"
                     ),
                     "q2": st.column_config.NumberColumn(
                         "q2 (Mvar)",
                         help="Reactive Power in MW on side j",
                         format="%.4f"
                     ),
                     "i2": st.column_config.NumberColumn(
                         "i2 (A)",
                         help="Current in A on side j",
                         format="%.4f"
                     ),
                     "inom2": st.column_config.NumberColumn(
                         "inom2 (A)",
                         help="Nominal Current in A on side j",
                         format="%.4f"
                     ),
                     "p3": st.column_config.NumberColumn(
                         "p3 (MW)",
                         help="Active Power in MW on side k",
                         format="%.4f"
                     ),
                     "q3": st.column_config.NumberColumn(
                         "q3 (Mvar)",
                         help="Reactive Power in MW on side k",
                         format="%.4f"
                     ),
                     "i3": st.column_config.NumberColumn(
                         "i3 (A)",
                         help="Current in A on side k",
                         format="%.4f"
                     ),
                     "inom3": st.column_config.NumberColumn(
                         "inom3 (A)",
                         help="Nominal Current in A on side k",
                         format="%.4f"
                     )
                 })