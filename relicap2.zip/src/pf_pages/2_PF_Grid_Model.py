import streamlit as st
import os
import tkinter as tk
from tkinter import filedialog
from src.core.config import config
from src.core.utilities import get_filename_without_extension
from src.core.pf.models_in_db_request import request_models_in_db
from src.core.pf.cgm_request import request_cgm_import

st.markdown("# PF Grid Model Import")
st.sidebar.header("PF Grid Model Import")

last_file = config.get('paths', 'last_opened_model', '')
st.session_state.setdefault('pf_last_index', 0)
st.session_state.setdefault('pf_db_checked', False)
st.session_state.setdefault('pf_model_imported', False)
if 'pf_db_list' not in st.session_state:
    last_pf_model = config.get('paths', 'last_pf_model', '')
    st.session_state['pf_db_list'] = [last_pf_model] # from config ini
    st.session_state['pf_current_model'] = last_pf_model

# This solution to pick a file only works if app is deployed on machine
# it will not work on a cloud
# This is preferred to a file_uploader because the file is actually uploaded
# saved in a temp location, but it will not work for large CGMs

def pick_file() -> str:
    root = tk.Tk()
    root.withdraw()  # Hide main window
    root.attributes('-topmost', True)
    file_path = filedialog.askopenfilename(
        parent=root,
        title="Select CGMES Grid Model",
        filetypes=[("zip files", "*.zip")],
        initialdir=os.path.dirname(last_file),
        initialfile=os.path.basename(last_file)
    )
    root.destroy()
    return file_path

def check_in_db() -> None:
    # request pf to return db
    with st.spinner("Checking the PowerFactory Database..."):
        st.session_state.pf_db_list = request_models_in_db()
        if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] in st.session_state.pf_db_list:
            st.session_state.pf_last_index = st.session_state.pf_db_list.index(st.session_state.pf_current_model)
            st.session_state['pf_last_model_found_in_db'] = True
        else:
            st.session_state.pf_last_index = 0
            if len(st.session_state.pf_db_list) > 0:
                st.session_state['pf_current_model'] = st.session_state.pf_db_list[0]
            else:
                st.session_state['pf_current_model'] = None
            st.session_state['pf_last_model_found_in_db'] = False

        st.session_state.pf_db_checked = True

def import_cgm():
    with st.spinner('Importing CGMES Model into Database...'):
        if 'pf_grid_model_file_path' in st.session_state and st.session_state.pf_grid_model_file_path is not None:
            result, model_name = request_cgm_import(st.session_state['pf_grid_model_file_path'])
            if result:
                st.session_state.pf_db_list.insert(0, model_name)
                st.session_state.pf_last_index = 0
                st.session_state.pf_current_model = model_name
                st.session_state.pf_model_imported = True
    return False

def change_pf_model():
    st.session_state.pf_current_model = st.session_state.pf_select_current_model
    st.session_state.pf_last_index = st.session_state.pf_db_list.index(st.session_state.pf_current_model)
    config.update_last_pf_model(st.session_state.pf_current_model)
    config.save_config()


file_selected = 'pf_grid_model_file_path' in st.session_state and st.session_state['pf_grid_model_file_path'] is not None

col1, col2, col3, col4 = st.columns([25,25,25,25])
with col1:
    st.button('Check PowerFactory Database', on_click=check_in_db, type='primary')

with col2:
    if st.button("Select a CGMES Grid Model", type='secondary'):
        file_path = pick_file()
        if file_path:
            # Save last opened file to config
            config.update_last_grid_file_path(file_path)
            config.save_config()
            st.session_state.pf_grid_model_file_path = file_path
            st.session_state.pf_model_from_file = get_filename_without_extension(file_path)
            file_selected = True

model_exists = None
if st.session_state.pf_db_checked:
    if 'pf_model_from_file' in st.session_state:
        if st.session_state.pf_model_from_file in st.session_state.pf_db_list:
            model_exists = True
        else:
            model_exists = False

with col3:
    enabled = file_selected == True and st.session_state.pf_db_checked and model_exists == False
    st.button('Import CGMES Grid Model', type='primary', on_click=import_cgm, disabled=not enabled)

with col4:
    st.button('Remove Grid Model from Database', disabled=True) # TODO

st.selectbox('Select Existing Grid Model in DB', st.session_state.pf_db_list, index = st.session_state.pf_last_index, 
             key="pf_select_current_model", on_change=change_pf_model)

# Success/Error messages after clicking on buttons
if st.session_state.pf_db_checked and st.session_state.pf_last_model_found_in_db:
    st.success(f'PF database has been verified. Current Grid Model: {st.session_state.pf_current_model}.')
elif st.session_state.pf_db_checked and not st.session_state.pf_last_model_found_in_db:
    st.warning(f'PF database has been verified. Initial model not found in DB. Current Grid Model: {st.session_state.pf_current_model}.')
else:
    st.error('PF database has not been yet verified')

if file_selected:
    if model_exists:
        st.success(f'''
                Selected file: {st.session_state.pf_grid_model_file_path} \n
                Model Name: {st.session_state.pf_model_from_file} \n
                Model in PF database: {model_exists}
                ''')
    else:
        st.warning(f'''
                Selected file: {st.session_state.pf_grid_model_file_path} \n
                Model Name: {st.session_state.pf_model_from_file} \n
                Model in PF database: {model_exists}
                ''')

if 'pf_model_imported' in st.session_state and st.session_state.pf_model_imported:
    st.success(f'Grid Model successfully imported: {st.session_state.pf_current_model}')

