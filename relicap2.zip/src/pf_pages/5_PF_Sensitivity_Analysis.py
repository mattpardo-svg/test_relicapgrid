import streamlit as st
import tempfile
from typing import Any
from src.core.pf.sensitivity_analysis_request import request_sensitivity_analysis
from src.core.config import config

st.markdown("# Sensitivity Analysis")
st.sidebar.header("Sensitivity Analysis")

def file_upload():
    # uploaded_ncp = st.session_state.sn_uploaded_ncp_xml
    # if uploaded_ncp is not None:
    #     with tempfile.NamedTemporaryFile(delete=False, prefix="pytsc_co_", suffix=".xml") as tmp:
    #         tmp.write(uploaded_ncp.getbuffer())
    #         st.session_state["remedial_actions_file_path"] = tmp.name
    #     st.session_state['pf_sn_remedial_actions'] = parse_contingencies(tmp.name, '_')
    st.session_state["remedial_actions_file_path"] = "Mockup path/Non existent folder/fake file.xml"

def perform_sn() -> None:
    with st.spinner("Running Sensitivity Analysis..."):
        if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None:
            result, sn_results, output = request_sensitivity_analysis(st.session_state['pf_current_model'], st.session_state["remedial_actions_file_path"])
            st.session_state['pf_sn_result'] = result
            st.session_state['pf_sn_output'] = output
            if result:
                st.session_state['pf_sn_results'] = sn_results

def get_sn_results() -> Any:
    if 'pf_sn_results' in st.session_state and st.session_state['pf_sn_results'] is not None:
        return st.session_state['pf_sn_results']

if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None and \
'pf_db_checked' in st.session_state and st.session_state.pf_db_checked:
    st.caption(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: {st.session_state.pf_db_checked}')
elif 'pf_current_model' in st.session_state:
    st.warning(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')
else:
    st.session_state.pf_current_model = config.get('paths', 'last_pf_model', '')
    st.error(f'Default Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')
if 'remedial_actions_file_path' in st.session_state:
    st.caption(f"Active Remedial Actions File: {st.session_state['remedial_actions_file_path']}")

st.write("**Upload or select an NCP XML contingency file**")
uploaded_ncp = st.file_uploader("Upload NCP XML", type=["xml"], key="sn_uploaded_ncp_xml", on_change=file_upload)

enabled = 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None
st.button("Perform Sensitivity Analysis", type="primary", on_click=perform_sn, disabled=not enabled)

sn_result = st.session_state.get('pf_sn_result')
sn_attempted = 'pf_sn_result' in st.session_state
sn_has_results = st.session_state.get('pf_sn_results') is not None
sn_has_output = st.session_state.get('pf_sn_output') is not None
sn_remedial_actions = st.session_state.get("pf_sn_remedial_actions") is not None

# ---- Sensitivity Analysis Summary ----
if sn_attempted or sn_remedial_actions or sn_has_output:
    if sn_result is False:
        st.error("Sensitivity Analysis failed.")
    with st.expander("Sensitivity Analysis Summary", expanded=False):
        if sn_remedial_actions:
            with st.expander("Remedial Actions Definition"):
                st.table(st.session_state.pf_sn_remedial_actions)

        if sn_has_output:
             with st.expander("Sensitivity Analysis Log"):
                 st.text("\n".join(st.session_state['pf_sn_output']))

if sn_has_results:
    # ---- Branch Thermal Loading ----
    st.write("### Senstivity Analysis Results")
    pd_res = get_sn_results()
    st.dataframe(pd_res)