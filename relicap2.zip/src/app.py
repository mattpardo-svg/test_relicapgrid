import streamlit as st
from PIL import Image
from pathlib import Path

from core.logger import get_logger
from core.config import config

logger = get_logger(__name__)

# Script-relative, not CWD-relative — found directly from a real failure:
# the original ".\src\images\..." path only resolved correctly when the
# command was launched from one specific working directory, and broke
# silently otherwise. Path(__file__).resolve().parent always finds
# app.py's own directory regardless of where `streamlit run` is invoked
# from — same fix pattern already used throughout this project's own
# GUI code (_gui_common.py) for exactly this reason.
_IMAGES_DIR = Path(__file__).resolve().parent / "images"
sidebar_logo = Image.open(_IMAGES_DIR / "TSCNET_Logo_Medium.png")
main_body_logo = Image.open(_IMAGES_DIR / "TSCNET_Full_Logo_3400px.png")

st.set_page_config(
    page_title="pyTSCFlowBox",
    page_icon=sidebar_logo,
    layout="wide", # Layout options: "centered" or "wide"
    initial_sidebar_state="expanded", # Sidebar state: "auto", "expanded", or "collapsed"
    menu_items={
    'Get Help': 'https://www.example.com/help',
    'Report a Bug': 'https://www.example.com/bug',
    'About': "# Welcome to pyTSCFlowBox\nModule PowSyBl Interface"
    }
)

st.logo(sidebar_logo, size="large", icon_image=main_body_logo)

pages = {
    "App": [st.Page("home.py", title="Home")],
    "Module: PowSyBl": [
        st.Page("olf_pages/1_PowSyBl_Configuration.py", title="PowSyBl Configuration"),
        st.Page("olf_pages/2_PSB_Grid_Model.py", title="PowSyBl Grid Model"),
        st.Page("olf_pages/4_Open_Load_Flow.py", title="Load Flow"),
        st.Page("olf_pages/3_PSB_Grid_Visualization.py", title="Grid Visualization"),
        st.Page("olf_pages/5_OLF_Security_Analysis.py", title="Security Analysis"),
        st.Page("olf_pages/6_OLF_Sensitivity_Analysis.py", title="Sensitivity Analysis"),
        st.Page("olf_pages/7_OLF_Apply_Remedial_Actions.py", title="Apply Remedial Actions"),
        st.Page("olf_pages/8_Open_RAO.py", title="Open RAO")
    ],
    "Module: PowerFactory": [
        st.Page("pf_pages/1_PowerFactory_Configuration.py", title="PowerFactory Configuration"),
        st.Page("pf_pages/2_PF_Grid_Model.py", title="PF Grid Model"),
        st.Page("pf_pages/3_PF_Load_Flow.py", title="PF Load Flow"),
        st.Page("pf_pages/4_PF_Security_Analysis.py", title="PF Security Analysis"),
        st.Page("pf_pages/5_PF_Sensitivity_Analysis.py", title="PF Sensitivity Analysis"),
        st.Page("pf_pages/6_PF_Apply_Remedial_Actions.py", title="PF Apply Remedial Actions")
    ],
    "Module: Closed RAO": [
        st.Page("rao_pages/1_Main.py", title="Main"),
        st.Page("rao_pages/2_Load_Flow_Settings.py", title="Load Flow Settings"),
        st.Page("rao_pages/3_RAO_Settings.py", title="RAO Settings"),
    ]
}

pg = st.navigation(pages, expanded=False)
pg.run()

st.divider()
st.caption("Prototype developed by TSCNET Services GmbH - Main contributors C. Pereira & O. Munoz & M. Sarfati")



