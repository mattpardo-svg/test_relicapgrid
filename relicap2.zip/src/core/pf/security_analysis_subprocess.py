import sys
from pathlib import Path
import pandas as pd
import uuid
import time
from argparse import ArgumentParser
import numpy as np
from typing import Any, Tuple, Dict
from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json
from src.core.pf.store_pf_results import store_pf_results, store_pf_output
from src.core.pf.config_pf_lf import get_pf_lf_configuration
from src.core.parser_contingencies import parse_contingencies
from src.core.pf.powerfactory_bootstrap import load_powerfactory_module

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
powerfactory = load_powerfactory_module()

def main(model_name:str, contingencies_file:str) -> None:
    logger.info(model_name)
    logger.info(contingencies_file)
    unique_name = f"{int(time.time())}_{uuid.uuid4().hex}"
    pd_ctg_def = _get_contingencies(contingencies_file)
    result, full_name, output_name = run_security_analysis(model_name, unique_name, pd_ctg_def)
    result_dict = {
        "model": model_name,
        "result": result,
        "sa_results": None if full_name is None else str(full_name),
        "output": None if output_name is None else str(output_name)
    }
    print(dict_to_json(result_dict))

def run_security_analysis(model_name:str, unique_name:str, pd_ctg_def:pd.DataFrame)  -> Tuple[bool, str, str]:
    logger.info('Running Security Analysis')
    try:
        app = powerfactory.GetApplicationExt()
        logger.debug('PowerFactory App successfully called')
        if _network_reactivate(app, model_name):
            result, file_results, file_output = _execute_security_analysis(app, unique_name, pd_ctg_def)
            return result, file_results, file_output
        return False, None, None

    except Exception as e:
        logger.error(f"Error during security analysis execution: {e}", exc_info=True)
        return False, None, None
        
def _network_exists(app:Any, model_name: str) -> bool:
    result = False
    user = app.GetCurrentUser()
    projects = user.GetContents('*.IntPrj',0)
    for project in projects:
        logger.debug(project.loc_name)
        if model_name == project.loc_name:
            result = (True, project.loc_name)
            logger.info(f'Network {model_name} exists')
    if not result:
        logger.info(f'Network {model_name} does not exist')
    return result

def _network_reactivate(app:Any, model_name: str) -> bool:
    exists = _network_exists(app, model_name)
    if exists:
        app.ActivateProject(model_name)
        logger.info('Project activated')
        folder = app.GetProjectFolder('study')
        logger.debug(folder)
        if folder:
            all_studies = folder.GetContents()
            for study in all_studies:
                logger.debug(study)
            if len(all_studies) > 0:
                all_studies[0].Activate()
                logger.info('Study Case activated')
                return True
    else:
        logger.info(f'Network {model_name} does not exist')
    return False

def _execute_security_analysis(app:Any, unique_name:str, pd_ctg_def:pd.DataFrame) -> Tuple[bool, str, str]:
    try:
        logger.info("Running security analysis...")
        comldf = app.GetFromStudyCase("ComLdf")
        comsa = app.GetFromStudyCase("ComSimOutage")
        lf_parameters = get_pf_lf_configuration()
        logger.info(lf_parameters)

        # set the parameters for the load flow calculation based on the retrieved configuration values
        _set_lf_configuration(comldf, lf_parameters)

        _define_contingencies(app, comsa, pd_ctg_def)

        # Run the contingency analysis
        logger.info("Running contingency analysis...")
        error_code = comsa.Execute()
        if error_code != 0:
            raise RuntimeError(f"Contingency analysis failed with error code {error_code}.")

        logger.info("Contingency analysis completed successfully.")

        # get output messages
        output_window = app.GetOutputWindow()
        if output_window:
            messages = output_window.GetContent()
            output_file = store_pf_output(messages, unique_name)

        sa_results_file = _get_sa_results(app, unique_name)
        return True, sa_results_file, output_file
            
    except Exception as e:
        logger.error(f"Error during security analysis execution: {e}", exc_info=True)
        return False, None, None
    
def _get_sa_results(app:Any, unique_name:str) -> str:
    # save ElmRes as a csv file and read it back as a pandas dataframe to be able to manipulate it and adapt the format to the needs of the TSCNET platform
    logger.info('Preparing security analysis results...')
    study_case = app.GetActiveStudyCase()
    # Get results object (assuming results are stored in a table object)
    elmRes = study_case.GetContents("*.ElmRes")[0] if study_case.GetContents("*.ElmRes") else None
    if not elmRes:
        raise RuntimeError("No results object found. Ensure the contingency analysis is configured to store results.")
    
    # add rfid of element in multiindex columns
    elmRes.Load()
    elements_rdfids = []
    numberOfColumns = elmRes.GetNumberOfColumns()
    for column in range(numberOfColumns):
        obj = elmRes.GetObject(column)
        if obj is not None and obj.GetClassName() in ['ElmLne', 'ElmTr2', 'ElmTr3']:
            rdfid = getattr(obj, 'e:cimRdfId')
            if len(rdfid) > 0:
                elements_rdfids.append(rdfid[0])
            else:
                elements_rdfids.append(None)
        else:
           elements_rdfids.append(None)
    elmRes.Release()

    # Get export command
    comRes = app.GetFromStudyCase('ComRes')
    comsa = app.GetFromStudyCase("ComSimOutage")
    # Result file from which data should be exported
    if comsa.iopt_Linear == 0 or comsa.iopt_Linear == 2 or comsa.iopt_Linear == 3:
        comRes.pResult = comsa.p_rescnt # for AC results
    elif comsa.iopt_Linear == 1 or comsa.iopt_Linear == 3:
        comRes.pResult = comsa.p_reslin # for DC results

    # Export as csv file
    comRes.iopt_exp = 6
    comRes.iopt_locn = 2 # short name and class
    comRes.ciopt_head = 1 # parameter name

    # File path
    RES_DIR = Path(__file__).parent.parent.parent.parent / "pf.tmp"
    full_filename = RES_DIR / f"{unique_name}.csv"
    comRes.f_name = str(full_filename)
    logger.info(f"Saving security analysis results to {full_filename}")
    comRes.Execute()

    # Read the csv file as a pandas dataframe
    logger.info(f"Retrieving security analysis results from {full_filename}")
    pd_res = pd.read_csv(full_filename, header=[0,1], low_memory=False, keep_default_na=False, na_values=['   ----', '  ----', ' ----', '----'])

    logger.debug('Adapting security analysis results format')
    # add rdfids as a third level in the column MultiIndex
    pd_res.columns = pd.MultiIndex.from_arrays(
        [
            pd_res.columns.get_level_values(0),
            pd_res.columns.get_level_values(1),
            elements_rdfids,
        ],
        names=["element", "parameter", "rdfid"],
    )

    # add rdfid of contingencies
    rdfids = []
    for index, row in pd_res.iterrows():
        iobj = int(row.iloc[0])
        outage = elmRes.GetObj(iobj)
        if outage is not None:
            rdfid = getattr(outage, 'e:loc_name')
            rdfids.append(rdfid)
        else:
            rdfids.append(None)

    pd_res.index = pd.Index(rdfids, name='contingency_rdfid')

    logger.debug('Filtering dataframe to only needed values')
    # Filter the dataframe to only include the necessary columns
    valid_classes = ['ElmLne', 'ElmTr2', 'ElmTr3']
    valid_parameters = ['m:i:bus1', 'm:i:bus2', 'm:i:bushv', 'm:i:buslv', 'm:i:busmv',
                        'm:P:bus1', 'm:P:bus2', 'm:P:bushv', 'm:P:buslv', 'm:P:busmv',
                        'c:loading', 'c:loading_st']
    selected_columns = []
    for column in pd_res.columns:
        if any(class_name in column[0] for class_name in valid_classes) and any(parameter_name in column[1] for parameter_name in valid_parameters):
            selected_columns.append(column)

    pd_filtered = pd_res[selected_columns]
    #logger.debug(pd_filtered)
    pd_res = _stack_results(pd_filtered)

    # just display loadings above 100%
    pd_res = pd_res[pd_res['loading'] > 99.9]

    logger.debug('Saving security analysis results')
    stored = store_pf_results(pd_res, unique_name)
    store_pf_results(pd_res, unique_name, '.xlsx') # this file is for debugging
    return stored
    
def _stack_results(pd_ctg: pd.DataFrame) -> pd.DataFrame:
    class element:
        def __init__(self, class_name, rdfid, parameter_name):
            self.class_name = class_name
            self.rdfid = rdfid
            self.parameter_name = parameter_name
            self.i1 = None
            self.i2 = None
            self.i3 = None
            self.P1 = None
            self.P2 = None
            self.P3 = None
            self.loading = None
            self.loading_st = None

        def break_into_sides(self, ctg_id):
            row_1 = (ctg_id, self.rdfid, self.loading, self.loading_st, self.i1, self.P1, 'ONE')
            row_2 = (ctg_id, self.rdfid, self.loading, self.loading_st, self.i2, self.P2, 'TWO')
            if self.i3 is not None and self.P3 is not None:
                row_3 = (ctg_id, self.rdfid, self.loading, self.loading_st, self.i3, self.P3, 'THREE')
            else:
                row_3 = None
            return row_1, row_2, row_3

    logger.info('Stacking results')
    data = []
    for index, row in pd_ctg.iterrows():
        ctg_id = index
        prev_rdfid = None
        current_element = None
        for column in list(pd_ctg.columns):
            _, class_name = column[0].replace('..', '.').split(sep='.')
            parameter_name = column[1]
            rdfid = column[2]
            if rdfid != prev_rdfid:
                #write data
                if current_element is not None:
                    row_1, row_2, row_3 = current_element.break_into_sides(ctg_id)
                    data.append(row_1)
                    data.append(row_2)
                    if row_3 is not None:
                        data.append(row_3)
                # create a new element
                current_element = element(class_name, rdfid, parameter_name)

            if current_element is not None:
                value = row[column]
                match parameter_name:
                    case 'm:i:bus1 in p.u.':
                        current_element.i1 = value
                    case 'm:i:bus2 in p.u.':
                        current_element.i2 = value
                    case 'm:i:bushv in p.u.':
                        current_element.i1 =value
                    case 'm:i:buslv in p.u.':
                        current_element.i2 = value
                    case 'm:i:busmv in p.u.':
                        current_element.i3 = value
                    case 'm:P:bus1 in MW':
                        current_element.P1 = value
                    case 'm:P:bus2 in MW':
                        current_element.P2 = value
                    case 'm:P:bushv in MW':
                        current_element.P1 = value
                    case 'm:P:buslv in MW':
                        current_element.P2 = value
                    case 'm:P:busmv in MW':
                        current_element.P3 = value
                    case 'c:loading in %':
                        current_element.loading = value
                    case 'c:loading_st in %':
                        current_element.loading_st = value

            # make sure to record it as a prev element
            prev_rdfid = rdfid
        #make sure to also store the last object where columns can't go past by
        if current_element is not None:
            row_1, row_2, row_3 = current_element.break_into_sides(ctg_id)
            data.append(row_1)
            data.append(row_2)
            if row_3 is not None:
                data.append(row_3)        

    pd_res = pd.DataFrame(columns=['contingency_id', 'subject_id', 'loading', 'loading_st', 'i', 'P', 'side'], data=data)
    return pd_res

def _set_lf_configuration(comldf: Any, lf_parameters: dict) -> None:
    # set the parameters for the load flow command
    if comldf is not None:
        comldf.iopt_net = lf_parameters['iopt_net']
        comldf.iPST_at = lf_parameters['iPST_at']
        comldf.iopt_plim = lf_parameters['iopt_plim']
        comldf.iopt_at = lf_parameters['iopt_at']
        comldf.iopt_asht = lf_parameters['iopt_asht']
        comldf.iopt_lim = lf_parameters['iopt_lim']
        comldf.iopt_pq = lf_parameters['iopt_pq']
        comldf.iopt_fls = lf_parameters['iopt_fls']
        comldf.iopt_apdist = lf_parameters['iopt_apdist']
        comldf.iPbalancing = lf_parameters['iPbalancing']

        comldf.itapopt = lf_parameters['itapopt']
        comldf.krelax = lf_parameters['krelax']
        comldf.maxTapTrans = lf_parameters['maxTapTrans']
        comldf.maxQlimTrans = lf_parameters['maxQlimTrans']
        comldf.iopt_optaplim = lf_parameters['iopt_optaplim']
        comldf.iopt_limScale = lf_parameters['iopt_limScale']
        comldf.i_power = lf_parameters['i_power']
        comldf.itrlx = lf_parameters['itrlx']
        comldf.ictrlx = lf_parameters['ictrlx']
        comldf.nsteps = lf_parameters['nsteps']
        comldf.errlf = lf_parameters['errlf']
        comldf.allowedBusErrMV = lf_parameters['allowedBusErrMV']
        comldf.allowedBusErrLV = lf_parameters['allowedBusErrLV']
        comldf.erreq = lf_parameters['erreq']
        comldf.iStepAdapt = lf_parameters['iStepAdapt']
        comldf.iltAlgStag = lf_parameters['iltAlgStag']
        comldf.iTrimStep = lf_parameters['iTrimStep']
        comldf.iopt_lev = lf_parameters['iopt_lev']
        comldf.iopt_notopo = lf_parameters['iopt_notopo']
        comldf.maxPhaseShift = lf_parameters['maxPhaseShift']
        comldf.utr_init = lf_parameters['utr_init']

def _get_contingencies(filepath:str) -> pd.DataFrame:
    # parse file and get contingency info
    return parse_contingencies(filepath, '_')

def _define_contingencies(app:Any, comsa:Any, pd_ctg_set:pd.DataFrame) -> None:
    logger.info("Adding single element contingencies")
    if comsa is not None:
        logger.info('Cleaning existing ComOutages')
        outages = comsa.GetContents('*.ComOutage')
        for outage in outages:
            outage.Delete()

        # add new column for PF object in pd_ctg_set
        pd_ctg_set['PFObject'] = None
        # pd_ctg_set['bnumber'] = -100

        all_elements = app.GetCalcRelevantObjects('*.ElmLne,*.ElmTr2,*.ElmTr3,*.ElmSym')
        for element in all_elements: #loop through list
            rdfid = getattr(element, 'e:cimRdfId')[0]
            mask = pd_ctg_set['subject_id'] == rdfid
            if mask.any():
                pd_ctg_set.loc[mask, 'PFObject'] = element
        logger.debug(f"<class '{type(pd_ctg_set).__name__}'>. Size of dataframe: {pd_ctg_set.size}")

        # create fault cases
        logger.info('Creating contingencies in database')
        fault_folder = app.GetProjectFolder('fault')
        if fault_folder is not None:
            fault_cases_folders = fault_folder.GetContents('*.IntFltCases')
            #logger.debug(f"fault cases folders: {fault_cases_folders}")
            if len(fault_cases_folders) > 0: 
                fault_cases_folder = fault_cases_folders[0]
                #logger.debug(f"Cleaning fault cases folder: {fault_cases_folder}")
                contents = fault_cases_folder.GetContents('*.IntEvt')
                for cont in contents:
                    cont.Delete()
                for index, row in pd_ctg_set.iterrows():
                    ctg_id = row['contingency_id']
                    eq_id = row['subject_id']
                    pf_obj = row['PFObject']
                    intevt = fault_cases_folder.CreateObject('IntEvt', eq_id)
                    if intevt is not None:
                        #logger.info(f"intevt: {intevt}")
                        intevt.mod_cnt = 1
                        #logger.debug('Create EvtShc')
                        intshc = intevt.CreateObject('EvtShc', eq_id)
                        if intshc is not None:
                            intshc.p_target = pf_obj
                        #logger.debug('Create ComOutage')
                        comoutage = comsa.CreateObject('ComOutage', ctg_id)
                        if comoutage is not None:
                            comoutage.cpCase = intevt

        logger.info('Contingencies created in database')
        logger.debug(f"<class '{type(pd_ctg_set).__name__}'>. Size of dataframe: {pd_ctg_set.size}")

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-m", "--model")
    parser.add_argument("-c", "--contingencies")

    args = parser.parse_args()
    logger.debug("Calling run security analysis function")
    main(args.model, args.contingencies)