import sys
from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json, list_to_json_field
from src.core.pf.powerfactory_bootstrap import load_powerfactory_module

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
powerfactory = load_powerfactory_module()

def main() -> None:

    result = check_models_in_db()

    result_dict = {
        "models": list_to_json_field(result)
    }
    print(dict_to_json(result_dict))

def check_models_in_db() -> bool:
    logger.info('Check if model exists in PF database')
    try:
        project_names = []
        app = powerfactory.GetApplicationExt()
        logger.debug('PowerFactory App successfully called')
        user = app.GetCurrentUser()
        projects = user.GetContents('*.IntPrj',0)
        logger.debug(projects)
        for project in projects:
            project_names.append(project.loc_name)
        return project_names
    except Exception as e:
        logger.error(f"Error when checking model in DB: {e}", exc_info=True)
        return []
        
if __name__ == "__main__":
    logger.debug("Calling subprocess models in database")
    main()