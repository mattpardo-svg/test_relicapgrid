import sys
from argparse import ArgumentParser
from typing import Any, Tuple

from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json
from src.core.utilities import get_filename_without_extension
from src.core.pf.powerfactory_bootstrap import load_powerfactory_module

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
powerfactory = load_powerfactory_module()

def main(file_path:str) -> None:
    logger.info(file_path)
    result, model_name = cgm_import(file_path)
    result_dict = {
        "result": result,
        "model_name": model_name
    }
    print(dict_to_json(result_dict))
    
def cgm_import(file_path:str) -> Tuple[bool, str]:
    try:
        app = powerfactory.GetApplicationExt()
        logger.debug('PowerFactory App successfully called')
        model_name = get_filename_without_extension(file_path)
        if not network_exists(app, model_name):
            cimdbimp = app.GetFromStudyCase("ComCimdbimp")
            cimdbimp.SetAttribute("targetName", model_name)
            cimdbimp.SetAttribute("fileName", file_path)
            # The cimdbimp.ImportAndConvert does not create the CGMES model inside PF to save time
            # In order to retain the original CGMES inside PF, it is necessary to Execute
            # and then call cimtogrid.Execute()
            result = cimdbimp.Execute()
            if result == 0:
                logger.info("CGMES Network import successful")
                cimtogrid = app.GetFromStudyCase("ComCimtogrid")
                result = cimtogrid.Execute()
                if result == 0:
                    logger.info("CGMES to Grid conversion successful")
                    return True, model_name
                else:
                    logger.error("Error: CGMES to Grid conversion failed")
            else:
                logger.error("Error: CGMES Network import failed")
        return False, None
    except Exception as e:
        logger.error(f"Error during load flow execution: {e}", exc_info=True)

def network_exists(app:Any, model_name: str) -> bool:
    result = False
    user = app.GetCurrentUser()
    projects = user.GetContents('*.IntPrj',0)
    for project in projects:
        logger.debug(project.loc_name)
        if model_name == project.loc_name:
            result = True
            logger.info(f'Network {model_name} exists')
    if not result:
        logger.info(f'Network {model_name} does not exist')
    return result

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-f", "--filepath")

    args = parser.parse_args()
    logger.debug("Calling import cgmes function")
    main(args.filepath)