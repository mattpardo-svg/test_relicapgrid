import sys
from argparse import ArgumentParser
from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
import powerfactory

def main(model_name:str) -> None:
    logger.info(model_name)

    result = check_model_exists(model_name)

    result_dict = {
        "model": model_name,
        "result": result
    }
    print(dict_to_json(result_dict))

def check_model_exists(model_name:str) -> bool:
    logger.info('Check if model exists in PF database')
    try:
        app = powerfactory.GetApplicationExt()
        logger.debug('PowerFactory App successfully called')
        result= False
        user = app.GetCurrentUser()
        projects = user.GetContents('*.IntPrj',0)
        for project in projects:
            logger.debug(project.loc_name)
            if model_name == project.loc_name:
                result = True
                logger.info(f'Network {model_name} exists')
        if not result:
            logger.info(f'Network {model_name} does not exist')
        return result
    except Exception as e:
        logger.error(f"Error when checking model in DB: {e}", exc_info=True)
        return False
        
if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-m", "--model")

    args = parser.parse_args()
    logger.debug("Calling subprocess model exists")
    main(args.model)