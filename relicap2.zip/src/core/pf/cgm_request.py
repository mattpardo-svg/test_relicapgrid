import sys
import subprocess
from typing import Tuple
from src.core.json_utilities import str_to_dict
from src.core.logger import get_logger

logger = get_logger(__name__)

def request_cgm_import(file_path:str) -> Tuple[bool, str]:
    try:
        logger.info('Requesting cgm import in DB...')
        result = False
        model_name = None
        sp = subprocess.run([sys.executable, "-m", "src.core.pf.cgm_subprocess", "--filepath", file_path],
                                capture_output=True, 
                                check=True,
                                text=True)
        logger.debug(sp.stdout)
        result_dict = str_to_dict(sp.stdout)
        logger.info(result_dict)
        logger.debug(result_dict['result'])
        if 'result' in result_dict:
            result = result_dict['result']
        if 'model_name' in result_dict:
            model_name = result_dict['model_name']
        return result, model_name
    except subprocess.CalledProcessError as e:
        logger.error(f"Error running module: {e}")
        return False, None