import pandas as pd
from pathlib import Path
from typing import Any

from src.core.logger import get_logger

logger = get_logger(__name__)

# Get logging configuration from config file
RES_DIR = Path(__file__).parent.parent.parent.parent / "pf.tmp"
RES_DIR.mkdir(exist_ok=True)

def store_pf_results(lf_results: pd.DataFrame, file_name:str, format='.feather') -> str:
    try:
        pd.options.display.float_format = '{:.2f}'.format

        # save to feather
        full_filename = RES_DIR / f"{file_name}{format}"
        if format == '.feather':
            lf_results.to_feather(full_filename)
        elif format == '.xlsx':
            lf_results.to_excel(full_filename)
        logger.info(f"PowerFactory results saved to {full_filename}")
        return full_filename
    except Exception as e:
        logger.error(f"Error saving PF results: {e}")
        return ""

def store_pf_output(messages: Any, file_name:str) -> str:
    try:
        pd.options.display.float_format = '{:.2f}'.format

        # save to feather
        full_filename = RES_DIR / f"{file_name}.txt"
        with open(full_filename, 'w', encoding='utf-8') as file:
            for msg in messages:
                file.write(f"{msg}\n")
        logger.info(f"PowerFactory output saved to {full_filename}")
        return full_filename
    except Exception as e:
        logger.error(f"Error saving PF output: {e}")
        return "" 