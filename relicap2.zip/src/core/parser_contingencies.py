import xml.sax
import pandas as pd
from typing import Any
from src.core.logger import get_logger

logger = get_logger(__name__)

# --- Data Classes ---
class OrdinaryContingency:
    def __init__(self, mRID):
        self.mRID = mRID
        self.name = ""
        self.description = ""
        self.normalMustStudy = ""
        self.EquipmentOperator = ""

    def __repr__(self):
        return f"OrdinaryContingency(id={self.mRID}, name='{self.name}', description='{self.description}')"


class ContingencyEquipment:
    def __init__(self, mRID):
        self.mRID = mRID
        self.name = ""
        self.description = ""
        self.Contingency = ""
        self.contingentStatus = ""
        self.Equipment = ""

    def __repr__(self):
        return f"ContingencyEquipment(id={self.mRID}, name='{self.name}', description='{self.description}')"


# --- SAX Handler ---
class ContingenciesHandler(xml.sax.ContentHandler):
    def __init__(self):
        super().__init__()
        self.contingencies = []
        self.equipments = []
        self.current_data = ""
        self.current_contingency = None
        self.current_equipment = None

    def startElement(self, tag, attributes):
        self.current_data = tag
        if tag == "nc:OrdinaryContingency":
            self.current_contingency = OrdinaryContingency(mRID=attributes["rdf:ID"])
        elif tag == "cim:ContingencyEquipment":
            self.current_equipment = ContingencyEquipment(mRID=attributes["rdf:ID"])
        elif tag == "nc:Contingency.EquipmentOperator" and "rdf:resource" in attributes:
            self.current_contingency.EquipmentOperator = attributes.get("rdf:resource")
        elif tag == "cim:ContingencyElement.Contingency" and "rdf:resource" in attributes:
            self.current_equipment.Contingency = attributes.get("rdf:resource").replace("#_", "")
        elif tag == "cim:ContingencyEquipment.contingentStatus" and "rdf:resource" in attributes:
            self.current_equipment.contingentStatus = attributes.get("rdf:resource")
        elif tag == "cim:ContingencyEquipment.Equipment" and "rdf:resource" in attributes:
            self.current_equipment.Equipment = attributes.get("rdf:resource").replace("#_", "")

    def characters(self, content):
        if self.current_data == "cim:IdentifiedObject.name" and self.current_contingency:
            self.current_contingency.name += content.strip()
        elif self.current_data == "cim:IdentifiedObject.description" and self.current_contingency:
            self.current_contingency.description += content.strip()
        elif self.current_data == "nc:Contingency.normalMustStudy" and self.current_contingency:
            self.current_contingency.normalMustStudy += content.strip()         
        elif self.current_data == "cim:IdentifiedObject.name" and self.current_equipment:
            self.current_equipment.name += content.strip()
        elif self.current_data == "cim:IdentifiedObject.description" and self.current_equipment:
            self.current_equipment.description += content.strip()

    def endElement(self, tag):
        if tag == "nc:OrdinaryContingency" and self.current_contingency:
            self.contingencies.append(self.current_contingency)
            self.current_contingency = None
        elif tag == "cim:ContingencyEquipment" and self.current_equipment:
            self.equipments.append(self.current_equipment)
            self.current_equipment = None
        self.current_data = ""

def parse_contingencies(file_path: str, prefix='') -> Any:
    logger.info('Parsing contingeny file...')
    parser = xml.sax.make_parser()
    handler = ContingenciesHandler()
    parser.setContentHandler(handler)

    try:
        parser.parse(file_path)
        logger.info('Parsing of contingencies complete')
    except FileNotFoundError:
        logger.error("Error: xml file not found.")
        return None

    logger.info(f"Number of OrdinaryContingency parsed: {len(handler.contingencies)}")
    logger.info(f"Number of ContingencyEquipment parsed: {len(handler.equipments)}")

    ctg_list = []
    counter = 1
    for co_eq in handler.equipments:
        ctg_list.append((counter, prefix+co_eq.Contingency, prefix+co_eq.Equipment))
        counter += 1
    return pd.DataFrame(columns=['counter', 'contingency_id', 'subject_id'], data = ctg_list)