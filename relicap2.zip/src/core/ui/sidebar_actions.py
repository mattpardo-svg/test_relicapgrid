import streamlit as st
from datetime import datetime


STEP_ORDER = [
    "PowSyBl Grid Model",
    "Load Flow",
    "Security Analysis",
    "Sensitivity Analysis",
    "Open RAO",
]

PAGE_PATHS = {
    "PowSyBl Grid Model": "olf_pages/2_PSB_Grid_Model.py",
    "Load Flow": "olf_pages/4_Open_Load_Flow.py",
    "Security Analysis": "olf_pages/5_OLF_Security_Analysis.py",
    "Sensitivity Analysis": "olf_pages/6_OLF_Sensitivity_Analysis.py",
    "Open RAO": "olf_pages/8_Open_RAO.py"
}


def _status_chip(label: str, status: str) -> str:
    color_map = {
        "pending": ("#eef1f5", "#4b5563", "#dbe2ea"),
        "running": ("#fff3cd", "#7a4e00", "#ffe08a"),
        "completed": ("#d4edda", "#155724", "#b7e4c7"),
    }
    bg, fg, border = color_map.get(status, color_map["pending"])
    return (
        f'<span style="display:inline-block;margin:0.08rem 0.12rem 0.08rem 0;padding:0.12rem 0.36rem;'
        f'border-radius:999px;font-size:0.7rem;font-weight:600;border:1px solid {border};'
        f'background:{bg};color:{fg};white-space:nowrap;">{label}</span>'
    )


def _fmt_ts(epoch: float | None) -> str:
    if not epoch:
        return "-"
    return datetime.fromtimestamp(epoch).strftime("%H:%M:%S")


def _fmt_dur(seconds: float | None) -> str:
    if seconds is None:
        return "-"
    if seconds < 1:
        return f"{seconds * 1000:.0f} ms"
    mins, secs = divmod(seconds, 60)
    if mins >= 1:
        return f"{int(mins)}m {secs:.1f}s"
    return f"{secs:.1f}s"


def _status_style(status: str) -> tuple[str, str, str]:
    style_map = {
        "pending": ("#f8fafc", "#475569", "#e2e8f0"),
        "running": ("#fffbeb", "#92400e", "#fcd34d"),
        "completed": ("#f0fdf4", "#166534", "#bbf7d0"),
    }
    return style_map.get(status, style_map["pending"])


def _render_step_panel(status: dict[str, str]) -> None:
    now_ts = datetime.now().timestamp()

    started_map = {
        "PowSyBl Grid Model": st.session_state.get("olf_grid_model_started_at"),
        "Load Flow": st.session_state.get("lf_started_at"),
        "Security Analysis": st.session_state.get("sa_started_at"),
        "Sensitivity Analysis": st.session_state.get("sn_started_at"),
        "Open RAO": st.session_state.get("rao_started_at"),
    }
    completed_map = {
        "PowSyBl Grid Model": st.session_state.get("olf_grid_model_loaded_at"),
        "Load Flow": st.session_state.get("lf_completed_at"),
        "Security Analysis": st.session_state.get("sa_completed_at"),
        "Sensitivity Analysis": st.session_state.get("sn_completed_at"),
        "Open RAO": st.session_state.get("rao_completed_at"),
    }
    duration_map = {
        "PowSyBl Grid Model": st.session_state.get("olf_grid_model_time"),
        "Load Flow": st.session_state.get("lf_time"),
        "Security Analysis": st.session_state.get("sa_time"),
        "Sensitivity Analysis": st.session_state.get("sn_time"),
        "Open RAO": st.session_state.get("rao_time"),
    }

    rows = []
    for step in STEP_ORDER:
        step_status = status.get(step, "pending")
        bg, fg, border = _status_style(step_status)
        label = step_status.upper()

        if step_status == "running":
            started = started_map.get(step)
            elapsed = max(0.0, now_ts - started) if started else None
            meta = f"Started: {_fmt_ts(started)} | Elapsed: {_fmt_dur(elapsed)}"
        elif step_status == "completed":
            finished = completed_map.get(step)
            duration = duration_map.get(step)
            meta = f"Finished: {_fmt_ts(finished)} | Duration: {_fmt_dur(duration)}"
        else:
            meta = "Not run"

        rows.append(
            f'<div style="margin:0.22rem 0;padding:0.40rem 0.46rem;border-radius:8px;border:1px solid {border};background:{bg};">'
            f'<div style="display:flex;justify-content:space-between;align-items:center;gap:0.4rem;">'
            f'<span style="font-size:0.80rem;font-weight:600;color:#0f172a;">{step}</span>'
            f'<span style="font-size:0.65rem;font-weight:700;letter-spacing:0.02em;color:{fg};">{label}</span>'
            f'</div>'
            f'<div style="font-size:0.67rem;color:#475569;margin-top:0.14rem;line-height:1.2;">{meta}</div>'
            f'</div>'
        )

    st.sidebar.markdown("".join(rows), unsafe_allow_html=True)


def render_step_actions(current_step: str) -> None:
    """
    Source: adapted from pyTSC sidebar Step Actions panel for the new TSCFlowBox page navigation.
    """
    status = {
        "PowSyBl Grid Model": "running" if st.session_state.get("olf_grid_model_running") else ("completed" if st.session_state.get("olf_grid_model_read") else "pending"),
        "Load Flow": "running" if st.session_state.get("lf_running") else ("completed" if st.session_state.get("olf_lf_result") else "pending"),
        "Security Analysis": "running" if st.session_state.get("sa_running") else ("completed" if st.session_state.get("olf_sa_result") else "pending"),
        "Sensitivity Analysis": "running" if st.session_state.get("sn_running") else ("completed" if st.session_state.get("olf_sn_result") else "pending"),
        "Open RAO": "running" if st.session_state.get("rao_running") else ("completed" if st.session_state.get("rao_result") is not None else "pending"),
    }

    st.sidebar.markdown("### Workflow Status")
    _render_step_panel(status)

    st.sidebar.divider()
    for step in STEP_ORDER:
        if step == current_step:
            continue
        if st.sidebar.button(f"Go to {step}", key=f"go_to_{step}"):
            st.switch_page(PAGE_PATHS[step])
