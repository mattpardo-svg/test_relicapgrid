import os
import collections
import xml.etree.ElementTree as ET
import zipfile
import pandas as pd
from typing import Any, List, Tuple

PROFILE_KEYS = ["EQ", "SSH", "SV", "TP"]

# ---- Small helpers ----
def _norm_id(raw_value):
    if raw_value is None:
        return None
    text = str(raw_value).strip().lstrip("#").lstrip("_")
    return text.lower() if text else None

def _xml_tag(raw_tag):
    return raw_tag.split("}", 1)[-1] if "}" in raw_tag else raw_tag

class model_metadata():
    def __init__(self, model_path :str, network: Any):
        self.model_path = model_path
        self.network = network
        self.result = {}

    def profile_status_from_zip(self) -> dict[str, str]:
        zip_path = self.model_path
        status = {k: "waiting" for k in PROFILE_KEYS}
        if not zip_path or not os.path.exists(zip_path):
            return status
        try:
            with zipfile.ZipFile(zip_path, "r") as z:
                zip_files = z.namelist()
            for key in PROFILE_KEYS:
                status[key] = "found" if any(key in f and str(f).lower().endswith(".xml") for f in zip_files) else "missing"
        except Exception:
            return {k: "waiting" for k in PROFILE_KEYS}
        return status

    def collect_model_metadata(self) -> None:
        if not self.model_path or not os.path.exists(self.model_path):
            return

        files_in_zip = []
        xml_files = []
        phits = {k: 0 for k in ["EQ", "SSH", "SV", "TP", "GL"]}
        eq_tags = collections.Counter()

        try:
            with zipfile.ZipFile(self.model_path, "r") as z:
                files_in_zip = z.namelist()
                xml_files = [f for f in files_in_zip if f.lower().endswith(".xml")]
                for xml_name in xml_files:
                    upper = xml_name.upper()
                    for k in phits:
                        phits[k] += (k in upper)
                    try:
                        root = ET.fromstring(z.read(xml_name))
                        for el in root.iter():
                            t = _xml_tag(el.tag)
                            if t in {"ACLineSegment", "PowerTransformer", "TieLine"}:
                                eq_tags[t] += 1
                    except Exception:
                        pass

                eq_ids = {"ACLineSegment": set(), "PowerTransformer": set(), "TieLine": set()}
                tp_tc = collections.Counter()
                for xml_name in [f for f in files_in_zip if f.lower().endswith(".xml") and "_eq_" in f.lower()]:
                    try:
                        root = ET.fromstring(z.read(xml_name))
                    except Exception:
                        continue
                    for el in root.iter():
                        tag = _xml_tag(el.tag)
                        if tag not in eq_ids:
                            continue
                        mid = None
                        for child in el:
                            if _xml_tag(child.tag) == "IdentifiedObject.mRID":
                                mid = _norm_id(child.text)
                                break
                        if not mid:
                            for ak, av in el.attrib.items():
                                if ak.endswith("ID"):
                                    mid = _norm_id(av)
                                    break
                        if mid:
                            eq_ids[tag].add(mid)
                for xml_name in [f for f in files_in_zip if f.lower().endswith(".xml") and "_tp_" in f.lower()]:
                    try:
                        root = ET.fromstring(z.read(xml_name))
                    except Exception:
                        continue
                    for el in root.iter():
                        if _xml_tag(el.tag) != "Terminal":
                            continue
                        ce = None
                        for child in el:
                            if _xml_tag(child.tag) == "Terminal.ConductingEquipment" and child.attrib:
                                ce = _norm_id(next(iter(child.attrib.values())))
                                break
                        if ce:
                            tp_tc[ce] += 1
        except Exception as exc:
            self.result["uploaded_grid_summary_error"] = str(exc)
            self.result["uploaded_import_reconciliation_error"] = str(exc)
            return

        branches = self.network.get_branches()
        tw3 = self.network.get_3_windings_transformers().reset_index().rename(columns={"index": "transformer_id", "id": "transformer_id"})
        tc = branches["type"].value_counts() if "type" in branches.columns else pd.Series(dtype=int)

        base_files_in_zip = []
        for file_zip in files_in_zip:
            name = os.path.basename(file_zip)
            if len(name) > 0:
                base_files_in_zip.append(name)

        self.result["uploaded_zip_file_list"] = base_files_in_zip
        self.result["uploaded_zip_diagnostics"] = {
            "XML files in ZIP": len(xml_files),
            "Filename hits - EQ": phits["EQ"], "Filename hits - SSH": phits["SSH"],
            "Filename hits - SV": phits["SV"], "Filename hits - TP": phits["TP"], "Filename hits - GL": phits["GL"],
            "Raw ACLineSegment tags": int(eq_tags["ACLineSegment"]),
            "Raw PowerTransformer tags": int(eq_tags["PowerTransformer"]),
            "Raw TieLine tags": int(eq_tags["TieLine"]),
        }
        self.result["uploaded_grid_summary"] = {
            "Total Branches": int(len(branches) + len(tw3)),
            "Lines": int(tc.get("LINE", 0)),
            "Tie-lines": int(tc.get("TIE_LINE", 0)),
            "Transformers": int(tc.get("TWO_WINDINGS_TRANSFORMER", 0) + len(tw3)),
        }
        self.result["uploaded_grid_summary_error"] = None

        br_df = branches.reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})
        l_ids = {_norm_id(x) for x in br_df.loc[br_df["type"] == "LINE", "branch_id"].astype(str)}
        tie_ids = {_norm_id(x) for x in br_df.loc[br_df["type"] == "TIE_LINE", "branch_id"].astype(str)}
        t_ids = ({_norm_id(x) for x in br_df.loc[br_df["type"].isin(["TWO_WINDINGS_TRANSFORMER", "THREE_WINDINGS_TRANSFORMER"]), "branch_id"].astype(str)}
                | {_norm_id(x) for x in tw3["transformer_id"].astype(str)})
        tie_parts = set()
        for tr in br_df.loc[br_df["type"] == "TIE_LINE", "branch_id"].astype(str):
            for piece in tr.split("+"):
                pid = _norm_id(piece)
                if pid:
                    tie_parts.add(pid)
        acl_eff = l_ids | tie_parts
        ml_d = sorted(eq_ids["ACLineSegment"] - l_ids)
        ml_e = sorted(eq_ids["ACLineSegment"] - acl_eff)
        mt = sorted(eq_ids["PowerTransformer"] - t_ids)
        mtie = sorted(eq_ids["TieLine"] - tie_ids)

        self.result["uploaded_import_reconciliation"] = {
            "EQ ACLineSegment IDs": len(eq_ids["ACLineSegment"]),
            "Imported LINE IDs": len(l_ids),
            "Matched LINE IDs": len(eq_ids["ACLineSegment"] & l_ids),
            "Missing LINE IDs": len(ml_d),
            "Imported ACLine-equivalent IDs (LINE + TIE parts)": len(acl_eff),
            "Matched ACLineSegment IDs (LINE + TIE parts)": len(eq_ids["ACLineSegment"] & acl_eff),
            "Missing ACLineSegment IDs (LINE + TIE parts)": len(ml_e),
            "EQ ACLineSegment IDs with TP terminals": len({x for x in eq_ids["ACLineSegment"] if tp_tc.get(x, 0) >= 2}),
            "EQ PowerTransformer IDs": len(eq_ids["PowerTransformer"]),
            "Imported Transformer IDs": len(t_ids),
            "Matched Transformer IDs": len(eq_ids["PowerTransformer"] & t_ids),
            "Missing Transformer IDs": len(mt),
            "EQ Transformer IDs with TP terminals": len({x for x in eq_ids["PowerTransformer"] if tp_tc.get(x, 0) >= 2}),
            "EQ TieLine IDs": len(eq_ids["TieLine"]),
            "Imported Tie-line IDs": len(tie_ids),
            "Matched Tie-line IDs": len(eq_ids["TieLine"] & tie_ids),
            "Missing Tie-line IDs": len(mtie),
            "EQ Tie-line IDs with TP terminals": len({x for x in eq_ids["TieLine"] if tp_tc.get(x, 0) >= 2}),
            "Sample missing LINE IDs": ", ".join(ml_d[:5]) if ml_d else "-",
            "Sample missing ACLineSegment IDs (LINE + TIE parts)": ", ".join(ml_e[:5]) if ml_e else "-",
            "Sample missing Transformer IDs": ", ".join(mt[:5]) if mt else "-",
            "Sample missing Tie-line IDs": ", ".join(mtie[:5]) if mtie else "-",
        }
        self.result["uploaded_import_reconciliation_error"] = None

    def get(self, key: str, default=None):
        if key in self.result:
            return self.result[key]
        return default

    def check_expected_equipment(self, expected_ids) -> Tuple[str, List]:
        imp_net = self.network
        imp_br = imp_net.get_branches().reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})
        imp_3w = imp_net.get_3_windings_transformers().reset_index().rename(columns={"index": "transformer_id", "id": "transformer_id"})
        imp_br["branch_id_norm"] = imp_br["branch_id"].apply(_norm_id)
        direct_ids = set(imp_br["branch_id_norm"].dropna().astype(str)) | {_norm_id(x) for x in imp_3w["transformer_id"].astype(str)}
        id_to_types = collections.defaultdict(set)
        for _, row in imp_br.iterrows():
            rid = row.get("branch_id_norm")
            if rid and not pd.isna(rid): id_to_types[rid].add(str(row.get("type", "Branch")))
        for rid in {_norm_id(x) for x in imp_3w["transformer_id"].astype(str)}: id_to_types[rid].add("THREE_WINDINGS_TRANSFORMER")
        tie_parts = set()
        for tr in imp_br.loc[imp_br["type"] == "TIE_LINE", "branch_id"].astype(str):
            for piece in tr.split("+"): 
                pid = _norm_id(piece)
                if pid: tie_parts.add(pid)
        eff_ids = direct_ids | tie_parts
        exp_set = set(expected_ids)
        eq_type_map, tp_tc2, te_tc = {}, collections.Counter(), collections.Counter()
        with zipfile.ZipFile(self.model_path, "r") as z:
            eq_xmls = [f for f in z.namelist() if f.lower().endswith(".xml") and "_eq_" in f.lower()]
            tp_xmls = [f for f in z.namelist() if f.lower().endswith(".xml") and ("_tp_" in f.lower() or "_eq_" in f.lower())]
            for xml_name in eq_xmls:
                try: root = ET.fromstring(z.read(xml_name))
                except Exception: continue
                for el in root.iter():
                    tag = _xml_tag(el.tag)
                    if tag == "PowerTransformerEnd":
                        tr_ref = None
                        for child in el:
                            if _xml_tag(child.tag) == "PowerTransformerEnd.PowerTransformer" and child.attrib:
                                tr_ref = _norm_id(next(iter(child.attrib.values()))); break
                        if tr_ref and tr_ref in exp_set: te_tc[tr_ref] += 1
                    mid = None
                    for child in el:
                        if _xml_tag(child.tag) == "IdentifiedObject.mRID": mid = _norm_id(child.text); break
                    if not mid:
                        for ak, av in el.attrib.items():
                            if ak.endswith("ID"): mid = _norm_id(av); break
                    if mid and mid in exp_set and mid not in eq_type_map: eq_type_map[mid] = tag
            for xml_name in tp_xmls:
                try: root = ET.fromstring(z.read(xml_name))
                except Exception: continue
                for el in root.iter():
                    if _xml_tag(el.tag) != "Terminal": continue
                    ce = None
                    for child in el:
                        if _xml_tag(child.tag) == "Terminal.ConductingEquipment" and child.attrib:
                            ce = _norm_id(next(iter(child.attrib.values()))); break
                    if ce and ce in exp_set: tp_tc2[ce] += 1
        rows = []
        for eid in expected_ids:
            direct = eid in direct_ids
            comp = eid in tie_parts
            included = eid in eff_ids
            if direct:
                bts = sorted(id_to_types.get(eid, {"Branch"}))
                imp_as = ", ".join(bts) if bts else "Branch"
            elif comp: imp_as = "TIE_LINE component"
            else: imp_as = "Not imported"
            in_eq = eid in eq_type_map
            eq_t = eq_type_map.get(eid, "-")
            if eq_t == "PowerTransformer":
                conn_cnt = int(te_tc.get(eid, 0))
                conn_basis = "PowerTransformerEnd"
            else:
                conn_cnt = int(tp_tc2.get(eid, 0))
                conn_basis = "Terminal"
            if included: reason = "Included in imported study network"
            elif not in_eq: reason = "Expected ID not found in uploaded EQ files"
            elif eq_t == "PowerTransformer" and conn_cnt < 2: reason = "Found in EQ but transformer has insufficient connected ends"
            elif conn_cnt < 2: reason = "Found in EQ but terminal connectivity is insufficient in EQ/TP"
            else: reason = "Found in EQ/TP but not imported as branch (model mapping/filter)"
            rows.append({"Equipment ID": eid, "Included in Study": "Yes" if included else "No",
                            "Imported As": imp_as, "Present in EQ": "Yes" if in_eq else "No",
                            "EQ Type": eq_t, "Connectivity Count": conn_cnt,
                            "Connectivity Basis": conn_basis, "Likely Reason": reason})
        return rows
