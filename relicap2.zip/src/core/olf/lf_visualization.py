import html

import streamlit as st


def coerce_float(value):
    try:
        if value is None:
            return None
        if hasattr(value, "item"):
            value = value.item()
        numeric = float(value)
        if numeric != numeric:
            return None
        return numeric
    except (TypeError, ValueError):
        return None


def format_metric(value, decimals=2, suffix=""):
    numeric = coerce_float(value)
    if numeric is None:
        return "N/A"
    return f"{numeric:.{decimals}f}{suffix}"


def display_text(value, fallback="N/A"):
    if value is None:
        return fallback
    if hasattr(value, "item"):
        value = value.item()
    if isinstance(value, float) and value != value:
        return fallback
    text = str(value).strip()
    if text == "" or text.lower() == "nan":
        return fallback
    return text


def render_compact_details(title, detail_map):
    rows = []
    for key, value in detail_map.items():
        rows.append(
            "<tr>"
            f"<td style='padding:2px 6px; font-weight:600; color:#334155; white-space:nowrap;'>{html.escape(str(key))}</td>"
            f"<td style='padding:2px 6px; color:#0f172a;'>{html.escape(display_text(value))}</td>"
            "</tr>"
        )
    st.markdown(f"#### {title}")
    st.markdown(
        "<div style='font-size:11px; line-height:1.2; margin-bottom:8px;'>"
        "<table style='border-collapse:collapse; width:100%;'>"
        + "".join(rows)
        + "</table></div>",
        unsafe_allow_html=True,
    )


def build_node_hover_lines(node_row):
    voltage_level_text = display_text(node_row.get("voltage_level_name"), fallback="")
    if voltage_level_text == "":
        voltage_level_text = display_text(node_row.get("voltage_level_id"))
    substation_text = display_text(node_row.get("substation_name"), fallback="")
    if substation_text == "":
        substation_text = display_text(node_row.get("substation_id"))
    return [
        display_text(node_row.get("display_name", node_row.get("node_id"))),
        f"Node type: {display_text(node_row.get('node_kind', 'bus'))}",
        f"Voltage level: {voltage_level_text}",
        f"Substation: {substation_text}",
        f"Nominal voltage: {format_metric(node_row.get('nominal_kv'), suffix=' kV')}",
        f"Solved voltage: {format_metric(node_row.get('v_mag'), suffix=' pu')}",
        f"Angle: {format_metric(node_row.get('v_angle'), suffix=' deg')}",
        f"Connections: {int(node_row.get('degree', 0))}",
    ]


def build_branch_hover_lines(edge_row):
    return [
        display_text(edge_row.get("branch_name") or edge_row.get("branch_id")),
        f"ID: {display_text(edge_row.get('branch_id'))}",
        f"Type: {display_text(edge_row.get('branch_type'))}",
        f"Status: {display_text(edge_row.get('status'))}",
        f"Power loading: {format_metric(edge_row.get('loading_power_pct'), suffix='%')}",
        f"Current loading: {format_metric(edge_row.get('loading_current_pct'), suffix='%')}",
        f"Max power: {format_metric(edge_row.get('s_max_mva'), suffix=' MVA')}",
        f"Max current: {format_metric(edge_row.get('i_max_a'), suffix=' A')}",
    ]


def build_injection_hover_lines(row):
    return [
        display_text(row.get("name"), fallback=row.get("item_id")),
        f"Type: {display_text(row.get('kind'))}",
        f"Bus: {display_text(row.get('bus_id'))}",
        f"Voltage level: {display_text(row.get('voltage_level_name') or row.get('voltage_level_id'))}",
        f"P: {format_metric(row.get('p'), suffix=' MW')}",
        f"Q: {format_metric(row.get('q'), suffix=' MVAr')}",
        f"I: {format_metric(row.get('i'), suffix=' A')}",
    ]


def build_node_detail_map(node_row):
    return {
        "Name": display_text(node_row.get("display_name", node_row.get("node_id"))),
        "Node type": display_text(node_row.get("node_kind", "bus")),
        "Voltage level": display_text(node_row.get("voltage_level_name") or node_row.get("voltage_level_id")),
        "Substation": display_text(node_row.get("substation_name") or node_row.get("substation_id")),
        "Nominal voltage": format_metric(node_row.get("nominal_kv"), suffix=" kV"),
        "Solved voltage": format_metric(node_row.get("v_mag"), suffix=" pu"),
        "Angle": format_metric(node_row.get("v_angle"), suffix=" deg"),
        "Connections": int(node_row.get("degree", 0)),
    }


def build_branch_detail_map(edge_row):
    return {
        "Name": display_text(edge_row.get("branch_name") or edge_row.get("branch_id")),
        "ID": display_text(edge_row.get("branch_id")),
        "Type": display_text(edge_row.get("branch_type")),
        "Status": display_text(edge_row.get("status")),
        "Bus 1": display_text(edge_row.get("bus1_id")),
        "Bus 2": display_text(edge_row.get("bus2_id")),
        "Bus 3": display_text(edge_row.get("bus3_id")),
        "Power loading": format_metric(edge_row.get("loading_power_pct"), suffix="%"),
        "Current loading": format_metric(edge_row.get("loading_current_pct"), suffix="%"),
        "Max power": format_metric(edge_row.get("s_max_mva"), suffix=" MVA"),
        "Max current": format_metric(edge_row.get("i_max_a"), suffix=" A"),
    }


def build_injection_detail_map(row):
    return {
        "Name": display_text(row.get("name"), fallback=row.get("item_id")),
        "Type": display_text(row.get("kind")),
        "Bus": display_text(row.get("bus_id")),
        "Voltage level": display_text(row.get("voltage_level_name") or row.get("voltage_level_id")),
        "P": format_metric(row.get("p"), suffix=" MW"),
        "Q": format_metric(row.get("q"), suffix=" MVAr"),
        "I": format_metric(row.get("i"), suffix=" A"),
    }


def build_injection_markers(nodes_df, loads_df, generators_df):
    import math
    import pandas as pd

    bus_nodes = nodes_df[nodes_df["node_kind"] == "bus"].copy()
    if bus_nodes.empty:
        return pd.DataFrame()

    bus_nodes["node_id"] = bus_nodes["node_id"].astype(str)
    bus_pos_map = {
        str(row["node_id"]): (coerce_float(row["x"]) or 0.0, coerce_float(row["y"]) or 0.0)
        for _, row in bus_nodes.iterrows()
    }

    vl_anchor = {}
    if "voltage_level_id" in bus_nodes.columns:
        for _, row in bus_nodes.iterrows():
            vl_id = row.get("voltage_level_id")
            if pd.notna(vl_id) and str(vl_id) not in vl_anchor:
                vl_anchor[str(vl_id)] = str(row.get("node_id"))

    def _build(df, kind, symbol, color, radial_distance):
        if df is None or df.empty:
            return []
        local = df.copy()
        if "bus_id" not in local.columns:
            local["bus_id"] = pd.NA
        if "voltage_level_id" not in local.columns:
            local["voltage_level_id"] = pd.NA
        if "name" not in local.columns:
            local["name"] = pd.NA
        if "connected" in local.columns:
            local = local[local["connected"].fillna(True)]
        if local.empty:
            return []

        records = []
        for _, row in local.iterrows():
            item_id = display_text(row.get("item_id"), fallback="")
            bus_id = display_text(row.get("bus_id"), fallback="")
            vl_id = display_text(row.get("voltage_level_id"), fallback="")
            anchor_bus_id = bus_id if bus_id in bus_pos_map else vl_anchor.get(vl_id)
            if not anchor_bus_id or anchor_bus_id not in bus_pos_map:
                continue
            base_x, base_y = bus_pos_map[anchor_bus_id]
            angle_seed = sum(ord(ch) for ch in f"{kind}:{item_id}:{anchor_bus_id}")
            angle = (angle_seed % 360) * math.pi / 180.0
            x = base_x + radial_distance * math.cos(angle)
            y = base_y + radial_distance * math.sin(angle)
            records.append(
                {
                    "item_id": item_id,
                    "kind": kind,
                    "name": display_text(row.get("name"), fallback=item_id),
                    "bus_id": anchor_bus_id,
                    "voltage_level_id": display_text(row.get("voltage_level_id")),
                    "p": coerce_float(row.get("p")),
                    "q": coerce_float(row.get("q")),
                    "i": coerce_float(row.get("i")),
                    "symbol": symbol,
                    "color": color,
                    "x": x,
                    "y": y,
                }
            )
        return records

    load_records = _build(loads_df, "LOAD", "triangle-down", "#A855F7", 0.055)
    generator_records = _build(generators_df, "GENERATOR", "triangle-up", "#059669", 0.065)
    return pd.DataFrame(load_records + generator_records)


def loading_status_color(status):
    palette = {
        "Overloaded": "#C44536",
        "High": "#D9A441",
        "Normal": "#5B8A72",
        "Unknown": "#8B95A5",
    }
    return palette.get(str(status), palette["Unknown"])


def render_svg_panel(svg_data, download_name, height=820):
    import urllib.parse

    svg_data_url = urllib.parse.quote(svg_data)
    iframe_src = f"data:image/svg+xml;utf8,{svg_data_url}"
    st.iframe(iframe_src, height=height)
    st.markdown(
        f'<div style="margin-bottom:24px;"><a href="data:image/svg+xml;utf8,{svg_data_url}" download="{download_name}">Download SVG</a></div>',
        unsafe_allow_html=True,
    )


def build_network_visual_frames(buses_df, graph_branch_df, voltage_levels_df):
    import math
    import networkx as nx
    import pandas as pd

    nodes_df = buses_df.copy()
    if "bus_id" not in nodes_df.columns:
        return pd.DataFrame(), pd.DataFrame()

    nodes_df["bus_id"] = nodes_df["bus_id"].astype(str)
    nodes_df["node_id"] = nodes_df["bus_id"]
    nodes_df["node_kind"] = "bus"
    nodes_df["display_name"] = nodes_df["bus_id"]

    if "voltage_level_id" in nodes_df.columns and "voltage_level_id" in voltage_levels_df.columns:
        vl_subset = voltage_levels_df.copy()
        # Only bring in columns that are not already present in nodes_df to avoid
        # duplicate-suffix columns (e.g. nominal_kv_x / nominal_kv_y) when buses_df
        # was already enriched with VL metadata before being passed here.
        vl_candidate_cols = ["voltage_level_id", "voltage_level_name", "nominal_kv", "substation_id", "substation_name"]
        merge_cols = [
            col for col in vl_candidate_cols
            if col in vl_subset.columns and (col == "voltage_level_id" or col not in nodes_df.columns)
        ]
        if len(merge_cols) > 1:  # at least voltage_level_id + one extra column worth merging
            nodes_df = nodes_df.merge(vl_subset[merge_cols], on="voltage_level_id", how="left")
            # Consolidate any suffix columns produced by pandas when a column was present on both sides
            for base_col in ["nominal_kv", "voltage_level_name", "substation_id", "substation_name"]:
                if f"{base_col}_x" in nodes_df.columns:
                    nodes_df[base_col] = nodes_df[f"{base_col}_x"].combine_first(nodes_df.get(f"{base_col}_y"))
                    nodes_df = nodes_df.drop(columns=[c for c in [f"{base_col}_x", f"{base_col}_y"] if c in nodes_df.columns])

    edge_records = []
    hub_records = []
    for row in graph_branch_df.to_dict("records"):
        branch_id = str(row.get("branch_id", ""))
        branch_type = str(row.get("type", "Unknown"))
        branch_name = row.get("name") if pd.notna(row.get("name")) else branch_id
        bus1 = row.get("bus1_id")
        bus2 = row.get("bus2_id")
        bus3 = row.get("bus3_id")
        status = row.get("status", "Unknown")
        loading_pct = coerce_float(row.get("loading_power_pct"))
        current_pct = coerce_float(row.get("loading_current_pct"))
        midpoint_size = 10
        if loading_pct is not None:
            midpoint_size = min(22, max(8, 8 + (loading_pct / 20.0)))

        common_payload = {
            "branch_id": branch_id,
            "branch_name": branch_name,
            "branch_type": branch_type,
            "status": status,
            "loading_power_pct": loading_pct,
            "loading_current_pct": current_pct,
            "thermal_limit_a": coerce_float(row.get("thermal_limit_a")),
            "thermal_limit_mva": coerce_float(row.get("thermal_limit_mva")),
            "s_max_mva": coerce_float(row.get("s_max_mva")),
            "i_max_a": coerce_float(row.get("i_max_a")),
            "p1": coerce_float(row.get("p1")),
            "q1": coerce_float(row.get("q1")),
            "i1": coerce_float(row.get("i1")),
            "p2": coerce_float(row.get("p2")),
            "q2": coerce_float(row.get("q2")),
            "i2": coerce_float(row.get("i2")),
            "p3": coerce_float(row.get("p3")),
            "q3": coerce_float(row.get("q3")),
            "i3": coerce_float(row.get("i3")),
            "midpoint_size": midpoint_size,
        }

        if branch_type == "THREE_WINDINGS_TRANSFORMER":
            hub_id = f"hub::{branch_id}"
            hub_records.append(
                {
                    "node_id": hub_id,
                    "bus_id": branch_id,
                    "node_kind": "transformer_hub",
                    "display_name": branch_name,
                    "v_mag": None,
                    "v_angle": None,
                    "voltage_level_id": row.get("voltage_level1_id"),
                    "voltage_level_name": row.get("voltage_level1_id"),
                    "nominal_kv": coerce_float(row.get("nominal_kv_1")) or coerce_float(row.get("nominal_kv_2")) or coerce_float(row.get("nominal_kv_3")),
                    "substation_id": None,
                    "substation_name": None,
                }
            )
            for side_key, bus_value in (("side_1", bus1), ("side_2", bus2), ("side_3", bus3)):
                if pd.notna(bus_value):
                    edge_records.append(
                        {
                            "edge_key": f"{branch_id}::{side_key}",
                            "source": hub_id,
                            "target": str(bus_value),
                            "selection_id": branch_id,
                            **common_payload,
                        }
                    )
        elif pd.notna(bus1) and pd.notna(bus2):
            edge_records.append(
                {
                    "edge_key": branch_id,
                    "source": str(bus1),
                    "target": str(bus2),
                    "selection_id": branch_id,
                    **common_payload,
                }
            )

    if hub_records:
        nodes_df = pd.concat([nodes_df, pd.DataFrame(hub_records)], ignore_index=True, sort=False)
    nodes_df = nodes_df.sort_values(by="node_id", kind="stable").reset_index(drop=True)

    edges_df = pd.DataFrame(edge_records)
    if edges_df.empty:
        nodes_df["degree"] = 0
        nodes_df["x"] = 0.0
        nodes_df["y"] = 0.0
        return nodes_df, edges_df
    edges_df = edges_df.sort_values(by="edge_key", kind="stable").reset_index(drop=True)

    graph = nx.Graph()
    for node_row in nodes_df.to_dict("records"):
        graph.add_node(node_row["node_id"])
    for edge_row in edges_df.to_dict("records"):
        graph.add_edge(edge_row["source"], edge_row["target"])

    node_count = graph.number_of_nodes()
    spring_k = 1.1 / math.sqrt(max(node_count, 1))

    # Use faster positioning strategies for very large networks.
    if node_count > 3500:
        positions = nx.random_layout(graph, seed=42)
    else:
        if node_count > 1500:
            iterations = 35
        elif node_count > 600:
            iterations = 80
        else:
            iterations = 180
        positions = nx.spring_layout(graph, seed=42, k=spring_k, iterations=iterations)

    nodes_df["x"] = nodes_df["node_id"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[0]))
    nodes_df["y"] = nodes_df["node_id"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[1]))
    degree_map = dict(graph.degree())
    nodes_df["degree"] = nodes_df["node_id"].map(lambda nid: degree_map.get(nid, 0))

    edges_df["x0"] = edges_df["source"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[0]))
    edges_df["y0"] = edges_df["source"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[1]))
    edges_df["x1"] = edges_df["target"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[0]))
    edges_df["y1"] = edges_df["target"].map(lambda nid: float(positions.get(nid, (0.0, 0.0))[1]))
    edges_df["mid_x"] = (edges_df["x0"] + edges_df["x1"]) / 2.0
    edges_df["mid_y"] = (edges_df["y0"] + edges_df["y1"]) / 2.0
    return nodes_df, edges_df


@st.cache_data(show_spinner="Building interactive map layout...")
def build_network_visual_frames_cached(buses_df, graph_branch_df, voltage_levels_df):
    # Cache deterministic layout frames so click interactions only filter and redraw.
    return build_network_visual_frames(buses_df, graph_branch_df, voltage_levels_df)


def create_network_overview_figure(
    nodes_df,
    edges_df,
    selected_kind=None,
    selected_id=None,
    injections_df=None,
):
    import plotly.graph_objects as go

    fig = go.Figure()
    # Show loading status as line-style examples in the legend. Actual branch
    # traces below also use these styles, while voltage remains encoded by color.
    status_line_styles = {
        "Overloaded": {"width": 4.2, "dash": "solid"},
        "High": {"width": 3.0, "dash": "dash"},
        "Normal": {"width": 2.2, "dash": "solid"},
        "Unknown": {"width": 2.2, "dash": "dot"},
    }
    for status in ["Overloaded", "High", "Normal", "Unknown"]:
        fig.add_trace(
            go.Scatter(
                x=[None, None],
                y=[None, None],
                mode="lines",
                line={
                    "width": status_line_styles[status]["width"],
                    "color": loading_status_color(status),
                    "dash": status_line_styles[status]["dash"],
                },
                hoverinfo="skip",
                name=f"Status: {status}",
                showlegend=True,
                visible="legendonly",
            )
        )

    if not edges_df.empty:
        edge_sizes = (edges_df["midpoint_size"].fillna(9) + 4).tolist()
        edge_outline = [3 if selected_kind == "branch" and selected_id == branch_id else 1 for branch_id in edges_df["selection_id"]]
        edge_hover = []
        for edge_row in edges_df.to_dict("records"):
            edge_hover.append("<br>".join(build_branch_hover_lines(edge_row)))
        fig.add_trace(
            go.Scatter(
                x=edges_df["mid_x"],
                y=edges_df["mid_y"],
                mode="markers",
                text=None,
                textposition="bottom center",
                textfont={"family": "Segoe UI, Arial, sans-serif", "size": 10, "color": "#475569"},
                marker={
                    "size": edge_sizes,
                    "color": [loading_status_color(status) for status in edges_df["status"].fillna("Unknown")],
                    "symbol": "diamond",
                    "line": {"width": edge_outline, "color": "#F8F7F3"},
                    "opacity": 0.82,
                },
                customdata=[["branch", branch_id] for branch_id in edges_df["selection_id"]],
                hovertemplate="%{hovertext}<extra></extra>",
                hovertext=edge_hover,
                name="Branch detail points",
                showlegend=False,
            )
        )

    if not nodes_df.empty:
        target_voltage_levels = [750, 380, 220, 150, 120, 110, 70, 27, 330, 500]
        ordered_levels = sorted(set(target_voltage_levels), reverse=True)
        level_colors = {
            750: "#6A00A8",
            500: "#003F5C",
            380: "#2F4B7C",
            330: "#665191",
            220: "#00A6A6",
            150: "#7BC043",
            120: "#C0CA33",
            110: "#FFD166",
            70: "#F28E2B",
            27: "#E15759",
        }

        def _nearest_voltage_label(kv):
            if kv is None:
                return "Unknown kV"
            nearest = min(ordered_levels, key=lambda ref: abs(kv - ref))
            return f"{nearest} kV"

        def _color_for_label(level_label):
            if level_label == "Unknown kV":
                return "#7C8A9A"
            kv = int(level_label.split()[0])
            return level_colors.get(kv, "#7C8A9A")

        # Bus -> normalized VL label map so branch lines follow the same VL binning.
        bus_vl_map = {}
        for row in nodes_df.to_dict("records"):
            if row.get("node_kind") == "bus":
                bus_vl_map[str(row["node_id"])] = _nearest_voltage_label(coerce_float(row.get("nominal_kv")))

        level_labels = [f"{vl} kV" for vl in ordered_levels] + ["Unknown kV", "Transformer hub"]

        def _label_kv(level_label):
            if level_label is None or level_label == "Unknown kV":
                return None
            try:
                return int(str(level_label).split()[0])
            except (TypeError, ValueError):
                return None

        def _edge_level_label(edge_row):
            src_label = bus_vl_map.get(str(edge_row.get("source")), "Unknown kV")
            tgt_label = bus_vl_map.get(str(edge_row.get("target")), "Unknown kV")
            if src_label == "Unknown kV" and tgt_label != "Unknown kV":
                return tgt_label
            if tgt_label == "Unknown kV" and src_label != "Unknown kV":
                return src_label
            src_kv = _label_kv(src_label)
            tgt_kv = _label_kv(tgt_label)
            if src_kv is None and tgt_kv is None:
                return "Unknown kV"
            if src_kv is None:
                return tgt_label
            if tgt_kv is None:
                return src_label
            return f"{max(src_kv, tgt_kv)} kV"

        edge_records_by_level = {label: [] for label in level_labels}
        if not edges_df.empty:
            for edge_row in edges_df.to_dict("records"):
                level_label = _edge_level_label(edge_row)
                edge_records_by_level[level_label].append(edge_row)

        is_first_level = True
        for level_label in level_labels:
            bin_color = "#264653" if level_label == "Transformer hub" else _color_for_label(level_label)
            bin_rows = []
            for row in nodes_df.to_dict("records"):
                if row.get("node_kind") == "transformer_hub":
                    if level_label == "Transformer hub":
                        bin_rows.append(row)
                    continue
                if _nearest_voltage_label(coerce_float(row.get("nominal_kv"))) == level_label:
                    bin_rows.append(row)

            bin_edge_rows = edge_records_by_level.get(level_label, []) if level_label != "Transformer hub" else []
            if not bin_rows and not bin_edge_rows:
                continue

            legend_group = f"vl_bin_{level_label}"
            group_title = {"text": "Voltage levels"} if is_first_level else {}
            is_first_level = False

            if bin_edge_rows:
                # Split by status so the same line can show voltage via color and
                # loading state via width/dash.
                for status in ["Overloaded", "High", "Normal", "Unknown"]:
                    status_rows = [
                        edge_row for edge_row in bin_edge_rows
                        if str(edge_row.get("status", "Unknown") or "Unknown") == status
                    ]
                    if not status_rows:
                        continue
                    edge_x = []
                    edge_y = []
                    for edge_row in status_rows:
                        edge_x.extend([edge_row["x0"], edge_row["x1"], None])
                        edge_y.extend([edge_row["y0"], edge_row["y1"], None])
                    fig.add_trace(
                        go.Scatter(
                            x=edge_x,
                            y=edge_y,
                            mode="lines",
                            line={
                                "width": status_line_styles[status]["width"],
                                "dash": status_line_styles[status]["dash"],
                                "color": bin_color,
                            },
                            hoverinfo="skip",
                            name=level_label,
                            legendgroup=legend_group,
                            legendgrouptitle=group_title,
                            showlegend=not bin_rows and status == "Normal",
                        )
                    )
                    if group_title:
                        group_title = {}

            if bin_rows:
                bin_df = nodes_df[nodes_df["node_id"].isin({r["node_id"] for r in bin_rows})].copy()
                sizes = [16 if r.get("node_kind") == "transformer_hub" else min(28, 14 + (r.get("degree", 0) * 1.8)) for r in bin_rows]
                symbols = ["diamond" if r.get("node_kind") == "transformer_hub" else "circle" for r in bin_rows]
                lwidths = [3 if selected_kind == "node" and selected_id == r.get("node_id") else 1 for r in bin_rows]
                labels = [r.get("display_name", "") if r.get("node_kind") == "transformer_hub" else "" for r in bin_rows]
                hovers = ["<br>".join(build_node_hover_lines(r)) for r in bin_rows]
                fig.add_trace(
                    go.Scatter(
                        x=bin_df["x"].tolist(),
                        y=bin_df["y"].tolist(),
                        mode="markers+text",
                        text=labels,
                        textposition="top center",
                        marker={
                            "size": sizes,
                            "symbol": symbols,
                            "color": bin_color,
                            "line": {"width": lwidths, "color": "#F8F7F3"},
                        },
                        customdata=[["node", r["node_id"]] for r in bin_rows],
                        hovertemplate="%{hovertext}<extra></extra>",
                        hovertext=hovers,
                        textfont={"family": "Segoe UI, Arial, sans-serif", "size": 11, "color": "#374151"},
                        name=level_label,
                        legendgroup=legend_group,
                        legendgrouptitle=group_title,
                        showlegend=True,
                    )
                )

    if injections_df is not None and not injections_df.empty:
        for inj_kind, legend_label in (("LOAD", "Loads"), ("GENERATOR", "Generators")):
            subset = injections_df[injections_df["kind"] == inj_kind].copy()
            if subset.empty:
                continue
            hover = []
            marker_line_widths = []
            for row in subset.to_dict("records"):
                hover.append(
                    "<br>".join(
                        [
                            display_text(row.get("name"), fallback=row.get("item_id")),
                            f"Type: {display_text(row.get('kind'))}",
                            f"Bus: {display_text(row.get('bus_id'))}",
                            f"Voltage level: {display_text(row.get('voltage_level_id'))}",
                            f"P: {format_metric(row.get('p'), suffix=' MW')}",
                            f"Q: {format_metric(row.get('q'), suffix=' MVAr')}",
                            f"I: {format_metric(row.get('i'), suffix=' A')}",
                        ]
                    )
                )
                marker_line_widths.append(3 if selected_kind == "injection" and str(selected_id) == str(row.get("item_id")) else 1)

            fig.add_trace(
                go.Scatter(
                    x=subset["x"],
                    y=subset["y"],
                    mode="markers",
                    marker={
                        "size": 13,
                        "symbol": subset["symbol"].iloc[0],
                        "color": subset["color"].iloc[0],
                        "line": {"width": marker_line_widths, "color": "#F8F7F3"},
                    },
                    customdata=[["injection", str(item_id)] for item_id in subset["item_id"]],
                    hovertemplate="%{hovertext}<extra></extra>",
                    hovertext=hover,
                    name=legend_label,
                    showlegend=True,
                )
            )

    fig.update_layout(
        paper_bgcolor="#F5F1E8",
        plot_bgcolor="#FCFBF8",
        margin={"l": 10, "r": 10, "t": 70, "b": 28},
        title={"text": "Interactive Grid Overview", "x": 0.01, "font": {"family": "Georgia, serif", "size": 22, "color": "#2E3440"}},
        showlegend=True,
        legend={
            "orientation": "v",
            "yanchor": "top",
            "y": 0.985,
            "xanchor": "right",
            "x": 0.995,
            "font": {"size": 10, "color": "#64748B"},
            "bgcolor": "rgba(252,251,248,0.84)",
            "borderwidth": 0,
            "itemwidth": 30,
            "tracegroupgap": 3,
        },
        clickmode="event+select",
        dragmode="pan",
        selectionrevision=f"{selected_kind or 'none'}::{selected_id or 'none'}",
        hoverlabel={"bgcolor": "#FFFDF8", "font": {"family": "Segoe UI, Arial, sans-serif", "size": 12, "color": "#1F2937"}},
        uirevision="lf-network-overview",
        xaxis={"showgrid": False, "zeroline": False, "showticklabels": False},
        yaxis={"showgrid": False, "zeroline": False, "showticklabels": False, "scaleanchor": "x", "scaleratio": 1},
    )
    return fig


def get_selected_plotly_item(plotly_event, current_kind=None, current_id=None):
    if not plotly_event:
        return None, None
    selection = plotly_event.get("selection") if isinstance(plotly_event, dict) else None
    points = selection.get("points", []) if selection else []
    if not points:
        return None, None

    parsed = []
    for point in points:
        customdata = point.get("customdata")
        if isinstance(customdata, (list, tuple)) and len(customdata) >= 2:
            parsed.append((str(customdata[0]), str(customdata[1])))
    if not parsed:
        return None, None

    kind_priority = {"injection": 3, "branch": 2, "node": 1}

    # Prefer a changed point when toggling between elements.
    if current_kind is not None and current_id is not None:
        current_key = (str(current_kind), str(current_id))
        changed_points = []
        for kind, item_id in reversed(parsed):
            if (kind, item_id) != current_key:
                changed_points.append((kind, item_id))
        if changed_points:
            changed_points.sort(key=lambda entry: kind_priority.get(entry[0], 0), reverse=True)
            return changed_points[0][0], changed_points[0][1]

    # Fallback: prefer higher-priority element kinds first, then latest occurrence.
    fallback_points = list(reversed(parsed))
    fallback_points.sort(key=lambda entry: kind_priority.get(entry[0], 0), reverse=True)
    return fallback_points[0][0], fallback_points[0][1]


def get_single_line_diagram_svg(network, container_id):
    svg_obj = network.get_single_line_diagram(container_id)
    svg_data = str(svg_obj)
    if not svg_data or not svg_data.strip():
        raise ValueError(f"No single-line diagram returned for '{container_id}'.")
    return svg_data
