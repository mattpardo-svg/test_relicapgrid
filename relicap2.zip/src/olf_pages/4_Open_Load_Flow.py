"""
Load Flow page.
Source: pyTSC crosa_app.py Step 2, adapted for multi-page navigation.
Grid Visualization tabs moved to 3_PSB_Grid_Visualization.py.
"""
import re
import time
import traceback
import streamlit as st
from src.core.ui.sidebar_actions import render_step_actions

st.markdown("# Load Flow")
st.sidebar.header("Load Flow")

def perform_lf() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None:
        powsybl_solver = st.session_state.powsybl_solver
        result = powsybl_solver.run_loadflow()
        st.session_state.olf_lf_result = str(result)

def get_lf_results() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None:
        powsybl_solver = st.session_state.powsybl_solver
        return powsybl_solver.get_lf_results()

def style_status(row):
    cloading = row.get("loading", row.get("loading", ""))
    if cloading > 100.:
        return ["background-color: #f8d7da"] * len(row)
    elif cloading > 80.:
        return ["background-color: #fff3cd"] * len(row)
    else:
        return ["background-color: #d4edda"] * len(row)

cgm_path = st.session_state.get("olf_grid_model_file_path", "")
cgm_read = st.session_state.get("olf_grid_model_read", False)
if not cgm_path and not cgm_read:
    st.warning("Upload and read a grid model first in 'PowSyBl Grid Model'.")
    render_step_actions("Load Flow")
    st.stop()

st.caption(f"Active CGM Source: {st.session_state["olf_grid_model_file_path"]}")

run_lf_clicked = st.session_state.pop("trigger_run_lf", False)

if run_lf_clicked:
    st.session_state["lf_running"] = True
    st.session_state["lf_started_at"] = time.time()
    try:
        with st.spinner("Running Load Flow..."):
            start_time = time.time()
            lf_res = perform_lf()
            elapsed = time.time() - start_time
        st.session_state["lf_time"] = elapsed
        st.session_state["lf_running"] = False
        st.session_state["lf_error"] = None
    except Exception as e:
        st.session_state["lf_error"] = traceback.format_exc()
        st.session_state["lf_running"] = False

lf_res = st.session_state.get("olf_lf_result")
elapsed = st.session_state.get("lf_time")
lf_error = st.session_state.get("lf_error")

if not run_lf_clicked:
    if st.button("Run Load Flow", type="primary"):
        st.session_state["trigger_run_lf"] = True
        st.rerun()

if lf_error:
    st.error("Error during Load Flow calculation:")
    st.code(lf_error)

if lf_res:
    if elapsed is not None:
        st.caption(f"Execution time: {elapsed:.2f} s")

    # ---- Load Flow Summary ----
    st.write("### Load Flow Summary")
    summary_keys = ["status", "iteration_count", "active_power_mismatch", "distributed_active_power"]
    summary_items = {}
    for key in summary_keys:
        match = re.search(rf"{key}\s*[:=]\s*([^,\)\]\n]+)", lf_res, re.IGNORECASE)
        if match:
            summary_items[key] = match.group(1).strip()
    if summary_items:
        st.table([{k: summary_items.get(k, "") for k in summary_keys}])
    else:
        st.info("No summary fields found in Load Flow log.")

    # ---- Branch Thermal Loading ----
    st.write("### Branch Thermal Loading")
    st.caption(
        "Thermal limits are taken per side from CURRENT permanent_limit for lines and 2W transformers. "
        "Displayed loading uses the worst side (max loading) and the most restrictive limit."
    )
    pd_res = get_lf_results().sort_values(by="loading", ascending=False, inplace=False)
    st.dataframe(pd_res.style.format(na_rep="-").apply(style_status, axis=1), width="stretch",
                 column_config={
                     "loading": st.column_config.NumberColumn(
                        "loading (%)",
                        help="Worst loading",
                        format="%.3f"
                     ),
                     "p1": st.column_config.NumberColumn(
                         "p1 (MW)",
                         help="Active Power in MW on side i",
                         format="%.4f"
                     ),
                     "q1": st.column_config.NumberColumn(
                         "q1 (Mvar)",
                         help="Reactive Power in MW on side i",
                         format="%.4f"
                     ),
                     "i1": st.column_config.NumberColumn(
                         "i1 (A)",
                         help="Current in A on side i",
                         format="%.4f"
                     ),
                     "inom1": st.column_config.NumberColumn(
                         "inom1 (A)",
                         help="Nominal Current in A on side i",
                         format="%.4f"
                     ),
                     "p2": st.column_config.NumberColumn(
                         "p2 (MW)",
                         help="Active Power in MW on side j",
                         format="%.4f"
                     ),
                     "q2": st.column_config.NumberColumn(
                         "q2 (Mvar)",
                         help="Reactive Power in MW on side j",
                         format="%.4f"
                     ),
                     "i2": st.column_config.NumberColumn(
                         "i2 (A)",
                         help="Current in A on side j",
                         format="%.4f"
                     ),
                     "inom2": st.column_config.NumberColumn(
                         "inom2 (A)",
                         help="Nominal Current in A on side j",
                         format="%.4f"
                     ),
                     "p3": st.column_config.NumberColumn(
                         "p3 (MW)",
                         help="Active Power in MW on side k",
                         format="%.4f"
                     ),
                     "q3": st.column_config.NumberColumn(
                         "q3 (Mvar)",
                         help="Reactive Power in MW on side k",
                         format="%.4f"
                     ),
                     "i3": st.column_config.NumberColumn(
                         "i3 (A)",
                         help="Current in A on side k",
                         format="%.4f"
                     ),
                     "inom3": st.column_config.NumberColumn(
                         "inom3 (A)",
                         help="Nominal Current in A on side k",
                         format="%.4f"
                     )
                 })

render_step_actions("Load Flow")
