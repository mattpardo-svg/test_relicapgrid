"""
Security Analysis page.
Source: pyTSC crosa_app.py Step 3, adapted for multi-page navigation.
Default: catalog-based contingency selector (pyTSC approach).
Optional: NCP XML file upload (TSCFlowBox approach).
"""
import tempfile
import time
import traceback
import streamlit as st
from src.core.ui.sidebar_actions import render_step_actions

st.markdown("# Security Analysis")
st.sidebar.header("Security Analysis")

def file_upload():
    uploaded_ncp = st.session_state.sa_uploaded_ncp_xml
    if uploaded_ncp is not None:
        with tempfile.NamedTemporaryFile(delete=False, prefix="pytsc_co_", suffix=".xml") as tmp:
            tmp.write(uploaded_ncp.getbuffer())
            st.session_state["contingencies_file_path"] = tmp.name
        get_contingencies()

def get_contingencies() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None and \
        'contingencies_file_path' in st.session_state and st.session_state.contingencies_file_path is not None:
        lf_solver = st.session_state.powsybl_solver
        lf_solver.set_contingencies(st.session_state.contingencies_file_path)
        st.session_state['olf_sa_contingencies'] = lf_solver.contingencies

def perform_sa() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None and \
        'contingencies_file_path' in st.session_state and st.session_state.contingencies_file_path is not None:
        lf_solver = st.session_state.powsybl_solver
        result = lf_solver.run_sa()
        st.session_state['olf_sa_result'] = result
        st.session_state['olf_sa_contingencies'] = lf_solver.contingencies

def get_sa_results() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None:
        lf_solver = st.session_state.powsybl_solver
        return lf_solver.get_sa_results()

cgm_path = st.session_state.get("olf_grid_model_file_path", "")
cgm_read = st.session_state.get("olf_grid_model_read", False)
if not cgm_path and not cgm_read:
    st.warning("Upload and read a grid model first in 'PowSyBl Grid Model'.")
    render_step_actions("Security Analysis")
    st.stop()

if not st.session_state.get('olf_lf_result'):
    st.warning("Run Load Flow first to populate the solved network for visualization.")
    render_step_actions('Security Analysis')
    st.stop()

st.caption(f"Active CGM Source: {st.session_state['olf_grid_model_file_path']}")
if 'contingencies_file_path' in st.session_state:
    st.caption(f"Active Contingencies NC Profile: {st.session_state['contingencies_file_path']}")

st.write("**Upload or select an NCP XML contingency file**")
uploaded_ncp = st.file_uploader("Upload NCP XML", type=["xml"], key="sa_uploaded_ncp_xml", on_change=file_upload)

run_sa_clicked = st.session_state.pop("trigger_run_sa", False)

if run_sa_clicked:
    st.session_state["sa_running"] = True
    st.session_state["sa_started_at"] = time.time()
    try:
        with st.spinner("Running Security Analysis..."):
            start_time = time.time()
            sa_res = perform_sa()
            elapsed = time.time() - start_time
        st.session_state["sa_time"] = elapsed
        st.session_state["sa_running"] = False
        st.session_state["sa_error"] = None
    except Exception as e:
        st.session_state["sa_error"] = traceback.format_exc()
        st.session_state["sa_running"] = False        

sa_contingencies = st.session_state.get("olf_sa_contingencies")
sa_res = st.session_state.get("olf_sa_result")
elapsed = st.session_state.get("sa_time")
sa_error = st.session_state.get("sa_error")

if not run_sa_clicked:
    if st.button("Run Security Analysis", type="primary"):
        st.session_state["trigger_run_sa"] = True
        st.rerun()

if sa_error:
    st.error("Error during Security Analysis:")
    st.code(sa_error)

if sa_res:
    if elapsed is not None:
        st.caption(f"Execution time: {elapsed:.2f} s")

if sa_contingencies is not None:
    with st.expander("Contingencies Definition", expanded=False):
        st.table(sa_contingencies)

if sa_res:
    # ---- Post-Contingency Limit Violations ----
    st.write("### Post-Contingency Limit Violations")
    pd_res = get_sa_results()
    st.dataframe(pd_res)

render_step_actions("Security Analysis")
