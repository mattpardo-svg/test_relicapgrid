import tempfile
import time
import traceback
import streamlit as st
from src.core.ui.sidebar_actions import render_step_actions

st.markdown("# Sensitivity Analysis")
st.sidebar.header("Sensitivity Analysis")

def file_upload():
    # uploaded_ncp = st.session_state.sn_uploaded_ncp_xml
    # if uploaded_ncp is not None:
    #     with tempfile.NamedTemporaryFile(delete=False, prefix="pytsc_ra_", suffix=".xml") as tmp:
    #         tmp.write(uploaded_ncp.getbuffer())
    #         st.session_state["remedial_actions_file_path"] = tmp.name
    st.session_state["remedial_actions_file_path"] = "Mockup path/Non existent folder/fake file.xml"
    get_remedial_actions()

def get_remedial_actions() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None and \
        'remedial_actions_file_path' in st.session_state and st.session_state.remedial_actions_file_path is not None:
        lf_solver = st.session_state.powsybl_solver
        lf_solver.set_remedial_actions(st.session_state.remedial_actions_file_path)
        st.session_state['olf_sn_remedial_actions'] = lf_solver.remedial_actions

def perform_sn() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None and \
        'remedial_actions_file_path' in st.session_state and st.session_state.remedial_actions_file_path is not None:
        lf_solver = st.session_state.powsybl_solver
        result = lf_solver.run_sn()
        st.session_state['olf_sn_result'] = result
        st.session_state['olf_sn_remedial_actions'] = lf_solver.remedial_actions

def get_sn_results() -> None:
    if 'powsybl_solver' in st.session_state and st.session_state.powsybl_solver is not None:
        lf_solver = st.session_state.powsybl_solver
        return lf_solver.get_sn_results()

cgm_path = st.session_state.get("olf_grid_model_file_path", "")
cgm_read = st.session_state.get("olf_grid_model_read", False)
if not cgm_path and not cgm_read:
    st.warning("Upload and read a grid model first in 'PowSyBl Grid Model'.")
    render_step_actions("Sensitivity Analysis")
    st.stop()

if not st.session_state.get('olf_lf_result'):
    st.warning("Run Load Flow first to populate the solved network for visualization.")
    render_step_actions('Sensitivity Analysis')
    st.stop()

st.caption(f"Active CGM Source: {st.session_state['olf_grid_model_file_path']}")
if 'remedial_actions_file_path' in st.session_state:
    st.caption(f"Active Remedial Actions File: {st.session_state['remedial_actions_file_path']}")

st.write("**Upload or select an NCP XML remedial actions file**")
uploaded_ncp = st.file_uploader("Upload NCP XML", type=["xml"], key="sn_uploaded_ncp_xml", on_change=file_upload)

run_sa_clicked = st.session_state.pop("trigger_run_sn", False)

if run_sa_clicked:
    st.session_state["sn_running"] = True
    st.session_state["sn_started_at"] = time.time()
    try:
        with st.spinner("Running Sensitivity Analysis..."):
            start_time = time.time()
            sa_res = perform_sn()
            elapsed = time.time() - start_time
        st.session_state["sn_time"] = elapsed
        st.session_state["sn_running"] = False
        st.session_state["sn_error"] = None
    except Exception as e:
        st.session_state["sn_error"] = traceback.format_exc()
        st.session_state["sn_running"] = False        

sn_remedial_actions = st.session_state.get("olf_sn_remedial_actions")
sn_res = st.session_state.get("olf_sn_result")
elapsed = st.session_state.get("sn_time")
sn_error = st.session_state.get("sn_error")

if not run_sa_clicked:
    if st.button("Run Sensitivity Analysis", type="primary"):
        st.session_state["trigger_run_sn"] = True
        st.rerun()

if sn_error:
    st.error("Error during Sensitivity Analysis:")
    st.code(sn_error)

if sn_res:
    if elapsed is not None:
        st.caption(f"Execution time: {elapsed:.2f} s")

if sn_remedial_actions is not None:
    with st.expander("Remedial Actions Definition", expanded=False):
        st.table(sn_remedial_actions)

if sn_res:
    # ---- Post-Contingency Limit Violations ----
    st.write("### Sensitivity Factors - Branch Current Sensitivity (A/tap-step)")
    st.caption(
        "The Phase Shifting Transformer (PST) branch-current sensitivity factors indicate "
        "how much the worst-side current (A) on each branch would change in response to a "
        "one tap-step change in each PST. "
        "The rows correspond to the branches in the network, while the columns correspond to the PSTs."
    )
    pd_res = get_sn_results()
    st.dataframe(pd_res)

render_step_actions("Sensitivity Analysis")
