"""
Grid Model Import page.
Source blend:
  - File upload and local picker: pyTSC + TSCFlowBox
  - CGMES Profile Status, Files in ZIP, Grid Overview,
    Advanced Analytics: pyTSC crosa_app.py Step 1.
"""
import os
import streamlit as st
import time
import hashlib
import tempfile
import pandas as pd
from src.core.olf.powsybl_solver import powsybl_solver
from src.core.ui.sidebar_actions import render_step_actions
from src.core.olf.collect_model_metadata import model_metadata, _norm_id, PROFILE_KEYS


# ---- Session-state helpers ----
def reset_grid_model():
    for key in ["olf_grid_model_read", "olf_grid_model_file_path",
                "olf_lf_result",
                "olf_grid_model_running", "olf_grid_model_started_at", 
                "olf_grid_model_time",
                "olf_grid_model_profile_status", "olf_model_metadata"]:
        st.session_state.pop(key, None)

def file_upload():
    reset_grid_model()
    uploaded_file = st.session_state.olf_uploaded_zip
    if uploaded_file is not None:
        uploaded_bytes = uploaded_file.getbuffer()
        file_hash = hashlib.md5(uploaded_bytes).hexdigest()
        temp_zip_path = os.path.join(tempfile.gettempdir(), f"pytsc_{file_hash}_{uploaded_file.name}")
        if not os.path.exists(temp_zip_path):
            with open(temp_zip_path, "wb") as fh:
                fh.write(uploaded_bytes)
        del uploaded_bytes # needed to avoid BufferError
        st.session_state["olf_grid_model_file_path"] = temp_zip_path
        read_network()

def read_network():
    model_path = st.session_state.get("olf_grid_model_file_path")
    if not model_path:
        return
    st.session_state["powsybl_solver"] = powsybl_solver(model_path)
    st.session_state["olf_grid_model_running"] = True
    started = time.time()
    st.session_state["olf_grid_model_started_at"] = started
    try:
        with st.spinner("Reading CGMES network..."):
            start_time = time.time()
            st.session_state.powsybl_solver.read_network()
            elapsed = time.time() - start_time
        st.session_state["olf_grid_model_read"] = True
        st.session_state["olf_grid_model_time"] = elapsed
        st.session_state["olf_model_metadata"] = model_metadata(model_path, st.session_state.powsybl_solver.network)
        st.session_state["olf_grid_model_profile_status"] = st.session_state["olf_model_metadata"].profile_status_from_zip()
        st.session_state["olf_model_metadata"].collect_model_metadata()
    finally:
        st.session_state["olf_grid_model_running"] = False

st.markdown("# Grid Model")
st.sidebar.header("Grid Model")

cgm_path = st.session_state.get("olf_grid_model_file_path", "")
cgm_read = st.session_state.get("olf_grid_model_read", False)
if not cgm_path:
    st.error("Upload and read a grid model first.")
elif not cgm_read:
    st.error(f"Read the uploaded grid model first | Path: {cgm_path}")
else:
    st.caption(f"Active CGM Source: {st.session_state["olf_grid_model_file_path"]}")

# ---- Upload & profile inspection ----
profile_status = {k: "waiting" for k in PROFILE_KEYS}

st.file_uploader("Upload CGMES ZIP", type=["zip"], key="olf_uploaded_zip", 
                 accept_multiple_files=False, on_change=file_upload)

elapsed = st.session_state.get('olf_grid_model_time')
if elapsed is not None:
    st.caption(f"Execution time: {elapsed:.2f} s")

st.divider()

# ======================================================================
# CGMES Profile Files Status
# ======================================================================
profile_status = st.session_state.get("olf_grid_model_profile_status", {k: "waiting" for k in PROFILE_KEYS})
st.write("**CGMES Profile Files Status:**")
profile_cols = st.columns(len(PROFILE_KEYS))
for idx, key in enumerate(PROFILE_KEYS):
    status = profile_status[key]
    color = "green" if status == "found" else ("red" if status == "missing" else "#f0ad00")
    label = f"{key}: {status.capitalize()}"
    profile_cols[idx].markdown(
        f'<div style="background-color:{color};color:white;padding:8px;border-radius:6px;'
        f'text-align:center;font-weight:bold;">{label}</div>',
        unsafe_allow_html=True,
    )

# ======================================================================
# Files in ZIP
# ======================================================================
has_grid_loaded = st.session_state.get("olf_model_metadata", False)
cached_files = []
if has_grid_loaded:
    cached_files = st.session_state.olf_model_metadata.get("uploaded_zip_file_list", [])

with st.expander("Files in ZIP", expanded=False):
    if has_grid_loaded and cached_files:
        st.write(cached_files)
    elif has_grid_loaded:
        st.info("Files in ZIP are not available for the current model.")
    else:
        st.info("Click 'Read Network' to populate ZIP file details.")

# ======================================================================
# Uploaded Grid Overview
# ======================================================================
st.write("**Uploaded Grid Overview:**")
if has_grid_loaded:
    summary = st.session_state.olf_model_metadata.get("uploaded_grid_summary", False)
    summary_err = st.session_state.olf_model_metadata.get("uploaded_grid_summary_error")
else:
    summary= False
    summary_err = "No uploaded grid yet"

if not has_grid_loaded:
    st.table(pd.DataFrame([{"Total Branches": "-", "Lines": "-", "Tie-lines": "-", "Transformers": "-"}]))
elif summary_err:
    st.error("Uploaded file could not be loaded for branch inspection.")
    st.code(summary_err)
elif summary:
    st.table(pd.DataFrame([summary]))
else:
    st.info("Grid summary not available yet.")

# ======================================================================
# Advanced Analytics
# ======================================================================
with st.expander("Advanced Analytics", expanded=False):
    st.write("**ZIP Read Diagnostics:**")
    if not has_grid_loaded:
        st.info("Click 'Read Network' to populate diagnostics.")
    else:
        zip_diag = st.session_state.olf_model_metadata.get("uploaded_zip_diagnostics")
        st.table(pd.DataFrame([zip_diag]))

    st.write("**EQ vs Imported Branches Reconciliation:**")
    if not has_grid_loaded:
        st.info("Click 'Read Network' to populate diagnostics.")
    else:
        reconciliation = st.session_state.olf_model_metadata.get("uploaded_import_reconciliation")
        rec_err = st.session_state.olf_model_metadata.get("uploaded_import_reconciliation_error")
        if rec_err:
            st.error("Could not build EQ/import reconciliation diagnostics.")
            st.code(rec_err)
        elif reconciliation:
            st.table(pd.DataFrame([reconciliation]))
        else:
            st.info("Reconciliation diagnostics not available yet.")

    st.write("**Expected Equipment Inclusion Check:**")
    st.caption("Paste the ENTSO-E expected equipment IDs (comma/newline/space separated).")
    expected_ids_text = st.text_area(
        "Expected equipment IDs",
        key="expected_equipment_ids_text",
        height=120,
        placeholder="Example:\n2184f365-8cd5-4b5d-8a28-9d68603bb6a4\n84ed55f4-61f5-4d9d-8755-bba7b877a246",
    )
    enabled = st.session_state.get("olf_grid_model_file_path", False) and st.session_state.get('powsybl_solver', False)
    if st.button("Check Expected Equipment", disabled=not enabled):
        raw_tokens = expected_ids_text.replace(";", " ").replace(",", " ").split()
        raw_ids = [_norm_id(x) for x in raw_tokens]
        raw_ids = [x for x in raw_ids if x]
        seen, expected_ids = set(), []
        for eid in raw_ids:
            if eid not in seen: seen.add(eid); expected_ids.append(eid)
        dup_count = len(raw_ids) - len(expected_ids)
        if not expected_ids:
            st.warning("Provide at least one equipment ID to run the check.")
        else:
            try:
                with st.spinner("Comparing expected IDs against imported study network..."):
                    rows = st.session_state.olf_model_metadata.check_expected_equipment(expected_ids)
                    df_check = pd.DataFrame(rows)
                    inc_cnt = int((df_check["Included in Study"] == "Yes").sum())
                    st.success(f"Included: {inc_cnt} / {len(df_check)} | Missing: {len(df_check) - inc_cnt}")
                    st.dataframe(df_check, width="stretch")
            except Exception as exc:
                st.error("Failed to run expected equipment inclusion check.")
                st.code(str(exc))

# ---- Missing profile warning ----
missing_profiles = [k for k, v in profile_status.items() if v == "missing"]
if missing_profiles:
    st.warning(f"Missing required CGMES profile(s): {', '.join(missing_profiles)}")

render_step_actions("PowSyBl Grid Model")
