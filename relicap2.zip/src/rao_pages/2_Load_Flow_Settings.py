"""src/rao_pages/2_Load_Flow_Settings.py

13 pypowsybl LoadFlowParameters fields. Page 2. Does NOT call st.set_page_config()/st.logo() — already
called once, globally, in the platform's own app.py.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _gui_common as gc

st.write("# Load Flow Settings")
st.caption(
    "13 load-flow parameter fields. Persisted to disk — survives a full "
    "app restart, until changed again here."
)

settings = gc.load_settings()
lf = settings["load_flow_config"]

col1, col2 = st.columns(2)

with col1:
    use_reactive_limits = st.checkbox("use_reactive_limits", value=lf["use_reactive_limits"])
    voltage_init_mode = st.selectbox(
        "voltage_init_mode", gc.VOLTAGE_INIT_MODE_OPTIONS,
        index=gc.VOLTAGE_INIT_MODE_OPTIONS.index(lf["voltage_init_mode"]),
    )
    transformer_voltage_control_on = st.checkbox(
        "transformer_voltage_control_on", value=lf["transformer_voltage_control_on"],
    )
    phase_shifter_regulation_on = st.checkbox(
        "phase_shifter_regulation_on", value=lf["phase_shifter_regulation_on"],
    )
    twt_split_shunt_admittance = st.checkbox(
        "twt_split_shunt_admittance", value=lf["twt_split_shunt_admittance"],
    )
    shunt_compensator_voltage_control_on = st.checkbox(
        "shunt_compensator_voltage_control_on", value=lf["shunt_compensator_voltage_control_on"],
    )
    read_slack_bus = st.checkbox("read_slack_bus", value=lf["read_slack_bus"])

with col2:
    write_slack_bus = st.checkbox("write_slack_bus", value=lf["write_slack_bus"])
    distributed_slack = st.checkbox("distributed_slack", value=lf["distributed_slack"])
    balance_type = st.selectbox(
        "balance_type", gc.BALANCE_TYPE_OPTIONS,
        index=gc.BALANCE_TYPE_OPTIONS.index(lf["balance_type"]),
    )
    component_mode = st.selectbox(
        "component_mode", gc.COMPONENT_MODE_OPTIONS,
        index=gc.COMPONENT_MODE_OPTIONS.index(lf["component_mode"]),
        help=(
            "MAIN_SYNCHRONOUS is the codebase's own confirmed default — "
            "MAIN_CONNECTED alone does not exclude small synchronous "
            "islands that can otherwise break voltage warm-starting."
        ),
    )
    hvdc_ac_emulation = st.checkbox("hvdc_ac_emulation", value=lf["hvdc_ac_emulation"])
    dc_power_factor = st.number_input(
        "dc_power_factor", value=float(lf["dc_power_factor"]), min_value=0.0, max_value=1.0, step=0.01,
    )

st.divider()

if st.button("Save settings", type="primary"):
    new_lf = {
        "use_reactive_limits": use_reactive_limits,
        "voltage_init_mode": voltage_init_mode,
        "transformer_voltage_control_on": transformer_voltage_control_on,
        "phase_shifter_regulation_on": phase_shifter_regulation_on,
        "twt_split_shunt_admittance": twt_split_shunt_admittance,
        "shunt_compensator_voltage_control_on": shunt_compensator_voltage_control_on,
        "read_slack_bus": read_slack_bus,
        "write_slack_bus": write_slack_bus,
        "distributed_slack": distributed_slack,
        "balance_type": balance_type,
        "component_mode": component_mode,
        "hvdc_ac_emulation": hvdc_ac_emulation,
        "dc_power_factor": dc_power_factor,
    }
    gc.save_settings(settings["rao_config"], new_lf)
    st.success("Load Flow Settings saved.")
