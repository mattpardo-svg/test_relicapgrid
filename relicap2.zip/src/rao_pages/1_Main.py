"""src/rao_pages/1_Main.py

Closed RAO — Main page. Page 1.
Does NOT call st.set_page_config() or st.logo() — both already called
once, globally, in the platform's own app.py.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _gui_common as gc

st.write("# Closed RAO")

# ---------------------------------------------------------------------------
# Session state initialisation — Streamlit reruns this whole script on
# every interaction, so persistent state across reruns lives in
# st.session_state, not plain module-level variables.
# ---------------------------------------------------------------------------
_DEFAULTS = {
    "cgm_bytes": None, "ncp_bytes": None,
    "cgm_valid": False, "cgm_messages": [],
    "ncp_valid": False, "ncp_messages": [],
    "tier1_inventory": None,
    "run_in_progress": False, "run_complete": False, "run_exit_code": None,
    "log_lines": [], "tmpdir": None, "tier2_inventory": None,
}
for key, default in _DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = default

settings = gc.load_settings()

# ---------------------------------------------------------------------------
# 1-2. CGM / NCP upload widgets
# ---------------------------------------------------------------------------
st.subheader("1. Upload data")

col_cgm, col_ncp = st.columns(2)
with col_cgm:
    cgm_file = st.file_uploader("CGM package (.zip)", type=["zip"], key="cgm_uploader")
with col_ncp:
    ncp_file = st.file_uploader("NCP package (.zip)", type=["zip"], key="ncp_uploader")

if cgm_file is not None:
    new_bytes = cgm_file.getvalue()
    if new_bytes != st.session_state.cgm_bytes:
        st.session_state.cgm_bytes = new_bytes
        st.session_state.cgm_valid, st.session_state.cgm_messages = gc.validate_cgm_upload(new_bytes)

if ncp_file is not None:
    new_bytes = ncp_file.getvalue()
    if new_bytes != st.session_state.ncp_bytes:
        st.session_state.ncp_bytes = new_bytes
        st.session_state.ncp_valid, st.session_state.ncp_messages, _ = gc.validate_ncp_upload(new_bytes)
        st.session_state.tier1_inventory = None  # recompute below once valid

# ---------------------------------------------------------------------------
# 3. Validation results
# ---------------------------------------------------------------------------
st.subheader("2. Validation")

if st.session_state.cgm_bytes is None or st.session_state.ncp_bytes is None:
    st.info("Upload both a CGM package and an NCP package to continue.")
else:
    if st.session_state.cgm_valid:
        st.success("CGM package: " + " ".join(st.session_state.cgm_messages))
    else:
        st.error("CGM package: " + " ".join(st.session_state.cgm_messages))

    if st.session_state.ncp_valid:
        st.success("NCP package valid.")
        for msg in st.session_state.ncp_messages:
            st.caption(msg)
    else:
        st.error("NCP package invalid:")
        for msg in st.session_state.ncp_messages:
            st.write(f"- {msg}")

validation_passed = st.session_state.cgm_valid and st.session_state.ncp_valid

# ---------------------------------------------------------------------------
# 4. Tier 1 ("Parsed") inventory summary — shown once validation passes.
# See _gui_common.compute_tier1_inventory's own docstring: this is a
# raw, file-level, NCP-only summary — NOT the same PRA/CRA-classified
# numbers the completed run itself produces (Tier 2, below), since those
# genuinely require the full CGM load the real pipeline only does at
# Run time. Confirmed, deliberate deviation from the original design
# doc's own Section 7 — flagged here rather than presented as identical.
# ---------------------------------------------------------------------------
if validation_passed:
    st.subheader("3. Parsed inventory (upload-time preview)")
    st.caption(
        "Raw counts from the uploaded NCP files only — not yet filtered by "
        "availability, thresholds, or MILP-inclusion rules, and not yet "
        "cross-referenced against the CGM network (that only happens once "
        "you click Run). See \"Passed to MILP\" below for the real, final "
        "numbers after a completed run."
    )
    if st.session_state.tier1_inventory is None:
        with st.spinner("Parsing uploaded NCP files..."):
            st.session_state.tier1_inventory = gc.compute_tier1_inventory(st.session_state.ncp_bytes)
    import pandas as pd
    st.dataframe(pd.DataFrame.from_dict(st.session_state.tier1_inventory, orient="index"), width="stretch")

# ---------------------------------------------------------------------------
# 5. Three toggles — confirmed final: only the original 3, per the
# design doc's own settled decision (Section 4/Page 1).
# ---------------------------------------------------------------------------
st.subheader("4. Options")

wf = settings["rao_config"]["workflow_toggles"]
col_a, col_b, col_c = st.columns(3)
with col_a:
    enable_nx = st.toggle("N-X analysis", value=wf["enable_nx_analysis"], key="toggle_nx")
with col_b:
    enable_pst = st.toggle("PST remedial actions", value=wf["enable_pst_remedial_actions"], key="toggle_pst")
with col_c:
    enable_rd = st.toggle("RD remedial actions", value=wf["enable_rd_remedial_actions"], key="toggle_rd")

# ---------------------------------------------------------------------------
# 6. Run button
# ---------------------------------------------------------------------------
st.subheader("5. Run")

run_clicked = st.button(
    "Run",
    disabled=not validation_passed or st.session_state.run_in_progress,
    type="primary",
)

if run_clicked:
    # Apply this run's toggle choices on top of the persisted RAO Settings
    # / Load Flow Settings values, without permanently overwriting them —
    # the toggles above are per-run choices, not persisted settings
    # themselves (those are edited only on their own pages, per Section 6).
    run_rao_config = {
        section: dict(values) for section, values in settings["rao_config"].items()
    }
    run_rao_config["workflow_toggles"]["enable_nx_analysis"] = enable_nx
    run_rao_config["workflow_toggles"]["enable_pst_remedial_actions"] = enable_pst
    run_rao_config["workflow_toggles"]["enable_rd_remedial_actions"] = enable_rd

    st.session_state.run_in_progress = True
    st.session_state.run_complete = False
    st.session_state.log_lines = []
    st.session_state.tier2_inventory = None

    if st.session_state.tmpdir is not None:
        gc.cleanup_temp_run_dir(st.session_state.tmpdir)  # previous run's own temp dir, if any

    st.session_state.tmpdir = gc.build_temp_run_dir(
        st.session_state.cgm_bytes, st.session_state.ncp_bytes,
        run_rao_config, settings["load_flow_config"],
    )

# ---------------------------------------------------------------------------
# 7. Live log output — streamed synchronously while the subprocess runs.
# A single, blocking script execution is the correct pattern here, not
# an attempt at background async execution — Streamlit does not respond
# to other interactions while this runs, which is expected and fine for
# a single-user, single-run-at-a-time local tool.
# ---------------------------------------------------------------------------
if st.session_state.run_in_progress:
    st.subheader("6. Live log")
    log_placeholder = st.empty()
    error_stage_hint = None
    for line in gc.run_pipeline_subprocess(st.session_state.tmpdir):
        if line.startswith("__RAO_GUI_PROCESS_EXIT_CODE__:"):
            st.session_state.run_exit_code = int(line.split(":")[1])
            break
        st.session_state.log_lines.append(line)
        if line.startswith("=== "):
            error_stage_hint = line.strip("= ").strip()
        log_placeholder.code("\n".join(st.session_state.log_lines[-200:]), language=None)

    st.session_state.run_in_progress = False
    st.session_state.run_complete = True

    if st.session_state.run_exit_code == 0:
        st.session_state.tier2_inventory = gc.read_tier2_inventory(st.session_state.tmpdir / "output")
    st.rerun()

elif st.session_state.log_lines:
    st.subheader("6. Live log")
    with st.expander("Show full log", expanded=not st.session_state.run_complete or st.session_state.run_exit_code != 0):
        st.code("\n".join(st.session_state.log_lines), language=None)

# ---------------------------------------------------------------------------
# 8. Error handling (Section 8) — friendlier message + full technical
# detail available underneath, plus a continuously-available log download.
# ---------------------------------------------------------------------------
if st.session_state.run_complete:
    if st.session_state.run_exit_code == 0:
        st.success("Run completed successfully.")
    else:
        last_section = next(
            (l.strip("= ").strip() for l in reversed(st.session_state.log_lines) if l.startswith("=== ")),
            None,
        )
        if last_section:
            st.error(f"Something went wrong during: {last_section}")
        else:
            st.error("The run did not complete successfully.")
        with st.expander("Show technical details"):
            st.code("\n".join(st.session_state.log_lines), language=None)

    st.download_button(
        "Download log",
        data="\n".join(st.session_state.log_lines),
        file_name="run_log.txt",
        mime="text/plain",
    )

# ---------------------------------------------------------------------------
# 8. "Passed to MILP" inventory — Tier 2, real numbers from the completed
# run's own output CSVs.
# ---------------------------------------------------------------------------
if st.session_state.tier2_inventory is not None:
    st.subheader("7. Passed to MILP (final numbers)")
    import pandas as pd
    st.dataframe(pd.DataFrame([st.session_state.tier2_inventory]), width="stretch")

# ---------------------------------------------------------------------------
# 9. Results section (Section 9) — organized by category, 2 rendered
# inline, everything else as downloads plus a single "download all" zip.
# ---------------------------------------------------------------------------
if st.session_state.run_complete and st.session_state.run_exit_code == 0 and st.session_state.tmpdir is not None:
    st.subheader("8. Results")
    output_dir = st.session_state.tmpdir / "output"
    all_files = sorted(f for f in output_dir.iterdir() if f.is_file())

    categories = {
        "Base case": [f for f in all_files if f.name.startswith("lf_basecase") or f.name.startswith("lf_post")],
        "N-0 results": [f for f in all_files if f.name.startswith("results_pst") or f.name.startswith("results_preventive_rd") or f.name.startswith("results_rd") or f.name.startswith("results_ra")],
        "N-X results": [f for f in all_files if "nx" in f.name and not f.name.startswith("sensitivity")],
        "Sensitivity": [f for f in all_files if f.name.startswith("sensitivity")],
    }
    categorized = {f for files in categories.values() for f in files}
    categories["Other"] = [f for f in all_files if f not in categorized]

    for category, files in categories.items():
        if not files:
            continue
        with st.expander(f"{category} ({len(files)} file(s))"):
            for f in files:
                if f.name in ("results_preventive_rd.csv",):
                    st.write(f"**{f.name}**")
                    import pandas as pd
                    st.dataframe(pd.read_csv(f), width="stretch")
                st.download_button(
                    f"Download {f.name}", data=f.read_bytes(), file_name=f.name, key=f"dl_{f.name}",
                )

    import io as _io
    import zipfile as _zipfile
    zip_buffer = _io.BytesIO()
    with _zipfile.ZipFile(zip_buffer, "w") as zf:
        for f in all_files:
            zf.write(f, arcname=f.name)
    st.download_button(
        "Download all results (.zip)", data=zip_buffer.getvalue(),
        file_name="rao_results.zip", mime="application/zip",
    )
