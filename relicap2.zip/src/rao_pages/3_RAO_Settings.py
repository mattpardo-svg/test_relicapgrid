"""src/rao_pages/3_RAO_Settings.py

Thresholds, iteration caps, hard RA limits, and logging verbosity. Page 3 (renamed from "Solver
Tuning" — everything here is RAO-specific business logic, not solver
internals; the 70+ actual solver-tuning parameters are deliberately
excluded, see Page 2). Does NOT call st.set_page_config()/st.logo() —
already called once, globally, in the platform's own app.py.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _gui_common as gc

st.write("# RAO Settings")
st.caption(
    "Persisted to disk — survives a full app restart, until changed "
    "again here."
)

settings = gc.load_settings()
th = settings["rao_config"]["thresholds"]
caps = settings["rao_config"]["iteration_caps"]
limits = settings["rao_config"]["ra_limits"]
logging_opts = settings["rao_config"]["logging_options"]

# ---------------------------------------------------------------------------
# 9 thresholds
# ---------------------------------------------------------------------------
st.subheader("Thresholds")

col1, col2 = st.columns(2)
with col1:
    min_loading_threshold_pct = st.number_input(
        "min_loading_threshold_pct", value=float(th["min_loading_threshold_pct"]),
        help="N-0: minimum branch loading % to be considered at all.",
    )
    min_loading_threshold_pct_nx = st.number_input(
        "min_loading_threshold_pct_nx", value=float(th["min_loading_threshold_pct_nx"]),
        help="Same, for N-X — kept deliberately separate in the codebase.",
    )
    sensitivity_threshold_pct_pst = st.number_input(
        "sensitivity_threshold_pct_pst", value=float(th["sensitivity_threshold_pct_pst"]),
        help="N-0: minimum PST sensitivity to keep a branch in scope.",
    )
    sensitivity_threshold_pct_rd = st.number_input(
        "sensitivity_threshold_pct_rd", value=float(th["sensitivity_threshold_pct_rd"]),
        help="N-0: same, for RD.",
    )
    sensitivity_threshold_pct_pst_nx = st.number_input(
        "sensitivity_threshold_pct_pst_nx", value=float(th["sensitivity_threshold_pct_pst_nx"]),
        help="N-X: same, for PST.",
    )
with col2:
    sensitivity_threshold_pct_rd_nx = st.number_input(
        "sensitivity_threshold_pct_rd_nx", value=float(th["sensitivity_threshold_pct_rd_nx"]),
        help="N-X: same, for RD.",
    )
    max_change_ra_sum_threshold = st.number_input(
        "max_change_ra_sum_threshold", value=float(th["max_change_ra_sum_threshold"]), min_value=0.0,
        help="Aggregate sum of all PST tap / RD MW changes since the previous iteration, below which the AC loop considers itself converged.",
    )
    max_change_ra = st.number_input(
        "max_change_ra", value=float(th["max_change_ra"]), min_value=0.0,
        help="Per-RA individual movement threshold (max of any single mover), distinct from the aggregate sum above.",
    )
    max_change_overload = st.number_input(
        "max_change_overload", value=float(th["max_change_overload"]), min_value=0.0,
        help="Congestion-picture stabilisation — whether the overload level itself (not RA movement) has stopped changing between iterations.",
    )

# ---------------------------------------------------------------------------
# 3 iteration caps
# ---------------------------------------------------------------------------
st.subheader("Iteration caps")

col3, col4, col5 = st.columns(3)
with col3:
    max_linearisation_iterations = st.number_input(
        "max_linearisation_iterations", value=int(caps["max_linearisation_iterations"]), min_value=1, step=1,
    )
with col4:
    max_completeness_iterations = st.number_input(
        "max_completeness_iterations", value=int(caps["max_completeness_iterations"]), min_value=1, step=1,
    )
with col5:
    incremental_ac_fallback_max_steps = st.number_input(
        "incremental_ac_fallback_max_steps", value=int(caps["incremental_ac_fallback_max_steps"]), min_value=1, step=1,
    )

# ---------------------------------------------------------------------------
# Hard RA limits — max_taps_per_tso always active; the 2 per-TSO RA-count
# limits default to None (no limit) and need an explicit enable toggle,
# not a plain number field, since None is a genuinely different state
# from any numeric value including 0.
# ---------------------------------------------------------------------------
st.subheader("Hard limits")

max_taps_per_tso = st.number_input(
    "max_taps_per_tso", value=int(limits["max_taps_per_tso"]), min_value=1, step=1,
    help=(
        "Hard, per-TSO cap on combined PST tap movement in a single "
        "timestamp. A TSO will not realistically authorise a large "
        "single-timestamp swing — this constraint reflects that."
    ),
)

col6, col7 = st.columns(2)
with col6:
    enable_timestamp_limit = st.checkbox(
        "Limit RA count per timestamp per TSO",
        value=limits["max_ra_count_per_timestamp_tso"] is not None,
    )
    max_ra_count_per_timestamp_tso = None
    if enable_timestamp_limit:
        max_ra_count_per_timestamp_tso = st.number_input(
            "max_ra_count_per_timestamp_tso",
            value=int(limits["max_ra_count_per_timestamp_tso"] or 1), min_value=1, step=1,
        )
with col7:
    enable_timeframe_limit = st.checkbox(
        "Limit RA count per timeframe per TSO",
        value=limits["max_ra_count_per_timeframe_tso"] is not None,
    )
    max_ra_count_per_timeframe_tso = None
    if enable_timeframe_limit:
        max_ra_count_per_timeframe_tso = st.number_input(
            "max_ra_count_per_timeframe_tso",
            value=int(limits["max_ra_count_per_timeframe_tso"] or 1), min_value=1, step=1,
        )

# ---------------------------------------------------------------------------
# Logging verbosity
# ---------------------------------------------------------------------------
st.subheader("Logging")

debug_log_mode = st.toggle(
    "Debug log mode", value=logging_opts["debug_log_mode"],
    help=(
        "Normal mode shows a concise, one-line-per-iteration summary and "
        "every warning. Debug mode shows the full, verbose solver trace "
        "on top of that."
    ),
)

st.divider()

if st.button("Save settings", type="primary"):
    new_rao_config = {section: dict(values) for section, values in settings["rao_config"].items()}
    new_rao_config["thresholds"] = {
        "min_loading_threshold_pct": min_loading_threshold_pct,
        "min_loading_threshold_pct_nx": min_loading_threshold_pct_nx,
        "sensitivity_threshold_pct_pst": sensitivity_threshold_pct_pst,
        "sensitivity_threshold_pct_rd": sensitivity_threshold_pct_rd,
        "sensitivity_threshold_pct_pst_nx": sensitivity_threshold_pct_pst_nx,
        "sensitivity_threshold_pct_rd_nx": sensitivity_threshold_pct_rd_nx,
        "max_change_ra_sum_threshold": max_change_ra_sum_threshold,
        "max_change_ra": max_change_ra,
        "max_change_overload": max_change_overload,
    }
    new_rao_config["iteration_caps"] = {
        "max_linearisation_iterations": max_linearisation_iterations,
        "max_completeness_iterations": max_completeness_iterations,
        "incremental_ac_fallback_max_steps": incremental_ac_fallback_max_steps,
    }
    new_rao_config["ra_limits"] = {
        **new_rao_config["ra_limits"],
        "max_taps_per_tso": max_taps_per_tso,
        "max_ra_count_per_timestamp_tso": max_ra_count_per_timestamp_tso,
        "max_ra_count_per_timeframe_tso": max_ra_count_per_timeframe_tso,
    }
    new_rao_config["logging_options"] = {"debug_log_mode": debug_log_mode}

    gc.save_settings(new_rao_config, settings["load_flow_config"])
    st.success("RAO Settings saved.")
