"""nx_sensitivity.py — N-X sensitivities of PSTs (A per degree) and RD units (A per MW) per
must-study contingency, for preventive AND curative available remedial actions, with the
loading filter (Filter 1) and the magnitude pruning (Filter 2). _get_must_study_contingencies
and _register_contingencies come from nx_security_analysis, _get_monitored_branch_sides from
milp_builder.
"""

import csv
import logging
from pathlib import Path
from typing import Optional

from data_model import AEType, AssessedElement, Contingency, PST, RDUnit, select_by_side
from pre_milp.lf_parameters import build_loadflow_parameters, build_sensitivity_parameters
from milp.milp_builder import _get_monitored_branch_sides
from pre_milp.nx_security_analysis import _get_must_study_contingencies, _register_contingencies
from pre_milp.sensitivity_checks import find_invalid_nx_contingencies

log = logging.getLogger(__name__)


def _get_limit_and_ae_type_by_branch_nx(
    ae_flat_list: list[AssessedElement], timestamp: str, lf_initial: dict[str, dict[int, float]],
) -> tuple[dict[str, float], dict[str, "AEType"]]:
    """({branch_mrid: limit_ampere}, {branch_mrid: AEType}) from milp_builder's limit resolver
    (PATL for SECURED, effective limit for SCANNED); imported lazily to avoid a circular import."""
    from milp.milp_builder import _get_monitored_branch_limits_and_ae_types

    return _get_monitored_branch_limits_and_ae_types(ae_flat_list, timestamp, lf_initial)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _get_available_pst_ids_nx(pst_list: list[PST], network=None) -> list[str]:
    """Available PST (PowerTransformer) mRIDs, preventive and curative, de-duplicated: a
    transformer with a preventive and a curative remedial action is one sensitivity variable
    (the same ID twice makes pypowsybl return a duplicate matrix row).
    With `network`, PSTs on a 3-winding transformer are left out (logged): pypowsybl's
    TRANSFORMER_PHASE variable does not support them.
    """
    candidates = sorted({str(pst.mrid) for pst in pst_list if pst.available})

    if network is None:
        return candidates

    try:
        two_w_ids = set(network.get_2_windings_transformers().index)
    except Exception:
        log.exception("Failed to fetch 2-winding transformer IDs — skipping 3W-transformer PST filter")
        return candidates

    filtered = [pst_mrid for pst_mrid in candidates if pst_mrid in two_w_ids]
    excluded = [pst_mrid for pst_mrid in candidates if pst_mrid not in two_w_ids]
    if excluded:
        log.warning(
            "Excluding %d PST(s) backed by a 3-winding transformer from N-X AC "
            "sensitivity (unsupported by pypowsybl's TRANSFORMER_PHASE "
            "variable type for 3W transformers): %s",
            len(excluded), excluded,
        )
    return filtered


def _get_available_rd_gu_ids_nx(rd_list: list[RDUnit]) -> list[str]:
    """Sorted, de-duplicated generating-unit mRIDs of the available RD units, preventive and
    curative (the sensitivity variable is the unit, shared by its remedial actions)."""
    gu_mrids = {str(rd.gu_mrid) for rd in rd_list if rd.available}
    return sorted(gu_mrids)


def _run_nx_sensitivity_analysis(
    network,
    must_study_contingencies: list[Contingency],
    branch_sides: dict[str, int],
    variable_sets: list[tuple[str, list[str], object]],
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
):
    """One pypowsybl AC sensitivity analysis with, per variable set (prefix, variable ids,
    variable type), one factor matrix per side for ALL registered contingencies
    (ContingencyContextType.ALL; several contingency IDs with SPECIFIC raise
    ArrayIndexOutOfBoundsException), run once with the pipeline's load-flow parameters.
    Returns (result, {prefix: {contingency: {side: matrix_id}}}), a side only when it has
    monitored branches; get_sensitivity_matrix(matrix_id, contingency) reads one contingency.
    """
    import pypowsybl as pp

    side1_branch_ids = sorted(b for b, s in branch_sides.items() if s == 1)
    side2_branch_ids = sorted(b for b, s in branch_sides.items() if s == 2)

    sensitivity_analysis = pp.sensitivity.create_ac_analysis()
    _register_contingencies(sensitivity_analysis, must_study_contingencies)

    matrix_ids_by_prefix: dict[str, dict[str, dict[int, str]]] = {}
    for prefix, variable_ids, sensitivity_variable_type in variable_sets:
        side_matrix_ids: dict[int, str] = {}
        for side, branch_ids, function_type in (
            (1, side1_branch_ids, pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_1),
            (2, side2_branch_ids, pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_2),
        ):
            if not branch_ids:
                continue
            matrix_id = f"{prefix}_side{side}"
            sensitivity_analysis.add_factor_matrix(
                functions_ids=branch_ids,
                variables_ids=variable_ids,
                contingencies_ids=[],
                contingency_context_type=pp.sensitivity.ContingencyContextType.ALL,
                sensitivity_function_type=function_type,
                sensitivity_variable_type=sensitivity_variable_type,
                matrix_id=matrix_id,
            )
            side_matrix_ids[side] = matrix_id
        matrix_ids_by_prefix[prefix] = {
            contingency.mrid: dict(side_matrix_ids) for contingency in must_study_contingencies
        }

    result = sensitivity_analysis.run(
        network, parameters=build_sensitivity_parameters(use_reactive_limits, extra_lf_params),
    )
    return result, matrix_ids_by_prefix


def _compute_sensitivity_matrices_nx(
    network,
    must_study_contingencies: list[Contingency],
    branch_sides: dict[str, int],
    variable_ids: list[str],
    sensitivity_variable_type,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
):
    """_run_nx_sensitivity_analysis with one variable set (matrix ids nx_side1 / nx_side2):
    returns (result, {contingency: {side: matrix_id}})."""
    result, matrix_ids_by_prefix = _run_nx_sensitivity_analysis(
        network, must_study_contingencies, branch_sides,
        [("nx", variable_ids, sensitivity_variable_type)],
        use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params,
    )
    return result, matrix_ids_by_prefix["nx"]


def _matrix_entries(matrix, contingency_mrid: str, function_name: str, variable_label: str) -> dict[tuple[str, str], float]:
    """{(branch, variable): value} of one sensitivity matrix (index = variables, columns =
    branches), read with numpy in column-then-row order. A duplicated label uses its FIRST
    row/column (warning per cell, as pandas .loc would return several values); NaN stays NaN."""
    matrix_variable_ids = [str(v) for v in matrix.index]
    matrix_branch_ids = [str(b) for b in matrix.columns]
    values = matrix.to_numpy()
    row_of: dict[str, int] = {}
    for position, variable_id in enumerate(matrix_variable_ids):
        row_of.setdefault(variable_id, position)
    column_of: dict[str, int] = {}
    for position, branch_id in enumerate(matrix_branch_ids):
        column_of.setdefault(branch_id, position)
    row_count = {v: matrix_variable_ids.count(v) for v in row_of}
    column_count = {b: matrix_branch_ids.count(b) for b in column_of}
    entries: dict[tuple[str, str], float] = {}
    for branch_mrid in matrix_branch_ids:
        for variable_mrid in matrix_variable_ids:
            duplicates = row_count[variable_mrid] if row_count[variable_mrid] > 1 else column_count[branch_mrid]
            if duplicates > 1:
                log.warning(
                    "%s: matrix.loc[%s, %s] returned %d value(s) instead of one (contingency %s) — "
                    "matrix.index has a duplicate entry for this %s despite the input list having "
                    "none. Using the first value; root cause not yet confirmed.",
                    function_name, variable_mrid, branch_mrid, duplicates, contingency_mrid, variable_label,
                )
            entries[(branch_mrid, variable_mrid)] = float(values[row_of[variable_mrid], column_of[branch_mrid]])
    return entries


def _reference_currents_nx(result, matrix_ids_by_contingency) -> dict[str, dict[str, float]]:
    """{contingency_mrid: {branch_mrid: reference (post-contingency) current in A}} as seen by
    the sensitivity analysis itself: the value the sensitivities are linearised around. The
    guard compares it with the N-X load flow (lf_nx) of the same state. A (contingency, side)
    the analysis returned no reference for is simply absent."""
    references: dict[str, dict[str, float]] = {}
    for contingency_mrid, matrix_ids in matrix_ids_by_contingency.items():
        per_branch: dict[str, float] = {}
        for matrix_id in matrix_ids.values():
            try:
                reference_matrix = result.get_reference_matrix(matrix_id, contingency_mrid)
            except Exception:
                reference_matrix = None
            if reference_matrix is None:
                continue
            for branch_mrid in reference_matrix.columns:
                per_branch[str(branch_mrid)] = float(reference_matrix.iloc[0][branch_mrid])
        references[contingency_mrid] = per_branch
    return references


def _apply_loading_threshold_filter_nx(
    sensitivity_nx: dict[str, dict[tuple[str, str], float]],
    lf_nx: dict[str, dict[str, dict[int, float]]],
    branch_sides: dict[str, int],
    limit_by_branch: dict[str, float],
    min_loading_threshold_pct_nx: float,
) -> dict[str, dict[tuple[str, str], float]]:
    """Filter 1 (loading): drop every (branch, RA) entry of a (branch, contingency) pair whose
    lf_nx[c][b] / limit_by_branch[b] is below min_loading_threshold_pct_nx (PATL for secured,
    effective limit for scanned branches). Applied after the analysis, which computes every
    monitored branch. A pair without a limit or without an N-X current is dropped.
    """
    filtered: dict[str, dict[tuple[str, str], float]] = {}
    for contingency_mrid, per_branch_ra in sensitivity_nx.items():
        per_branch_currents = lf_nx.get(contingency_mrid, {})
        filtered_for_contingency: dict[tuple[str, str], float] = {}
        for (branch_mrid, ra_mrid), value in per_branch_ra.items():
            limit_ampere = limit_by_branch.get(branch_mrid)
            if not limit_ampere or limit_ampere <= 0.0:
                continue
            side = branch_sides.get(branch_mrid, 1)
            nx_current_ampere = select_by_side(
                per_branch_currents.get(branch_mrid, {}), side, branch_mrid,
            )
            if nx_current_ampere is None:
                continue
            loading_pct = (float(nx_current_ampere) / limit_ampere) * 100.0
            if loading_pct < float(min_loading_threshold_pct_nx):
                continue
            filtered_for_contingency[(branch_mrid, ra_mrid)] = value
        filtered[contingency_mrid] = filtered_for_contingency
    return filtered


def compute_sensitivity_pst_nx(
    network,
    co_flat_list: list[Contingency],
    pst_list: list[PST],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    reference_out: Optional[dict] = None,
    guard_out: Optional[dict] = None,
) -> dict[str, dict[tuple[str, str], float]]:
    """N-X PST sensitivities dI/ds per must-study contingency:
    {contingency: {(branch, pst): A per degree}} (the A/tap conversion happens in the builder).
    Variables: preventive and curative available PSTs. Runs with the parameters of compute_lf_nx.
    reference_out: filled with {contingency: {branch: reference current A}}; guard_out: filled with
    {contingency: reason} for the guard failures (before Filter 1). Filter 1 is applied here.
    """
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")

    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")

    pst_ids = _get_available_pst_ids_nx(pst_list, network=network)
    if not pst_ids:
        raise ValueError("No available PSTs found in PSTList")

    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    result, matrix_ids_by_contingency = _compute_sensitivity_matrices_nx(
        network, must_study_contingencies, branch_sides,
        pst_ids, pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE,
        use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params,
    )
    return _pst_nx_from_result(
        network, result, matrix_ids_by_contingency, must_study_contingencies, branch_sides, pst_ids,
        ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, output_path,
        reference_out, guard_out,
    )


def _pst_nx_from_result(
    network, result, matrix_ids_by_contingency, must_study_contingencies, branch_sides, pst_ids,
    ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, output_path,
    reference_out, guard_out,
) -> dict[str, dict[tuple[str, str], float]]:
    """Read-back, guard, Filter 1, log and CSV of the PST N-X sensitivities of one analysis."""
    _references_nx = _reference_currents_nx(result, matrix_ids_by_contingency)
    if reference_out is not None:
        reference_out.clear()
        reference_out.update(_references_nx)

    sensitivity_pst_nx: dict[str, dict[tuple[str, str], float]] = {}
    for contingency in must_study_contingencies:
        per_contingency: dict[tuple[str, str], float] = {}
        for side, matrix_id in matrix_ids_by_contingency[contingency.mrid].items():
            matrix = result.get_sensitivity_matrix(matrix_id, contingency.mrid)
            if matrix is None:
                log.warning(
                    "compute_sensitivity_pst_nx: no matrix for contingency %s side %d",
                    contingency.mrid, side,
                )
                continue
            # pypowsybl's matrix can hold a duplicate row for one PST (cause unknown): the first
            # value is used and a warning is logged
            per_contingency.update(_matrix_entries(matrix, contingency.mrid, "compute_sensitivity_pst_nx", "PST"))
        sensitivity_pst_nx[contingency.mrid] = per_contingency

    if guard_out is not None:
        guard_out.clear()
        guard_out.update(find_invalid_nx_contingencies(
            _references_nx,
            {co for co, values in sensitivity_pst_nx.items() if values and all(v == 0.0 for v in values.values())},
            lf_nx, branch_sides,
        ))

    limit_by_branch, branch_ae_types = _get_limit_and_ae_type_by_branch_nx(
        ae_flat_list, timestamp, lf_initial,
    )
    sensitivity_pst_nx = _apply_loading_threshold_filter_nx(
        sensitivity_pst_nx, lf_nx, branch_sides, limit_by_branch, min_loading_threshold_pct_nx,
    )

    secured_branch_count = sum(1 for t in branch_ae_types.values() if t == AEType.SECURED)
    scanned_branch_count = sum(1 for t in branch_ae_types.values() if t == AEType.SCANNED)
    log.info(
        "compute_sensitivity_pst_nx: computed for %d must-study contingencies, "
        "%d PST(s), %d monitored branch(es) [%d secured, %d scanned] "
        "(post Filter 1: %d total (branch, pst) pairs)",
        len(sensitivity_pst_nx), len(pst_ids), len(branch_sides),
        secured_branch_count, scanned_branch_count,
        sum(len(v) for v in sensitivity_pst_nx.values()),
    )

    if output_path is not None:
        from pre_milp import cgmes_loader
        branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)
        write_sensitivity_nx_csv(
            sensitivity_pst_nx, branch_sides, branch_mrid_to_name, output_path, timestamp,
            branch_ae_types=branch_ae_types,
        )

    return sensitivity_pst_nx


def compute_sensitivity_rd_nx(
    network,
    co_flat_list: list[Contingency],
    rd_list: list[RDUnit],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    reference_out: Optional[dict] = None,
    guard_out: Optional[dict] = None,
) -> dict[str, dict[tuple[str, str], float]]:
    """N-X RD sensitivities dI/dP per must-study contingency:
    {contingency: {(branch, unit): A per MW}}, for preventive and curative available units.
    Filter 1 is applied here, as in compute_sensitivity_pst_nx."""
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")

    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")

    gu_ids = _get_available_rd_gu_ids_nx(rd_list)
    if not gu_ids:
        raise ValueError("No available RD units found in RDList")

    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    result, matrix_ids_by_contingency = _compute_sensitivity_matrices_nx(
        network, must_study_contingencies, branch_sides,
        gu_ids, pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER,
        use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params,
    )
    return _rd_nx_from_result(
        network, result, matrix_ids_by_contingency, must_study_contingencies, branch_sides, gu_ids,
        ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, output_path,
        reference_out, guard_out,
    )


def _rd_nx_from_result(
    network, result, matrix_ids_by_contingency, must_study_contingencies, branch_sides, gu_ids,
    ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, output_path,
    reference_out, guard_out,
) -> dict[str, dict[tuple[str, str], float]]:
    """Read-back, guard, Filter 1, log and CSV of the RD N-X sensitivities of one analysis."""
    _references_nx = _reference_currents_nx(result, matrix_ids_by_contingency)
    if reference_out is not None:
        reference_out.clear()
        reference_out.update(_references_nx)

    sensitivity_rd_nx: dict[str, dict[tuple[str, str], float]] = {}
    for contingency in must_study_contingencies:
        per_contingency: dict[tuple[str, str], float] = {}
        for side, matrix_id in matrix_ids_by_contingency[contingency.mrid].items():
            matrix = result.get_sensitivity_matrix(matrix_id, contingency.mrid)
            if matrix is None:
                log.warning(
                    "compute_sensitivity_rd_nx: no matrix for contingency %s side %d",
                    contingency.mrid, side,
                )
                continue
            # duplicate matrix row: the first value is used (see compute_sensitivity_pst_nx)
            per_contingency.update(
                _matrix_entries(matrix, contingency.mrid, "compute_sensitivity_rd_nx", "generating unit")
            )
        sensitivity_rd_nx[contingency.mrid] = per_contingency

    if guard_out is not None:
        guard_out.clear()
        guard_out.update(find_invalid_nx_contingencies(
            _references_nx,
            {co for co, values in sensitivity_rd_nx.items() if values and all(v == 0.0 for v in values.values())},
            lf_nx, branch_sides,
        ))

    limit_by_branch, branch_ae_types = _get_limit_and_ae_type_by_branch_nx(
        ae_flat_list, timestamp, lf_initial,
    )
    sensitivity_rd_nx = _apply_loading_threshold_filter_nx(
        sensitivity_rd_nx, lf_nx, branch_sides, limit_by_branch, min_loading_threshold_pct_nx,
    )

    secured_branch_count = sum(1 for t in branch_ae_types.values() if t == AEType.SECURED)
    scanned_branch_count = sum(1 for t in branch_ae_types.values() if t == AEType.SCANNED)
    log.info(
        "compute_sensitivity_rd_nx: computed for %d must-study contingencies, "
        "%d generating unit(s), %d monitored branch(es) [%d secured, %d scanned] "
        "(post Filter 1: %d total (branch, gu) pairs)",
        len(sensitivity_rd_nx), len(gu_ids), len(branch_sides),
        secured_branch_count, scanned_branch_count,
        sum(len(v) for v in sensitivity_rd_nx.values()),
    )

    if output_path is not None:
        from pre_milp import cgmes_loader
        branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)
        branch_tso = {str(ae.branch_mrid): ae.tso for ae in ae_flat_list if ae.branch_mrid}
        write_sensitivity_rd_nx_csv(
            sensitivity_rd_nx, branch_sides, output_path, timestamp,
            branch_mrid_to_name=branch_mrid_to_name,
            branch_tso=branch_tso,
            branch_ae_types=branch_ae_types,
        )

    return sensitivity_rd_nx

def compute_sensitivities_nx(
    network,
    co_flat_list: list[Contingency],
    pst_list: list[PST],
    rd_list: list[RDUnit],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    lf_initial: dict[str, dict[int, float]],
    min_loading_threshold_pct_nx: float = 0.0,
    with_pst: bool = True,
    with_rd: bool = True,
    pst_output_path: Optional[Path] = None,
    rd_output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: Optional[dict] = None,
    pst_guard_out: Optional[dict] = None,
    rd_guard_out: Optional[dict] = None,
    pst_reference_out: Optional[dict] = None,
    rd_reference_out: Optional[dict] = None,
) -> tuple[dict, dict]:
    """compute_sensitivity_pst_nx (when with_pst) and compute_sensitivity_rd_nx (when with_rd)
    from ONE sensitivity analysis with both variable sets (same values as two analyses):
    returns (sensitivity_pst_nx, sensitivity_rd_nx), {} for a kind that is not requested."""
    if not with_pst and not with_rd:
        return {}, {}
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")
    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")
    pst_ids = _get_available_pst_ids_nx(pst_list, network=network) if with_pst else []
    if with_pst and not pst_ids:
        raise ValueError("No available PSTs found in PSTList")
    gu_ids = _get_available_rd_gu_ids_nx(rd_list) if with_rd else []
    if with_rd and not gu_ids:
        raise ValueError("No available RD units found in RDList")
    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute sensitivities") from exc

    variable_sets = []
    if with_pst:
        variable_sets.append(("nx_pst", pst_ids, pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE))
    if with_rd:
        variable_sets.append(("nx_rd", gu_ids, pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER))
    result, matrix_ids_by_prefix = _run_nx_sensitivity_analysis(
        network, must_study_contingencies, branch_sides, variable_sets,
        use_reactive_limits=use_reactive_limits, extra_lf_params=extra_lf_params,
    )
    sensitivity_pst_nx = _pst_nx_from_result(
        network, result, matrix_ids_by_prefix["nx_pst"], must_study_contingencies, branch_sides, pst_ids,
        ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, pst_output_path,
        pst_reference_out, pst_guard_out,
    ) if with_pst else {}
    sensitivity_rd_nx = _rd_nx_from_result(
        network, result, matrix_ids_by_prefix["nx_rd"], must_study_contingencies, branch_sides, gu_ids,
        ae_flat_list, timestamp, lf_nx, lf_initial, min_loading_threshold_pct_nx, rd_output_path,
        rd_reference_out, rd_guard_out,
    ) if with_rd else {}
    return sensitivity_pst_nx, sensitivity_rd_nx


# ---------------------------------------------------------------------------
# Filter 2 (sensitivity magnitude pruning)
# ---------------------------------------------------------------------------


def prune_sensitivity_pst_nx(
    sensitivity_pst_nx: dict[str, dict[tuple[str, str], float]],
    limit_by_branch: dict[str, float],
    sensitivity_threshold_pct_pst_nx: float = 0.0,
) -> dict[str, dict[tuple[str, str], float]]:
    """Filter 2 for PSTs: drop a (branch, contingency, pst) entry if |value| <
    sensitivity_threshold_pct_pst_nx * limit_by_branch[branch] / 100. The branch is never
    dropped (it keeps a slack-only constraint) and every contingency key stays, possibly empty.
    0.0 is a no-op."""
    pruned: dict[str, dict[tuple[str, str], float]] = {}
    for contingency_mrid, per_branch_ra in sensitivity_pst_nx.items():
        pruned_for_contingency: dict[tuple[str, str], float] = {}
        for (branch_mrid, pst_mrid), value in per_branch_ra.items():
            limit_ampere = limit_by_branch.get(branch_mrid)
            if not limit_ampere or limit_ampere <= 0.0:
                continue
            threshold_ampere = float(sensitivity_threshold_pct_pst_nx) * limit_ampere / 100.0
            if abs(value) < threshold_ampere:
                continue
            pruned_for_contingency[(branch_mrid, pst_mrid)] = value
        pruned[contingency_mrid] = pruned_for_contingency
    return pruned


def prune_sensitivity_rd_nx(
    sensitivity_rd_nx: dict[str, dict[tuple[str, str], float]],
    limit_by_branch: dict[str, float],
    sensitivity_threshold_pct_rd_nx: float = 0.0,
) -> dict[str, dict[tuple[str, str], float]]:
    """Filter 2 for RD: as prune_sensitivity_pst_nx, with sensitivity_threshold_pct_rd_nx."""
    pruned: dict[str, dict[tuple[str, str], float]] = {}
    for contingency_mrid, per_branch_ra in sensitivity_rd_nx.items():
        pruned_for_contingency: dict[tuple[str, str], float] = {}
        for (branch_mrid, gu_mrid), value in per_branch_ra.items():
            limit_ampere = limit_by_branch.get(branch_mrid)
            if not limit_ampere or limit_ampere <= 0.0:
                continue
            threshold_ampere = float(sensitivity_threshold_pct_rd_nx) * limit_ampere / 100.0
            if abs(value) < threshold_ampere:
                continue
            pruned_for_contingency[(branch_mrid, gu_mrid)] = value
        pruned[contingency_mrid] = pruned_for_contingency
    return pruned


# ---------------------------------------------------------------------------
# TATL for N-X, and CSV export
# ---------------------------------------------------------------------------

TATL_DURATION_SECONDS_WHEN_SYNTHESIZED_FROM_PATL = 600
"""Duration (s) of a TATL set to the PATL because the CGM has no TATL for that branch/side.
A finite value keeps compute_pst_cra_availability's
(tatl_duration_seconds/60 - reaction_time_minutes) / time_per_stage_minutes bounded."""


def write_sensitivity_nx_csv(
    sensitivity_pst_nx: dict[str, dict[tuple[str, str], float]],
    branch_sides: dict[str, int],
    branch_mrid_to_name: dict[str, str],
    output_path: Path,
    timestamp: str,
    branch_ae_types: Optional[dict[str, "AEType"]] = None,
) -> None:
    """sensitivity_pst_nx.csv — one row per (contingency, branch, PST); the value column
    di_ds_ampere_per_degree holds A per degree. ae_type is blank without branch_ae_types."""
    branch_ae_types = branch_ae_types or {}
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "timestamp", "contingency_mrid", "branch_mrid", "branch_name",
            "ae_type", "pst_mrid", "side", "di_ds_ampere_per_degree",
        ])
        for contingency_mrid in sorted(sensitivity_pst_nx):
            for (branch_mrid, pst_mrid), sensitivity in sorted(sensitivity_pst_nx[contingency_mrid].items()):
                side = branch_sides.get(branch_mrid, 1)
                branch_name = branch_mrid_to_name.get(branch_mrid, branch_mrid)
                ae_type = branch_ae_types.get(branch_mrid)
                ae_type_str = ae_type.value if ae_type is not None else ""
                writer.writerow([
                    timestamp, contingency_mrid, branch_mrid, branch_name,
                    ae_type_str, pst_mrid, side, sensitivity,
                ])

    log.info("Written N-X PST sensitivity CSV: %s", output_path)


def write_sensitivity_rd_nx_csv(
    sensitivity_rd_nx: dict[str, dict[tuple[str, str], float]],
    branch_sides: dict[str, int],
    output_path: Path,
    timestamp: str,
    branch_mrid_to_name: Optional[dict[str, str]] = None,
    branch_tso: Optional[dict[str, str]] = None,
    branch_ae_types: Optional[dict[str, "AEType"]] = None,
) -> None:
    """sensitivity_rd_nx.csv — one row per (contingency, branch, generating unit), value column
    di_dp_ampere_per_mw; branch_name, tso and ae_type are blank when their maps are not given."""
    branch_mrid_to_name = branch_mrid_to_name or {}
    branch_tso = branch_tso or {}
    branch_ae_types = branch_ae_types or {}

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "timestamp", "contingency_mrid", "branch_mrid", "branch_name",
            "ae_type", "gu_mrid", "tso", "side", "di_dp_ampere_per_mw",
        ])
        for contingency_mrid in sorted(sensitivity_rd_nx):
            for (branch_mrid, gu_mrid), sensitivity in sorted(sensitivity_rd_nx[contingency_mrid].items()):
                side = branch_sides.get(branch_mrid, 1)
                branch_name = branch_mrid_to_name.get(branch_mrid, branch_mrid)
                tso = branch_tso.get(branch_mrid, "")
                ae_type = branch_ae_types.get(branch_mrid)
                ae_type_str = ae_type.value if ae_type is not None else ""
                writer.writerow([
                    timestamp, contingency_mrid, branch_mrid, branch_name,
                    ae_type_str, gu_mrid, tso, side, sensitivity,
                ])

    log.info("Written N-X RD sensitivity CSV: %s", output_path)


