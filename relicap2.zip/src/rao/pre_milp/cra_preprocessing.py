"""cra_preprocessing.py

Curative PST availability (does a curative PST have time to act within a TATL window, from
its reaction time and time per stage) and the curative PST group rules. Reads the tatl_data
that nx_security_analysis.compute_tatl_data returns. Preventive availability needs no
computation (normalAvailable and kind PREVENTIVE).
"""

import csv
import logging
import math
from collections import defaultdict
from itertools import combinations
from pathlib import Path
from typing import Optional

from data_model import PST

log = logging.getLogger(__name__)


def compute_pst_cra_availability(
    pst_list: list[PST],
    tatl_data: dict[str, dict],
    output_path: Optional[Path] = None,
    contingencies: Optional[list] = None,
) -> dict[tuple[str, str, str], dict]:
    """For every available curative PST linked to a contingency and every SECURED branch with
    a TATL: max_curative_taps = floor((tatl_duration_seconds / 60 - reaction_time_minutes)
    / time_per_stage_minutes); available = max_curative_taps > 0.
    Returns {(pst_mrid, xne_mrid, co_mrid): {"max_curative_taps", "available"}}. A PST without
    timing data is skipped (one warning), never defaulted. With `contingencies`, a PST that is
    an outage element of contingency c gets no entry for c. linked_xne_mrids is not used here.
    """
    from data_model import RAKind

    curative_psts = [pst for pst in pst_list if pst.available and pst.kind == RAKind.CURATIVE]
    if not curative_psts:
        log.warning(
            "compute_pst_cra_availability: no available curative PSTs in PSTList — "
            "returning empty result (not an error; e.g. ENABLE_PST_REMEDIAL_ACTIONS "
            "may be False, or none are marked available)."
        )
        return {}

    pst_cra_availability: dict[tuple[str, str, str], dict] = {}

    tripped_by_contingency: dict[str, set[str]] = {
        str(co.mrid): {str(m) for m in co.equipment_mrids} for co in (contingencies or [])
    }

    for pst in curative_psts:
        if not pst.linked_contingency_mrids:
            log.info(
                "compute_pst_cra_availability: curative PST %s has no "
                "linked_contingency_mrids (ContingencyWithRemedialAction) — "
                "contributes no CRA availability at all",
                pst.mrid,
            )
            continue

        if pst.reaction_time_minutes is None or pst.time_per_stage_minutes is None:
            log.warning(
                "compute_pst_cra_availability: curative PST %s missing "
                "reaction_time_minutes and/or time_per_stage_minutes — "
                "skipped entirely (genuine dataset boundary condition, see "
                "parse_psts' own docstring; not guessed or defaulted)",
                pst.mrid,
            )
            continue

        for xne_mrid in sorted(tatl_data):
            tatl_duration_seconds = tatl_data[xne_mrid]["tatl_duration_seconds"]
            max_curative_taps = math.floor(
                (tatl_duration_seconds / 60.0 - pst.reaction_time_minutes) / pst.time_per_stage_minutes
            )
            available = max_curative_taps > 0

            for co_mrid in pst.linked_contingency_mrids:
                if str(pst.mrid) in tripped_by_contingency.get(str(co_mrid), ()):
                    continue  # the PST is an outage element of this contingency
                pst_cra_availability[(pst.mrid, xne_mrid, co_mrid)] = {
                    "max_curative_taps": max_curative_taps,
                    "available": available,
                }

    if tripped_by_contingency:
        for pst in curative_psts:
            outage_cos = sorted(
                str(co) for co in pst.linked_contingency_mrids
                if str(pst.mrid) in tripped_by_contingency.get(str(co), ())
            )
            if outage_cos:
                log.info(
                    "compute_pst_cra_availability: curative PST %s is itself an outage "
                    "element of contingency(ies) %s — not available as a curative RA there",
                    pst.mrid, outage_cos,
                )

    available_count = sum(1 for entry in pst_cra_availability.values() if entry["available"])
    log.info(
        "compute_pst_cra_availability: %d (pst, xne, contingency) entries computed, "
        "%d available",
        len(pst_cra_availability), available_count,
    )

    if output_path is not None:
        write_pst_cra_availability_csv(pst_cra_availability, output_path)

    return pst_cra_availability


def write_pst_cra_availability_csv(
    pst_cra_availability: dict[tuple[str, str, str], dict],
    output_path: Path,
) -> None:
    """pst_cra_availability.csv — columns: [pst_mrid, branch_mrid,
    contingency_mrid, max_curative_taps, available]. The third column is
    named contingency_mrid (one contingency key name in every output file)."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["pst_mrid", "branch_mrid", "contingency_mrid", "max_curative_taps", "available"])
        for (pst_mrid, xne_mrid, co_mrid), entry in sorted(pst_cra_availability.items()):
            writer.writerow([
                pst_mrid, xne_mrid, co_mrid, entry["max_curative_taps"], entry["available"],
            ])

    log.info("Written PST CRA availability CSV: %s", output_path)


# ---------------------------------------------------------------------------
# Curative PST groups: curative PSTs sharing one group_id (one remedial action with several
# TapPositionActions). Per (group, contingency c):
#   * only members with an available curative entry for c are considered;
#   * a member that is an outage element of c: reducedGroup -> the other members stay a
#     group, blockedGroup -> the whole group is unavailable in c;
#   * no common rectified delta tap (up/down headroom from the current tap, limited by the
#     TATL tap cap) -> the group is excluded for c (warning);
#   * otherwise each pair gets (up_1 - down_1) == (up_2 - down_2).
# The group kind is not in the data: config curative_ra.pst_group_kind_default (blockedGroup)
# and the per-TSO map curative_ra.pst_group_kind_per_tso.
# ---------------------------------------------------------------------------

REDUCED_GROUP = "reducedGroup"
BLOCKED_GROUP = "blockedGroup"
VALID_PST_GROUP_KINDS = (REDUCED_GROUP, BLOCKED_GROUP)


def validate_pst_group_kind(value: str) -> str:
    if value not in VALID_PST_GROUP_KINDS:
        raise ValueError(
            f"pst_group_kind_default must be one of {VALID_PST_GROUP_KINDS}, got {value!r}"
        )
    return value


def build_curative_pst_group_constraints(
    curative_pst_list: list[PST],
    pst_cra_availability: dict[tuple[str, str, str], dict],
    pst_tap_bounds_curative: dict[str, tuple[int, int]],
    contingencies: Optional[list],
    pst_group_kind_default: str,
    pst_group_kind_per_tso: Optional[dict[str, str]] = None,
) -> tuple[dict[tuple[str, str, str], dict], list[tuple[str, str, str]]]:
    """Returns (filtered pst_cra_availability, sorted (pst_1, pst_2, contingency) triples).
    The availability is a copy without the entries of excluded or blocked groups; without
    groups it equals the input."""
    validate_pst_group_kind(pst_group_kind_default)
    kind_overrides = {
        str(tso): validate_pst_group_kind(kind) for tso, kind in (pst_group_kind_per_tso or {}).items()
    }
    filtered = dict(pst_cra_availability)

    members_by_group: dict[str, dict[str, PST]] = defaultdict(dict)
    for pst in curative_pst_list:
        if pst.group_id and pst.available:
            members_by_group[str(pst.group_id)][str(pst.mrid)] = pst

    tripped_by_contingency = {
        str(co.mrid): {str(m) for m in co.equipment_mrids} for co in (contingencies or [])
    }

    triples: list[tuple[str, str, str]] = []

    for group_id, members in sorted(members_by_group.items()):
        if len(members) < 2:
            continue
        # the group's TSO (one remedial action, one TSO) picks the per-TSO kind, else the default
        group_tsos = {str(pst.tso) for pst in members.values()}
        if len(group_tsos) > 1:
            log.warning("Curative PST group %s has members of several TSOs %s — default kind used",
                        group_id, sorted(group_tsos))
            group_kind = pst_group_kind_default
        else:
            group_kind = kind_overrides.get(next(iter(group_tsos)), pst_group_kind_default)

        contingency_mrids = sorted({
            str(co) for pst in members.values() for co in pst.linked_contingency_mrids
        } | {co for (m, _x, co) in filtered if m in members})

        for co_mrid in contingency_mrids:
            tripped = sorted(m for m in members if m in tripped_by_contingency.get(co_mrid, ()))
            if tripped and group_kind == BLOCKED_GROUP:
                for key in [k for k in filtered if k[0] in members and k[2] == co_mrid]:
                    del filtered[key]
                log.warning(
                    "Curative PST group %s: member(s) %s are outage element(s) of contingency %s "
                    "and the group kind is blockedGroup — the whole group is unavailable as "
                    "curative RA for that contingency",
                    group_id, tripped, co_mrid,
                )
                continue
            if tripped:
                log.info(
                    "Curative PST group %s: member(s) %s are outage element(s) of contingency %s "
                    "(reducedGroup) — the remaining available members still operate as a group",
                    group_id, tripped, co_mrid,
                )

            # tap cap per member in c: the shared variable pair must satisfy every
            # available (xne) magnitude row, so the binding cap is the minimum
            caps: dict[str, int] = {}
            for (m, _x, co), entry in filtered.items():
                if co == co_mrid and m in members and entry.get("available"):
                    cap = int(entry["max_curative_taps"])
                    caps[m] = min(cap, caps[m]) if m in caps else cap
            considered = sorted(m for m in caps if m not in tripped)
            if len(considered) < 2:
                continue

            low, high = [], []
            for m in considered:
                pst = members[m]
                bounds = pst_tap_bounds_curative.get(m, (pst.operating_tap_min, pst.operating_tap_max))
                current = int(getattr(pst, "r0", 0))
                low.append(max(int(bounds[0]) - current, -caps[m]))
                high.append(min(int(bounds[1]) - current, caps[m]))
            if max(low) > min(high):
                for key in [k for k in filtered if k[0] in considered and k[2] == co_mrid]:
                    del filtered[key]
                log.warning(
                    "Curative PST group %s, contingency %s: no common rectified delta tap "
                    "(per-member delta ranges %s) — the whole group is excluded for this "
                    "contingency",
                    group_id, co_mrid,
                    {m: (lo, hi) for m, lo, hi in zip(considered, low, high)},
                )
                continue

            triples.extend((a, b, co_mrid) for a, b in combinations(considered, 2))

    return filtered, sorted(triples)
