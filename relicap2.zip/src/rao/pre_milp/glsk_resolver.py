"""glsk_resolver.py — GLSK (generation shift key) per RD remedial action.

The NC profile has no GLSKSchedule class; the chain from an RD remedial action to its
participation factors is:
  RD RA <- PowerBidSchedule.PowerRemedialAction
  PowerBidSchedule <- PowerShiftKeyDistribution.PowerBidSchedule
  PowerShiftKeyDistribution -> PowerShiftKeyDistribution.PowerShiftKeySchedule
  PowerShiftKeySchedule -> GeneratingUnit; <- ParticipationFactorTimePoint (factor per timestamp)
Distributions linked to a PowerShiftKeyStrategy instead of a bid schedule have no remedial
action and are not used. An RA without a resolvable chain gets an empty dict (logged).
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Optional

from rdflib import Namespace, RDF

from data_model import RDUnit
from pre_milp.ncp_parser import _frag, _iso_to_hhmmz, _load_graph

log = logging.getLogger(__name__)

# Namespaces — same values as ncp_parser.py's CIM/NC. The graph helpers
# _frag, _load_graph and _iso_to_hhmmz are imported from ncp_parser.
CIM = Namespace("https://cim.ucaiug.io/ns#")
NC = Namespace("https://cim4.eu/ns/nc#")


def _get_available_rd_ra_mrids(rd_list: list[RDUnit]) -> list[str]:
    """Sorted, de-duplicated mRIDs (RDUnit.mrid) of the available RD remedial actions,
    preventive and curative (curative RD needs the GLSK of its units too)."""
    return sorted({
        str(rd.mrid)
        for rd in rd_list
        if rd.available
    })


def resolve_glsk(
    sis_path: Optional[Path],
    rd_list: list[RDUnit],
    tso: str,
    valid_generator_mrids: set[str],
    timestamp: str,
    output_path: Optional[Path] = None,
) -> dict[str, dict[str, float]]:
    """Participation factors per RD remedial action of one TSO's SIS file.

    rd_list: this TSO's RDUnits. valid_generator_mrids: the generators of the network; a unit
    not in it is removed and the factors are redistributed proportionally. timestamp: HHMMZ.
    Returns {ra_mrid: {gu_mrid: factor}} with every available RA as a key, an empty dict when
    nothing resolves (so "no participation" differs from "not considered").
    """
    available_ra_mrids = _get_available_rd_ra_mrids(rd_list)
    glsk: dict[str, dict[str, float]] = {ra_mrid: {} for ra_mrid in available_ra_mrids}

    if not available_ra_mrids:
        log.info("%s: no available RD RAs — resolve_glsk skipped", tso)
        return glsk

    if sis_path is None:
        log.info(
            "%s: no SIS file — GLSK cannot be resolved for %d RD RA(s): %s",
            tso, len(available_ra_mrids), available_ra_mrids,
        )
        return glsk

    sis_graph = _load_graph(sis_path)

    # --- Step 1: PowerBidSchedule mRID -> RA mRID (only for our available RAs) ---
    pbs_to_ra: dict[str, str] = {}
    for pbs_uri in sis_graph.subjects(RDF.type, NC.PowerBidSchedule):
        pbs_mrid_lit = sis_graph.value(pbs_uri, CIM["IdentifiedObject.mRID"])
        pbs_mrid = str(pbs_mrid_lit) if pbs_mrid_lit is not None else _frag(str(pbs_uri))

        ra_uri = sis_graph.value(pbs_uri, NC["PowerBidSchedule.PowerRemedialAction"])
        if ra_uri is None:
            continue
        ra_mrid = _frag(str(ra_uri))
        if ra_mrid in available_ra_mrids:
            pbs_to_ra[pbs_mrid] = ra_mrid

    # --- Step 2: PowerShiftKeyDistribution -> (PowerBidSchedule mRIDs, PowerShiftKeySchedule mRIDs) ---
    # .objects(), not .value(): RDF allows several triples with the same subject and predicate
    distribution_to_pbs: dict[str, set[str]] = {}
    distribution_to_psks: dict[str, set[str]] = {}
    for distribution_uri in sis_graph.subjects(RDF.type, NC.PowerShiftKeyDistribution):
        distribution_mrid_lit = sis_graph.value(distribution_uri, CIM["IdentifiedObject.mRID"])
        distribution_mrid = (
            str(distribution_mrid_lit) if distribution_mrid_lit is not None
            else _frag(str(distribution_uri))
        )

        pbs_mrids = {
            _frag(str(o)) for o in sis_graph.objects(distribution_uri, NC["PowerShiftKeyDistribution.PowerBidSchedule"])
        }
        psks_mrids = {
            _frag(str(o)) for o in sis_graph.objects(distribution_uri, NC["PowerShiftKeyDistribution.PowerShiftKeySchedule"])
        }
        if pbs_mrids:
            distribution_to_pbs[distribution_mrid] = pbs_mrids
        if psks_mrids:
            distribution_to_psks[distribution_mrid] = psks_mrids

    # --- Step 3: RA mRID -> set of PowerShiftKeySchedule mRIDs ---
    ra_to_psks: dict[str, set[str]] = {ra_mrid: set() for ra_mrid in available_ra_mrids}
    for distribution_mrid, pbs_mrids in distribution_to_pbs.items():
        psks_mrids = distribution_to_psks.get(distribution_mrid, set())
        if not psks_mrids:
            continue
        for pbs_mrid in pbs_mrids:
            ra_mrid = pbs_to_ra.get(pbs_mrid)
            if ra_mrid is not None:
                ra_to_psks[ra_mrid].update(psks_mrids)

    # --- Step 4: PowerShiftKeySchedule mRID -> GeneratingUnit mRID(s) ---
    psks_to_gu: dict[str, set[str]] = {}
    for psks_uri in sis_graph.subjects(RDF.type, NC.PowerShiftKeySchedule):
        psks_mrid_lit = sis_graph.value(psks_uri, CIM["IdentifiedObject.mRID"])
        psks_mrid = str(psks_mrid_lit) if psks_mrid_lit is not None else _frag(str(psks_uri))
        gu_mrids = {
            _frag(str(o)) for o in sis_graph.objects(psks_uri, NC["PowerShiftKeySchedule.GeneratingUnit"])
        }
        if gu_mrids:
            psks_to_gu[psks_mrid] = gu_mrids
            if len(gu_mrids) > 1:
                log.warning(
                    "%s: PowerShiftKeySchedule %s has %d GeneratingUnits — "
                    "the single participationFactor for this schedule will be "
                    "applied to all of them (not independently observed in "
                    "real data; this is an assumption for the multi-GU case)",
                    tso, psks_mrid, len(gu_mrids),
                )

    # --- Step 5: PowerShiftKeySchedule mRID -> participationFactor at this timestamp ---
    psks_to_participation_factor: dict[str, float] = {}
    for timepoint_uri in sis_graph.subjects(RDF.type, NC.ParticipationFactorTimePoint):
        psks_uri = timepoint_uri
        psks_ref = sis_graph.value(timepoint_uri, NC["ParticipationFactorTimePoint.PowerShiftKeySchedule"])
        at_time = sis_graph.value(timepoint_uri, NC["ParticipationFactorTimePoint.atTime"])
        factor_lit = sis_graph.value(timepoint_uri, NC["ParticipationFactorTimePoint.participationFactor"])

        if psks_ref is None or at_time is None or factor_lit is None:
            continue

        resolved_timestamp = _iso_to_hhmmz(str(at_time))
        if resolved_timestamp != timestamp:
            continue

        psks_mrid = _frag(str(psks_ref))
        try:
            psks_to_participation_factor[psks_mrid] = float(str(factor_lit))
        except (TypeError, ValueError):
            log.warning(
                "%s: ParticipationFactorTimePoint for PowerShiftKeySchedule %s "
                "has a non-numeric participationFactor %r — skipped",
                tso, psks_mrid, factor_lit,
            )

    # --- Step 6: assemble raw (pre-normalisation) participation factors per RA ---
    raw_participation_by_ra: dict[str, dict[str, float]] = {ra_mrid: {} for ra_mrid in available_ra_mrids}
    for ra_mrid, psks_mrids in ra_to_psks.items():
        for psks_mrid in psks_mrids:
            gu_mrids = psks_to_gu.get(psks_mrid)
            participation_factor = psks_to_participation_factor.get(psks_mrid)
            if not gu_mrids or participation_factor is None:
                continue
            for gu_mrid in gu_mrids:
                raw_participation_by_ra[ra_mrid][gu_mrid] = (
                    raw_participation_by_ra[ra_mrid].get(gu_mrid, 0.0) + participation_factor
                )

    # --- Step 7: normalise — drop GUs absent from the network, redistribute proportionally ---
    for ra_mrid, raw_participation in raw_participation_by_ra.items():
        if not raw_participation:
            log.warning(
                "%s: RD RA %s — no PowerShiftKeySchedule/participationFactor "
                "resolved for timestamp %s (0 generating units) — GLSK is empty "
                "for this RA (confirmed dataset boundary condition on Jotunheim "
                "for the real Belgovia RD RA; a genuine parsing gap on other "
                "dataset cuts would look identical, so check the RA<->SIS "
                "linkage directly if this is unexpected)",
                tso, ra_mrid, timestamp,
            )
            glsk[ra_mrid] = {}
            continue

        valid_participation = {
            gu_mrid: factor
            for gu_mrid, factor in raw_participation.items()
            if gu_mrid in valid_generator_mrids
        }
        removed_gu_mrids = set(raw_participation) - set(valid_participation)
        if removed_gu_mrids:
            log.warning(
                "%s: RD RA %s — %d generating unit(s) not found in "
                "network.get_generators().index, removed and redistributed: %s",
                tso, ra_mrid, len(removed_gu_mrids), sorted(removed_gu_mrids),
            )

        total_valid_factor = sum(valid_participation.values())
        if total_valid_factor <= 0.0:
            if valid_participation:
                log.warning(
                    "%s: RD RA %s — remaining generating unit(s) after removal "
                    "have zero total participation factor (%s) — cannot "
                    "redistribute proportionally, GLSK is empty for this RA",
                    tso, ra_mrid, sorted(valid_participation.keys()),
                )
            glsk[ra_mrid] = {}
            continue

        glsk[ra_mrid] = {
            gu_mrid: factor / total_valid_factor
            for gu_mrid, factor in valid_participation.items()
        }

    if output_path is not None:
        write_glsk_csv(glsk, output_path, timestamp, tso_by_ra_mrid={ra: tso for ra in glsk})

    total_ra_with_data = sum(1 for factors in glsk.values() if factors)
    log.info(
        "%s: resolve_glsk — %d / %d RD RA(s) have non-empty GLSK for timestamp %s",
        tso, total_ra_with_data, len(available_ra_mrids), timestamp,
    )

    return glsk


def write_glsk_csv(
    glsk: dict[str, dict[str, float]],
    output_path: Path,
    timestamp: str,
    tso_by_ra_mrid: Optional[dict[str, str]] = None,
) -> None:
    """Write glsk_resolved.csv once for all TSOs (with a tso column from tso_by_ra_mrid, blank
    when unknown). An RA with an empty factor dict still gets one row with gu_mrid and
    participation_factor blank, so every considered RA is listed."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    row_count = 0
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ra_mrid", "gu_mrid", "participation_factor", "tso", "timestamp"])
        tso_by_ra_mrid = tso_by_ra_mrid or {}
        for ra_mrid in sorted(glsk.keys()):
            gu_factors = glsk[ra_mrid]
            tso = tso_by_ra_mrid.get(ra_mrid, "")
            if not gu_factors:
                writer.writerow([ra_mrid, "", "", tso, timestamp])
                row_count += 1
                continue
            for gu_mrid, factor in sorted(gu_factors.items()):
                writer.writerow([ra_mrid, gu_mrid, factor, tso, timestamp])
                row_count += 1

    log.info("Written GLSK CSV: %s (%d rows)", output_path, row_count)
