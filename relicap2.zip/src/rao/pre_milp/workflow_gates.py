"""Workflow gates — small pure predicates deciding which RA workflows have
something to optimise, kept out of run_pipeline.main() so they can be tested."""
from data_model import RAKind, RDUnit


def rd_inputs_required(rd_list: list[RDUnit], enable_nx_analysis: bool) -> bool:
    """True if RD preprocessing / rd_inputs should be built: an available PREVENTIVE RD unit
    always opens the RD workflow; an available CURATIVE unit only with N-X analysis enabled
    (curative RD acts only through the N-X block)."""
    if any(rd.available and rd.kind == RAKind.PREVENTIVE for rd in rd_list):
        return True
    return bool(enable_nx_analysis) and any(rd.available and rd.kind == RAKind.CURATIVE for rd in rd_list)
