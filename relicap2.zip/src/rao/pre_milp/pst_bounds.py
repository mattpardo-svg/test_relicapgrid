"""pst_bounds.py — effective PST tap bounds for the MILP."""

import logging

from data_model import PST

log = logging.getLogger(__name__)


def build_pst_tap_bounds(pst_list: list[PST]) -> dict[str, tuple[int, int]]:
    """Effective tap bounds per PST. A PST whose effective range is empty (min > max:
    the operating and relative limits conflict) is left out of the result, never widened to
    its hardware limits; callers build constraints only for the PSTs in the result."""
    pst_tap_bounds: dict[str, tuple[int, int]] = {}

    for pst in pst_list:
        low_step = int(pst.low_step)
        high_step = int(pst.high_step)
        current_tap = int(pst.r0)

        operating_tap_min = int(pst.operating_tap_min)
        operating_tap_max = int(pst.operating_tap_max)

        effective_min = max(low_step, operating_tap_min)
        effective_max = min(high_step, operating_tap_max)

        if pst.low_step_relative is not None:
            effective_min = max(effective_min, current_tap + int(pst.low_step_relative))
        if pst.high_step_relative is not None:
            effective_max = min(effective_max, current_tap + int(pst.high_step_relative))

        if effective_min > effective_max:
            log.warning(
                "PST %s (%s): effective tap bounds empty (%s > %s) — "
                "excluded from MILP (no valid tap position)",
                pst.mrid, pst.name, effective_min, effective_max,
            )
            continue

        if not (effective_min <= current_tap <= effective_max):
            log.warning(
                "PST %s (%s): current tap %s outside effective bounds [%s, %s]",
                pst.mrid, pst.name, current_tap, effective_min, effective_max,
            )

        pst_tap_bounds[pst.mrid] = (effective_min, effective_max)

    return pst_tap_bounds


def build_curative_tap_bounds_with_fallback(
    curative_pst_list: list[PST],
    explicit_curative_bounds: dict[str, tuple[int, int]],
) -> dict[str, tuple[int, int]]:
    """Curative tap bounds per transformer mRID: the explicit curative RangeConstraint
    bounds, else the curative PST's own operating_tap_min/max (one log line counts the
    fallbacks). Pass CURATIVE PSTs only: a preventive PST object on the same transformer
    must never supply a curative range."""
    bounds: dict[str, tuple[int, int]] = {}
    fallback_count = 0
    for pst in curative_pst_list:
        mrid = str(pst.mrid)
        if mrid in explicit_curative_bounds:
            bounds[mrid] = explicit_curative_bounds[mrid]
        else:
            bounds[mrid] = (pst.operating_tap_min, pst.operating_tap_max)
            fallback_count += 1
    log.info(
        "Curative tap bounds: %d of %d curative PST(s) used the fallback to their own "
        "operating tap range (no explicit curative range constraint found)",
        fallback_count, len(curative_pst_list),
    )
    return bounds
