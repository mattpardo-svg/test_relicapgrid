"""Sensitivity checks: the guard that declares a sensitivity set invalid (part 1) and what
the loop does with an invalid set (part 2).

PART 1 - GUARD. A sensitivity analysis linearises around a reference current, which must agree
with the load flow of the same state (lf_initial for N-0, lf_nx for N-X). A failed analysis
returns a zero reference and all-zero sensitivities without an error. A contingency / branch
is invalid when any of these holds:
  1. no reference current for a branch with a non-zero load-flow current (a branch the
     contingency disconnects has current 0 and no reference: valid);
  2. reference exactly zero while the load-flow current is above ZERO_CURRENT_AMPERE;
  3. all sensitivities of the contingency exactly zero while one of its load-flow currents is
     above ZERO_CURRENT_AMPERE;
  4. |reference - lf| / max(|lf|, RELATIVE_FLOOR_AMPERE) above the tolerance.

PART 2 - REUSE. An invalid set never reaches the MILP: the last VALID set of the same contingency
(N-X) or branch (N-0) replaces it, the constraint stays. A reused set never becomes the "last
valid" one. A stored set is usable only if every (branch, element) key is still monitored and
available and (N-X) the contingency still has a load flow; otherwise the functions return a
failure message and the caller stops the loop.
"""
from __future__ import annotations

import logging
import math
from typing import Optional

log = logging.getLogger(__name__)

NX_RELATIVE_TOLERANCE = 1e-2
N0_RELATIVE_TOLERANCE = 1e-3
RELATIVE_FLOOR_AMPERE = 1.0
ZERO_CURRENT_AMPERE = 1.0


def _finite(value) -> bool:
    return value is not None and not (isinstance(value, float) and math.isnan(value))


def _deviation_reason(reference: Optional[float], lf_current: Optional[float], tolerance: float) -> Optional[str]:
    if not _finite(lf_current):
        return None
    if not _finite(reference):
        # a branch the contingency itself disconnects has load-flow current 0 and no reference
        return "no reference current" if abs(lf_current) > ZERO_CURRENT_AMPERE else None
    if reference == 0.0 and abs(lf_current) > ZERO_CURRENT_AMPERE:
        return f"zero reference current while the load flow current is {lf_current:.1f} A"
    deviation = abs(reference - lf_current) / max(abs(lf_current), RELATIVE_FLOOR_AMPERE)
    if deviation > tolerance:
        return f"reference {reference:.1f} A differs from the load flow {lf_current:.1f} A (relative {deviation:.2f})"
    return None


def find_invalid_nx_contingencies(
    reference_nx: dict[str, dict[str, float]],
    all_zero_contingencies: set,
    lf_nx: dict[str, dict[str, dict[int, float]]],
    branch_sides: dict[str, int],
    tolerance: float = NX_RELATIVE_TOLERANCE,
) -> dict[str, str]:
    """{contingency_mrid: reason} for every contingency of reference_nx whose sensitivities
    cannot be trusted. all_zero_contingencies: contingencies whose raw sensitivities are all
    exactly zero (taken before any filter)."""
    invalid: dict[str, str] = {}
    for contingency_mrid in sorted(set(reference_nx) | set(all_zero_contingencies)):
        per_branch_lf = lf_nx.get(contingency_mrid) or {}
        references = reference_nx.get(contingency_mrid) or {}
        if contingency_mrid in all_zero_contingencies:
            for branch_mrid, per_side in per_branch_lf.items():
                lf_current = (per_side or {}).get(branch_sides.get(branch_mrid, 1))
                if _finite(lf_current) and abs(lf_current) > ZERO_CURRENT_AMPERE:
                    invalid[contingency_mrid] = "all sensitivities are exactly zero while the load flow current is non-zero"
                    break
            if contingency_mrid in invalid:
                continue
        for branch_mrid, per_side in per_branch_lf.items():
            lf_current = (per_side or {}).get(branch_sides.get(branch_mrid, 1))
            if branch_mrid not in branch_sides:
                continue
            reason = _deviation_reason(references.get(branch_mrid), lf_current, tolerance)
            if reason is not None:
                invalid[contingency_mrid] = f"branch {branch_mrid}: {reason}"
                break
    return invalid


def find_invalid_n0_branches(
    reference_n0: dict[str, float],
    lf_initial: dict[str, dict[int, float]],
    branch_sides: dict[str, int],
    tolerance: float = N0_RELATIVE_TOLERANCE,
) -> dict[str, str]:
    """{branch_mrid: reason} for every branch whose N-0 reference current disagrees with lf_initial."""
    invalid: dict[str, str] = {}
    for branch_mrid, reference in reference_n0.items():
        lf_current = (lf_initial.get(branch_mrid) or {}).get(branch_sides.get(branch_mrid, 1))
        reason = _deviation_reason(reference, lf_current, tolerance)
        if reason is not None:
            invalid[branch_mrid] = reason
    return invalid


def log_invalid(kind: str, invalid: dict[str, str], context: str) -> None:
    """One WARNING listing every invalid contingency / branch with its reason."""
    if not invalid:
        return
    log.warning(
        "SENSITIVITY GUARD (%s, %s): %d invalid: %s",
        kind, context, len(invalid), "; ".join(f"{key} ({reason})" for key, reason in sorted(invalid.items())),
    )


# ---------------------------------------------------------------------------
# Part 2 - reuse of the last valid set
# ---------------------------------------------------------------------------

class SensitivityGuardError(RuntimeError):
    """Invalid sensitivities at the first computation: nothing valid exists to reuse, the run stops."""


FRESH = "fresh"
STALE_REUSED = "stale_reused"


def _key_mismatch(stored: dict, allowed_branches: set, allowed_elements: set) -> Optional[str]:
    for branch_mrid, element_mrid in stored:
        if str(branch_mrid) not in allowed_branches:
            return f"branch {branch_mrid} is no longer monitored"
        if str(element_mrid) not in allowed_elements:
            return f"element {element_mrid} is no longer available"
    return None


def resolve_nx(
    fresh_pst: dict, fresh_rd: dict, invalid: dict, lf_nx: dict, store: dict,
    allowed_branches: set, allowed_psts: set, allowed_gus: set,
):
    """Returns (pst, rd, source, failure). pst/rd: {contingency: {(branch, element): A per unit}} to
    hand to the builder; source: {contingency: FRESH | STALE_REUSED}; failure: None or a message.
    store: {contingency: {"pst": {...}, "rd": {...}}}, updated in place with the valid fresh sets."""
    pst, rd, source = dict(fresh_pst), dict(fresh_rd), {}
    for contingency in sorted(set(fresh_pst) | set(fresh_rd) | set(invalid)):
        if contingency not in invalid:
            store[contingency] = {"pst": dict(fresh_pst.get(contingency, {})), "rd": dict(fresh_rd.get(contingency, {}))}
            source[contingency] = FRESH
            continue
        rule = invalid[contingency]
        stored = store.get(contingency)
        if stored is None:
            return pst, rd, source, (
                f"contingency {contingency}: sensitivities invalid ({rule}) and no earlier valid set exists"
            )
        if contingency not in (lf_nx or {}):
            return pst, rd, source, (
                f"contingency {contingency}: sensitivities invalid ({rule}); the stored valid set no longer "
                f"matches the model: the contingency has no load flow at the current state"
            )
        mismatch = (
            _key_mismatch(stored["pst"], allowed_branches, allowed_psts)
            or _key_mismatch(stored["rd"], allowed_branches, allowed_gus)
        )
        if mismatch:
            return pst, rd, source, (
                f"contingency {contingency}: sensitivities invalid ({rule}); the stored valid set no longer "
                f"matches the model keys: {mismatch}"
            )
        pst[contingency], rd[contingency] = dict(stored["pst"]), dict(stored["rd"])
        source[contingency] = STALE_REUSED
    return pst, rd, source, None


def resolve_n0(
    fresh_pst: dict, fresh_rd: dict, invalid: dict, monitored_branches: set,
    store_pst: dict, store_rd: dict, allowed_branches: set, allowed_psts: set, allowed_gus: set,
):
    """N-0 counterpart, per branch. Returns (pst, rd, stale_branches, failure); the sets are
    {(branch, element): value}. store_pst / store_rd: {branch: {(branch, element): value}}."""
    def of_branch(values, branch):
        return {key: value for key, value in values.items() if key[0] == branch}

    branches = set(monitored_branches) | {key[0] for key in fresh_pst} | {key[0] for key in fresh_rd}
    pst, rd, stale = dict(fresh_pst), dict(fresh_rd), {}
    for branch in sorted(branches | set(invalid)):
        if branch not in invalid:
            store_pst[branch], store_rd[branch] = of_branch(fresh_pst, branch), of_branch(fresh_rd, branch)
            continue
        rule = invalid[branch]
        if branch not in store_pst or branch not in store_rd:
            return pst, rd, stale, f"branch {branch}: N-0 sensitivities invalid ({rule}) and no earlier valid set exists"
        mismatch = (
            _key_mismatch(store_pst[branch], allowed_branches, allowed_psts)
            or _key_mismatch(store_rd[branch], allowed_branches, allowed_gus)
        )
        if mismatch:
            return pst, rd, stale, (
                f"branch {branch}: N-0 sensitivities invalid ({rule}); the stored valid set no longer "
                f"matches the model keys: {mismatch}"
            )
        pst = {k: v for k, v in pst.items() if k[0] != branch}
        rd = {k: v for k, v in rd.items() if k[0] != branch}
        pst.update(store_pst[branch])
        rd.update(store_rd[branch])
        stale[branch] = STALE_REUSED
    return pst, rd, stale, None
