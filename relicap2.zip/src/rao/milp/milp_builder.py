"""milp_builder.py — the Pyomo MILP of one solve, built at the current operating point.

Blocks, each built only when its inputs exist (RA types compose freely):
- PST: tap_change_upward/downward, tap bounds, group equality, per-TSO tap cap;
- RD: rd_volume_upward/downward (preventive bids only), rd_net_injection_g, Pmax/Pmin,
  balance sum_g rd_net_injection_g[g] = 0, lead times (usable only STRICTLY after
  radp + lead time), RA-count binaries (big-M = the bid's available_mw), RA-group caps;
- N-0: secured (PATL) and scanned (effective limit) loading constraints with slacks;
- N-X: PATL, TATL (separate constraint, no loading pre-filter) and scanned constraints
  per (branch, contingency), with curative PST and curative RD (gated only on rd_inputs;
  cost on the max-over-contingencies reservation).
"""

import logging
import math
from dataclasses import dataclass
from typing import Optional

from data_model import AEType, AssessedElement, BidDirection, PST, PowerBid, RAKind, RDUnit, select_by_side

log = logging.getLogger(__name__)

# Logging verbosity only, set once by run_pipeline from logging_options.debug_log_mode.
# False: _log_if_changed suppresses repeats of the same message; True: every call logs.
DEBUG_LOG_MODE = False

_last_logged_values: dict[str, object] = {}


def _log_if_changed(key: str, value: object, message: str, *args) -> None:
    """Log `message % args` at INFO unless DEBUG_LOG_MODE is False and `value` equals the
    last value logged under `key` (module-level, across builds). Used only for the two
    messages that repeat unchanged every rebuild (RD curative-bid split, N-X pair count)."""
    if DEBUG_LOG_MODE or _last_logged_values.get(key) != value:
        log.info(message, *args)
        _last_logged_values[key] = value


# ---------------------------------------------------------------------------
# Composable MILP input groupings
# ---------------------------------------------------------------------------

@dataclass
class PstMilpInputs:
    """PST inputs of the MILP. Non-None builds the PST block (tap variables, bounds, group
    equality, model.pst_effect_on_branch); None builds no PST component at all.
    max_taps_per_tso: HARD per-TSO cap on sum(tap_change_upward + tap_change_downward) over
    its available preventive PSTs (per timestamp and per timeframe coincide with one
    timestamp)."""
    pst_list: list[PST]
    pst_tap_bounds: dict[str, tuple[int, int]]
    pst_group_equality_pairs: list[tuple[str, str]]
    sensitivity_pst_n0_pruned: dict[tuple[str, str], float]
    pst_degrees_per_tap: dict[str, float]
    penalty_reference_pst_pra: float
    penalty_reference_pst_pra_per_tso: Optional[dict[str, float]] = None
    pst_taping_discrete: bool = True
    max_taps_per_tso: int = 6
    # Optional per-TSO override of max_taps_per_tso (same pattern as the
    # penalty_reference_*_per_tso maps): {tso: limit}. A TSO not listed uses
    # max_taps_per_tso. Values are validated (non-negative integers).
    max_taps_per_tso_overrides: Optional[dict[str, int]] = None
    # tap of each PST in the ORIGINAL network (pst.r0 is the current tap); None: original ==
    # current. The tap limit and penalty act on the cumulative |current - original + delta|.
    pst_original_taps: Optional[dict[str, int]] = None

    # pst_list holds every PST (both kinds) so the AC loop updates r0 in one pass; the kind
    # split is made here: everything preventive reads preventive_pst_list, everything curative
    # curative_pst_list. A transformer with both kinds appears in both, as two PST objects.
    @property
    def preventive_pst_list(self) -> list[PST]:
        return [pst for pst in self.pst_list if pst.kind == RAKind.PREVENTIVE]

    @property
    def curative_pst_list(self) -> list[PST]:
        return [pst for pst in self.pst_list if pst.kind == RAKind.CURATIVE]

    # What the MILP actually builds on: an unavailable PST (PST.available is
    # False, NC normalAvailable) gets no variables, no tap-limit contribution
    # and no objective term, preventive or curative.
    @property
    def available_preventive_pst_list(self) -> list[PST]:
        # no pst_tap_bounds entry: excluded by build_pst_tap_bounds (empty range, warned):
        # no variables, no tap-limit term, no objective term
        return [
            pst for pst in self.preventive_pst_list
            if pst.available and str(pst.mrid) in self.pst_tap_bounds
        ]

    @property
    def available_curative_pst_list(self) -> list[PST]:
        return [pst for pst in self.curative_pst_list if pst.available]


@dataclass
class RdMilpInputs:
    """RD inputs of the MILP. Non-None builds the RD block (bid volumes, rd_net_injection_g,
    rd_effect_on_branch, Pmax/Pmin); None builds no RD component at all.
    generator_data: {gu_mrid: {target_p/initial_p, max_p, min_p, name}}.
    penalty_reference_rd_pra (default 0.0, no-op) with per-TSO overrides.
    RA count: per-TSO limits per timestamp (hard if ra_limit_constraint_hard, default True,
    else soft) and per timeframe (always soft); a TSO without a limit is not constrained.
    ra_groups: parse_ra_groups output (None/{}: no group caps). raart: None -> radp is one
    hour before `timestamp` (_compute_radp). The timestamp is build_n0_milp_model's own.
    """
    rd_list: list[RDUnit]
    bid_list: list[PowerBid]
    glsk: dict[str, dict[str, float]]
    sensitivity_rd_n0_pruned: dict[tuple[str, str], float]
    generator_data: dict[str, dict]
    penalty_reference_rd_pra: float = 0.0
    penalty_reference_rd_pra_per_tso: Optional[dict[str, float]] = None
    max_ra_count_per_timestamp_tso: Optional[dict[str, int]] = None
    max_ra_count_per_timeframe_tso: Optional[dict[str, int]] = None
    ra_limit_penalty: float = 0.0
    ra_limit_constraint_hard: bool = True
    ra_groups: Optional[dict[str, dict]] = None
    raart: Optional[str] = None
    # cumulative_signed_volume_mw: {bid: MW used by earlier iterations, UP +, DOWN -}; headroom,
    # cost, RA binary and group caps act on used + this solve's change (None: nothing used).
    # original_target_p_mw: {gu: ORIGINAL target_p}, for original / cumulative / final reports.
    cumulative_signed_volume_mw: Optional[dict[str, float]] = None
    original_target_p_mw: Optional[dict[str, float]] = None


@dataclass
class NxMilpInputs:
    """N-X inputs of the MILP. None: the N-0 model only. N-X terms of an RA type are added
    only when that type's preventive block exists (nx_inputs never creates RA variables).
    - lf_nx / sensitivity_pst_nx / sensitivity_rd_nx: keyed by contingency; only contingencies
      in lf_nx get constraints. The sensitivities are the Filter-2-PRUNED dicts (the caller
      prunes); PST values are A/degree, converted with pst_inputs.pst_degrees_per_tap.
    - min_loading_threshold_pct_nx: the PATL pre-filter, separate from the N-0 threshold.
    - PATL constraint: SECURED branches; scanned branches get the scanned constraint
      (penalty_cost_overload_nx_scanned, effective limit).
    - tatl_data: a separate TATL constraint for every usable pair of a branch with a TATL,
      with no loading pre-filter.
    - pst_cra_availability: one curative variable pair per (PST, contingency) with at least
      one available XNE; each available (pst, xne, c) entry adds its own magnitude bound.
    - pst_tap_bounds_curative: effective bounds (the caller applies the preventive fallback);
      a curative PST missing from it has no bound constraint (warning).
    - activate_cra_xne_linkage (default False): True also requires the XNE to be in the
      PST's linked_xne_mrids for its term to enter that XNE's constraint.
    """
    lf_nx: dict[str, dict[str, dict[int, float]]]
    sensitivity_pst_nx: dict[str, dict[tuple[str, str], float]]
    sensitivity_rd_nx: dict[str, dict[tuple[str, str], float]]
    penalty_cost_overload_nx_patl: float = 0.0
    min_loading_threshold_pct_nx: float = 0.0
    tatl_data: Optional[dict[str, dict]] = None
    penalty_cost_overload_nx_tatl: float = 0.0
    pst_cra_availability: Optional[dict[tuple[str, str, str], dict]] = None
    pst_tap_bounds_curative: Optional[dict[str, tuple[int, int]]] = None
    # (pst_1, pst_2, contingency) triples whose curative delta tap (up - down) must be equal,
    # from cra_preprocessing.build_curative_pst_group_constraints (curative PSTs only)
    curative_pst_group_triples: Optional[list[tuple[str, str, str]]] = None
    activate_cra_xne_linkage: bool = False
    penalty_cost_overload_nx_scanned: float = 0.0


# ---------------------------------------------------------------------------
# Shared helpers (RA-type-agnostic)
# ---------------------------------------------------------------------------

def _hhmmz_to_minutes(hhmmz: str) -> int:
    """"HHMMZ" (e.g. "1030Z") -> minutes since midnight."""
    hh = int(hhmmz[0:2])
    mm = int(hhmmz[2:4])
    return hh * 60 + mm


def _minutes_to_hhmmz(minutes: int) -> str:
    """Inverse of _hhmmz_to_minutes, mod 1440: one hour before "0030Z" is "2330Z"."""
    minutes = minutes % (24 * 60)
    return f"{minutes // 60:02d}{minutes % 60:02d}Z"


def _compute_radp(raart: Optional[str], timestamp: str, interval_minutes: int = 60) -> str:
    """radp (RD availability reference point): raart when given ("2200Z" -> "2200Z"), else
    the timestamp interval_minutes (60, the hourly timestamp list) before `timestamp`."""
    if raart is not None:
        return raart
    return _minutes_to_hhmmz(_hhmmz_to_minutes(timestamp) - interval_minutes)


def _timestamp_is_usable(radp: str, bid_lead_time_hours: float, timestamp: str) -> bool:
    """True if `timestamp` is usable for a bid: t_start_minutes > radp_minutes +
    lead_time_minutes (STRICT: a lead time ending within or exactly at the start of a
    timestamp's hour blocks it). Example: radp 23:30, lead 3 h -> cutoff 02:30 -> 0230Z
    blocked, 0330Z usable. A timestamp earlier than radp on the clock is the next day (+24 h).
    """
    radp_minutes = _hhmmz_to_minutes(radp)
    timestamp_minutes = _hhmmz_to_minutes(timestamp)
    if timestamp_minutes < radp_minutes:
        timestamp_minutes += 24 * 60

    cutoff_minutes = radp_minutes + bid_lead_time_hours * 60
    return timestamp_minutes > cutoff_minutes


def _compute_earliest_usable_timestamp(
    radp: str, bid_lead_time_hours: float, timestamp_list: list[str],
) -> Optional[str]:
    """First entry of timestamp_list that passes _timestamp_is_usable (the same check as the
    bound tightening), for results_lead_times.csv; None if none is usable."""
    for candidate_timestamp in timestamp_list:
        if _timestamp_is_usable(radp, bid_lead_time_hours, candidate_timestamp):
            return candidate_timestamp
    return None


def _get_monitored_branch_limits_and_ae_types(
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_initial: Optional[dict[str, dict[int, float]]],
) -> tuple[dict[str, float], dict[str, "AEType"]]:
    """({branch_mrid: limit_ampere}, {branch_mrid: ae_type}) for every SECURED and SCANNED AE:
    PATL for secured, effective_limit = max(PATL, initial loading) for scanned (virtual
    margin 0). build_n0_milp_model splits the branches by ae_type into the secured and the
    scanned constraint, both reading the same limits dict."""
    limits: dict[str, float] = {}
    ae_types: dict[str, AEType] = {}
    for ae in ae_flat_list:
        if ae.ae_type not in (AEType.SECURED, AEType.SCANNED) or ae.branch_mrid is None:
            continue
        branch_mrid = str(ae.branch_mrid)
        patl_ka = ae.patl_ka.get(timestamp)
        if patl_ka is None:
            continue

        if ae.ae_type == AEType.SCANNED:
            side = int(getattr(ae, "branch_side", 1))
            per_side_currents = lf_initial.get(branch_mrid) if lf_initial else None
            i_a = select_by_side(per_side_currents, side, branch_mrid) if per_side_currents else None
            limit_ka = max(patl_ka, float(i_a) / 1000.0) if i_a is not None else patl_ka
        else:
            limit_ka = patl_ka

        limits[branch_mrid] = float(limit_ka) * 1000.0
        ae_types[branch_mrid] = ae.ae_type
    return limits, ae_types


def _get_monitored_branch_sides(ae_flat_list: list[AssessedElement]) -> dict[str, int]:
    """{branch_mrid: resolved side (1 or 2)} for every SECURED and SCANNED AE (the side of its
    CurrentLimit; used for the side-aware lf_initial lookups)."""
    sides: dict[str, int] = {}
    for ae in ae_flat_list:
        if ae.ae_type not in (AEType.SECURED, AEType.SCANNED) or not ae.branch_mrid:
            continue
        sides[str(ae.branch_mrid)] = int(getattr(ae, "branch_side", 1))
    return sides


def _branch_is_above_threshold(
    branch_mrid: str,
    lf_initial: dict[str, dict[int, float]],
    branch_patls: dict[str, float],
    branch_sides: dict[str, int],
    min_loading_threshold_pct: float,
) -> bool:
    side = branch_sides.get(branch_mrid, 1)
    per_side_currents = lf_initial.get(branch_mrid)
    initial_current = select_by_side(per_side_currents, side, branch_mrid) if per_side_currents else None
    if initial_current is None:
        log.warning("Branch %s missing initial current (side %d); excluding from MILP", branch_mrid, side)
        return False
    if math.isnan(float(initial_current)):
        log.warning("Branch %s has a NaN initial current (side %d); excluding from MILP", branch_mrid, side)
        return False

    patl_ampere = branch_patls.get(branch_mrid)
    if patl_ampere is None or patl_ampere <= 0.0:
        log.warning("Branch %s missing or invalid PATL; excluding from MILP", branch_mrid)
        return False

    loading_pct = (initial_current / patl_ampere) * 100.0
    return loading_pct >= float(min_loading_threshold_pct)


# ---------------------------------------------------------------------------
# PST-specific helpers
# ---------------------------------------------------------------------------

def _get_pst_ids(pst_list: list[PST]) -> list[str]:
    return [str(pst.mrid) for pst in pst_list]


def validate_max_taps_per_tso(value, description: str = "max_taps_per_tso") -> int:
    """A tap limit must be a non-negative integer (bool is not accepted)."""
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{description} must be a non-negative integer, got {value!r}")
    return value


def _get_effective_penalty_costs(
    pst_list: list[PST],
    penalty_reference_pst_pra: float,
    penalty_reference_pst_pra_per_tso: Optional[dict[str, float]] = None,
) -> dict[str, float]:
    override = penalty_reference_pst_pra_per_tso or {}
    # callers pass one kind's list at a time (preventive and curative never share an entry);
    # two RAs of one kind on one transformer with different penalties: the larger (warning)
    costs: dict[str, float] = {}
    for pst in pst_list:
        mrid = str(pst.mrid)
        cost = float(pst.penalty_factor) * float(override.get(pst.tso, penalty_reference_pst_pra))
        if mrid in costs and costs[mrid] != cost:
            log.warning(
                "PST %s has two RAs of the same kind with different effective "
                "penalties (%s vs %s) — using the larger, order-independent value",
                mrid, costs[mrid], cost,
            )
            cost = max(costs[mrid], cost)
        costs[mrid] = cost
    return costs


def _add_pst_block(model, pyo, pst_inputs: PstMilpInputs, branch_ids: list[str]) -> list[str]:
    """Add the PST variables, tap bound / group equality constraints and
    model.pst_effect_on_branch. Returns pst_ids for the objective."""
    if not pst_inputs.pst_list:
        raise ValueError("PST list is empty; cannot build MILP model")
    preventive_pst_list = pst_inputs.available_preventive_pst_list
    if not preventive_pst_list:
        # only curative PSTs: no preventive block (no tap variables, no tap cap); the curative
        # block is built by _add_nx_block
        log.info(
            "_add_pst_block: pst_list contains %d PST(s) but none is an available "
            "preventive PST — no preventive PST variables added (curative PSTs are "
            "handled by _add_curative_pst_block)", len(pst_inputs.pst_list),
        )
        return []
    pst_by_mrid: dict[str, PST] = {str(pst.mrid): pst for pst in preventive_pst_list}
    # One variable pair per transformer: two preventive RAs on the same
    # transformer share their mRID and must count ONCE in the branch effect
    # and in the per-TSO tap limit (pyo.Set dedups, plain lists do not).
    pst_ids = list(dict.fromkeys(_get_pst_ids(preventive_pst_list)))
    if len(pst_ids) != len(preventive_pst_list):
        log.warning(
            "_add_pst_block: %d available preventive PST object(s) share an mRID with another "
            "— each transformer is modelled once (variables, tap limit, branch effect)",
            len(preventive_pst_list) - len(pst_ids),
        )

    missing_deg_per_tap = [p for p in pst_ids if p not in pst_inputs.pst_degrees_per_tap]
    if missing_deg_per_tap:
        log.warning(
            "PST(s) missing degrees-per-tap conversion factor — excluded from "
            "tap_effect (their sensitivity cannot be safely applied): %s",
            missing_deg_per_tap,
        )

    model.pst_ids = pyo.Set(initialize=pst_ids)
    # Only the equality pairs naming a PST without model variables (excluded
    # for an empty tap range, or unavailable) are dropped, since an equality
    # with a PST that is not modelled cannot be built; the group's other
    # pairs stay.
    group_pairs = []
    for pair in pst_inputs.pst_group_equality_pairs:
        if pair[0] in model.pst_ids and pair[1] in model.pst_ids:
            group_pairs.append(pair)
        else:
            log.warning(
                "_add_pst_block: PST group pair %s dropped - a member has no model "
                "variables (excluded for an empty tap range or unavailable)", tuple(pair),
            )
    model.pst_group_pairs = pyo.Set(initialize=group_pairs, dimen=2)

    tap_domain = pyo.NonNegativeIntegers if pst_inputs.pst_taping_discrete else pyo.NonNegativeReals
    model.tap_change_upward = pyo.Var(model.pst_ids, domain=tap_domain)
    model.tap_change_downward = pyo.Var(model.pst_ids, domain=tap_domain)

    def tap_upper_bound_rule(m, pst_mrid):
        pst = pst_by_mrid[str(pst_mrid)]
        current_tap = int(getattr(pst, "r0", 0))
        effective_max = int(pst_inputs.pst_tap_bounds[str(pst_mrid)][1])
        return current_tap + m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid] <= effective_max

    def tap_lower_bound_rule(m, pst_mrid):
        pst = pst_by_mrid[str(pst_mrid)]
        current_tap = int(getattr(pst, "r0", 0))
        effective_min = int(pst_inputs.pst_tap_bounds[str(pst_mrid)][0])
        return effective_min <= current_tap + m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid]

    def pst_group_equality_rule(m, pst_mrid_1, pst_mrid_2):
        current_tap_1 = int(getattr(pst_by_mrid[str(pst_mrid_1)], "r0", 0))
        current_tap_2 = int(getattr(pst_by_mrid[str(pst_mrid_2)], "r0", 0))
        return (
            current_tap_1 + m.tap_change_upward[pst_mrid_1] - m.tap_change_downward[pst_mrid_1]
            ==
            current_tap_2 + m.tap_change_upward[pst_mrid_2] - m.tap_change_downward[pst_mrid_2]
        )

    model.tap_upper_bound = pyo.Constraint(model.pst_ids, rule=tap_upper_bound_rule)
    model.tap_lower_bound = pyo.Constraint(model.pst_ids, rule=tap_lower_bound_rule)
    model.pst_group_equality = pyo.Constraint(model.pst_group_pairs, rule=pst_group_equality_rule)

    # CUMULATIVE tap change against the ORIGINAL network: offset = pst.r0 - original tap;
    # cumulative change = offset + up - down, on which the per-TSO tap limit and the penalty
    # act. Offset 0: the cumulative terms are the up/down variables. Otherwise two extra
    # non-negative variables with cum_up - cum_down = offset + up - down carry |.| (no
    # binary: the limit and the positive penalty push their sum down to the absolute value).
    original_taps = pst_inputs.pst_original_taps or {}
    tap_offset_by_pst = {
        pst_mrid: int(getattr(pst_by_mrid[str(pst_mrid)], "r0", 0))
        - int(original_taps.get(str(pst_mrid), getattr(pst_by_mrid[str(pst_mrid)], "r0", 0)))
        for pst_mrid in pst_ids
    }
    model.pst_start_tap_by_mrid = {
        str(p): int(getattr(pst_by_mrid[str(p)], "r0", 0)) for p in pst_ids
    }
    model.pst_original_tap_by_mrid = {
        str(p): int(model.pst_start_tap_by_mrid[str(p)] - tap_offset_by_pst[p]) for p in pst_ids
    }
    pst_ids_with_offset = [p for p in pst_ids if tap_offset_by_pst[p] != 0]
    model.cum_tap_pst_ids = pyo.Set(initialize=pst_ids_with_offset)
    model.cum_tap_change_upward = pyo.Var(model.cum_tap_pst_ids, domain=pyo.NonNegativeReals)
    model.cum_tap_change_downward = pyo.Var(model.cum_tap_pst_ids, domain=pyo.NonNegativeReals)

    def cum_tap_balance_rule(m, pst_mrid):
        return (
            m.cum_tap_change_upward[pst_mrid] - m.cum_tap_change_downward[pst_mrid]
            == tap_offset_by_pst[pst_mrid] + m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid]
        )

    model.cum_tap_balance = pyo.Constraint(model.cum_tap_pst_ids, rule=cum_tap_balance_rule)
    # plain dicts {pst_mrid: Var}: the term to use for "cumulative up" / "cumulative down"
    model.cum_tap_up_term = {
        p: (model.cum_tap_change_upward[p] if p in model.cum_tap_pst_ids else model.tap_change_upward[p])
        for p in pst_ids
    }
    model.cum_tap_down_term = {
        p: (model.cum_tap_change_downward[p] if p in model.cum_tap_pst_ids else model.tap_change_downward[p])
        for p in pst_ids
    }

    def pst_effect_on_branch_rule(m, branch_mrid):
        # sensitivity_pst_n0_pruned is in A/degree: x pst_degrees_per_tap gives A per tap
        return sum(
            float(pst_inputs.sensitivity_pst_n0_pruned.get((branch_mrid, pst_mrid), 0.0))
            * float(pst_inputs.pst_degrees_per_tap[pst_mrid])
            * (m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid])
            for pst_mrid in pst_ids
            if pst_mrid in pst_inputs.pst_degrees_per_tap
        )

    model.pst_effect_on_branch = pyo.Expression(branch_ids, rule=pst_effect_on_branch_rule)

    # Hard per-TSO tap-change limit: sum over the TSO's PSTs of (up + down) <= max_taps_per_tso.
    # Why: a large combined multi-PST move makes the linear sensitivities wrong, even in sign,
    # and no TSO would allow such a swing within one timestamp. With one timestamp the limits
    # per timestamp and per timeframe are the same constraint. up + down is |change| at the
    # optimum (both positive only adds cost), so no abs variable is needed. A TSO without
    # PSTs gets a vacuous constraint.
    tso_to_pst_ids: dict[str, list[str]] = {}
    for pst_mrid in pst_ids:
        tso_to_pst_ids.setdefault(pst_by_mrid[pst_mrid].tso, []).append(pst_mrid)

    model.tso_ids_for_tap_change_limit = pyo.Set(initialize=sorted(tso_to_pst_ids.keys()))

    default_limit = validate_max_taps_per_tso(pst_inputs.max_taps_per_tso)
    limit_overrides = {
        str(tso): validate_max_taps_per_tso(limit, f"max_taps_per_tso_overrides[{tso!r}]")
        for tso, limit in (pst_inputs.max_taps_per_tso_overrides or {}).items()
    }
    tso_tap_limits = {tso: limit_overrides.get(tso, default_limit) for tso in tso_to_pst_ids}
    # kept on the model so the results file reports the limit that was applied
    model.tso_tap_limit_values = tso_tap_limits  # plain dict attribute: {tso: limit}

    def max_taps_per_tso_rule(m, tso):
        # CUMULATIVE against the original network: later
        # iterations only get the headroom the earlier ones left.
        return sum(
            m.cum_tap_up_term[pst_mrid] + m.cum_tap_down_term[pst_mrid]
            for pst_mrid in tso_to_pst_ids[tso]
        ) <= tso_tap_limits[tso]

    model.max_taps_per_tso_constraint = pyo.Constraint(
        model.tso_ids_for_tap_change_limit, rule=max_taps_per_tso_rule,
    )

    return pst_ids


# ---------------------------------------------------------------------------
# RD-specific helpers
# ---------------------------------------------------------------------------

def _get_gu_ids_reachable_via_glsk(glsk: dict[str, dict[str, float]]) -> list[str]:
    """Every generating-unit mRID that appears with a non-empty participation
    factor in ANY RA's resolved GLSK — the only units RD can actually move.

    Sorted for deterministic Pyomo Set ordering (matters for reproducible
    solves and test assertions).
    """
    gu_ids: set[str] = set()
    for ra_participation in glsk.values():
        gu_ids.update(ra_participation.keys())
    return sorted(gu_ids)


def _add_rd_block(model, pyo, rd_inputs: RdMilpInputs, timestamp: str, branch_ids: list[str]) -> bool:
    """Add the RD variables, model.rd_net_injection_g / rd_effect_on_branch and the Pmax/Pmin
    constraints, for bids of PREVENTIVE RD units only (curative bids get their
    contingency-gated variables in _add_curative_rd_block).
    Returns False and adds nothing when there are no bids or no generating unit is
    reachable via GLSK (a legitimate empty RD block, not an error).
    """
    ra_kind_by_mrid: dict[str, RAKind] = {str(rd.mrid): rd.kind for rd in rd_inputs.rd_list}
    # An unavailable RD unit (RDUnit.available False, NC normalAvailable) gets
    # no bid variables, no RA-count variable, no group-limit entry and no cost
    # term — same rule as for PSTs.
    available_ra_mrids = {str(rd.mrid) for rd in rd_inputs.rd_list if rd.available}
    preventive_bid_list = [
        bid for bid in rd_inputs.bid_list
        if ra_kind_by_mrid.get(str(bid.ra_mrid)) == RAKind.PREVENTIVE
        and str(bid.ra_mrid) in available_ra_mrids
    ]
    curative_bid_count = sum(1 for bid in rd_inputs.bid_list if ra_kind_by_mrid.get(str(bid.ra_mrid)) == RAKind.CURATIVE)
    if curative_bid_count:
        _log_if_changed(
            "curative_rd_bid_split", (curative_bid_count, len(rd_inputs.bid_list)),
            "_add_rd_block: %d of %d bid(s) belong to a curative RD RA — "
            "excluded from the preventive rd_volume_upward/downward variables "
            "(handled separately by _add_curative_rd_block, if this "
            "workflow's nx_inputs provides curative RD data)",
            curative_bid_count, len(rd_inputs.bid_list),
        )

    gu_ids_reachable = _get_gu_ids_reachable_via_glsk(rd_inputs.glsk)

    if not preventive_bid_list or not gu_ids_reachable:
        log.warning(
            "RD block skipped — preventive bid_list has %d entries (of %d total; "
            "%d curative), %d generating unit(s) reachable via GLSK (need both "
            "non-zero). This is the confirmed empty-GLSK/empty-bid dataset "
            "boundary condition on the current Jotunheim dataset cut (see "
            "power-bid and GLSK findings) if this is unexpected, check "
            "bid_list and glsk directly before assuming a bug.",
            len(preventive_bid_list), len(rd_inputs.bid_list), curative_bid_count, len(gu_ids_reachable),
        )
        return False

    missing_generator_data = [g for g in gu_ids_reachable if g not in rd_inputs.generator_data]
    if missing_generator_data:
        log.warning(
            "Generating unit(s) reachable via GLSK but missing from "
            "generator_data (network.get_generators()) — excluded from "
            "Pmax/Pmin and rd_net_injection_g: %s",
            missing_generator_data,
        )
        gu_ids_reachable = [g for g in gu_ids_reachable if g not in missing_generator_data]
        if not gu_ids_reachable:
            log.warning("RD block skipped — no generating unit has both GLSK participation and generator_data")
            return False

    bid_ids = [str(bid.mrid) for bid in preventive_bid_list]
    bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in preventive_bid_list}

    model.bid_ids = pyo.Set(initialize=bid_ids)
    model.gu_ids = pyo.Set(initialize=gu_ids_reachable)

    model.rd_volume_upward = pyo.Var(model.bid_ids, domain=pyo.NonNegativeReals)
    model.rd_volume_downward = pyo.Var(model.bid_ids, domain=pyo.NonNegativeReals)

    # Upper bounds per bid direction (a PowerBidSchedule is UP or DOWN): the other direction
    # is bounded to 0.0. CUMULATIVE headroom: with `used` MW already applied in the bid's
    # direction, this solve may add (availability - used) and take back at most `used`.
    used_signed_by_bid = rd_inputs.cumulative_signed_volume_mw or {}
    used_magnitude_by_bid: dict[str, float] = {}
    for bid_mrid in bid_ids:
        bid = bid_by_mrid[bid_mrid]
        signed_used = float(used_signed_by_bid.get(bid_mrid, 0.0))
        used_magnitude_by_bid[bid_mrid] = max(signed_used if bid.direction == BidDirection.UP else -signed_used, 0.0)
    for bid_mrid in bid_ids:
        bid = bid_by_mrid[bid_mrid]
        available_mw = float(bid.available_mw.get(timestamp, 0.0))
        used_mw = used_magnitude_by_bid[bid_mrid]
        if bid.direction == BidDirection.UP:
            model.rd_volume_upward[bid_mrid].setub(max(available_mw - used_mw, 0.0))
            model.rd_volume_downward[bid_mrid].setub(used_mw)
        else:
            model.rd_volume_downward[bid_mrid].setub(max(available_mw - used_mw, 0.0))
            model.rd_volume_upward[bid_mrid].setub(used_mw)

    # cumulative volume per bid and direction: the plain up/down variables when nothing is
    # used yet, otherwise used + this solve's change
    model.rd_used_signed_volume_mw = {b: float(used_signed_by_bid.get(b, 0.0)) for b in bid_ids}
    model.rd_cumulative_up_term = {}
    model.rd_cumulative_down_term = {}
    model.rd_cumulative_volume_term = {}
    for bid_mrid in bid_ids:
        bid = bid_by_mrid[bid_mrid]
        used_mw = used_magnitude_by_bid[bid_mrid]
        up_var, down_var = model.rd_volume_upward[bid_mrid], model.rd_volume_downward[bid_mrid]
        if used_mw == 0.0:
            model.rd_cumulative_volume_term[bid_mrid] = up_var + down_var
            model.rd_cumulative_up_term[bid_mrid] = up_var
            model.rd_cumulative_down_term[bid_mrid] = down_var
        elif bid.direction == BidDirection.UP:
            cumulative = used_mw + up_var - down_var
            model.rd_cumulative_volume_term[bid_mrid] = cumulative
            model.rd_cumulative_up_term[bid_mrid] = cumulative
            model.rd_cumulative_down_term[bid_mrid] = 0.0
        else:
            cumulative = used_mw + down_var - up_var
            model.rd_cumulative_volume_term[bid_mrid] = cumulative
            model.rd_cumulative_up_term[bid_mrid] = 0.0
            model.rd_cumulative_down_term[bid_mrid] = cumulative
    model.rd_cumulative_used_in_any_bid = any(v != 0.0 for v in used_magnitude_by_bid.values())

    # lead time: after the direction bounds (it only tightens): a bid whose lead time is not
    # satisfied at this timestamp gets setub(0.0)
    radp = _compute_radp(rd_inputs.raart, timestamp)
    for bid_mrid in bid_ids:
        bid = bid_by_mrid[bid_mrid]
        if bid.lead_time_h <= 0:
            continue  # no lead time restriction for this bid
        if not _timestamp_is_usable(radp, bid.lead_time_h, timestamp):
            model.rd_volume_upward[bid_mrid].setub(0.0)
            model.rd_volume_downward[bid_mrid].setub(0.0)
            log.info(
                "Bid %s: lead_time_h=%.2f not satisfied by radp=%s at timestamp=%s "
                "— rd_volume_upward/downward bounds fixed to 0.0",
                bid_mrid, bid.lead_time_h, radp, timestamp,
            )

    def rd_net_injection_rule(m, gu_mrid):
        terms = [
            float(participation_factor) * (m.rd_volume_upward[bid_mrid] - m.rd_volume_downward[bid_mrid])
            for bid_mrid in bid_ids
            for participation_factor in [rd_inputs.glsk.get(bid_by_mrid[bid_mrid].ra_mrid, {}).get(gu_mrid)]
            if participation_factor is not None
        ]
        return sum(terms) if terms else 0.0

    model.rd_net_injection_g = pyo.Expression(model.gu_ids, rule=rd_net_injection_rule)

    def rd_effect_on_branch_rule(m, branch_mrid):
        return sum(
            float(rd_inputs.sensitivity_rd_n0_pruned.get((branch_mrid, gu_mrid), 0.0))
            * m.rd_net_injection_g[gu_mrid]
            for gu_mrid in gu_ids_reachable
        )

    model.rd_effect_on_branch = pyo.Expression(branch_ids, rule=rd_effect_on_branch_rule)

    def pmax_pmin_rule(m, gu_mrid):
        gu_data = rd_inputs.generator_data.get(gu_mrid, {})
        target_p = float(gu_data.get("target_p", gu_data.get("initial_p", 0.0)))
        max_p = float(gu_data.get("max_p", 0.0))
        min_p = float(gu_data.get("min_p", 0.0))
        return (min_p, target_p + m.rd_net_injection_g[gu_mrid], max_p)

    model.pmax_pmin_constraint = pyo.Constraint(model.gu_ids, rule=pmax_pmin_rule)

    # the production baseline (target_p, MW) this model was built on, for the result
    # exporters (not the original CGM value after a rebuild); no model term depends on it
    model.rd_original_target_p_mw = {
        str(gu_mrid): float(
            (rd_inputs.original_target_p_mw or {}).get(
                str(gu_mrid),
                rd_inputs.generator_data.get(gu_mrid, {}).get(
                    "target_p", rd_inputs.generator_data.get(gu_mrid, {}).get("initial_p", 0.0)),
            )
        )
        for gu_mrid in gu_ids_reachable
    }
    model.rd_baseline_target_p_mw = {
        str(gu_mrid): float(
            rd_inputs.generator_data.get(gu_mrid, {}).get(
                "target_p", rd_inputs.generator_data.get(gu_mrid, {}).get("initial_p", 0.0))
        )
        for gu_mrid in gu_ids_reachable
    }

    return True


# ---------------------------------------------------------------------------
# N-X PATL and TATL loading constraints
# ---------------------------------------------------------------------------

def _add_curative_pst_block(
    model,
    pyo,
    nx_inputs: NxMilpInputs,
    pst_inputs: PstMilpInputs,
) -> int:
    """Curative PST variables, curative tap bounds and magnitude constraints; returns the
    number of (pst, contingency) pairs. Called by _add_nx_block when pst_cra_availability is
    not empty. One variable pair per (PST, contingency); each available (pst, xne, c) entry
    adds its own magnitude bound on it, so the tightest max_curative_taps binds.
    """
    pst_cra_availability = nx_inputs.pst_cra_availability
    available_curative_mrids = {str(pst.mrid) for pst in pst_inputs.available_curative_pst_list}

    curative_pst_contingency_pairs = sorted({
        (pst_mrid, co_mrid)
        for (pst_mrid, xne_mrid, co_mrid), entry in pst_cra_availability.items()
        if entry.get("available") and str(pst_mrid) in available_curative_mrids
    })

    if not curative_pst_contingency_pairs:
        log.info(
            "_add_curative_pst_block: pst_cra_availability has entries but none "
            "with available=True — no curative PST variables added (genuine "
            "outcome, not an error; see nx_sensitivity.compute_pst_cra_availability)"
        )
        return 0

    model.curative_pst_contingency_pairs = pyo.Set(initialize=curative_pst_contingency_pairs, dimen=2)
    model.curative_tap_change_upward = pyo.Var(
        model.curative_pst_contingency_pairs, domain=pyo.NonNegativeReals,
    )
    model.curative_tap_change_downward = pyo.Var(
        model.curative_pst_contingency_pairs, domain=pyo.NonNegativeReals,
    )

    pst_by_mrid: dict[str, PST] = {str(pst.mrid): pst for pst in pst_inputs.available_curative_pst_list}
    pst_tap_bounds_curative = nx_inputs.pst_tap_bounds_curative or {}
    preventive_pst_id_set = set(model.pst_ids) if hasattr(model, "pst_ids") else set()

    def curative_tap_bounds_rule(m, pst_mrid, co_mrid):
        if pst_mrid not in pst_tap_bounds_curative:
            log.warning(
                "_add_curative_pst_block: PST %s has curative variables but no "
                "entry in pst_tap_bounds_curative — constraint skipped for "
                "(pst=%s, contingency=%s) rather than crashing or guessing bounds",
                pst_mrid, pst_mrid, co_mrid,
            )
            return pyo.Constraint.Skip
        curative_tap_min, curative_tap_max = pst_tap_bounds_curative[pst_mrid]
        current_tap = int(getattr(pst_by_mrid[pst_mrid], "r0", 0))
        # preventive delta only when the transformer also has a preventive RA (else 0)
        preventive_delta = (
            m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid]
            if pst_mrid in preventive_pst_id_set else 0.0
        )
        combined_tap = (
            current_tap
            + preventive_delta
            + m.curative_tap_change_upward[pst_mrid, co_mrid]
            - m.curative_tap_change_downward[pst_mrid, co_mrid]
        )
        return (float(curative_tap_min), combined_tap, float(curative_tap_max))

    model.curative_tap_bounds = pyo.Constraint(
        model.curative_pst_contingency_pairs, rule=curative_tap_bounds_rule,
    )

    magnitude_triples = sorted(
        (pst_mrid, xne_mrid, co_mrid)
        for (pst_mrid, xne_mrid, co_mrid), entry in pst_cra_availability.items()
        if entry.get("available")
    )
    model.curative_tap_magnitude_triples = pyo.Set(initialize=magnitude_triples, dimen=3)

    def curative_tap_magnitude_rule(m, pst_mrid, xne_mrid, co_mrid):
        max_curative_taps = pst_cra_availability[(pst_mrid, xne_mrid, co_mrid)]["max_curative_taps"]
        return (
            m.curative_tap_change_upward[pst_mrid, co_mrid]
            + m.curative_tap_change_downward[pst_mrid, co_mrid]
            <= float(max_curative_taps)
        )

    model.curative_tap_magnitude = pyo.Constraint(
        model.curative_tap_magnitude_triples, rule=curative_tap_magnitude_rule,
    )

    # curative PST group: equal curative delta tap (up - down) per contingency, for triples
    # where both PSTs have a curative variable pair in that contingency
    curative_pair_set = set(curative_pst_contingency_pairs)
    group_triples = sorted(
        (pst_1, pst_2, co_mrid)
        for pst_1, pst_2, co_mrid in (nx_inputs.curative_pst_group_triples or [])
        if (pst_1, co_mrid) in curative_pair_set and (pst_2, co_mrid) in curative_pair_set
    )
    if group_triples:
        model.curative_pst_group_triples = pyo.Set(initialize=group_triples, dimen=3)

        def curative_pst_group_equality_rule(m, pst_1, pst_2, co_mrid):
            return (
                m.curative_tap_change_upward[pst_1, co_mrid] - m.curative_tap_change_downward[pst_1, co_mrid]
                == m.curative_tap_change_upward[pst_2, co_mrid] - m.curative_tap_change_downward[pst_2, co_mrid]
            )

        model.curative_pst_group_equality = pyo.Constraint(
            model.curative_pst_group_triples, rule=curative_pst_group_equality_rule,
        )

    return len(curative_pst_contingency_pairs)


def get_effective_rd_penalty_cost_per_mw(
    rd_list: list[RDUnit],
    penalty_reference_rd_pra: float,
    penalty_reference_rd_pra_per_tso: Optional[dict[str, float]] = None,
) -> dict[str, tuple[float, str]]:
    """{ra_mrid: (RA penalty_factor x penalty reference [EUR/MW], tso)}, with the
    per-TSO reference override applied. The single source of this product for
    the curative RD objective term AND results_curative_rd.csv (spec: the
    penalty is not recomputed a second time in the exporter)."""
    override = penalty_reference_rd_pra_per_tso or {}
    return {
        str(rd.mrid): (
            float(rd.penalty_factor) * float(override.get(rd.tso, penalty_reference_rd_pra)),
            rd.tso,
        )
        for rd in rd_list
    }


def _add_curative_rd_block(
    model,
    pyo,
    nx_inputs: NxMilpInputs,
    rd_inputs: RdMilpInputs,
    timestamp: str,
) -> int:
    """Curative RD variables, operation gating, combined preventive + curative Pmax/Pmin and the
    max-over-contingencies variables for the objective; returns the number of (bid,
    contingency) pairs. A curative bid is fixed to 0 if none of its RA's GLSK units has
    target_p > 0 (checked per bid: a bid belongs to the RA, not to one unit).
    activate_cra_xne_linkage is checked per generating unit (allowed if ANY curative RD RA of
    the unit is linked to the XNE): curative_rd_net_injection_g has no per-bid identity.
    """
    ra_kind_by_mrid: dict[str, RAKind] = {str(rd.mrid): rd.kind for rd in rd_inputs.rd_list}
    rd_by_ra_mrid: dict[str, RDUnit] = {str(rd.mrid): rd for rd in rd_inputs.rd_list}
    available_ra_mrids = {str(rd.mrid) for rd in rd_inputs.rd_list if rd.available}
    curative_bid_list = [
        bid for bid in rd_inputs.bid_list
        if ra_kind_by_mrid.get(str(bid.ra_mrid)) == RAKind.CURATIVE
        and str(bid.ra_mrid) in available_ra_mrids
    ]

    curative_bid_contingency_pairs: list[tuple[str, str]] = []
    for bid in curative_bid_list:
        rd_unit = rd_by_ra_mrid.get(str(bid.ra_mrid))
        if rd_unit is None:
            continue
        for co_mrid in rd_unit.linked_contingency_mrids:
            if co_mrid in nx_inputs.lf_nx:
                curative_bid_contingency_pairs.append((str(bid.mrid), co_mrid))

    if not curative_bid_contingency_pairs:
        log.info(
            "_add_curative_rd_block: %d curative RD bid(s) found but none have a "
            "linked_contingency_mrids entry matching a usable contingency in "
            "nx_inputs.lf_nx — no curative RD variables added (genuine outcome, "
            "not an error)",
            len(curative_bid_list),
        )
        return 0

    curative_bid_contingency_pairs = sorted(set(curative_bid_contingency_pairs))
    model.curative_bid_contingency_pairs = pyo.Set(initialize=curative_bid_contingency_pairs, dimen=2)
    model.curative_rd_volume_upward = pyo.Var(model.curative_bid_contingency_pairs, domain=pyo.NonNegativeReals)
    model.curative_rd_volume_downward = pyo.Var(model.curative_bid_contingency_pairs, domain=pyo.NonNegativeReals)

    bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in curative_bid_list}

    for bid_mrid, co_mrid in curative_bid_contingency_pairs:
        bid = bid_by_mrid[bid_mrid]
        available_mw = float(bid.available_mw.get(timestamp, 0.0))

        gu_ids_for_bid = list(rd_inputs.glsk.get(str(bid.ra_mrid), {}).keys())
        # on the ORIGINAL production: "in operation" must not flip because a preventive
        # iteration moved the unit
        original_target_p = rd_inputs.original_target_p_mw or {}
        unit_in_operation = any(
            float(original_target_p.get(
                gu_mrid, rd_inputs.generator_data.get(gu_mrid, {}).get("target_p", 0.0))) > 0.0
            for gu_mrid in gu_ids_for_bid
        )

        if not unit_in_operation:
            model.curative_rd_volume_upward[bid_mrid, co_mrid].fix(0.0)
            model.curative_rd_volume_downward[bid_mrid, co_mrid].fix(0.0)
            log.info(
                "_add_curative_rd_block: bid %s (RA %s) — no GLSK-linked generating "
                "unit has target_p > 0 (not in operation at %s) — "
                "curative_rd_volume_upward/downward fixed to 0.0 for contingency %s",
                bid_mrid, bid.ra_mrid, timestamp, co_mrid,
            )
            continue

        if bid.direction == BidDirection.UP:
            model.curative_rd_volume_upward[bid_mrid, co_mrid].setub(available_mw)
            model.curative_rd_volume_downward[bid_mrid, co_mrid].setub(0.0)
        else:
            model.curative_rd_volume_downward[bid_mrid, co_mrid].setub(available_mw)
            model.curative_rd_volume_upward[bid_mrid, co_mrid].setub(0.0)

    # curative lead time, the same rule and radp as _add_rd_block: an unsatisfied bid gets
    # both upper bounds 0 (bounded, not dropped, so the rows keep their shape)
    radp = _compute_radp(rd_inputs.raart, timestamp)
    blocked_bid_ids: set[str] = set()
    for bid_mrid, co_mrid in curative_bid_contingency_pairs:
        bid = bid_by_mrid[bid_mrid]
        if bid.lead_time_h <= 0:
            continue  # no lead time restriction for this bid
        if not _timestamp_is_usable(radp, bid.lead_time_h, timestamp):
            model.curative_rd_volume_upward[bid_mrid, co_mrid].setub(0.0)
            model.curative_rd_volume_downward[bid_mrid, co_mrid].setub(0.0)
            blocked_bid_ids.add(bid_mrid)
    for bid_mrid in sorted(blocked_bid_ids):
        log.info(
            "_add_curative_rd_block: bid %s lead_time_h=%.2f not satisfied by "
            "radp=%s at timestamp=%s — curative_rd_volume_upward/downward "
            "bounds fixed to 0.0",
            bid_mrid, bid_by_mrid[bid_mrid].lead_time_h, radp, timestamp,
        )

    curative_gu_contingency_pairs = sorted({
        (gu_mrid, co_mrid)
        for bid_mrid, co_mrid in curative_bid_contingency_pairs
        for gu_mrid in rd_inputs.glsk.get(str(bid_by_mrid[bid_mrid].ra_mrid), {})
    })
    model.curative_gu_contingency_pairs = pyo.Set(initialize=curative_gu_contingency_pairs, dimen=2)

    def curative_rd_net_injection_rule(m, gu_mrid, co_mrid):
        terms = [
            float(participation_factor)
            * (m.curative_rd_volume_upward[bid_mrid, co] - m.curative_rd_volume_downward[bid_mrid, co])
            for bid_mrid, co in curative_bid_contingency_pairs
            if co == co_mrid
            for participation_factor in [rd_inputs.glsk.get(bid_by_mrid[bid_mrid].ra_mrid, {}).get(gu_mrid)]
            if participation_factor is not None
        ]
        return sum(terms) if terms else 0.0

    model.curative_rd_net_injection_g = pyo.Expression(
        model.curative_gu_contingency_pairs, rule=curative_rd_net_injection_rule,
    )

    # combined preventive + curative Pmax/Pmin per (gu, contingency) with a curative
    # contribution, on top of the preventive-only constraint
    def combined_pmax_pmin_rule(m, gu_mrid, co_mrid):
        gu_data = rd_inputs.generator_data.get(gu_mrid, {})
        target_p = float(gu_data.get("target_p", gu_data.get("initial_p", 0.0)))
        max_p = float(gu_data.get("max_p", 0.0))
        min_p = float(gu_data.get("min_p", 0.0))
        preventive_injection = m.rd_net_injection_g[gu_mrid] if hasattr(m, "rd_net_injection_g") and gu_mrid in m.gu_ids else 0.0
        return (
            min_p,
            target_p + preventive_injection + m.curative_rd_net_injection_g[gu_mrid, co_mrid],
            max_p,
        )

    model.combined_pmax_pmin_constraint = pyo.Constraint(
        model.curative_gu_contingency_pairs, rule=combined_pmax_pmin_rule,
    )

    # max-over-contingencies variable for the objective: pay for the worst-case reservation,
    # not the sum over contingencies (only one contingency happens)
    curative_bid_ids = sorted({bid_mrid for bid_mrid, _co in curative_bid_contingency_pairs})
    model.bid_ids_curative = pyo.Set(initialize=curative_bid_ids)
    model.max_curative_rd_volume_upward = pyo.Var(model.bid_ids_curative, domain=pyo.NonNegativeReals)
    model.max_curative_rd_volume_downward = pyo.Var(model.bid_ids_curative, domain=pyo.NonNegativeReals)

    def max_curative_upward_rule(m, bid_mrid, co_mrid):
        return m.max_curative_rd_volume_upward[bid_mrid] >= m.curative_rd_volume_upward[bid_mrid, co_mrid]

    def max_curative_downward_rule(m, bid_mrid, co_mrid):
        return m.max_curative_rd_volume_downward[bid_mrid] >= m.curative_rd_volume_downward[bid_mrid, co_mrid]

    model.max_curative_upward_constraint = pyo.Constraint(
        model.curative_bid_contingency_pairs, rule=max_curative_upward_rule,
    )
    model.max_curative_downward_constraint = pyo.Constraint(
        model.curative_bid_contingency_pairs, rule=max_curative_downward_rule,
    )

    return len(curative_bid_contingency_pairs)


def _add_nx_block(
    model,
    pyo,
    nx_inputs: NxMilpInputs,
    pst_inputs: Optional[PstMilpInputs],
    rd_inputs: Optional[RdMilpInputs],
    timestamp: str,
    branch_limits: dict[str, float],
    branch_ae_types: dict[str, "AEType"],
    branch_sides: dict[str, int],
) -> int:
    """N-X constraints; returns the number of PATL pairs. PATL candidates are ALL secured
    branches filtered by min_loading_threshold_pct_nx against lf_nx (not the N-0-filtered
    set: a branch light at N-0 can be heavy after a contingency). PST/RD terms enter only
    when that type's preventive block exists. Curative PST variables are built first (the
    shared _nx_pst_and_rd_effect needs them); the TATL and scanned constraints reuse it.
    """
    if (
        pst_inputs is not None
        and pst_inputs.available_curative_pst_list
        and nx_inputs.pst_cra_availability
    ):
        _add_curative_pst_block(model, pyo, nx_inputs, pst_inputs)

    if rd_inputs is not None and rd_inputs.bid_list:
        # curative RD is gated only on rd_inputs carrying bids, not on the preventive RD block
        # (rd_inputs exists for curative-only RD: workflow_gates.rd_inputs_required)
        _add_curative_rd_block(model, pyo, nx_inputs, rd_inputs, timestamp)

    # Same rule as the N-0 side (_branch_is_above_threshold): a branch with a limit
    # <= 0 A cannot be evaluated and is excluded (one warning per branch).
    nx_unusable_limit_branches = sorted(b for b, lim in branch_limits.items() if float(lim) <= 0.0)
    for branch_mrid in nx_unusable_limit_branches:
        log.warning(
            "N-X: branch %s has a limit of %.1f A (<= 0) - excluded from the N-X constraints",
            branch_mrid, float(branch_limits[branch_mrid]),
        )
    nx_unusable_limit_set = set(nx_unusable_limit_branches)

    all_secured_branch_mrids = [
        branch_mrid for branch_mrid in branch_limits
        if branch_ae_types.get(branch_mrid) == AEType.SECURED
        and branch_mrid not in nx_unusable_limit_set
    ]

    # A pair is only built from usable data: a missing or NaN N-X current, or a NaN
    # sensitivity of the branch under the contingency, skips the pair (never 0.0).
    def _nan_sensitivity_branches(contingency_mrid: str) -> set:
        branches = set()
        for table in (nx_inputs.sensitivity_pst_nx, nx_inputs.sensitivity_rd_nx):
            for (branch, _ra), value in (table.get(contingency_mrid) or {}).items():
                if value is not None and math.isnan(float(value)):
                    branches.add(branch)
        return branches

    def _pair_current_or_skip(branch_mrid, contingency_mrid, nan_sens_branches, skipped, side=None):
        """The side-selected N-X current of the pair, or None (and the skip is recorded)."""
        side = branch_sides.get(branch_mrid, 1) if side is None else side
        per_side_currents = nx_inputs.lf_nx[contingency_mrid].get(branch_mrid)
        current = select_by_side(per_side_currents, side, branch_mrid) if per_side_currents else None
        if current is None or math.isnan(float(current)):
            skipped.setdefault(contingency_mrid, {}).setdefault("current", []).append(branch_mrid)
            return None
        if branch_mrid in nan_sens_branches:
            skipped.setdefault(contingency_mrid, {}).setdefault("sensitivity", []).append(branch_mrid)
            return None
        return current

    def _warn_skipped_pairs(kind: str, skipped: dict) -> None:
        for contingency_mrid in sorted(skipped):
            for reason, label in (("current", "no usable N-X current (missing or NaN)"),
                                  ("sensitivity", "NaN sensitivity")):
                branches = skipped[contingency_mrid].get(reason)
                if branches:
                    log.warning(
                        "N-X %s: contingency %s: %d pair(s) skipped - %s: %s",
                        kind, contingency_mrid, len(branches), label, sorted(branches),
                    )

    def _loaded_pairs(kind: str, branch_mrids: list[str]) -> list[tuple[str, str]]:
        """(branch, contingency) pairs with a usable current whose loading against the branch's
        limit (all limits > 0 here) reaches min_loading_threshold_pct_nx."""
        pairs: list[tuple[str, str]] = []
        skipped: dict = {}
        for contingency_mrid in sorted(nx_inputs.lf_nx):
            nan_sens_branches = _nan_sensitivity_branches(contingency_mrid)
            for branch_mrid in branch_mrids:
                current = _pair_current_or_skip(branch_mrid, contingency_mrid, nan_sens_branches, skipped)
                if current is None:
                    continue
                loading_pct = (float(current) / float(branch_limits[branch_mrid])) * 100.0
                if loading_pct >= float(nx_inputs.min_loading_threshold_pct_nx):
                    pairs.append((branch_mrid, contingency_mrid))
        _warn_skipped_pairs(kind, skipped)
        return pairs

    nx_pairs = _loaded_pairs("PATL", all_secured_branch_mrids)

    model.nx_branch_contingency_pairs = pyo.Set(initialize=nx_pairs, dimen=2)
    model.nx_patl_overload_slack = pyo.Var(model.nx_branch_contingency_pairs, domain=pyo.NonNegativeReals)

    pst_degrees_per_tap = pst_inputs.pst_degrees_per_tap if pst_inputs is not None else {}
    pst_by_mrid_for_linkage: dict[str, PST] = (
        {str(pst.mrid): pst for pst in pst_inputs.available_curative_pst_list} if pst_inputs is not None else {}
    )

    def _curative_xne_linkage_allows(pst_mrid: str, branch_mrid: str) -> bool:
        """True when activate_cra_xne_linkage is False; else (pst_mrid, branch_mrid) must be
        in that PST's linked_xne_mrids."""
        if not nx_inputs.activate_cra_xne_linkage:
            return True
        pst = pst_by_mrid_for_linkage.get(pst_mrid)
        return pst is not None and branch_mrid in pst.linked_xne_mrids

    rd_by_mrid_for_linkage: dict[str, RDUnit] = (
        {str(rd.mrid): rd for rd in rd_inputs.rd_list} if rd_inputs is not None else {}
    )

    def _curative_rd_xne_linkage_allows(gu_mrid: str, branch_mrid: str) -> bool:
        """As _curative_xne_linkage_allows, per generating unit: allowed if ANY curative RD RA
        contributing to the unit via GLSK is linked to the branch."""
        if not nx_inputs.activate_cra_xne_linkage:
            return True
        if rd_inputs is None:
            return False
        for ra_mrid, participation in rd_inputs.glsk.items():
            if gu_mrid not in participation:
                continue
            rd_unit = rd_by_mrid_for_linkage.get(ra_mrid)
            if rd_unit is not None and branch_mrid in rd_unit.linked_xne_mrids:
                return True
        return False

    curative_pst_ids_by_contingency: dict[str, list[str]] = {}
    if hasattr(model, "curative_pst_contingency_pairs"):
        for _pst_mrid, _co_mrid in sorted(model.curative_pst_contingency_pairs):
            curative_pst_ids_by_contingency.setdefault(_co_mrid, []).append(_pst_mrid)


    def _nx_pst_and_rd_effect(m, branch_mrid, contingency_mrid):
        """RA-effect term on a branch under a contingency, shared by the PATL, TATL and scanned
        constraints (it does not depend on the limit). Preventive PST/RD terms when their
        block exists. Curative PST: sensitivity x (curative up - down) for the same PST, only
        where pst_cra_availability marks (pst, branch, c) available (and, with
        activate_cra_xne_linkage, the branch is linked). Curative RD: gated on
        curative_rd_net_injection_g, independently of the preventive RD block.
        """
        pst_term = 0.0
        if hasattr(m, "tap_change_upward"):
            sensitivity_for_contingency = nx_inputs.sensitivity_pst_nx.get(contingency_mrid, {})
            pst_term = sum(
                float(sensitivity_for_contingency.get((branch_mrid, pst_mrid), 0.0))
                * float(pst_degrees_per_tap[pst_mrid])
                * (m.tap_change_upward[pst_mrid] - m.tap_change_downward[pst_mrid])
                for pst_mrid in m.pst_ids
                if pst_mrid in pst_degrees_per_tap
            )


        # curative PST term: the curative PSTs with a variable pair for THIS contingency (works
        # without preventive PSTs)
        if hasattr(m, "curative_tap_change_upward"):
            sensitivity_for_contingency = nx_inputs.sensitivity_pst_nx.get(contingency_mrid, {})
            pst_term += sum(
                float(sensitivity_for_contingency.get((branch_mrid, pst_mrid), 0.0))
                * float(pst_degrees_per_tap[pst_mrid])
                * (
                    m.curative_tap_change_upward[pst_mrid, contingency_mrid]
                    - m.curative_tap_change_downward[pst_mrid, contingency_mrid]
                )
                for pst_mrid in curative_pst_ids_by_contingency.get(contingency_mrid, [])
                if pst_mrid in pst_degrees_per_tap
                and (pst_mrid, branch_mrid, contingency_mrid) in m.curative_tap_magnitude_triples
                and _curative_xne_linkage_allows(pst_mrid, branch_mrid)
            )

        rd_term = 0.0
        if hasattr(m, "rd_net_injection_g"):
            sensitivity_for_contingency = nx_inputs.sensitivity_rd_nx.get(contingency_mrid, {})
            rd_term = sum(
                float(sensitivity_for_contingency.get((branch_mrid, gu_mrid), 0.0))
                * m.rd_net_injection_g[gu_mrid]
                for gu_mrid in m.gu_ids
            )

        if hasattr(m, "curative_rd_net_injection_g"):
            sensitivity_for_contingency = nx_inputs.sensitivity_rd_nx.get(contingency_mrid, {})
            rd_term += sum(
                float(sensitivity_for_contingency.get((branch_mrid, gu_mrid), 0.0))
                * m.curative_rd_net_injection_g[gu_mrid, co_mrid]
                for gu_mrid, co_mrid in m.curative_gu_contingency_pairs
                if co_mrid == contingency_mrid
                and _curative_rd_xne_linkage_allows(gu_mrid, branch_mrid)
            )

        return pst_term, rd_term

    def _nx_curative_effect_ampere(branch_mrid: str, contingency_mrid: str) -> float:
        """The linearised effect of the CURATIVE actions of the SOLVED model on the
        N-X current of (branch, contingency), in A: exactly the curative terms of
        _nx_pst_and_rd_effect, evaluated at the solution. 0.0 when the model has no
        curative action for the pair. Used by the convergence check (the AC N-X
        current plus this effect is the post-curative current the PATL/TATL
        constraints bound). Only valid after the model was solved."""
        effect = 0.0
        if hasattr(model, "curative_tap_change_upward"):
            sensitivity_for_contingency = nx_inputs.sensitivity_pst_nx.get(contingency_mrid, {})
            effect += sum(
                float(sensitivity_for_contingency.get((branch_mrid, pst_mrid), 0.0))
                * float(pst_degrees_per_tap[pst_mrid])
                * (
                    pyo.value(model.curative_tap_change_upward[pst_mrid, contingency_mrid])
                    - pyo.value(model.curative_tap_change_downward[pst_mrid, contingency_mrid])
                )
                for pst_mrid in curative_pst_ids_by_contingency.get(contingency_mrid, [])
                if pst_mrid in pst_degrees_per_tap
                and (pst_mrid, branch_mrid, contingency_mrid) in model.curative_tap_magnitude_triples
                and _curative_xne_linkage_allows(pst_mrid, branch_mrid)
            )
        if hasattr(model, "curative_rd_net_injection_g"):
            sensitivity_for_contingency = nx_inputs.sensitivity_rd_nx.get(contingency_mrid, {})
            effect += sum(
                float(sensitivity_for_contingency.get((branch_mrid, gu_mrid), 0.0))
                * pyo.value(model.curative_rd_net_injection_g[gu_mrid, co_mrid])
                for gu_mrid, co_mrid in model.curative_gu_contingency_pairs
                if co_mrid == contingency_mrid
                and _curative_rd_xne_linkage_allows(gu_mrid, branch_mrid)
            )
        return float(effect)

    model.nx_curative_effect_ampere = _nx_curative_effect_ampere
    # what the convergence check monitors, with the side and limit the constraints use
    model.overload_monitoring["nx_patl"] = {
        (branch_mrid, contingency_mrid): (branch_sides.get(branch_mrid, 1), float(branch_limits[branch_mrid]))
        for branch_mrid, contingency_mrid in nx_pairs
    }

    def nx_patl_loading_rule(m, branch_mrid, contingency_mrid):
        side = branch_sides.get(branch_mrid, 1)
        nx_current_ampere = select_by_side(
            nx_inputs.lf_nx[contingency_mrid].get(branch_mrid, {}), side, branch_mrid,
        ) or 0.0
        patl_ampere = float(branch_limits[branch_mrid])
        pst_term, rd_term = _nx_pst_and_rd_effect(m, branch_mrid, contingency_mrid)

        return (
            float(nx_current_ampere) + pst_term + rd_term
            <= patl_ampere + m.nx_patl_overload_slack[branch_mrid, contingency_mrid]
        )

    model.nx_patl_loading = pyo.Constraint(model.nx_branch_contingency_pairs, rule=nx_patl_loading_rule)

    # N-X TATL constraint, separate from PATL (a branch can have both). No loading pre-filter:
    # every usable pair of a branch with a TATL; only when tatl_data is not empty.
    if nx_inputs.tatl_data:
        # SECURED branches only, also when tatl_data was built directly (scanned branches have
        # no TATL)
        tatl_pairs = []
        skipped_tatl_pairs: dict = {}
        for contingency_mrid in sorted(nx_inputs.lf_nx):
            nan_sens_branches = _nan_sensitivity_branches(contingency_mrid)
            for branch_mrid in sorted(nx_inputs.tatl_data):
                if branch_ae_types.get(branch_mrid) != AEType.SECURED:
                    continue
                if _pair_current_or_skip(
                    branch_mrid, contingency_mrid, nan_sens_branches, skipped_tatl_pairs,
                    side=int(nx_inputs.tatl_data[branch_mrid]["side"]),
                ) is None:
                    continue
                tatl_pairs.append((branch_mrid, contingency_mrid))
        _warn_skipped_pairs("TATL", skipped_tatl_pairs)
        model.nx_tatl_branch_contingency_pairs = pyo.Set(initialize=tatl_pairs, dimen=2)
        model.nx_tatl_overload_slack = pyo.Var(
            model.nx_tatl_branch_contingency_pairs, domain=pyo.NonNegativeReals,
        )

        def nx_tatl_loading_rule(m, branch_mrid, contingency_mrid):
            tatl_entry = nx_inputs.tatl_data[branch_mrid]
            side = int(tatl_entry["side"])
            nx_current_ampere = select_by_side(
                nx_inputs.lf_nx[contingency_mrid].get(branch_mrid, {}), side, branch_mrid,
            ) or 0.0
            tatl_limit_ampere = float(tatl_entry["tatl_limit_ampere"])
            pst_term, rd_term = _nx_pst_and_rd_effect(m, branch_mrid, contingency_mrid)

            return (
                float(nx_current_ampere) + pst_term + rd_term
                <= tatl_limit_ampere + m.nx_tatl_overload_slack[branch_mrid, contingency_mrid]
            )

        model.nx_tatl_loading = pyo.Constraint(
            model.nx_tatl_branch_contingency_pairs, rule=nx_tatl_loading_rule,
        )
        model.overload_monitoring["nx_tatl"] = {
            (branch_mrid, contingency_mrid): (
                int(nx_inputs.tatl_data[branch_mrid]["side"]),
                float(nx_inputs.tatl_data[branch_mrid]["tatl_limit_ampere"]),
            )
            for branch_mrid, contingency_mrid in tatl_pairs
        }

    # N-X scanned-element constraint: as PATL (same _nx_pst_and_rd_effect), for SCANNED
    # branches against the effective limit in branch_limits. Scanned elements have no TATL.
    all_scanned_branch_mrids = [
        branch_mrid for branch_mrid in branch_limits
        if branch_ae_types.get(branch_mrid) == AEType.SCANNED
        and branch_mrid not in nx_unusable_limit_set
    ]

    nx_scanned_pairs = _loaded_pairs("scanned", all_scanned_branch_mrids)

    model.nx_scanned_branch_contingency_pairs = pyo.Set(initialize=nx_scanned_pairs, dimen=2)
    model.nx_scanned_overload_slack = pyo.Var(
        model.nx_scanned_branch_contingency_pairs, domain=pyo.NonNegativeReals,
    )

    def nx_scanned_loading_rule(m, branch_mrid, contingency_mrid):
        side = branch_sides.get(branch_mrid, 1)
        nx_current_ampere = select_by_side(
            nx_inputs.lf_nx[contingency_mrid].get(branch_mrid, {}), side, branch_mrid,
        ) or 0.0
        effective_limit_ampere = float(branch_limits[branch_mrid])
        pst_term, rd_term = _nx_pst_and_rd_effect(m, branch_mrid, contingency_mrid)

        return (
            float(nx_current_ampere) + pst_term + rd_term
            <= effective_limit_ampere + m.nx_scanned_overload_slack[branch_mrid, contingency_mrid]
        )

    model.nx_scanned_loading = pyo.Constraint(
        model.nx_scanned_branch_contingency_pairs, rule=nx_scanned_loading_rule,
    )

    return len(nx_pairs)


def _add_ra_activation_and_count_constraints(
    model,
    pyo,
    rd_inputs: RdMilpInputs,
    bid_ids: list[str],
    bid_by_mrid: dict[str, PowerBid],
    timestamp: str,
) -> None:
    """Binary ra_activated variables and per-TSO RA count limits; called only when the RD
    block was built. big-M per bid = its own available_mw[timestamp] (its volume upper
    bound): the tightest valid value, avoiding a large shared big-M.
    """
    ra_mrid_to_tso: dict[str, str] = {str(rd.mrid): rd.tso for rd in rd_inputs.rd_list}
    ra_mrids_in_model = sorted({str(bid_by_mrid[b].ra_mrid) for b in bid_ids})

    model.ra_mrids = pyo.Set(initialize=ra_mrids_in_model)
    model.ra_activated = pyo.Var(model.ra_mrids, domain=pyo.Binary)

    def big_m_activation_rule(m, bid_mrid):
        bid = bid_by_mrid[bid_mrid]
        big_m = float(bid.available_mw.get(timestamp, 0.0))
        # linked to the CUMULATIVE volume: an RA used in an
        # earlier iteration stays "activated" as long as its cumulative net volume
        # is non-zero. The binary is NOT fixed to 1.
        return (
            m.rd_cumulative_volume_term[bid_mrid]
            <= big_m * m.ra_activated[str(bid.ra_mrid)]
        )

    model.ra_activation_big_m = pyo.Constraint(model.bid_ids, rule=big_m_activation_rule)

    def _activated_sum_for_tso(m, tso: str):
        return sum(
            m.ra_activated[ra_mrid] for ra_mrid in ra_mrids_in_model
            if ra_mrid_to_tso.get(ra_mrid) == tso
        )

    # per-TSO per-timestamp RA count: only TSOs with a limit (a TSO with a limit and no RA
    # gets a trivially satisfied constraint)
    max_ra_count_per_timestamp_tso = rd_inputs.max_ra_count_per_timestamp_tso or {}
    if max_ra_count_per_timestamp_tso:
        model.tsos_with_timestamp_ra_limit = pyo.Set(initialize=sorted(max_ra_count_per_timestamp_tso.keys()))

        if not rd_inputs.ra_limit_constraint_hard:
            model.ra_count_slack_per_timestamp = pyo.Var(
                model.tsos_with_timestamp_ra_limit, domain=pyo.NonNegativeReals,
            )

        def ra_count_limit_per_timestamp_rule(m, tso):
            slack = m.ra_count_slack_per_timestamp[tso] if hasattr(m, "ra_count_slack_per_timestamp") else 0.0
            return _activated_sum_for_tso(m, tso) - slack <= max_ra_count_per_timestamp_tso[tso]

        model.ra_count_limit_per_timestamp = pyo.Constraint(
            model.tsos_with_timestamp_ra_limit, rule=ra_count_limit_per_timestamp_rule,
        )

    # per-TSO per-timeframe RA count: always soft (ra_count_slack_per_timeframe); with one
    # timestamp it constrains the same solve as the per-timestamp limit
    max_ra_count_per_timeframe_tso = rd_inputs.max_ra_count_per_timeframe_tso or {}
    if max_ra_count_per_timeframe_tso:
        model.tsos_with_timeframe_ra_limit = pyo.Set(initialize=sorted(max_ra_count_per_timeframe_tso.keys()))
        model.ra_count_slack_per_timeframe = pyo.Var(
            model.tsos_with_timeframe_ra_limit, domain=pyo.NonNegativeReals,
        )

        def ra_count_limit_per_timeframe_rule(m, tso):
            return (
                _activated_sum_for_tso(m, tso) - m.ra_count_slack_per_timeframe[tso]
                <= max_ra_count_per_timeframe_tso[tso]
            )

        model.ra_count_limit_per_timeframe = pyo.Constraint(
            model.tsos_with_timeframe_ra_limit, rule=ra_count_limit_per_timeframe_rule,
        )


def _add_ra_group_volume_constraints(
    model,
    pyo,
    rd_inputs: RdMilpInputs,
    bid_ids: list[str],
    bid_by_mrid: dict[str, PowerBid],
) -> None:
    """Restrictive RA group volume limits, hard (no slack); called only when the RD block was
    built. Per group: sum of its bids' rd_volume_upward <= max_regulating_up (downward
    likewise), for each limit that is not None; a group without limits is logged.
    """
    ra_groups = rd_inputs.ra_groups or {}
    if not ra_groups:
        return

    group_bid_ids: dict[str, list[str]] = {}
    for group_mrid, group_data in ra_groups.items():
        member_ra_mrids = set(group_data.get("ra_mrids", []))
        group_bid_ids[group_mrid] = [
            bid_mrid for bid_mrid in bid_ids
            if str(bid_by_mrid[bid_mrid].ra_mrid) in member_ra_mrids
        ]

    groups_with_upward_limit = {
        g: data for g, data in ra_groups.items()
        if data.get("max_regulating_up") is not None and group_bid_ids.get(g)
    }
    groups_with_downward_limit = {
        g: data for g, data in ra_groups.items()
        if data.get("max_regulating_down") is not None and group_bid_ids.get(g)
    }

    for group_mrid, data in ra_groups.items():
        if data.get("max_regulating_up") is None and data.get("max_regulating_down") is None:
            log.warning(
                "RA group %s (restrictive) has no resolved volume limit in "
                "either direction — no group volume constraint added for it",
                group_mrid,
            )
        elif not group_bid_ids.get(group_mrid):
            log.warning(
                "RA group %s (restrictive) has a resolved volume limit but "
                "no member RA has a bid in the model — no group volume "
                "constraint added for it",
                group_mrid,
            )

    if groups_with_upward_limit:
        model.ra_groups_with_upward_limit = pyo.Set(initialize=sorted(groups_with_upward_limit.keys()))

        def group_volume_upward_rule(m, group_mrid):
            if getattr(m, "rd_cumulative_used_in_any_bid", False):
                # cumulative group volume (earlier iterations + this solve)
                return (
                    sum(m.rd_cumulative_up_term[b] for b in group_bid_ids[group_mrid])
                    <= groups_with_upward_limit[group_mrid]["max_regulating_up"]
                )
            return (
                sum(m.rd_volume_upward[b] for b in group_bid_ids[group_mrid])
                <= groups_with_upward_limit[group_mrid]["max_regulating_up"]
            )

        model.ra_group_volume_upward_limit = pyo.Constraint(
            model.ra_groups_with_upward_limit, rule=group_volume_upward_rule,
        )

    if groups_with_downward_limit:
        model.ra_groups_with_downward_limit = pyo.Set(initialize=sorted(groups_with_downward_limit.keys()))

        def group_volume_downward_rule(m, group_mrid):
            if getattr(m, "rd_cumulative_used_in_any_bid", False):
                return (
                    sum(m.rd_cumulative_down_term[b] for b in group_bid_ids[group_mrid])
                    <= groups_with_downward_limit[group_mrid]["max_regulating_down"]
                )
            return (
                sum(m.rd_volume_downward[b] for b in group_bid_ids[group_mrid])
                <= groups_with_downward_limit[group_mrid]["max_regulating_down"]
            )

        model.ra_group_volume_downward_limit = pyo.Constraint(
            model.ra_groups_with_downward_limit, rule=group_volume_downward_rule,
        )


# ---------------------------------------------------------------------------
# Composable model builder
# ---------------------------------------------------------------------------

def build_n0_milp_model(
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_initial: dict[str, dict[int, float]],
    penalty_cost_overload_n0: float,
    pst_inputs: Optional[PstMilpInputs] = None,
    rd_inputs: Optional[RdMilpInputs] = None,
    nx_inputs: Optional[NxMilpInputs] = None,
    min_loading_threshold_pct: float = 0.0,
    scanned_element_constraint_hard: bool = True,
    scanned_element_penalty_eur_per_ka: float = 0.0,
    lf_original: Optional[dict[str, dict[int, float]]] = None,
):
    """Build the MILP: PST-only, RD-only or PST + RD, selected by which of pst_inputs /
    rd_inputs is non-None (both None -> ValueError before any model is created; an RD block
    that adds nothing is logged, not raised). nx_inputs adds the N-X constraints on top.
    lf_initial: {branch: {1: A, 2: A}}, side-selected per branch.
    scanned_element_constraint_hard (default True) / scanned_element_penalty_eur_per_ka: the
    N-0 scanned constraint, independent of the RA types.
    """
    if pst_inputs is None and rd_inputs is None and nx_inputs is None:
        raise ValueError(
            "At least one of pst_inputs, rd_inputs, or nx_inputs must be "
            "provided — there is nothing to optimise with all three absent. "
            "nx_inputs alone (even without dispatchable capacity) is valid: the "
            "slacks absorb what nothing can resolve."
        )

    try:
        import pyomo.environ as pyo
    except ImportError as exc:
        raise ImportError("pyomo is required to build the MILP model") from exc

    # lf_original: the scanned-element effective limit is
    # "at least the pre-RA initial loading", so it stays anchored to the
    # ORIGINAL network's N-0 load flow while the flows below use lf_initial (the
    # current operating point). None = lf_initial is the original.
    branch_limits, branch_ae_types = _get_monitored_branch_limits_and_ae_types(
        ae_flat_list, timestamp, lf_original if lf_original is not None else lf_initial,
    )
    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    branch_ids = [
        branch_mrid
        for branch_mrid in sorted(branch_limits)
        if _branch_is_above_threshold(
            branch_mrid, lf_initial, branch_limits, branch_sides, min_loading_threshold_pct
        )
    ]
    # same rule as the N-X pairs: a NaN N-0 sensitivity (PST or RD) excludes the branch
    nan_sensitivity_branches = {
        branch_mrid
        for table in (
            pst_inputs.sensitivity_pst_n0_pruned if pst_inputs is not None else {},
            rd_inputs.sensitivity_rd_n0_pruned if rd_inputs is not None else {},
        )
        for (branch_mrid, _ra), value in table.items()
        if value is not None and math.isnan(float(value))
    }
    for branch_mrid in sorted(nan_sensitivity_branches & set(branch_ids)):
        log.warning("Branch %s has a NaN N-0 sensitivity; excluding from MILP", branch_mrid)
    branch_ids = [b for b in branch_ids if b not in nan_sensitivity_branches]
    # secured branches -> xne_loading_n0 (PATL), scanned -> scanned_element_n0 (effective
    # limit); both read branch_limits, which already holds the type-correct limit
    secured_branch_ids = [b for b in branch_ids if branch_ae_types.get(b) == AEType.SECURED]
    scanned_branch_ids = [b for b in branch_ids if branch_ae_types.get(b) == AEType.SCANNED]

    model = pyo.ConcreteModel()
    # The elements whose overload the linearisation convergence check follows, with the
    # side and the limit (A) the model's own constraints use: N-0 = every branch of
    # model.branch_ids (PATL for secured, effective limit for scanned branches);
    # N-X PATL / TATL = the pairs of the N-X constraints (filled by _add_nx_block).
    model.overload_monitoring = {
        "n0": {b: (branch_sides.get(b, 1), float(branch_limits[b])) for b in branch_ids},
        "nx_patl": {},
        "nx_tatl": {},
    }
    # model.branch_ids is the combined secured + scanned set over which
    # pst_effect_on_branch / rd_effect_on_branch are indexed
    model.branch_ids = pyo.Set(initialize=branch_ids)
    model.secured_branch_ids = pyo.Set(initialize=secured_branch_ids)
    # overload_slack_n0: secured branches only (scanned have scanned_overload_slack)
    model.overload_slack_n0 = pyo.Var(model.secured_branch_ids, domain=pyo.NonNegativeReals)

    pst_ids: list[str] = []
    if pst_inputs is not None:
        pst_ids = _add_pst_block(model, pyo, pst_inputs, branch_ids)

    if rd_inputs is not None:
        rd_block_added = _add_rd_block(model, pyo, rd_inputs, timestamp, branch_ids)
        if rd_block_added:
            # RA count: only once RD variables exist
            bid_by_mrid: dict[str, PowerBid] = {str(bid.mrid): bid for bid in rd_inputs.bid_list}
            _add_ra_activation_and_count_constraints(
                model, pyo, rd_inputs, list(model.bid_ids), bid_by_mrid, timestamp,
            )
            # restrictive RA group volume limits
            _add_ra_group_volume_constraints(
                model, pyo, rd_inputs, list(model.bid_ids), bid_by_mrid,
            )

    # hard RD balance, sum_g rd_net_injection_g[g] = 0, no slack: added when
    # rd_net_injection_g exists (not merely rd_inputs, whose block can add nothing)
    if hasattr(model, "rd_net_injection_g"):
        def rd_balancing_n0_rule(m):
            return sum(m.rd_net_injection_g[gu_mrid] for gu_mrid in m.gu_ids) == 0.0

        model.rd_balancing_n0 = pyo.Constraint(rule=rd_balancing_n0_rule)

    def xne_loading_n0_rule(m, branch_mrid):
        side = branch_sides.get(branch_mrid, 1)
        initial_current = select_by_side(lf_initial.get(branch_mrid, {}), side, branch_mrid) or 0.0
        patl_ampere = float(branch_limits[branch_mrid])
        pst_term = m.pst_effect_on_branch[branch_mrid] if hasattr(m, "pst_effect_on_branch") else 0.0
        rd_term = m.rd_effect_on_branch[branch_mrid] if hasattr(m, "rd_effect_on_branch") else 0.0
        return float(initial_current) + pst_term + rd_term <= patl_ampere + m.overload_slack_n0[branch_mrid]

    # secured_branch_ids only (model.branch_ids also holds the scanned branches)
    model.xne_loading_n0 = pyo.Constraint(model.secured_branch_ids, rule=xne_loading_n0_rule)

    # N-0 scanned element constraint on the same effect Expressions; only when a scanned
    # branch survived the min_loading_threshold_pct pre-filter
    if scanned_branch_ids:
        model.scanned_branch_ids = pyo.Set(initialize=scanned_branch_ids)

        if not scanned_element_constraint_hard:
            model.scanned_overload_slack = pyo.Var(model.scanned_branch_ids, domain=pyo.NonNegativeReals)

        def scanned_element_n0_rule(m, branch_mrid):
            side = branch_sides.get(branch_mrid, 1)
            initial_current = select_by_side(lf_initial.get(branch_mrid, {}), side, branch_mrid) or 0.0
            effective_limit_ampere = float(branch_limits[branch_mrid])
            pst_term = m.pst_effect_on_branch[branch_mrid] if hasattr(m, "pst_effect_on_branch") else 0.0
            rd_term = m.rd_effect_on_branch[branch_mrid] if hasattr(m, "rd_effect_on_branch") else 0.0
            slack = m.scanned_overload_slack[branch_mrid] if hasattr(m, "scanned_overload_slack") else 0.0
            return float(initial_current) + pst_term + rd_term <= effective_limit_ampere + slack

        model.scanned_element_n0 = pyo.Constraint(model.scanned_branch_ids, rule=scanned_element_n0_rule)

    # N-X constraints when nx_inputs is given; RA-type terms gated inside _add_nx_block
    nx_pair_count = 0
    if nx_inputs is not None:
        nx_pair_count = _add_nx_block(
            model, pyo, nx_inputs, pst_inputs, rd_inputs, timestamp,
            branch_limits, branch_ae_types, branch_sides,
        )
        _log_if_changed(
            "nx_pair_count", nx_pair_count,
            "N-X PATL loading constraint added for %d (branch, contingency) pair(s)",
            nx_pair_count,
        )

    objective_terms = []
    # Results summary: the slack and RA-count penalty terms are recorded by name
    # (the very expressions that are summed into the objective) so the summary
    # reports them without repeating the penalty coefficients.
    model.objective_penalty_term_expressions = {}

    def _append_named_term(name, expression):
        objective_terms.append(expression)
        model.objective_penalty_term_expressions[name] = expression

    if hasattr(model, "tap_change_upward"):
        effective_penalties = _get_effective_penalty_costs(
            pst_inputs.available_preventive_pst_list,
            pst_inputs.penalty_reference_pst_pra,
            pst_inputs.penalty_reference_pst_pra_per_tso,
        )
        # model.pst_ids (a deduplicated Set): a PST with a preventive and a curative RA appears
        # twice in pst_ids and would be costed twice
        objective_terms.append(
            sum(
                effective_penalties[pst_mrid]
                * (model.cum_tap_up_term[pst_mrid] + model.cum_tap_down_term[pst_mrid])
                for pst_mrid in model.pst_ids
            )
        )
    # curative PST penalty: SUM over (PST, contingency) of the curative RA's effective penalty
    # x (up + down); a sum, not a max (unlike curative RD). The TATL duration is in the tap
    # cap. Penalty from the curative PST object, same helper and reference as preventive.
    # Absent without curative PST pairs.
    if hasattr(model, "curative_pst_contingency_pairs"):
        curative_effective_penalties = _get_effective_penalty_costs(
            pst_inputs.available_curative_pst_list,
            pst_inputs.penalty_reference_pst_pra,
            pst_inputs.penalty_reference_pst_pra_per_tso,
        )
        objective_terms.append(
            sum(
                curative_effective_penalties[pst_mrid]
                * (
                    model.curative_tap_change_upward[pst_mrid, contingency_mrid]
                    + model.curative_tap_change_downward[pst_mrid, contingency_mrid]
                )
                for pst_mrid, contingency_mrid in model.curative_pst_contingency_pairs
            )
        )
    # RD penalty and price cost, gated on rd_volume_upward (absent for PST-only and for an
    # RD block that added nothing)
    if hasattr(model, "rd_volume_upward"):
        # RA-level penalty_factor and tso per bid (PowerBid.ra_mrid -> RDUnit.mrid); the
        # bid-level PowerBid.penalty_factor is a different field and not used
        ra_penalty_factor_and_tso: dict[str, tuple[float, str]] = {
            str(rd.mrid): (float(rd.penalty_factor), rd.tso) for rd in rd_inputs.rd_list
        }
        penalty_reference_rd_pra_per_tso = rd_inputs.penalty_reference_rd_pra_per_tso or {}

        bid_by_mrid_all_for_cost: dict[str, PowerBid] = {str(b.mrid): b for b in rd_inputs.bid_list}
        rd_cost_terms = []
        for bid_mrid in model.bid_ids:
            bid = bid_by_mrid_all_for_cost[bid_mrid]
            penalty_factor, bid_tso = ra_penalty_factor_and_tso.get(str(bid.ra_mrid), (None, None))
            if penalty_factor is None:
                log.warning(
                    "PowerBid %s references RA %s not found in rd_list — "
                    "penalty component of its RD cost term defaults to 0.0 "
                    "(price component is unaffected)",
                    bid_mrid, bid.ra_mrid,
                )
                penalty_factor, bid_tso = 0.0, ""

            effective_penalty_reference_rd_pra = float(
                penalty_reference_rd_pra_per_tso.get(bid_tso, rd_inputs.penalty_reference_rd_pra)
            )

            # cost = (penalty_factor * penalty_reference_rd_pra + price) * (up + down): each bid is
            # one-directional and the other direction is bounded to 0, so this equals the
            # separate up/down form with price_eur_mw as the bid direction's price
            rd_cost_terms.append(
                (penalty_factor * effective_penalty_reference_rd_pra + float(bid.price_eur_mw))
                * model.rd_cumulative_volume_term[bid_mrid]
            )

        if rd_cost_terms:
            objective_terms.append(sum(rd_cost_terms))

    # Curative RD reservation cost on the max-over-contingencies variables (worst-case
    # reservation, not a sum), same penalty/price formula as preventive RD, gated on
    # max_curative_rd_volume_upward. Priced at the bid's ENERGY price (price_eur_mw), not a
    # reservation price (none is parsed); for one-directional bids each bid pays its own
    # direction only.
    if hasattr(model, "max_curative_rd_volume_upward"):
        penalty_cost_per_mw_and_tso = get_effective_rd_penalty_cost_per_mw(
            rd_inputs.rd_list, rd_inputs.penalty_reference_rd_pra, rd_inputs.penalty_reference_rd_pra_per_tso,
        )
        bid_by_mrid_all = {str(bid.mrid): bid for bid in rd_inputs.bid_list}

        curative_rd_cost_terms = []
        for bid_mrid in model.bid_ids_curative:
            bid = bid_by_mrid_all[bid_mrid]
            penalty_cost_per_mw, _bid_tso = penalty_cost_per_mw_and_tso.get(str(bid.ra_mrid), (0.0, ""))
            curative_rd_cost_terms.append(
                (penalty_cost_per_mw + float(bid.price_eur_mw))
                * (model.max_curative_rd_volume_upward[bid_mrid] + model.max_curative_rd_volume_downward[bid_mrid])
            )

        if curative_rd_cost_terms:
            objective_terms.append(sum(curative_rd_cost_terms))

    # RA count slack penalties: ra_count_slack_per_timestamp exists only when soft and a TSO
    # has a limit; ra_count_slack_per_timeframe when a TSO has a timeframe limit
    if hasattr(model, "ra_count_slack_per_timestamp"):
        _append_named_term(
            "ra_count_timestamp",
            rd_inputs.ra_limit_penalty
            * sum(model.ra_count_slack_per_timestamp[tso] for tso in model.tsos_with_timestamp_ra_limit)
        )
    if hasattr(model, "ra_count_slack_per_timeframe"):
        _append_named_term(
            "ra_count_timeframe",
            rd_inputs.ra_limit_penalty
            * sum(model.ra_count_slack_per_timeframe[tso] for tso in model.tsos_with_timeframe_ra_limit)
        )

    # over secured_branch_ids (scanned branches are penalised separately below)
    _append_named_term(
        "overload_n0",
        penalty_cost_overload_n0
        * sum(model.overload_slack_n0[branch_mrid] for branch_mrid in secured_branch_ids)
    )

    # N-0 scanned slack penalty (soft mode): scanned_element_penalty_eur_per_ka is EUR/kA and
    # the slack is in A, hence / 1000
    if hasattr(model, "scanned_overload_slack"):
        _append_named_term(
            "overload_n0_scanned",
            scanned_element_penalty_eur_per_ka
            * sum(model.scanned_overload_slack[branch_mrid] / 1000.0 for branch_mrid in scanned_branch_ids)
        )

    # N-X PATL slack penalty, gated on nx_patl_overload_slack (an empty pair set sums to 0)
    if hasattr(model, "nx_patl_overload_slack"):
        _append_named_term(
            "overload_nx_patl",
            nx_inputs.penalty_cost_overload_nx_patl
            * sum(model.nx_patl_overload_slack[pair] for pair in model.nx_branch_contingency_pairs)
        )

    # N-X TATL slack penalty (its own rate, penalty_cost_overload_nx_tatl)
    if hasattr(model, "nx_tatl_overload_slack"):
        _append_named_term(
            "overload_nx_tatl",
            nx_inputs.penalty_cost_overload_nx_tatl
            * sum(model.nx_tatl_overload_slack[pair] for pair in model.nx_tatl_branch_contingency_pairs)
        )

    # N-X scanned slack penalty (its own rate, penalty_cost_overload_nx_scanned)
    if hasattr(model, "nx_scanned_overload_slack"):
        _append_named_term(
            "overload_nx_scanned",
            nx_inputs.penalty_cost_overload_nx_scanned
            * sum(model.nx_scanned_overload_slack[pair] for pair in model.nx_scanned_branch_contingency_pairs)
        )

    model.objective = pyo.Objective(expr=sum(objective_terms), sense=pyo.minimize)

    return model
