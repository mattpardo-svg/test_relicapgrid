"""output_file_registry.py

The single place that names the files the pipeline writes into its output folder:
OUTPUT_FILE_REGISTRY (every file name), RENAMED_OUTPUT_FILES (old name -> current name)
and delete_registered_output_files (removes stale files of earlier runs at start).
A test fails if a writer produces a file that is not registered here.
"""

from pathlib import Path
from typing import Iterable

# Every file name the pipeline can write into OUTPUT_DIR (current names).
OUTPUT_FILE_REGISTRY: list[str] = [
    "co_flat_list.csv",
    "glsk_resolved.csv",
    "lf_basecase.csv",
    "lf_nx_initial.csv",
    "lf_post_n0.csv",
    "pst_cra_availability.csv",
    "results_completeness_iterations.csv",
    "results_contingency_status.csv",
    "results_curative_pst.csv",
    "results_curative_pst_groups.csv",
    "results_curative_rd.csv",
    "results_generating_units.csv",
    "results_iteration_history.csv",
    "results_lead_times.csv",
    "results_nx_loadings.csv",
    "results_nx_scanned_elements.csv",
    "results_preventive_rd.csv",
    "results_preventive_rd_ra_count.csv",
    "results_preventive_rd_ra_groups.csv",
    "results_pst.csv",
    "results_summary.csv",
    "results_tso_tap_limits.csv",
    "run_log.txt",
    "scanned_element_list.csv",
    "sensitivity_pst_n0.csv",
    "sensitivity_pst_nx.csv",          # not written when outputs.write_nx_sensitivity_csvs is false
    "sensitivity_rd_n0.csv",
    "sensitivity_rd_nx.csv",           # not written when outputs.write_nx_sensitivity_csvs is false
    "tatl_data.csv",
]

# earlier file name -> current file name
RENAMED_OUTPUT_FILES: dict[str, str] = {
    "results_rd.csv": "results_preventive_rd.csv",
    "sensitivity_nx.csv": "sensitivity_pst_nx.csv",
    "results_ra_count.csv": "results_preventive_rd_ra_count.csv",
    "results_ra_groups.csv": "results_preventive_rd_ra_groups.csv",
}

# The log file is (re)opened by the pipeline itself before the cleanup runs.
LOG_FILE_NAME = "run_log.txt"


def delete_registered_output_files(output_dir: Path, keep: Iterable[str] = (LOG_FILE_NAME,)) -> list[str]:
    """Delete stale files of an earlier run: only regular files directly in output_dir whose
    name is registered (current or earlier name) and not in `keep` (the open log file).
    Returns the sorted deleted names; a missing folder is a no-op."""
    output_dir = Path(output_dir)
    if not output_dir.is_dir():
        return []
    deletable_names = (set(OUTPUT_FILE_REGISTRY) | set(RENAMED_OUTPUT_FILES)) - set(keep)
    deleted: list[str] = []
    for name in sorted(deletable_names):
        candidate = output_dir / name
        if candidate.is_file() and not candidate.is_symlink():
            candidate.unlink()
            deleted.append(name)
        elif candidate.is_symlink():
            candidate.unlink()
            deleted.append(name)
    return deleted
