# User Guide

A plain-language guide to running this pipeline and understanding its output. For decisions and assumptions behind the code, see `DECISIONS.md` and `ASSUMPTIONS.md` in this folder.

---

## What this pipeline does

Given a network model and a set of TSO-submitted remedial-action data, it decides how to move phase-shifting transformers (PSTs) and redispatch generation (RD) to resolve overloads — both under normal conditions and, optionally, under a list of contingencies (N-X security analysis) — at the lowest total penalty cost.

## Running it

```bash
python src/rao/run_pipeline.py
```

Reads its configuration from two required YAML files (below), reads the network and remedial-action data from `input/`, and writes every output file to `output/`.

### Input folder

`input/` (in the repo root) must contain exactly one CGM zip and exactly one NCP zip. A file counts as the CGM zip if its name starts with `cgm`, and as the NCP zip if it starts with `ncp` (upper or lower case, `.zip`), e.g. `cgm.zip` and `NCP_generic.zip`. Zero or several matches stop the run with a clear message. The zips are unpacked to `input/_extracted_cgm` and `input/_extracted_ncp`.

### Output folder

At the start of every run, files in `output/` whose names are registered output files (current or earlier names) are deleted, so results of an earlier run cannot be mistaken for this one. Other files in `output/` are left alone. The run log is written to `output/run_log.txt`.

---

## Configuration

Two files, both required — the pipeline will not start without them:

### `src/rao/config/rao_config.yaml`

Grouped into seven sections:

- **`workflow_toggles`** — whether PST is included, whether RD is included, whether contingency (N-X) analysis runs at all, and a few lower-level solve behaviors. At least one of PST or RD must be on, or there's nothing to optimize.
- **`thresholds`** — cutoffs for which branches get modeled at all, and how tightly the solver has to converge before it stops iterating.
- **`iteration_caps`** — how many times the two internal solve loops are allowed to repeat before giving up.
- **`ra_limits`** — optional per-TSO caps on how many remedial actions can be used at once.
- **`penalty_costs`** — the cost weights the solver uses to decide what's "worth" doing. None of these are finalized real-world values — every one is explicitly marked as a placeholder in the file itself.
- **`curative_ra`** — how a curative PST group is treated when one of its members is itself an outage element of a contingency (`blockedGroup` or `reducedGroup`, optionally per TSO).
- **`logging_options`** — `debug_log_mode`: how much INFO-level detail is logged. Warnings are never hidden.
- **`performance`** — `lf_thread_count` (threads of the N-X security and sensitivity analyses, default 1), `solver_time_limit_seconds` and `solver_mip_rel_gap` (HiGHS time limit per solve and MIP gap, default null = not set). A solve stopped at the time limit ends the run with the status `SOLVER_NON_OPTIMAL`.
- **`outputs`** — `write_nx_sensitivity_csvs` (default true): false skips `sensitivity_pst_nx.csv` and `sensitivity_rd_nx.csv`, which have one row per contingency, branch and remedial action.

A missing key stops the run with a `ConfigKeyError` that names the key and the file. Values are range-checked when the pipeline starts: the thresholds (`min_loading_threshold_pct*`, `sensitivity_threshold_pct_*`, `max_change_ra_sum_threshold`, `max_change_ra`, `max_change_overload`) must be numbers ≥ 0, and `max_linearisation_iterations`, `max_completeness_iterations` and `incremental_ac_fallback_max_steps` must be integers ≥ 1; otherwise the run stops with a message naming the key, the value and the file. A TSO named in `max_taps_per_tso_overrides` that is not a TSO of the run gets a warning, because the entry would be unused.

Every setting has its own explanatory comment directly in the file — that's the authoritative description of what each one does, not this guide.

### `src/rao/config/load_flow_config.yaml`

Physical solver settings passed to the underlying power-flow engine (voltage initialization, slack distribution, and similar). Most of these can be left at their defaults; the one worth knowing about specifically is `use_reactive_limits`, which is deliberately off by default — turning it on has been confirmed to cause widespread solve failures on this dataset.

### If something goes wrong after changing a setting

Both config files have a matching `.default.yaml` copy (`rao_config.default.yaml`, `load_flow_config.default.yaml`) that's never meant to be edited — a known-good baseline. If a change to the active file causes a failure or produces results that don't make sense, copy the `.default.yaml` over the active file to get back to a state that's been verified to work.

---

## Output files

Written to `output/`. Grouped by what they describe, not the order they're written in.

### Base-case (no contingency) results

| File | Contents |
|---|---|
| `lf_basecase.csv` | Every monitored branch's current and loading percentage before any remedial action |
| `results_pst.csv` | Per PST: original tap, cumulative change against the original network, final tap, and the cost of that cumulative change (only if PST is active); `last_solve_*` columns show what the final solve alone moved |
| `results_preventive_rd.csv` | Cumulative redispatch per bid against the original network and its cost (only if RD is active); `last_solve_rd_volume_net_mw` is the final solve's own change |
| `results_preventive_rd_ra_count.csv` | How many remedial actions were used per TSO, against any configured limits |
| `results_preventive_rd_ra_groups.csv` | Volume usage against any configured remedial-action group limits |
| `results_lead_times.csv` | Every bid's earliest-usable timestamp, based on its own lead time |
| `results_summary.csv` | Cost components that add up to the objective, the status of the verification loop, and `completeness_iteration_limit_reached` (True when the contingency-discovery loop stopped at `max_completeness_iterations` and new congestion may remain) |
| `results_tso_tap_limits.csv` | Per TSO with preventive PSTs: taps used against the `max_taps_per_tso` limit, taps remaining, and whether the limit is binding |
| `results_generating_units.csv` | Per generating unit: initial production, net redispatch volume, resulting production, and the redispatch cost and penalty (only if RD is active) |
| `lf_post_n0.csv` | Branch currents after remedial action, for every internal solve iteration |

### Contingency (N-X) results — only present if contingency analysis is enabled

| File | Contents |
|---|---|
| `lf_nx_initial.csv` | Every monitored branch's current under every contingency, before any remedial action |
| `results_nx_loadings.csv` | Same, after remedial action — the main N-X results file. The post-action loading is the actual AC result at the final applied state; the model's own linear prediction and the difference are in separate columns |
| `results_contingency_status.csv` | Which contingencies were usable, which were skipped and why (also those lost at a later N-X load-flow refresh, shown as "N-X refresh k: reason"), and whether each one ended up mattering to the final model |
| `results_curative_pst.csv` | Per curative PST and contingency: the curative tap change (up, down, net; not rounded), its bounds, whether the PST was available, and the penalty cost |
| `results_curative_pst_groups.csv` | Per curative PST group and contingency: the group's members and its common curative tap change |
| `results_curative_rd.csv` | Per curative redispatch bid and contingency: the curative volume, its maximum, the price and the cost |
| `results_nx_scanned_elements.csv` | Same idea as the main N-X loadings file, but for monitored-only (not fully enforced) branches |
| `results_iteration_history.csv` | One row per optimisation solve (outer completeness × inner linearisation iteration): objective, size of the change, the value of each convergence criterion (`overload_change_ampere` is the change of the element overloads in A, from the AC state), which criterion declared convergence (`converged_by`), the iteration a cyclic repetition matched, whether the solution was applied, how many contingencies the N-X load-flow refresh after the solve lost (`nx_contingencies_lost_at_refresh`), and the runtime of the solve, the load flows and the sensitivities. Status `CYCLIC_REPETITION` in the result files means the loop stopped because a solution repeated an earlier one |
| `results_completeness_iterations.csv` | How many times the contingency-discovery loop had to re-solve, and how much new congestion it found each time |
| `pst_cra_availability.csv` | (per PST, monitored branch `branch_mrid`, contingency) Which curative PSTs had enough reaction time to be usable under which contingency |
| `tatl_data.csv` | Temporary loading limits used for contingency checking, including any that had to be estimated because none was directly provided |

### Diagnostic and intermediate files

| File | Contents |
|---|---|
| `co_flat_list.csv` | Every contingency that was successfully parsed, before any usability filtering |
| `scanned_element_list.csv` | Every monitored-only branch and its computed limit |
| `glsk_resolved.csv` | How each redispatch remedial action's volume gets distributed across individual generating units |
| `sensitivity_pst_n0.csv`, `sensitivity_rd_n0.csv` | How much each branch's current changes per unit of PST movement or RD dispatch, base case |
| `sensitivity_pst_nx.csv`, `sensitivity_rd_nx.csv` | Same, per contingency |
| `run_log.txt` | The log of the run (warnings, per-iteration summaries, the stale files removed at the start) |

### How the run ended (status)

Every result file carries `ac_verification_status` and the raw termination reason:

| Status | Meaning |
|---|---|
| `CONVERGED` | A convergence criterion held; the last solution is applied. |
| `MAX_ITERATIONS_REACHED` | The iteration cap ended the loop; the last solution is applied. |
| `CYCLIC_REPETITION` | A solution repeated an earlier one; the best member of the cycle is applied. |
| `REVERTED_NON_CONVERGENT` | A load flow failed and nothing was applied in the run: the files show the original network (no change, blank objective). |
| `REVERTED_TO_LAST_CONVERGED_STATE` | A load flow failed later: the files show the last applied solution. |
| `SENSITIVITY_INVALID` | Invalid sensitivities with no earlier valid set: the files show the last applied solution. |
| `SOLVER_NON_OPTIMAL` | A MILP solve was infeasible or otherwise not optimal: the files show the last applied solution, or the original network when nothing was applied. |

The files never show a solution that was not applied to the network.

### A note on empty files

An output file that exists but contains only a header row is a genuine, checked result — "there was nothing to report here" — not a sign that something failed. A file that's missing entirely means that part of the pipeline never ran at all (usually because the relevant toggle is off). These are meant to be distinguishable at a glance.
