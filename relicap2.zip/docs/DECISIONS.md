# Decisions

One entry per decision: what, why. Newest at the bottom. Agents add an entry only after the decision is agreed.

## Scope and method
1. **Single timestamp only.** Multi-timestamp work is on a separate branch and out of scope.
2. **Nested loops.** Completeness is the outer loop, linearisation the inner loop. Each iteration applies the solution to the grid model first, then runs the convergence check (spec order).
3. **State.** The original operating point is frozen; the current one is updated. All baselines (taps, redispatch set-points, N-0 and N-X load flows, N-0 and N-X sensitivities) are refreshed every iteration.
4. **Cumulative MILP.** Each solve is built at the current operating point (current load flow, sensitivities, taps), with cumulative up/down variables whose offsets, per-TSO tap limits and bid headroom refer to the original state. Applied taps are integer-rounded. Curative actions are re-optimised in every solve and never applied to the grid model.
5. **RA count.** The RA-count binary is linked one-sidedly to the cumulative net volume, big-M is the bid's own availability.

## Convergence
6. **Criteria (OR):** (1) sum of |tap change| and sum of |MW change| below `max_change_ra_sum_threshold`; (3) max |tap change| and max |MW change| below `max_change_ra`; (4) sum of overload changes below `max_change_overload` (amperes, from AC currents; covers N-0 secured and scanned branches and N-X PATL/TATL pairs, not N-X scanned pairs). Criterion 4 is not evaluated if the N-X load flow refresh failed. Tap sum and MW sum use two parameters that the pipeline sets from the same config value. Max linearisation iterations is a hard limit.
7. **Cycle exit.** If a solution repeats an earlier one, the member with the lowest total AC overload is kept (ties: lowest cost, latest member). Status `CYCLIC_REPETITION`. The original state is not a candidate. The cycle check runs only when no criterion holds.
8. **Load-flow failure.** An incremental-apply fallback (`incremental_ac_fallback_max_steps`) is tried first. If it fails: at iteration 1 revert to the original state, later to the last converged state.
9. **Not built:** the spec's sum-of-RA-change criterion (eq. 3.35) as a separate criterion; taps and MW share one threshold.

## Load flow and sensitivities
10. **One set of load-flow parameters everywhere** (`build_loadflow_parameters`). Sensitivities previously used pypowsybl defaults and were inconsistent with the load flow.
11. **Contingency propagation is off everywhere.** With it on, the security analysis tripped extra equipment (through node-breaker topology) that the sensitivity analysis does not trip. Switching it off brought the model-versus-AC gap in the N-X final state from 1.98 pp to 0.002 pp on the mock case. Confirmed against a direct load flow (difference ≤ 4.3e-3) for a generator, two shunts and a load contingency. Not reproduced for a busbar contingency and six generic ones: see ASSUMPTIONS.
12. **Sensitivity guard.** Sensitivities are compared with the load flow at the same state (N-0 relative tolerance 1e-3, N-X 1e-2, floors 1 A). On failure the last valid set is reused; with no valid set the run ends with `SENSITIVITY_INVALID`.
13. **N-X sensitivity refresh has no warm start** (the N-0 refresh has, `PREVIOUS_VALUES`). Measured: no effect on the results (differences ≤ 1e-6 relative). Leave as is.

## Input data
14. **TATL.** If a secured branch has no TATL at all, TATL = PATL and TATL duration = 600 s (deliberate deviation from the spec, which says no TATL is considered). A branch with several TATLs gets no TATL (warning; as in the spec). A TATL below the PATL is raised to the PATL and keeps its own duration.
15. **Assessed element classification.** An assessed element is secured, scanned or excluded. Neither a secured nor a scanned region code, and no exclusion reason: excluded (reason "no secured or scanned region code"), logged, not optimised. Both codes and no exclusion reason: secured. Only a scanned code and no exclusion reason: **secured** (the Jotunheim data uses it this way; scanned would leave no secured branch). An invalid exclusion reason cancels the RAO (spec).
16. **Redispatch Pmax/Pmin default 0.0** when missing (the unit is then fixed). A warning names every such unit.
17. **PATL ≤ 0 or missing current:** the branch or pair is excluded with a warning, on the N-0 and the N-X side alike.
18. **PST with an empty tap range** is dropped from the model. Group equality pairs that name a dropped PST are dropped with a warning; the remaining members stay tied.
19. **Config.** The default file lists every key (documented defaults). A missing key raises `ConfigKeyError`. Range checks run at import (9 threshold keys ≥ 0, 3 iteration caps ≥ 1); tap-limit keys are validated separately.

## Model gaps (known, not built)
20. Bid activation cost (spec eq. 3.38) is parsed but not used in the model. Generating-unit start-up cost (eq. 3.39) does not exist in the code. Neither is in the objective.
21. Busbar contingency modelling is not settled.

## Stops, missing data, fixed parameters
22. **Result files describe only what was applied.** A stop without a new applied solution (load-flow failure, sensitivity guard, non-optimal solve) reports the last applied solution of the whole run. With nothing applied, PST and RD files show zero change from the original network, curative files show no activation, the summary objective is blank and the status keeps the reason. Why: a rejected solution must never look like a result.
23. **Non-optimal solve.** An infeasible or other non-optimal solve inside the loop ends the run with status `SOLVER_NON_OPTIMAL` and the last applied state, and all result files are written; `scanned_element_constraint_hard` stays `true`. Why: earlier applied work is not lost and the cause is visible.
24. **Cycle exit re-application.** If re-applying both the selected and the newest member fails, the newest member's set-points and voltage snapshot are restored and the loop ends with `REVERTED_TO_LAST_CONVERGED_STATE`. Why: the network must stay at a known converged state.
25. **Empty generator read-back.** An empty `target_p` read-back before a solution is applied stops the loop with the revert status, before anything is applied. Why: a failed load flow could not be reverted.
26. **Missing N-0 current** (missing `i1`/`i2`) is NaN with a warning, so decision 17's exclusion applies. **A NaN or unreadable N-0 sensitivity** excludes the branch from the N-0 constraints with a warning per branch (the N-X pair rule). Why: no silent 0.
27. **PST remedial action without `penaltyFactor`:** 1.0 with a warning (as for RD, which now also warns). Why: 0 made PST moves free.
28. **Bid price:** the price at the run's timestamp; a missing or negative price is 0 with a warning. Why: single-timestamp scope; another timestamp's price is not this run's price.
29. **N-X scanned limit** = max(PATL, original N-0 current), the same effective limit as on the N-0 side. Why: one limit per scanned branch, anchored to the original network.
30. **Fixed parameters, not in config** (`run_pipeline.py`): `START_HOUR` ("1030Z"), `N_TIMESTAMPS` (4), `RAART` (None), the per-TSO penalty overrides `PENALTY_REFERENCE_PST_PRA_PER_TSO` / `PENALTY_REFERENCE_RD_PRA_PER_TSO` (None) and `ACTIVATE_CRA_XNE_LINKAGE` (False). Why: not needed for the single-timestamp scope yet.

## Recorded from code comments
31. **Curative RD reservation priced at the energy price** (`price_eur_mw`), not at the reservation price of the spec (deviation from the spec). Why: no reservation price is parsed. For one-directional bids each bid pays its own direction only.
32. **`use_reactive_limits` defaults to false**, unlike the spec's `respectReactivePowerLimits=true`. Why: with reactive limits enforced most contingency load flows of the dataset do not converge (several generators need far more reactive power than their limits).
33. **PST group kind** (`blockedGroup` / `reducedGroup`) is not in the data: config `curative_ra.pst_group_kind_default` (`blockedGroup`) plus the per-TSO map `curative_ra.pst_group_kind_per_tso`. Why: the NCP profiles carry no group kind.
34. **PATL source order:** SHS `CurrentLimitTimePoint`, then the AE profile's `BaseCaseCurrentLimit.normalValue`, then the CGM static permanent limit, then 0 with a warning (decision 17 then excludes the branch). Falling back to the CGM value is logged. Why: the NCP is the priority source.
35. **TSO names** come from the Organisation profile (`Org-NineRealms_CD.xml`), not from the EQ `SubGeographicalRegion` (which gives 14 sub-regions instead of 7 TSOs on this dataset).
36. **Incremental AC fallback** (decision 8) needs `component_mode` `MAIN_SYNCHRONOUS`: small islands have no voltage to warm-start from.
37. **Not built / skipped:** corridor (`PowerTransferCorridor`) results; `lf_results_branches.csv` / `lf_results_buses.csv`; GLSK from `PowerShiftKeyStrategy` distributions (only the `PowerBidSchedule` chain is used); the CoMo equipment type "bus" (pypowsybl buses cannot be disconnected); PSTs on 3-winding transformers (left out of the sensitivities, logged); `RedispatchRemedialAction` / `CountertradeRemedialAction` (no generating-unit link; ignored with a warning). NCP files of profiles that are not parsed (SSI, CD_OR, ER, PS, RAS, FAP, cross-TSO CO exports) are skipped without a warning.

## Performance
38. **Performance config keys** (`rao_config.yaml`): `performance.lf_thread_count` (1), `performance.solver_time_limit_seconds` (null), `performance.solver_mip_rel_gap` (null), `outputs.write_nx_sensitivity_csvs` (true). The defaults keep the earlier behaviour: one thread and nothing passed, no time limit, the solver's default gap, both N-X sensitivity CSVs written. A solve stopped at the time limit ends the run as `SOLVER_NON_OPTIMAL` (decision 23). Values for large cases are set after the real-data run. Why: these settings decide run time on large networks and must not change results unless chosen.
39. **Equality rule for performance changes.** A performance change is kept only if objective, selected actions, taps, MW and all output files stay identical, shown by a test that compares the new logic with the old (kept in the test) or with stored values. Why: speed must not change results. The builder change that summed only non-zero N-X sensitivities was not kept: the model is identical, but the outputs differed in the last digits.
