# Changelog

Newest first. One short entry per task: date, what changed, tests, open items.

## 2026-10-12 — Coverage check and data-validation reference (docs only)
- `docs/Coverage_Checklist.md` filled from the code and tests: 72 rows (31 Built, 6 Partly, 6 Deviation, 29 Not built), section B (60 rows), section C (34 rows).
- New `docs/Data_Validation_Reference.md`: checks on inputs and intermediate data per area (12 areas) and 78 silent drops/defaults.
- No source or test change; suite not run.
- Open: Partly rows R0.8 (no SAR cross-check), R1.3 (operating tap limits not parsed), R2.8 (RA count covers preventive RD only), R3.5 (curative taps continuous), R3.7 (only per-contingency Pmax/Pmin); no test sets the per-timeframe RA-count limit.

## 2026-10-11 — Performance quick wins (results identical)
Fixture run (mock N-X case, wall time per phase as in docs/Scalability_Report.md), before -> after: total 16.0 s -> 10.5 s; generic fixture 12.5 s -> 7.9 s. Output files compared byte by byte against the run before the changes (iteration-history timing columns and log timing lines excluded).
- Q1: each EQ file is parsed once (`ncp_parser.load_eq_graph`; `build_current_limit_side_map` and `build_tap_changer_to_transformer_map` take an optional `graph`). RDF parsing 9.05 s -> 4.80 s. Tests: maps from one graph = maps from separate parses (every fixture EQ file); a run parses each EQ file once.
- Q2: `compute_lf_nx` reads the security analysis in one pass (`_index_branch_results`, first row per (contingency, branch) as before). 0.92 s -> 0.22 s. Tests: equal to the per-contingency selection on synthetic results (duplicate row, NaN, missing branch, own trip, non-convergent) and on an IEEE 14 security analysis.
- Q3: N-X sensitivities: one factor matrix per side for all contingencies (`ContingencyContextType.ALL`), numpy read-back (`_matrix_entries`, first value of a duplicate label, NaN kept). Works for TRANSFORMER_PHASE and BRANCH_CURRENT_2. 1.19 s -> 0.61 s. Tests: numpy read = per-cell `.loc` (duplicate row/column, NaN); ALL = per-contingency matrices on IEEE 14 (RD, both sides) and on the fixture network (PST).
- Q6: PST and RD N-X sensitivities from one analysis (`compute_sensitivities_nx`; the frozen `compute_sensitivity_pst_nx` / `compute_sensitivity_rd_nx` stay). 0.61 s -> 0.48 s. Tests: one analysis = two analyses (values, guard results, reference currents) on IEEE 14 with two added phase shifters and on the fixture network. The call-site test of `test_rao_lf_parameters.py` now checks the one combined call (two parametrized cases fewer).
- Q4 not kept: summing only non-zero N-X sensitivities gave the same model (fingerprint test) but outputs differing in the last digits (term order inside the rows); no gain on the dense fixture. The model fingerprint test (`tests/fixtures/milp_model_fingerprints.json`, PYTHONHASHSEED=0 subprocess) stays as a guard for builder changes.
- Q5, B4, B6: config keys `performance.lf_thread_count`, `performance.solver_time_limit_seconds`, `performance.solver_mip_rel_gap`, `outputs.write_nx_sensitivity_csvs` (defaults keep the earlier behaviour; range checks). Tests: the thread count reaches every security and sensitivity analysis of a run; a 1 µs limit ends the run as `SOLVER_NON_OPTIMAL`; a 1 ms limit on the synthetic model raises not-optimal; the CSVs are skipped when switched off and written by default.
- Found: run-to-run variation in the last digits (pypowsybl sensitivities, hash-seed-dependent summation order) that exists with the old code too: ASSUMPTIONS 16. 8 threads changed `lf_nx_initial.csv` in the last digits.
- Docs: DECISIONS 38-39, ASSUMPTIONS 15-16, README and User_Guide config keys.
- Suite: 947 passed, 0 failed (908 before; 41 tests added, 2 parametrized call-site cases merged into the combined one).

## 2026-10-11 — Last smoke-test references
- `tests/test_rao_frozen_imports.py`: `test_frozen_module_exposes_the_names_the_gui_and_smoke_scripts_import` renamed to `test_frozen_module_exposes_the_frozen_names`.
- `.github/copilot-instructions.md`: `smoke_tests/` removed from the never-change list.
- Suite: 908 passed, 0 skipped, 0 failed.

## 2026-10-11 — data/ and smoke_tests/ removed
- `data/` and `smoke_tests/` deleted from the repository. Suite before the doc edits: 908 passed, 0 skipped, 0 failed.
- Smoke-test comments removed: `tests/test_rao_frozen_imports.py` (module docstring, the `# smoke tests` group label, the comment about `extract_scanned_element_results`; the test and its frozen names unchanged), `docs/ASSUMPTIONS.md` item 8 (removed; later items keep their numbers), `docs/README.md` (smoke-test line and the smoke mention in the test layout).
- Suite after the edits: 908 passed, 0 skipped, 0 failed.

## 2026-10-11 — Tests and code no longer need data/
- `tests/helpers.py`: `fixture_instance_root()` builds an `Instance/`-shaped tree once per session in a temp folder from `tests/fixtures/NCP_generic.zip` (the NCP files of the ReliCapGrid instance) and `CGM_package.zip` (its EQ files); both hold the same content as `data/relicapgrid/Instance` apart from line endings. `build_fixture_input_folder()` builds the input/ folder `real_input_folder` used to build from `data/` (checked identical: same 18 NCP files, same CGM zip). Nothing added to `tests/fixtures`.
- The 41 tests that skipped without `data/` now run on the fixtures: `test_rao_ncp_parser.py` (23) and `test_rao_run_pipeline_end_to_end.py` (8) on `fixture_instance_root()`; `test_rao_ncp_loader.py` (6) on a small synthetic `Instance/` tree under `tmp_path` (the Organisation profile from `NCP_generic.zip`, placeholder profile files); `test_rao_ac_convergence_loop.py` (1) via `real_input_folder`; `test_rao_cgmes_loader.py` (3) gated on `tests/fixtures/CGM_package.zip`. No assertion changed, no test deleted. Unused `data/` skip markers removed from `test_rao_milp_builder_pst.py` / `_rd.py`.
- `cgmes_loader`: `get_cgm_files`, `CGM_ZIP` and `RELICAPGRID_ROOT` removed; `load_cgm(cgm_zip_override)` needs the zip path (no default source, `FileNotFoundError` when missing). `run_pipeline` error text for a missing input folder no longer mentions `data/relicapgrid`.
- Removed: `.gitmodules` (only the `data/relicapgrid` submodule), the `data/` lines of `.gitignore`, `data/relicapgrid` in `pytest.ini`, `requirements-gui.txt`, `.python-version`. Updated: `.github/copilot-instructions.md` (scope, test command, hard rule about real data in `input/`), `docs/README.md`, `docs/ASSUMPTIONS.md` item 8.
- Suite: 908 passed, 0 skipped, 0 failed; again with `data/` renamed: 908 passed, 0 skipped (`data/` restored).
## 2026-10-11 — Follow-up fixes, requirements merge, data/ check
- `tests/test_rao_nx_security_analysis.py`: the merged TATL test split again; the second half is `test_several_tatls_on_one_side_give_no_entry_and_no_patl_fallback` (it had lost its `def` and ran inside `test_no_per_branch_correction_log_only_summary`).
- Deleted `test_module_header_says_curative_taps_are_continuous` (it read a docstring); `n0_results_export` module docstring back to the short form.
- Requirement IDs and document references removed from code strings: argparse descriptions (`ncp_loader`, `scanned_elements`, `tso_name_resolver`), log texts (`ncp_parser` "cancelling the AE parse", `nx_security_analysis` "(exactly one expected)", `run_pipeline` "RA group volume limits (per TSO)"), the `build_n0_milp_model` ValueError text (still contains "nothing to optimise"), test assertion messages, and the comments in `rao_config.yaml` / `rao_config.default.yaml` (parsed values unchanged). Renamed tests: `test_group_upward_limit_caps_combined_dispatch`, `test_pst_only_scanned_constraint_has_only_pst_term`, `test_pruning_on_the_real_rd_sensitivity_shape`.
- `requirements.txt` now also holds the GUI packages (own section) and starts with `# Python 3.12.9`; `requirements-gui.txt` and `.python-version` kept. `docs/README.md` updated (install, tests without `data/`).
- Suite: 908 passed. With `data/` renamed: 867 passed, 41 skipped, 0 failed (`data/` restored, 361 files).
## 2026-10-11 — Comment clean-up (no behaviour change)
- `src/rao` (all 26 modules) and `tests/`: comments and docstrings describe the current code; history, requirement IDs, spec references, personal names and names of modules or test files that no longer exist removed; long blocks shortened. Comment lines: `src/rao` 5267 → 1720, `tests` 3163 → 2242. Checked by comparing the AST without docstrings against the original (identical for `src/rao`; for `tests` identical apart from the renames below). Two dead duplicate strings removed (a second module docstring in `cgmes_loader.py`, an attribute docstring rewritten in `nx_sensitivity.py` / `nx_security_analysis.py`).
- `ncp_parser.py`: the RD `penaltyFactor` comment said the PST default is 0.0; it is 1.0 (DECISIONS 27).
- `milp_builder.py`: the "Item B" wording removed; the curative RD energy-price deviation is DECISIONS 31.
- Test renames (history words): `TestPreFixBypassConfirmed` → `TestRdActiveRunUsesAcVerification`, `TestNoRegressionWhenNxDisabled` → `TestRdOnlyOutputWhenNxDisabled`, and 11 test functions (`..._now_...`, `..._new_...`, `..._regression_...`, `..._legacy_...`, `..._old_..._now_...`) renamed after what they check.
- Docs: DECISIONS 31–37, ASSUMPTIONS 11–14; "owner" wording removed from `docs/` and `.github/copilot-instructions.md`; comment rule added to `.github/copilot-instructions.md`.
- Suite: 907 passed, 1 failed (`test_module_header_says_curative_taps_are_continuous` reads the `n0_results_export` module docstring, which had lost the file name `results_curative_pst.csv`); docstring corrected, that test and its file (86) pass. Count 908 unchanged.

## 2026-10-11 — Fixes from the code review (A, B, C, E findings)
- Group 1 (crashes, wrong output): a stop in a later completeness iteration returns the last applied model of the run (A1); `remaining_overload_count` reads secured branches only (A2); with nothing applied the result files describe the original network, objective blank (A3, `describe_original_network`); a non-optimal solve ends the loop with the new status `SOLVER_NON_OPTIMAL` instead of raising, the solver loads solutions only after the termination check (A4); cycle exit restores the snapshot when both re-applications fail (A11); an empty generator read-back stops before applying (A13).
- Group 2 (no silent defaults): NaN Pmax/Pmin of a generator is 0.0 with a warning (A5); NaN/unreadable N-0 sensitivity excludes the branch (A6); a missing N-0 current is NaN (A7); PST and RD `penaltyFactor` default 1.0 with a warning (A8); bid price is the run timestamp's price, missing or negative = 0 with a warning (A9); `compute_lf_nx` catches lookup errors only (A14); `extract_equipment_dicts` logs failing accessors (A15); tap 0 kept in the non-DataFrame path (A17).
- Group 3 (clean code, no behaviour change): `select_result_models`/`ResultModels` removed with their 3 tests (B6, C1, C2); one pair builder for N-X PATL and scanned pairs (B4); one `_get_monitored_branch_sides` (in `milp_builder`, B5); the solver no longer writes CSV (B7, B8, B14); unused imports removed (B9, AST re-scan clean); dead variable and branch removed (B10, B11); named tolerances (B13); a real-solve test in `test_rao_milp_solver.py` (C4); unused test helpers left by the merges removed.
- Group 4: comments E1–E9 rewritten. Docs: DECISIONS 22–30, ASSUMPTIONS (bid price, `remaining_overload_count`, items 9–10), User_Guide status table.
- Suite: 908 passed (888 + 23 added − 3 deleted). Line endings of `src/rao` and `tests` normalised to LF.

## 2026-10-11 — Test merge, steps 7-9: registry, run_pipeline, source-text tests, final check
- Step 7: `test_rao_output_file_registry.py` (13 tests) absorbed the former rename tests; `test_rao_run_pipeline.py` (32, fast: config keys, range checks, selector, RD gate) and `test_rao_run_pipeline_end_to_end.py` (49, tests that run `main()`: integration, operating point of the loop, sensitivity guard in a full run, selection runtime test, curative-only RD, lf_nx baseline, summary identity, unknown TSO) replace 9 files. Tests named `t1`…`t7` renamed after what they check. Suite 892 after the step.
- Step 8: deleted `test_pipeline_builds_fallback_from_curative_psts_only`, `test_no_source_still_writes_the_old_branch_headers`, `test_main_has_no_dead_convergence_check_after_the_initial_load_flow`, `test_registry_has_29_names_and_no_sar_files` (source text or removed code). Replaced (count-neutral): the `inspect.getsource` tolerance test by `test_net_volume_at_the_edge_of_the_tolerance_decides_the_count`; the two "both config files carry…" tests by one parametrized `test_the_config_loader_returns_the_documented_defaults` (2 cases); `test_default_and_active_config_have_the_same_keys_and_values` now compares keys only. `test_rao_validation_fix_pass.py` is gone (empty). Suite: 888.
- Step 9: all 26 test files start with `test_rao_`; no test imports another test file; `tests/helpers.py` comments reworded; `docs/README.md` test layout and `.github/copilot-instructions.md` updated; `docs/Refactor_Inventory.md` deleted. A merge hazard found on the way: an autouse fixture applies to every test moved into its file (`fake_pyomo` in `test_rao_milp_solver.py`), and top-level `try:` blocks that define names must travel with the tests that use them.
- Suite: 888 (892 − 4 deleted).

## 2026-10-11 — Test merge, step 6: ac_convergence_loop, post_ra_congestion_check, milp_solver
- `test_rao_ac_convergence_loop.py` (66 tests) now holds the old file, `test_rao_convergence_check.py` and `test_rao_cycle_exit.py` (both deleted), the completeness outer-loop and `_count_nx_pairs` classes of the completeness file, the 2 N-0 refresh tests of the guard file and 3 state/history tests of the fix-pass file. New `test_rao_post_ra_congestion_check.py` (15 tests: extract/apply/restore and find-new-congested-pairs classes). `test_rao_operating_point_state.py` unchanged. The scanned-branch solve test of the fix-pass file went to `test_rao_milp_builder.py` (42 tests), not to `test_rao_milp_solver.py`, because that file's autouse `fake_pyomo` fixture replaces `pyomo.environ` and the test needs real Pyomo.
- Suite: 892 (unchanged).

## 2026-10-11 — Test merge, step 5: milp_builder in four files, cra_preprocessing
- `test_rao_milp_builder.py` (core, results, RA limits, scanned elements, N-0 zero-PATL and NaN-current tests), `test_rao_milp_builder_pst.py` (58: PST blocks, curative PST penalty, tap limit per TSO, PST kinds, empty tap range), `test_rao_milp_builder_rd.py` (47: RD blocks, availability, curative RD cost, lead time, curative-only RD scenario), `test_rao_milp_builder_nx.py` (23: N-X blocks plus the N-X pair tests of the fix-pass file). New `test_rao_cra_preprocessing.py` (48: curative PST groups, fallback tap bounds, PST tap bounds and group pairs, curative PST availability). The curative-bounds live-data class moved to `test_rao_ncp_parser.py` (64). Ten old files deleted.
- Suite: 892 (unchanged).

## 2026-10-11 — Test merge, step 4: nx_results_export, n0_results_export
- `test_rao_nx_results_export.py` (33 tests) now also holds the scanned-element results file tests (`test_rao_nx_scanned_elements_results.py`, deleted) and 3 tests from `test_rao_validation_fix_pass.py` (loading after RAO, contingency status reasons). New `test_rao_n0_results_export.py` (85 tests) takes `test_rao_ra_count_export.py`, `test_rao_curative_rd_results.py`, `test_rao_generating_units_results.py`, `test_rao_curative_pst_results_file.py`, `test_rao_pipeline_output_files.py` (all deleted, their mock-run tests keep using the session fixture), 6 summary tests from `test_rao_results_summary.py`, 2 lead-time tests from `test_rao_output_renames.py`, the 6 writer-status classes of `test_rao_ac_convergence_loop.py`, `TestCyclicRepetitionStatus` of `test_rao_convergence_check.py` (moved whole), the completeness-iterations writer test, and 3 tests from `test_rao_validation_fix_pass.py`. The non-converged initial load flow test moved to `test_rao_cgmes_loader.py`.
- Left for later steps: `test_identity_holds_on_the_mock_n_x_pipeline_run` (alone in `test_rao_results_summary.py`, runs `main()`).
- Suite: 892 (unchanged).

## 2026-10-11 — Test merge, step 3: n0_sensitivity, nx_security_analysis, nx_sensitivity
- `test_rao_sensitivity_n0.py` renamed `test_rao_n0_sensitivity.py`. `test_rao_nx_filters_and_scanned_elements.py` is dissolved: its monitored-sides test went to `test_rao_nx_security_analysis.py`, the two filter classes to `test_rao_nx_sensitivity.py`, the two model tests to `test_rao_milp_builder_nx.py`, the real-dataset scanned-AE test to `test_rao_ncp_parser.py`. From `test_rao_validation_fix_pass.py`: 2 NaN/tripped-branch tests to `test_rao_nx_security_analysis.py`, 2 Pmax/Pmin tests to `test_rao_ncp_parser.py` (43 tests left there).
- Suite: 892 (unchanged).

## 2026-10-11 — Test merge, step 2: sensitivity_checks, lf_parameters
- New `test_rao_sensitivity_checks.py` (37 tests: 17 guard-rule tests from `test_rao_sensitivity_guard.py`, all 17 of `test_rao_sensitivity_reuse.py`, 3 guard-tolerance tests from the propagation file) and `test_rao_lf_parameters.py` (24 tests: all of `test_rao_sensitivity_lf_parameters.py` and the 7 other propagation tests). `test_rao_sensitivity_reuse.py`, `test_rao_sensitivity_lf_parameters.py` and `test_rao_contingency_propagation.py` are deleted.
- `test_rao_sensitivity_guard.py` (27 tests) stays for now: 25 of its tests run `main()` (step 7) and 2 test the N-0 loop refresh (step 6).
- Suite: 892 (unchanged).

## 2026-10-11 — Test merge, step 1: ncp_parser, glsk_resolver
- `test_rao_ncp_ignored_power_ras.py` and the 3 assessed-element tests of `test_rao_validation_fix_pass.py` moved into `test_rao_ncp_parser.py` (59 tests); `test_rao_glsk.py` renamed `test_rao_glsk_resolver.py` (10 tests). `test_rao_cgmes_loader.py`, `test_rao_ncp_loader.py`, `test_rao_data_model.py` and `test_rao_scanned_elements.py` already mirror their module and are unchanged. Tests moved, not rewritten; sys.path set-up lines of merged files dropped (`conftest.py` and `helpers.py` set the path).
- Suite: 892 (unchanged).

## 2026-10-11 — Source cleanup, step 6: docs
- `docs/README.md` code layout updated: 26 modules in `src/rao` (28 before steps 4 and 5), `sensitivity_checks`, curative PST groups inside `cra_preprocessing`, `select_by_side` in `data_model`, 53 test files plus `conftest.py` and `helpers.py`. `docs/Refactor_Inventory.md` is kept until all steps are accepted.
- Suite: 892 (unchanged; docs only). Summary of steps 0-5: 884 → 901 (frozen-import tests) → 895 (dead code) → 892 (duplicate tests). Open: `.github/copilot-instructions.md` could mention `tests/helpers.py`; the smoke scripts have drifted (see ASSUMPTIONS item 8).

## 2026-10-11 — Source cleanup, step 5: merge M2
- `pre_milp/curative_pst_groups.py` merged into `pre_milp/cra_preprocessing.py` (its two existing public names are unchanged; the group code and its docstring, now a comment block, are appended). `run_pipeline` imports `validate_pst_group_kind` and `build_curative_pst_group_constraints` from there (3 call sites); `tests/helpers.py` and `test_rao_curative_pst_groups.py` import from the new path; `milp_builder` comment updated. The old module is removed.
- Suite: 892 (unchanged).

## 2026-10-11 — Source cleanup, step 4: merge M1
- `pre_milp/sensitivity_validation.py` and `pre_milp/sensitivity_reuse.py` merged into `pre_milp/sensitivity_checks.py` (guard first, reuse second; code unchanged, one combined docstring). Imports updated in `run_pipeline`, `ac_convergence_loop`, `n0_sensitivity`, `nx_sensitivity`, `test_rao_contingency_propagation` and `test_rao_sensitivity_guard`; comments in `operating_point_state`, `n0_sensitivity` and `nx_sensitivity` updated. Both old modules are removed.
- Suite: 892 (unchanged).

## 2026-10-11 — Source cleanup, step 3: duplicate helpers
- `nx_sensitivity` imports `_get_monitored_branch_sides_nx`, `_get_must_study_contingencies` and `_register_contingencies` from `nx_security_analysis` (copies deleted); `glsk_resolver` imports `_frag`, `_load_graph`, `_iso_to_hhmmz` from `ncp_parser` (copies deleted; the two `_iso_to_hhmmz` versions had the same regex and results). `n0_sensitivity._get_monitored_branch_sides` (with the loading-threshold filter) is renamed `_get_loading_filtered_branch_sides`, so it no longer shares a name with the unfiltered `milp_builder._get_monitored_branch_sides`. No behaviour change.
- Suite: 892 (unchanged).

## 2026-10-10 — Source cleanup, step 2: one `select_by_side`
- `data_model.select_by_side` replaces the five `_select_by_side` copies (`milp_builder`, `n0_sensitivity`, `nx_security_analysis`, `nx_sensitivity`, `nx_results_export`); `ac_convergence_loop`, `milp_solver`, `n0_results_export`, `post_ra_congestion_check` and a test import it from there instead of from `milp_builder`. It keeps the `nx_results_export` guard (empty or None dict → None). The 3 duplicate tests in `test_rao_nx_security_analysis.py` were deleted; the other set moved to `test_rao_data_model.py`. Removed the dead `if __name__ == "__main__":` block of `cgmes_loader.py` (it called `run_loadflow` and `build_branch_name_to_mrid`, which do not exist).
- Suite: 892 (895 − 3).

## 2026-10-10 — Source cleanup, step 1: dead code removed
- Deleted `cgmes_loader.pu_to_ka` and `select_by_side`, `pst_bounds._is_within_bounds`, `nx_security_analysis._get_limit_by_branch_nx`, `n0_results_export.write_lf_post_csv`, `post_ra_congestion_check.extract_pst_tap_solution`, the 6 tests that covered only them (3 for `select_by_side`, 3 for `extract_pst_tap_solution`), an unused `import math` and one unused test helper. Comments and docstrings that cited them were rewritten. No behaviour change.
- Suite: 895 (901 − 6).

## 2026-10-10 — Source cleanup, step 0: test helpers and frozen-import test
- New `tests/helpers.py` holds the builders that test files used to import from each other (`_make_ae`, `_make_pst`, `Scenario`, `_run_nested`, `run_pipeline_on_fixture_inputs` and the rest); all cross-test imports now go there; `conftest.py` keeps fixtures and imports the pipeline-run helper from it. New `tests/test_rao_frozen_imports.py` (17 tests) checks the modules and names the GUI and smoke scripts import, and the paths of `run_pipeline.py`, `data_model.py` and the config files. No source change.
- Suite: 901 (884 + 17). Open: `smoke_test_r2_1_rd_sensitivity.py` imports `extract_scanned_element_results`, which no longer exists.

## 2026-10-10 — README matched to the repo
- `docs/README.md`: Python 3.12.9, pandas 3.0.3, numpy 2.5.1, pinned `requirements.txt`, 52 test files, `src/rao_pages` in the code layout. New `requirements-gui.txt` (streamlit, plotly, pillow). BOM removed from `test_rao_validation_fix_pass.py`; document citations removed from `smoke_test_r3_nx_cra.py`. No behaviour change.

## 2026-10-10 — Docs in place and cleanup
- Created `reference/spec`, `reference/technical`, `reference/release_plan` (empty). Removed three tests that read documents; comments in `src` and `tests` no longer cite document files (rule stated in the comment). Corrected the PST-group pair comment in `milp_builder.py` (only pairs naming a dropped PST are dropped). No behaviour change.
- Suite: 884 passed, 0 skipped (the 41 dataset tests ran because `data/relicapgrid` is present). Open: README Environment section differs from `requirements.txt` and the venv (Python, pandas, numpy versions).

## 2026-10-10 — Repo restructuring (docs)
- Documents split: `docs/` (agents) and `reference/` (not for agents). Instructions in `.github/copilot-instructions.md`.

## 2026-10-10 — Validation fix pass
- AE with no region code and no exclusion reason: excluded. Scanned-only AE stays secured.
- PST with empty tap range dropped consistently; groups dropped with a warning.
- PATL ≤ 0 excluded on the N-X side; missing/NaN `lf_nx` currents and N-X NaN sensitivities skip the pair with a warning.
- Export curative effect uses the builder's own effect (same gating).
- Pmax/Pmin default warns; summary flag `completeness_iteration_limit_reached`; skipped-contingency reasons in `results_contingency_status.csv`; column `nx_contingencies_lost_at_refresh`.
- `solve_n0_milp_model` fixed for scanned branches; config range checks; sar module and registry entries removed (29 output names).
- Suite: 846 passed, 41 skipped. Open: NaN in N-0 sensitivities; no pipeline-level test for the skipped-reason merge.

## Before 2026-10-10 (summary)
- Loop redesign (state object, nested loops, cumulative MILP, convergence criteria, cycle exit), sensitivity load-flow parameter fix with guard, propagation off, results export and file registry, config completion with `ConfigKeyError`, dead code removed.
