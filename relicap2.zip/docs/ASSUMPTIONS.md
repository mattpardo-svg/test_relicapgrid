# Assumptions

What we assume about the data and the spec. Agents update this when they confirm or disprove an item.

## Data
- Dataset: CGMES ReliCapGrid "Jotunheim" (mock and generic variants for tests; the real dataset is not in the repository).
- Most assessed elements in the data carry only a scanned region code and no exclusion reason; they are treated as secured (see DECISIONS 15).
- Missing bid time point: available 0 MW, price 0. Bid direction defaults to UP unless the text says down. Bid volume is taken as absolute value.
- A missing PST or RD `available` means not available. A missing bid `leadTime` is 0 h. Missing curative PST timing attributes stay unset (warning) and availability is not computed. The bid's price is its price at the run's timestamp; a missing or negative price is 0 with a warning (DECISIONS 28).
- `remaining_overload_count` in `results_summary.csv` counts the MILP's own overload slack (linearised model), not AC overloads.

## Spec
- The functional specification is the source of truth for behaviour, except where DECISIONS says otherwise.
- No TATL at all: the spec says no TATL is considered; this project uses TATL = PATL with 600 s (DECISIONS 14). Several TATLs: no TATL, as in the spec.

## To verify on real data
Each item is open until a dated result is written under it.

1. **Contingencies lost at the N-X refresh.** A refreshed `lf_nx` that lost contingencies replaces the previous one, so the next MILP has no constraints for them. Look for the warning and the column `nx_contingencies_lost_at_refresh` in `results_iteration_history.csv`; reasons are in `results_contingency_status.csv`. Not seen on mock or generic data.
2. **TATL = PATL with 600 s** (branches with no TATL row). Count the branches affected and check the effect on curative results.
3. **Redispatch units with the Pmax/Pmin default.** Count them (search the log for the warning).
4. **Assessed elements without any region code.** They are excluded; confirm none was meant to be secured. Count those with reason "no secured or scanned region code".
5. **Busbar contingency e8e8300b** (propagation off): 86 branches differ from N-0 against 45 before. How busbar tripping should be modelled is not settled. Also the generic contingencies where the propagated state was not reproduced.
6. **Runtime of the N-X sensitivity refresh.** Worst case 10 iterations × 5 completeness solves.
7. **Integer versus fractional applied taps.** First-solve linearisation error can be large (up to 374 A in one preventive-only N-X case).
9. **Generators without limits.** What pypowsybl returns for a generator with no Pmax/Pmin in the CGM (NaN or a sentinel). NaN is treated as missing (0.0, warning); a sentinel would pass as a real limit.
10. **Load-flow convergence is read from component 0 only** (initial and post-RA load flows). Check that no other synchronous component in scope fails on real data.
11. **Virtual load margin.** `normalPositiveVirtualMargin` is not parsed: `virtual_load_margin_pct` is 0 (the spec default), so a scanned branch's effective limit is max(PATL, initial loading).
12. **CurrentLimit side.** `ACDCTerminal.sequenceNumber` 1 is taken as pypowsybl side ONE (i1) and 2 as TWO (i2); not cross-checked with a pypowsybl call.
13. **Curative tap range direction.** A `StaticPropertyRange` direction containing "up" is the upper bound, "down" the lower; "none" is skipped. The dataset has no curative PST range to confirm it.
14. **RA groups.** The RemedialAction-to-group predicates and the SIS time-point class (`RemedialActionGroupTimePoint`) are inferred; the dataset has no RA group content.
15. **Phase times on real data.** Measure wall time per phase (EQ parsing, N-X security analysis, N-X sensitivities, model build, translation, solve) on the real data and compare with `docs/Scalability_Report.md`; check the effect of `performance.lf_thread_count` > 1 on time and on results (on the fixture 8 threads changed `lf_nx_initial.csv` in the last digits).
16. **Run-to-run reproducibility.** pypowsybl sensitivity values can differ in the last digits between two runs of the same input (seen with one matrix per contingency and with one matrix for all contingencies), and the model coefficients depend in the last bits on Python's hash seed (set iteration order). Mostly the outputs are identical; sometimes a later solve differs at about 1e-10 relative. Check whether this matters for the real data.
