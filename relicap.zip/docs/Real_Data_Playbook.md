# Real-data playbook

For agents working on the machine that holds the real data. Follow it for any task that says "real data", "real run" or "performance". It is part of `docs/`; keep it short and up to date.

## 1. Rules
- Real data is confidential. Never copy it, or file names or element names from it, into `tests/`, `docs/`, comments, commit messages or logs that are committed. Use counts and aggregate numbers. Keep `input/` and `output/` out of version control.
- Do not change behaviour to make a real run "look better". A behaviour change needs the owner. Crashes get a minimal fix with a failing test first. Data problems and open questions are reported, not silently handled.
- Every default or dropped input must log a warning and be listed in `docs/ASSUMPTIONS.md`.
- Scope, commands and hard rules are in `.github/copilot-instructions.md`. Those win over this file.

## 2. Setup
1. Python 3.12.9; `pip install -r requirements.txt`.
2. `python -m pytest tests -q` must pass before you start. Write the pass count in the results file.
3. `input/` holds exactly one `cgm*.zip` and one `ncp*.zip`.

## 3. Baseline runs
1. Run `python src/rao/run_pipeline.py` twice with the default config. Copy `output/` of each run to a folder outside the repo (`../rao_runs/run1`, `run2`).
2. Compare run 1 and run 2. The same input can give last-digit differences (pypowsybl); this is the noise level. Equality below means: objective equal within 1e-9 relative, selected taps and MW equal within 1e-6, same termination status and iteration counts, every other number equal within 1e-9 relative, text equal.
3. Time every phase from `output/run_log.txt` and the total wall time. Record peak memory (process working set).

## 4. Results file
Create `docs/Real_Data_Results.md` (not committed if the repo is shared) with these sections. Put open questions for the owner at the top.
- A. Size: buses, branches, assessed elements by class (secured, scanned, excluded and why), contingencies (must-study, skipped and why), PSTs, RD units, bids, TSOs, N-X pairs in the model, MILP rows, columns and non-zeros.
- B. Run status: termination status, inner and outer iterations, objective, summary flags.
- C. Time and memory per phase and in total (two runs).
- D. Warnings in the log, counted by message type.
- E. The items under "To verify on real data" in `docs/ASSUMPTIONS.md`: for each, what you checked, the result (counts), and whether it is settled.
- F. Findings: crashes, wrong or odd results, data problems. For each: evidence, impact, proposed action (fix / report / ask owner).
- G. Performance: see section 5.

## 5. Performance
Do nothing if the total run is under 10 minutes and peak memory under 8 GB. Otherwise find the dominant phase (above 40 % of the time) and act as follows. Prove each change with an equality test (section 3 rule) on the test fixtures and on a real run; undo any change that fails it.

| Dominant phase | Action |
|---|---|
| N-X security analysis or N-X sensitivities | Try `performance.lf_thread_count` 4 and 8. Keep the value only if the equality rule holds; otherwise keep 1 and report. |
| Model build or Pyomo-to-HiGHS translation | (a) Build N-X rows from non-zero sensitivities only and index the curative (unit, contingency) pairs by contingency. (b) Skip N-X rows that can never bind: current + sum(abs(coefficient) x maximum movement of that RA) <= limit, using tap bounds, the per-TSO tap cap, bid availability and the curative bounds; keep such pairs in the monitoring and export sets and in the completeness check. Both are exact changes. |
| Solve | Record solve times per iteration. If one solve exceeds 5 minutes, report it with the model size and recommend `performance.solver_time_limit_seconds` and `performance.solver_mip_rel_gap` values. Do not set them; a limit changes results and the owner decides. |
| Memory | Keep only the results (rows, values) of earlier loop members for the cycle exit, instead of whole models. Behaviour of the cycle exit must stay the same. |
| Output size | Set `outputs.write_nx_sensitivity_csvs` to false if the two N-X sensitivity CSVs are very large, and say so in the results file. |

Not allowed without the owner: positive pruning or loading thresholds, a solver limit or gap, lazy constraint schemes, changing defaults in config.

## 6. Finish
`docs/Real_Data_Results.md` is complete; the tests pass; `docs/CHANGELOG.md`, `docs/DECISIONS.md` and `docs/ASSUMPTIONS.md` are updated for anything you changed; the open questions for the owner are listed at the top of the results file.
